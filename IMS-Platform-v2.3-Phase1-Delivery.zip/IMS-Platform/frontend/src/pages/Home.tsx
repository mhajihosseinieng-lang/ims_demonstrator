// The public entry route is defined in App.tsx and redirects to the IMS Explorer.
// This unused legacy splash is retained only as a neutral fallback component.
export default function Home() {
  return <main className="flex min-h-svh items-center justify-center">IMS Platform</main>;
}
