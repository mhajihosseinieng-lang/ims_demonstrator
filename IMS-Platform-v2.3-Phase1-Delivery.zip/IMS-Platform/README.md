# IMS Platform

A control-theory research platform for Intrinsic Manifold Stability (IMS)
analysis and automatic Manifold-Restoring Control (MRC) synthesis on
power-electronic networks (Buck / Boost / Buck-Boost converters, constant-power
and impedance loads, multi-converter networks) -- built around the Network
Builder, an automatic MRC derivation pipeline (including bus-voltage-anchored
manifold reshaping for tangentially-unstable cases), closed-loop
before/after verification, and HTML/PDF reporting.

## Quickstart (clean machine)

Requires Python 3.10+ and Node.js 18+ (both on `PATH`). No other manual setup
-- MongoDB is not required.

```bash
git clone <repo-url>
cd IMS-Platform
./run_ims_demo.sh
```

Then open **http://127.0.0.1:3000/explorer.html**.

The script creates an isolated Python virtual environment, installs backend
and frontend dependencies (skipped automatically on later runs unless
`backend/requirements.txt` changes), starts the backend (FastAPI, port 8001)
and frontend (Vite dev server, port 3000), verifies both actually came up,
and prints the URL to open. Stop with `Ctrl+C`.

```bash
BACKEND_PORT=8002 FRONTEND_PORT=3001 ./run_ims_demo.sh   # use different ports
```

## What's in the box

```
IMS-Platform/
  backend/
    ims_platform/        The IMS Platform itself: network model, IMS analysis,
                          auto-MRC synthesis (mrc_designer/auto_manifold.py),
                          the Flask app + explorer.html UI (server/)
    routers/              FastAPI routes: /api/four_state, /api/analysis,
                          /api/mrc_designer (mounted alongside the legacy
                          Flask app, which is mounted at / as the primary UI)
    lib/db.py             Shared MongoDB handle (see "About MongoDB" below)
    ims_tests/             pytest suite -- run with:
                          PYTHONPATH=. python -m pytest ims_tests/ -o addopts="" -q
    requirements.txt      Core runtime dependencies (audited: only what's
                          actually imported by the code above)
    requirements-optional.txt   Unused legacy-scaffold dependencies (auth/
                          cloud SDKs, dev/lint tools) -- not needed to run
                          or test the IMS Platform
  frontend/               Vite + React 19 + TypeScript. Serves the "Analysis
                          Hub" / "Stabilising MRC" (/mrc) surfaces and proxies
                          /api, /explorer.html, /assets to the backend.
  run_ims_demo.sh         One-command launcher (see Quickstart)
```

## About MongoDB

No IMS/MRC functionality touches a database -- the Network Builder, MRC
design/inspection, M1/M2 manifold reshaping, closed-loop verification, and
HTML/PDF report generation are all pure computation served by the Flask app
mounted at `/`. Only one unrelated legacy demo endpoint
(`/api/status`, from the original project scaffold) uses MongoDB.

`run_ims_demo.sh` writes a placeholder `backend/.env` pointing at
`mongodb://localhost:27017` if you don't already have one. The Motor client
connects lazily with a short timeout; if no MongoDB is running, you'll see a
single informational log line (`MongoDB not reachable ... skipping
status_checks indexing`), never a crash or a connection-refused error
blocking startup. If you already run your own MongoDB and want `/api/status`
to work too, drop your own `backend/.env` (`MONGO_URL`, `DB_NAME`,
`CORS_ORIGINS`) before running the script and it will be left untouched.

## PDF report export

Report PDF export (`/api/report/<case_id>/pdf`) uses `pdfkit` +
`wkhtmltopdf`. A working `wkhtmltopdf` binary for Linux x86-64 is bundled at
`backend/ims_platform/server/bin/wkhtmltopdf` and is preferred automatically;
if it doesn't run on your machine (different OS/architecture), pdfkit falls
back to any `wkhtmltopdf` on `PATH`. `run_ims_demo.sh` reports which one it
found. HTML reports and every other feature work regardless of PDF export.

## Running the test suite directly

```bash
cd backend
source .venv_demo/bin/activate   # created by run_ims_demo.sh
PYTHONPATH=. python -m pytest ims_tests/ -o addopts="" -q
```

Expected: **414 passed, 0 failed, 0 skipped**. Also:

```bash
node backend/ims_tests/test_explorer_report_content.js
```

Expected: **ALL PASSED**.

## Extending the FastAPI/MongoDB scaffold

`backend/server.py` (FastAPI, port 8001) and `backend/lib/db.py` originate
from a generic project-generator template unrelated to the IMS Platform --
kept because the IMS Platform's Flask app is mounted inside it (see
`server.py`'s `WSGIMiddleware` block) and the frontend proxies through it.
If you build new features that need the extra scaffold dependencies (JWT
auth, cloud SDKs, etc.), install `backend/requirements-optional.txt`; none
of it is required to run or test the IMS Platform itself.

## Interface and architecture

The Explorer interface is served from `backend/ims_platform/server/static/explorer.html`
using an external stylesheet (`assets/css/explorer.css`) and five ordered, independently
maintainable JS files (`assets/js/`). See `ARCHITECTURE.md` for responsibilities,
navigation principles, testing and scientific workflow sequencing.

The six-stage workflow is **Model → Equilibrium → Baseline Simulation → IMS
Analysis → MRC Design & Verification (optional) → Report**. Downstream results are
invalidated whenever an upstream stage is rerun. Hero graphics are conceptual;
quantitative charts use backend-generated data without aesthetic interpolation.
