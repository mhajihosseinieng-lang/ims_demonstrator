# IMS Platform v2.1 — Hero diagram correction

The hero is an **illustrative 2D state-space schematic**, not a simulated converter trajectory.
Its purpose is to distinguish (i) the invariant manifold, (ii) a disturbed state, (iii) a
transverse deviation, and (iv) the equilibrium target without implying numerical evidence.

## Geometry

With normalized path parameter `s` in `[0,1]`, diagram coordinates use:

```
a(s) = 1-s
x(s) = 540 - 420 a(s)^2
h(x) = 235 - 24 sin(pi (x-120)/420) - 19(x-120)/420
e_m(s) = -145 a(s)^4
y(s) = h(x(s)) + e_m(s)
```

Thus `e_m(0)=-145`, `e_m(1)=0`, and `d|e_m|/ds <= 0`; the state trajectory ends at
`(540,216)` on the manifold. The coordinates are purely illustrative (screen pixels,
not physical voltage/current values). `e_m` is the displayed vertical coordinate
residual; it must not be interpreted as a numerically computed IMS residual.

The path is rendered as piecewise cubic Hermite/Bézier segments using derivatives
computed from the analytic curve. At each segment joint, the incoming and outgoing
first derivatives agree. The SVG renders one uninterrupted recovery path, a separate
manifold centreline, and two labelled endpoints. Labels stay within its viewBox.

## Scope of changes

- `backend/ims_platform/server/static/explorer.html`: replaced only the conceptual hero SVG.
- `backend/ims_platform/server/static/assets/css/explorer.css`: refined chart styles.
- `backend/ims_tests/test_explorer_architecture.js`: ensures tangent continuity, exact endpoint alignment, and existence of the independently drawn manifold.

The computation engine and remaining application workflow are unchanged from v2.

## Verification

- Six `backend/ims_tests/test_*.js` suites pass.
- Browser interactions pass at 1600px, 390px, and 320px widths; image layouts also rendered at 1366px and 850px.
- SVG label bounds checked against the viewBox at 1600, 850, 390, and 320px widths.
- To replace an older running app, stop it, extract this zip afresh, restart the server and perform a hard refresh (Ctrl+Shift+R). Older screenshots or browser tabs can show a previous hero design.
