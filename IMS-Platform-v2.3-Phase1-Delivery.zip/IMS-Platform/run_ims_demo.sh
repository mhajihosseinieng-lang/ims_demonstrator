#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# run_ims_demo.sh
#
# ONE-COMMAND launcher for the full IMS Platform stack, from a clean
# checkout on a supported machine (Linux/macOS with python3 + node/npm):
#
#   git clone <repo-url>
#   cd IMS-Book_Version
#   ./run_ims_demo.sh
#
# It creates an isolated Python venv, installs backend + frontend
# dependencies (only on first run / when requirements change), starts:
#   - backend/server.py  (FastAPI, port 8001) -- mounts the legacy Flask
#     explorer.html app at "/", plus /api/analysis/*, /api/mrc_designer/*,
#     /api/four_state/*, /api/network_mrc/* (the auto-MRC routes), etc.
#   - frontend/          (Vite + React, port 3000) -- proxies /api/*,
#     /explorer.html and /assets to the backend, and serves the native React
#     routes (e.g. /mrc, used by the "Stabilising MRC" analysis surface).
# then verifies both actually came up before printing the URL to open.
#
# The two pieces are split on purpose (see frontend/vite.config.ts's proxy
# block and the repo README): explorer.html's "Analysis Hub" and
# "Stabilising MRC" nav items only work when BOTH are running and you view
# the app through the Vite dev server (port 3000), not the backend alone.
#
# MongoDB is NOT required: no IMS/MRC route touches a database (see
# backend/lib/db.py). A placeholder backend/.env is generated if one isn't
# already present so the process boots even with no MongoDB running at all
# -- this is the expected, fully-supported case for this workflow.
#
# Usage:
#   ./run_ims_demo.sh              # backend on :8001, frontend on :3000
#   BACKEND_PORT=8002 FRONTEND_PORT=3001 ./run_ims_demo.sh
#
# Then open:  http://127.0.0.1:${FRONTEND_PORT:-3000}/explorer.html
# (In Codespaces, open the forwarded URL for the frontend port with
#  /explorer.html appended -- Codespaces will prompt to make it public/private
#  the first time a port is forwarded.)
#
# Stop with Ctrl+C (stops both processes).
# ---------------------------------------------------------------------------
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$SCRIPT_DIR/backend"
FRONTEND_DIR="$SCRIPT_DIR/frontend"
VENV_DIR="$BACKEND_DIR/.venv_demo"
BACKEND_PORT="${BACKEND_PORT:-8001}"
FRONTEND_PORT="${FRONTEND_PORT:-3000}"

fail() { echo "error: $*" >&2; exit 1; }

# ---------------------------------------------------------------------------
# Prerequisite detection -- fail fast with an actionable message rather than
# a confusing failure three steps later.
# ---------------------------------------------------------------------------
[ -d "$BACKEND_DIR/ims_platform" ] || fail "expected $BACKEND_DIR/ims_platform to exist. Run this script from the repo root."

PYTHON_BIN="${PYTHON_BIN:-python3}"
command -v "$PYTHON_BIN" >/dev/null 2>&1 || fail "python3 not found on PATH. Install Python 3.10+ and re-run."
PY_VERSION="$("$PYTHON_BIN" -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')"
case "$PY_VERSION" in
  3.9|3.8|3.7|3.6|3.5|2.*) fail "Python $PY_VERSION found, but 3.10+ is required." ;;
esac

if [ -d "$FRONTEND_DIR" ]; then
  command -v node >/dev/null 2>&1 || fail "node not found on PATH, but $FRONTEND_DIR exists. Install Node.js 18+ (https://nodejs.org) and re-run, or remove/ignore the frontend directory to run backend-only."
  command -v npm >/dev/null 2>&1 || fail "npm not found on PATH. Install Node.js 18+ (it bundles npm) and re-run."
fi

port_in_use() {
  "$PYTHON_BIN" - "$1" <<'PYEOF'
import socket, sys
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.settimeout(0.3)
try:
    sys.exit(0 if s.connect_ex(("127.0.0.1", int(sys.argv[1]))) == 0 else 1)
finally:
    s.close()
PYEOF
}
if port_in_use "$BACKEND_PORT"; then
  fail "port $BACKEND_PORT is already in use. Stop whatever is using it, or run: BACKEND_PORT=8002 ./run_ims_demo.sh"
fi
if [ -d "$FRONTEND_DIR" ] && port_in_use "$FRONTEND_PORT"; then
  fail "port $FRONTEND_PORT is already in use. Stop whatever is using it, or run: FRONTEND_PORT=3001 ./run_ims_demo.sh"
fi

# ---------------------------------------------------------------------------
# Backend: venv + deps
# ---------------------------------------------------------------------------
if [ ! -d "$VENV_DIR" ]; then
  echo "==> Creating backend virtual environment at $VENV_DIR"
  "$PYTHON_BIN" -m venv "$VENV_DIR" || fail "failed to create the virtual environment (is the 'venv' module available? on Debian/Ubuntu: apt install python3-venv)"
fi
# shellcheck disable=SC1091
source "$VENV_DIR/bin/activate"

# Skip reinstalling every launch: only run pip install when requirements.txt
# has actually changed since the last successful install (hashed marker file
# inside the venv, so a fresh venv always installs once).
REQ_FILE="$BACKEND_DIR/requirements.txt"
REQ_HASH_FILE="$VENV_DIR/.requirements.sha256"
NEW_HASH="$( [ -f "$REQ_FILE" ] && "$PYTHON_BIN" - "$REQ_FILE" <<'PYEOF'
import hashlib, sys
print(hashlib.sha256(open(sys.argv[1], "rb").read()).hexdigest())
PYEOF
)"
OLD_HASH="$(cat "$REQ_HASH_FILE" 2>/dev/null || true)"

if [ -z "$REQ_FILE" ] || [ ! -f "$REQ_FILE" ]; then
  fail "$REQ_FILE not found."
elif [ "$NEW_HASH" = "$OLD_HASH" ]; then
  echo "==> Backend dependencies already installed and up to date (skipping reinstall)"
else
  echo "==> Installing backend dependencies (first run, or requirements.txt changed -- can take a minute)"
  pip install --quiet --upgrade pip
  if pip install --quiet -r "$REQ_FILE"; then
    echo "$NEW_HASH" > "$REQ_HASH_FILE"
  else
    fail "backend dependency install failed. See the pip output above for the specific package; requirements.txt is audited to contain only packages this platform actually imports, so a failure here is almost always a network/proxy issue rather than a missing/unpublished package."
  fi
fi

# backend/.env is gitignored and required at import time (MONGO_URL / DB_NAME).
# If you already have a real MongoDB configured, drop your own backend/.env
# before running this script and it will be left untouched. Otherwise this
# generates a harmless placeholder: Motor connects lazily with a short
# timeout (see backend/lib/db.py) and degrades gracefully with a single INFO
# log line, so the app boots and every route exercised by the Explorer,
# Network Builder, MRC design (M1/M2 reshaping), closed-loop verification,
# and report/PDF generation -- none of which touch Mongo -- works fine.
if [ ! -f "$BACKEND_DIR/.env" ]; then
  echo "==> No backend/.env found -- writing a placeholder Mongo config (safe: nothing in this workflow touches the DB)"
  cat > "$BACKEND_DIR/.env" <<EOF
MONGO_URL=mongodb://localhost:27017
DB_NAME=ims_demo
CORS_ORIGINS=*
EOF
fi

# ---------------------------------------------------------------------------
# wkhtmltopdf: confirm the bundled binary actually runs on this machine
# (report/PDF export uses it -- see ims_platform/server/report_generator.py).
# Non-fatal: HTML reports and everything else work regardless; only the PDF
# export button would be affected, and pdfkit falls back to any wkhtmltopdf
# on PATH if the bundled one doesn't run.
# ---------------------------------------------------------------------------
WKHTMLTOPDF_BIN="$BACKEND_DIR/ims_platform/server/bin/wkhtmltopdf"
if [ -x "$WKHTMLTOPDF_BIN" ] && "$WKHTMLTOPDF_BIN" --version >/dev/null 2>&1; then
  echo "==> Bundled wkhtmltopdf OK ($("$WKHTMLTOPDF_BIN" --version 2>&1 | head -1))"
elif command -v wkhtmltopdf >/dev/null 2>&1; then
  echo "==> Bundled wkhtmltopdf did not run on this machine; using wkhtmltopdf on PATH instead ($(command -v wkhtmltopdf))"
else
  echo "warning: wkhtmltopdf (bundled binary or on PATH) did not run. PDF report export will fail with a clear error; HTML reports and every other feature are unaffected. To fix: install wkhtmltopdf for your OS (https://wkhtmltopdf.org/downloads.html)." >&2
fi

# ---------------------------------------------------------------------------
# Frontend: npm deps (same skip-if-unchanged idempotency as the backend, via
# npm's own package-lock.json-based node_modules check)
# ---------------------------------------------------------------------------
if [ -d "$FRONTEND_DIR" ]; then
  if [ ! -d "$FRONTEND_DIR/node_modules" ]; then
    echo "==> Installing frontend dependencies (first run only, can take a couple of minutes)"
    # --legacy-peer-deps: this dependency graph trips a known npm/arborist
    # crash ("Cannot read properties of null (reading 'edgesOut')") under
    # strict peer-dep resolution on newer npm; legacy resolution avoids it.
    ( cd "$FRONTEND_DIR" && npm install --legacy-peer-deps ) || fail "frontend 'npm install' failed. See the npm output above."
  else
    echo "==> Frontend dependencies already installed (skipping reinstall)"
  fi
else
  echo "warning: $FRONTEND_DIR not found -- Analysis Hub / Stabilising MRC (/mrc) will 404 without it." >&2
fi

# ---------------------------------------------------------------------------
# Launch both, tear down together on Ctrl+C / exit
# ---------------------------------------------------------------------------
PIDS=()
cleanup() {
  echo ""
  echo "==> Stopping..."
  for pid in "${PIDS[@]:-}"; do
    kill "$pid" >/dev/null 2>&1 || true
  done
}
trap cleanup EXIT INT TERM

cd "$BACKEND_DIR"
echo "==> Starting backend (FastAPI + legacy Flask app mounted at /) on :$BACKEND_PORT"
"$PYTHON_BIN" -m uvicorn server:app --host 0.0.0.0 --port "$BACKEND_PORT" > "$SCRIPT_DIR/backend.demo.log" 2>&1 &
PIDS+=($!)

if [ -d "$FRONTEND_DIR" ]; then
  cd "$FRONTEND_DIR"
  echo "==> Starting frontend (Vite dev server, proxies /api + /explorer.html + /assets to :$BACKEND_PORT) on :$FRONTEND_PORT"
  VITE_PORT="$FRONTEND_PORT" npx vite --port "$FRONTEND_PORT" --host > "$SCRIPT_DIR/frontend.demo.log" 2>&1 &
  PIDS+=($!)
fi

# ---------------------------------------------------------------------------
# Health check: actually verify each process came up and is answering
# requests, instead of a blind sleep + unconditional success message.
# ---------------------------------------------------------------------------
wait_for_http() {
  local url="$1" label="$2" pid="$3" deadline=$((SECONDS + 30))
  while [ $SECONDS -lt $deadline ]; do
    if ! kill -0 "$pid" 2>/dev/null; then
      return 1  # process died -- caller reports the log
    fi
    if "$PYTHON_BIN" - "$url" <<'PYEOF' >/dev/null 2>&1
import sys, urllib.request
urllib.request.urlopen(sys.argv[1], timeout=1)
PYEOF
    then
      return 0
    fi
    sleep 0.5
  done
  return 1
}

BACKEND_OK=0
if wait_for_http "http://127.0.0.1:${BACKEND_PORT}/" "backend" "${PIDS[0]}"; then
  BACKEND_OK=1
else
  echo "error: backend did not respond on :$BACKEND_PORT within 30s. Last 30 lines of $SCRIPT_DIR/backend.demo.log:" >&2
  tail -30 "$SCRIPT_DIR/backend.demo.log" >&2 || true
fi

FRONTEND_OK=1
if [ -d "$FRONTEND_DIR" ]; then
  FRONTEND_OK=0
  if wait_for_http "http://127.0.0.1:${FRONTEND_PORT}/" "frontend" "${PIDS[1]}"; then
    FRONTEND_OK=1
  else
    echo "error: frontend did not respond on :$FRONTEND_PORT within 30s. Last 30 lines of $SCRIPT_DIR/frontend.demo.log:" >&2
    tail -30 "$SCRIPT_DIR/frontend.demo.log" >&2 || true
  fi
fi

if [ "$BACKEND_OK" -ne 1 ] || [ "$FRONTEND_OK" -ne 1 ]; then
  echo "" >&2
  echo "==> Startup failed. See the log excerpt(s) above for the specific error." >&2
  exit 1
fi

cat <<EOF

==================================================================
 IMS Platform Explorer -- local demo stack (running)
 Open this in your browser:   http://127.0.0.1:${FRONTEND_PORT}/explorer.html
 (backend alone, no Analysis Hub / Stabilising MRC: http://127.0.0.1:${BACKEND_PORT}/)
 Logs:  $SCRIPT_DIR/backend.demo.log , $SCRIPT_DIR/frontend.demo.log
 Stop with:                   Ctrl+C
==================================================================

EOF

wait
