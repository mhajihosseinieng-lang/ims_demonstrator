// IMS Platform / services.js — ordered classic script; public stage API stays stable.
/* ===================== DOCUMENTATION ===================== */

function openDocs(sectionId) {
  $("docModalBody").innerHTML =
    "<div class='doc-toc'>" +
    "<a href='#doc-overview'>Overview</a><a href='#doc-pipeline'>Analysis pipeline</a>" +
    "<a href='#doc-builder'>Building a custom network</a><a href='#doc-controllers'>Controllers</a>" +
    "<a href='#doc-ims'>IMS concepts</a><a href='#doc-reports'>Reports</a><a href='#doc-limits'>Current limitations</a>" +
    "</div>" +
    "<h3 id='doc-overview'>Overview</h3>" +
    "<p>IMS Platform Explorer runs converter and network models through a real Python backend " +
    "(equilibrium solving, time-domain simulation, and Intrinsic Manifold Stability analysis) -- " +
    "figures and numbers in this app come from that engine, not a browser-side approximation.</p>" +
    "<h3 id='doc-pipeline'>Analysis pipeline</h3>" +
    "<p>Every project follows these six stages, in order:</p>" +
    "<ol>" +
    "<li><b>Build Model</b> -- assembles the network from its components and parameters.</li>" +
    "<li><b>Solve Equilibrium</b> -- finds the steady-state operating point and checks small-signal stability via the Jacobian's eigenvalues.</li>" +
    "<li><b>Baseline Simulation</b> -- applies a disturbance to the equilibrium and simulates the resulting trajectory.</li>" +
    "<li><b>IMS Analysis</b> -- traces the intrinsic manifold, computes the manifold residual, and assesses recoverability (deterministically from the trajectory, and optionally via Monte-Carlo sampling with a traced boundary).</li>" +
    "<li><b>Design &amp; Verify MRC (optional)</b> -- checks feasibility, synthesises supported manifold-reshaping controllers, and verifies closed-loop performance where supported.</li>" +
    "<li><b>Review &amp; Export Report</b> -- compiles the analysis results into a report, exportable as HTML or via browser PDF printing. This stage remains available if MRC synthesis is unsupported.</li>" +
    "</ol>" +
    "<p>Click any completed stage in the left sidebar to review its results -- nothing is re-run until you press its own \"Run\" button.</p>" +
    "<h3 id='doc-builder'>Building a custom network</h3>" +
    "<p>From <b>New Project</b>, you can assemble your own network instead of using a built-in one:</p>" +
    "<ul>" +
    "<li><b>Buses</b> -- <code>Dynamic</code> buses have their own voltage state (a capacitance <code>C</code>); <code>Ideal / slack</code> buses hold a fixed voltage (<code>v_fixed</code>) and don't add a state. Every network needs at least one bus.</li>" +
    "<li><b>Power converters</b> -- Buck, Boost, and Buck-Boost are the validated topologies. Each converter is attached to a bus and given a controller.</li>" +
    "<li><b>Ideal sources</b> -- a fixed-voltage feed behind a source resistance; use this where you don't need a converter model.</li>" +
    "<li><b>Transmission lines</b> -- only needed once you have more than one bus to connect.</li>" +
    "</ul>" +
    "<h3 id='doc-controllers'>Controllers</h3>" +
    "<p><b>Constant duty (open loop)</b> -- the duty ratio is fixed at whatever value you set; there is no feedback, so the output voltage will drift with load and input changes.</p>" +
    "<p><b>PI voltage regulator</b> -- regulates the bus voltage toward a target (<code>v_nom</code>) by adjusting duty cycle around an auto-estimated nominal duty. <code>Kp</code> and <code>Ki</code> are dimensionless gains acting on the normalized voltage error -- start from the defaults (Kp=0.3, Ki=5.0) and adjust if the response is too slow (increase both) or oscillatory (reduce both).</p>" +
    "<p><b>Droop (voltage-current)</b> -- decreases the effective voltage setpoint proportionally with the converter's own output current (<code>v_ref = v_nom - R_droop &times; i_L</code>), the standard mechanism for proportional load sharing among parallel converters without requiring communication between them. Unlike PI, this is stateless (no integrator), so it does not drive steady-state voltage error to exactly zero -- there will always be some voltage droop under load, proportional to <code>R_droop</code>. Use PI when exact regulation matters more than load sharing.</p>" +
    "<h3 id='doc-ims'>IMS concepts</h3>" +
    "<ul>" +
    "<li><b>Intrinsic manifold</b> -- the curve of equilibria as a parameter is swept, computed via continuation. Its stable branch shows where the system stays well-behaved as operating conditions change.</li>" +
    "<li><b>Manifold residual</b> -- how far the current state is from that manifold; a residual that shrinks toward zero after a disturbance is the geometric signature of recoverability.</li>" +
    "<li><b>Recoverability</b> -- whether a disturbed trajectory returns to, and stays within, an admissible neighborhood of the manifold. Assessed both deterministically (from one trajectory's own residual) and statistically (Monte-Carlo sampling around the equilibrium, with an optional traced boundary showing the recoverable region's approximate extent).</li>" +
    "</ul>" +
    "<h3 id='doc-reports'>Reports</h3>" +
    "<p>The Generate Report stage compiles a full report -- executive summary, network description, mathematical model, IMS analysis, and simulation results -- with numbered figures and captions. Export as a self-contained HTML file, or use \"Export PDF (Print)\" to open the same report in a print-ready window.</p>" +
    "<h3 id='doc-limits'>Current limitations</h3>" +
    "<p>Stated directly rather than left implicit: Bidirectional, generic DC/AC, and AC/DC converter models are not yet implemented. Backstepping, sliding-mode, MPC, and a general per-converter LQR/MRC assignment are not yet available for arbitrary user-built topologies. The platform does not track a per-project base-unit system (explicit per-unit/p.u. scaling); values are in the same units the network was built with.</p>";
  $("docModalOverlay").style.display = "flex";
  if (sectionId) { setTimeout(function () { var el = document.getElementById(sectionId); if (el) el.scrollIntoView(); }, 50); }
}

function closeDocs() { $("docModalOverlay").style.display = "none"; }

/* ===================== AUTH ===================== */

var authState = { username: null, token: null };
var authTab = "signin";

function authHeaders() {
  return authState.token ? { "X-Session-Token": authState.token } : {};
}

function toggleAuthPanel() {
  var panel = $("authPanel");
  var opening = panel.style.display === "none";
  panel.style.display = opening ? "block" : "none";
  if (opening) renderAuthPanel();
}

document.addEventListener("click", function (e) {
  var panel = $("authPanel");
  if (panel && panel.style.display !== "none" && !panel.contains(e.target) && e.target.id !== "headerProfile" && !(e.target.closest && e.target.closest("#headerProfile"))) {
    panel.style.display = "none";
  }
});

function renderAuthPanel() {
  var panel = $("authPanel");
  if (authState.username) {
    panel.innerHTML =
      "<div style='font-size:12.5px;color:var(--text);font-weight:600;margin-bottom:2px;'>" + authState.username + "</div>" +
      "<div style='font-size:10.5px;color:var(--text-dim);margin-bottom:12px;'>Signed in</div>" +
      "<button class='secondary-btn' style='width:100%;margin:0;' onclick='authSignOut()'>Sign out</button>";
    return;
  }
  panel.innerHTML =
    "<div class='auth-tab-row'>" +
    "<div class='auth-tab" + (authTab === "signin" ? " active" : "") + "' onclick='authSwitchTab(\"signin\")'>Sign in</div>" +
    "<div class='auth-tab" + (authTab === "signup" ? " active" : "") + "' onclick='authSwitchTab(\"signup\")'>Sign up</div>" +
    "</div>" +
    "<div id='authErrorBox'></div>" +
    "<label class='field-label'>Username</label><input id='authUsername' autocomplete='username'>" +
    "<label class='field-label'>Password</label><input id='authPassword' type='password' autocomplete='" + (authTab === "signin" ? "current-password" : "new-password") + "'>" +
    "<button class='run-stage' style='width:100%;margin:4px 0 0;' onclick='" + (authTab === "signin" ? "authSignIn()" : "authSignUp()") + "'>" +
    (authTab === "signin" ? "Sign in" : "Create account") + "</button>";
}

function authSwitchTab(tab) { authTab = tab; renderAuthPanel(); }

function authShowError(msg) {
  var box = $("authErrorBox");
  if (box) box.innerHTML = "<div class='auth-error'>" + msg + "</div>";
}

function authSignUp() {
  var username = $("authUsername").value.trim();
  var password = $("authPassword").value;
  fetch("/api/auth/signup", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: username, password: password }) })
    .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); })
    .then(function (res) {
      if (!res.ok) return authShowError(res.d.error || "Sign up failed.");
      authState.token = res.d.session_token; authState.username = res.d.username;
      localStorage.setItem("ims_session_token", authState.token);
      updateAuthUI();
    })
    .catch(function () { authShowError("Could not reach the server."); });
}

function authSignIn() {
  var username = $("authUsername").value.trim();
  var password = $("authPassword").value;
  fetch("/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: username, password: password }) })
    .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); })
    .then(function (res) {
      if (!res.ok) return authShowError(res.d.error || "Sign in failed.");
      authState.token = res.d.session_token; authState.username = res.d.username;
      localStorage.setItem("ims_session_token", authState.token);
      updateAuthUI();
    })
    .catch(function () { authShowError("Could not reach the server."); });
}

function authSignOut() {
  fetch("/api/auth/logout", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ session_token: authState.token }) })
    .finally(function () {
      authState.token = null; authState.username = null;
      localStorage.removeItem("ims_session_token");
      updateAuthUI();
      $("authPanel").style.display = "none";
    });
}

function updateAuthUI() {
  $("profileLabel").textContent = authState.username || "Project Manager";
  $("profileAvatar").textContent = authState.username ? authState.username.slice(0, 2).toUpperCase() : "PM";
  if ($("authPanel").style.display !== "none") renderAuthPanel();
}

function initAuth() {
  var stored = localStorage.getItem("ims_session_token");
  if (!stored) return;
  fetch("/api/auth/me", { headers: { "X-Session-Token": stored } })
    .then(function (r) { return r.json(); })
    .then(function (d) {
      if (d.authenticated) { authState.token = stored; authState.username = d.username; updateAuthUI(); }
      else { localStorage.removeItem("ims_session_token"); }
    })
    .catch(function () {});
}

/* ===================== SYSTEM HEALTH / NAVIGATION ===================== */
function scrollToProjects() {
  var grid = $("projectLibrary");
  if (grid) grid.scrollIntoView({ behavior: "smooth", block: "start" });
}
function showRecentProjects() {
  showProjectManager();
  var el = $("recentProjectsSection");
  if (el && !el.hidden) el.scrollIntoView({ behavior: "smooth", block: "start" });
  else scrollToProjects();
}
function refreshBackendHealth() {
  var b = $("backendStatus"); if (!b) return;
  fetch("/api/health", { cache: "no-store" }).then(function (r) {
    if (!r.ok) throw new Error("Backend unavailable");
    return r.json();
  }).then(function (d) {
    if (d && d.status !== "ok") throw new Error("Backend unavailable");
    b.textContent = "● Engine online";
    if ($("engineFooterStatus")) $("engineFooterStatus").textContent = "Online";
    b.classList.remove("is-offline"); b.classList.add("is-online");
    b.title = d && d.version ? "IMS engine " + d.version : "IMS engine responding";
  }).catch(function () {
    b.textContent = "● Engine offline";
    if ($("engineFooterStatus")) $("engineFooterStatus").textContent = "Offline";
    b.classList.remove("is-online"); b.classList.add("is-offline");
    b.title = "Cannot reach /api/health";
  });
}
/* ===================== INIT ===================== */

document.addEventListener("DOMContentLoaded", function () {
  loadProjects();
  refreshBackendHealth();
  renderRecentProjectsPanel();
  initAuth();
  if ($("footerLastUpdated")) $("footerLastUpdated").textContent = formatRelativeTime(Date.now());
  window.addEventListener("resize", function () {
    if (currentProject && stageResults[activeStage]) renderStageResults(activeStage);
  });
});
