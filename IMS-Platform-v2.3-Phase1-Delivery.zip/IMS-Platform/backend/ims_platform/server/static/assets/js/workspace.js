// IMS Platform / workspace.js — ordered classic script; public stage API stays stable.
/* ===================== WORKSPACE: STEPPER + SIDEBAR ===================== */

var STAGES = [
  { key: "build", label: "Build Model" },
  { key: "equilibrium", label: "Solve Equilibrium" },
  { key: "simulate", label: "Baseline Simulation" },
  { key: "ims_analysis", label: "IMS Analysis" },
  { key: "design_mrc", label: "Design & Verify MRC (Optional)" },
  { key: "report", label: "Review & Export Report" },
];

function stageStatus(key) {
  if (key === "report") return stageResults.report ? "done" : (stageResults.ims_analysis ? "active" : "disabled");
  var idx = STAGES.findIndex(function (s) { return s.key === key; });
  if (stageResults[key]) return "done";
  if (idx === 0) return "active";
  var prevKey = STAGES[idx - 1].key;
  return stageResults[prevKey] ? "active" : "disabled";
}

function renderWorkspace() {
  renderSidebar();
  renderMain();
}

function renderSidebar() {
  var el = $("wsSidebar");
  var html = '<div class="field-group-label">Analysis pipeline</div><div class="stepper">';
  STAGES.forEach(function (s, i) {
    var status = stageStatus(s.key);
    html += '<div class="step ' + status + '" onclick="' + (status !== "disabled" ? "goToStage('" + s.key + "')" : "") + '">' +
      '<span class="dot">' + (status === "done" ? "\u2713" : (i + 1)) + '</span>' + s.label + '</div>';
    if (i < STAGES.length - 1) html += '<div class="step-arrow">&#8595;</div>';
  });
  html += '</div>';
  html += '<div class="help-text" style="margin-top:10px;">Results stay available as you navigate. MRC design is optional; reporting is available after IMS analysis.</div>';
  el.innerHTML = html;
}

var activeStage = "build";
function goToStage(key) { activeStage = key; renderMain(); }

function renderMain() {
  var el = $("wsMain");
  el.innerHTML = "";

  var header = document.createElement("div");
  header.innerHTML = "<h2 style='margin:0 0 4px;font-size:18px;'>" + currentProject.label + "</h2>" +
    "<p style='color:var(--text-muted);margin:0 0 20px;font-size:12.5px;'>" + currentProject.description + "</p>";
  el.appendChild(header);

  var err = document.createElement("div");
  err.id = "wsError"; err.className = "error-box no-print"; err.style.display = "none";
  el.appendChild(err);

  if (activeStage === "design_mrc") { renderDesignMrcStage(el); return; }

  var formPanel = document.createElement("div");
  formPanel.className = "panel no-print";
  formPanel.innerHTML = "<div class='panel-title'>" + STAGES.find(function (s) { return s.key === activeStage; }).label + "</div>";
  var formBody = document.createElement("div"); formBody.id = "stageForm";
  formPanel.appendChild(formBody);
  var runBtn = document.createElement("button");
  runBtn.className = "run-stage"; runBtn.id = "runStageBtn";
  runBtn.textContent = "Run: " + STAGES.find(function (s) { return s.key === activeStage; }).label;
  runBtn.onclick = function () { runStage(activeStage); };
  formPanel.appendChild(runBtn);
  el.appendChild(formPanel);

  renderStageForm(activeStage);

  var resultsPanel = document.createElement("div");
  resultsPanel.id = "stageResultsPanel";
  el.appendChild(resultsPanel);
  renderStageResults(activeStage);

  if (stageResults[activeStage] && activeStage !== "report") {
    var nextKey = nextStageAfter(activeStage);
    if (nextKey !== activeStage) {
      var contPanel = document.createElement("div");
      contPanel.className = "panel no-print";
      contPanel.style.cssText = "text-align:center;background:var(--teal-dim);border-color:var(--teal);";
      var contBtn = document.createElement("button");
      contBtn.className = "run-stage"; contBtn.style.maxWidth = "320px"; contBtn.style.margin = "0 auto";
      contBtn.textContent = "\u2713 Continue to " + STAGES.find(function (s) { return s.key === nextKey; }).label + " \u2192";
      contBtn.onclick = function () { goToStage(nextKey); };
      contPanel.appendChild(contBtn);
      el.appendChild(contPanel);
    }
  }
}

function applyDisturbancePreset(deltaVal, omegaVal) {
  formState.disturbance_value[0] = deltaVal;
  formState.disturbance_value[1] = omegaVal;
  if ($("distField0")) $("distField0").value = deltaVal;
  if ($("distField1")) $("distField1").value = omegaVal;
}

function applyRandomDisturbancePreset() {
  // Scaled to roughly the same order of magnitude as the built-in
  // default disturbance, so "Random" produces a genuinely disturbed
  // but not absurd initial condition.
  var d = (Math.random() * 2 - 1) * 1.5;
  var o = (Math.random() * 2 - 1) * 3.0;
  applyDisturbancePreset(Number(d.toFixed(3)), Number(o.toFixed(3)));
}

function numField(label, key, obj, help) {
  return "<label class='field-label'>" + label + "</label>" +
    "<input type='number' step='any' value='" + obj[key] + "' oninput='formState." + key + "=parseFloat(this.value)'>" +
    (help ? "<div class='help-text'>" + help + "</div>" : "");
}

function renderStageForm(stage) {
  var f = $("stageForm");
  var p = currentProject;
  if (stage === "build") {
    var html = "<div class='field-group-label'>Parameters</div>";
    (p.params || []).forEach(function (prm) {
      html += "<label class='field-label'>" + prm.label + "</label>" +
        "<input type='number' step='any' value='" + formState.params[prm.key] + "' " +
        "oninput='formState.params[\"" + prm.key + "\"]=parseFloat(this.value)'>" +
        (prm.help ? "<div class='help-text'>" + prm.help + "</div>" : "");
    });
    f.innerHTML = html;
  } else if (stage === "equilibrium") {
    var html = "";
    if (p.category !== "network_mrc") {
      html += "<label class='field-label'>" + (p.input_label || "Nominal input") + "</label>" +
        "<input type='number' step='any' value='" + formState.nominal_input[0] + "' oninput='formState.nominal_input[0]=parseFloat(this.value)'>";
    } else {
      html += "<label class='field-label'>k_m (contraction gain, 1/s)</label>" +
        "<input type='number' step='any' value='" + formState.km + "' oninput='formState.km=parseFloat(this.value)'>" +
        "<label class='field-label'>Initial bus-voltage guess (V)</label>" +
        "<input type='number' step='any' value='" + formState.v_bus_init + "' oninput='formState.v_bus_init=parseFloat(this.value)'>";
    }
    if (p.category === "single_model") {
      html += "<label class='field-label'>Equilibrium-solve initial guess</label><div class='row2'>" +
        "<input type='number' step='any' value='" + p.default_state_guess[0] + "' oninput='formState.guess0=parseFloat(this.value)'>" +
        "<input type='number' step='any' value='" + p.default_state_guess[1] + "' oninput='formState.guess1=parseFloat(this.value)'></div>";
    }
    f.innerHTML = html || "<div class='help-text'>No additional inputs for this stage.</div>";
  } else if (stage === "simulate") {
    var labels = p.state_short || formState.disturbance_value.map(function (_, i) { return "x" + (i + 1); });
    var distLabel = "\u0394 " + labels.join(", ");
    var presetsHtml = "";
    if (p.id === "grid_forming_inverter") {
      presetsHtml = "<label class='field-label'>Disturbance presets</label>" +
        "<div style='display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:8px;'>" +
        "<button type='button' class='secondary-btn' style='margin:0;' onclick='applyDisturbancePreset(0,3.0)'>Frequency step</button>" +
        "<button type='button' class='secondary-btn' style='margin:0;' onclick='applyDisturbancePreset(1.0,0)'>Angle jump</button>" +
        "<button type='button' class='secondary-btn' style='margin:0;' onclick='applyDisturbancePreset(1.0,2.0)'>Combined disturbance</button>" +
        "<button type='button' class='secondary-btn' style='margin:0;' onclick='applyRandomDisturbancePreset()'>Random</button>" +
        "</div>" +
        "<div class='help-text' style='margin-bottom:10px;'>Presets set an initial-condition offset (\u0394\u03b4, \u0394\u03c9) \u2014 the only kind of disturbance this version simulates. Scenarios that change an input or parameter mid-run (a P_set step, a voltage sag, a reactance change) are not yet supported here; a voltage sag, for instance, would need editing V at the Build Model stage and re-running the pipeline, not a runtime disturbance.</div>";
    }
    var fields = formState.disturbance_value.map(function (v, i) {
      return "<div><label class='field-label' style='font-size:10.5px;'>" + (labels[i] || ("x" + (i + 1))) + "</label>" +
        "<input type='number' step='any' value='" + v + "' id='distField" + i + "' oninput='formState.disturbance_value[" + i + "]=parseFloat(this.value)'></div>";
    }).join("");
    var html = presetsHtml + "<label class='field-label'>Disturbance offset (" + distLabel + ")</label>" +
      "<div style='display:grid;grid-template-columns:repeat(" + formState.disturbance_value.length + ",1fr);gap:6px;'>" + fields + "</div>" +
      "<label class='field-label'>Simulation horizon (s)</label>" +
      "<input type='number' step='any' value='" + formState.horizon + "' oninput='formState.horizon=parseFloat(this.value)'>";
    if (p.category === "single_model") {
      html += "<div class='checkbox-row'><input type='checkbox' id='mrcChk' " + (formState.mrc_enabled ? "checked" : "") +
        " onchange='formState.mrc_enabled=this.checked'><label for='mrcChk'>Design scheduled LQR (Conventional Control Library)</label></div>" +
        "<details style='margin-top:2px;'><summary style='cursor:pointer;font-size:11px;color:var(--text-dim);'>What is Scheduled LQR?</summary>" +
        "<div class='help-text' style='margin-top:6px;line-height:1.6;'>" +
        "<b>Scheduling variable:</b> position along the traced intrinsic manifold (nearest sample to the current state) \u2014 not a fixed operating point.<br>" +
        "<b>How it's built:</b> a full linear-quadratic (Riccati) gain is solved once at <i>every</i> manifold sample point and cached; at runtime the controller looks up the nearest sample's precomputed gain (an O(1) lookup, not interpolation and not a fresh solve per timestep).<br>" +
        "<b>States controlled:</b> full-state feedback \u2014 every state, via u = u_ff + saturate(-K\u00b7(x \u2212 x*)).<br>" +
        "<b>Q / R:</b> the diagonal weighting matrices below, applied identically at every scheduled gain.<br>" +
        "<b>When active:</b> only for this Run Simulation call when this box is checked; it does not persist to other stages.<br>" +
        "<b>Note:</b> this is the Conventional Control Library's LQR design, manifold-<i>aware</i> via its scheduling \u2014 not IMS-native MRC (see the Network + Auto-MRC project for that; the two are architecturally distinct, not the same method under different names)." +
        "</div></details>";
    }
    f.innerHTML = html;
  } else if (stage === "ims_analysis") {
    if (p.category === "network_mrc") {
      f.innerHTML = "<div class='help-text'>This project's manifold is 1-D (see note in results); no additional inputs needed.</div>";
      return;
    }
    if (formState.ims_advanced_mode === undefined) formState.ims_advanced_mode = false;
    var html = "<div class='tab-row' style='margin-bottom:14px;'>" +
      "<div class='tab-btn" + (!formState.ims_advanced_mode ? " active" : "") + "' onclick='formState.ims_advanced_mode=false;renderStageForm(\"ims_analysis\");'>Basic</div>" +
      "<div class='tab-btn" + (formState.ims_advanced_mode ? " active" : "") + "' onclick='formState.ims_advanced_mode=true;renderStageForm(\"ims_analysis\");'>Advanced</div>" +
      "</div>";
    if (!formState.ims_advanced_mode) {
      html += "<div class='help-text'>Runs the intrinsic manifold trace and a geometry-based recoverability assessment (from a single disturbance trajectory's manifold residual \u2014 no statistical sampling in this mode) using recommended defaults (sweep range, tolerance). Switch to Advanced for optional statistical validation and boundary tracing. Larger networks (more buses/converters) and higher sweep-point counts both increase runtime \u2014 if a run times out, try reducing them here.</div>";
      f.innerHTML = html;
      return;
    }
    html += "<label class='field-label'>Manifold sweep range</label><div class='row2'>" +
      "<input type='number' step='any' value='" + formState.sweep_range[0] + "' oninput='formState.sweep_range[0]=parseFloat(this.value)'>" +
      "<input type='number' step='any' value='" + formState.sweep_range[1] + "' oninput='formState.sweep_range[1]=parseFloat(this.value)'></div>" +
      "<label class='field-label'>Sweep points</label>" +
      "<input type='number' step='1' value='" + formState.sweep_points + "' oninput='formState.sweep_points=parseInt(this.value)'>" +
      "<label class='field-label'>Residual projection method</label>" +
      "<select oninput='formState.residual_projection_method=this.value' style='width:100%;'>" +
      ["auto", "polyline", "newton_refined", "nearest_sample"].map(function (m) {
        var labels = { auto: "Auto (recommended)", polyline: "Polyline", newton_refined: "Newton-refined (highest accuracy, slower)", nearest_sample: "Nearest sample (legacy)" };
        return "<option value='" + m + "'" + ((formState.residual_projection_method || "auto") === m ? " selected" : "") + ">" + labels[m] + "</option>";
      }).join("") + "</select>" +
      "<div class='help-text' style='margin-bottom:8px;'>Auto uses polyline, benchmarked as the recommended default (see the IMS Analysis results for the validation summary). Newton-refined adds one extra equilibrium solve per residual query \u2014 more accurate, but noticeably slower on longer trajectories.</div>" +
      "<label class='field-label'>Recoverability sampling radius</label>" +
      "<input type='number' step='any' value='" + formState.radius + "' oninput='formState.radius=parseFloat(this.value)'>" +
      "<label class='field-label'># samples</label>" +
      "<input type='number' step='1' value='" + formState.n_samples + "' oninput='formState.n_samples=parseInt(this.value)'>" +
      "<label class='field-label'>Recovery tolerance (manifold residual)</label>" +
      "<input type='number' step='any' value='" + formState.recovery_tol + "' oninput='formState.recovery_tol=parseFloat(this.value)'>" +
      "<div class='checkbox-row'><input type='checkbox' id='boundaryChk' " + (formState.trace_boundary ? "checked" : "") +
      " onchange='formState.trace_boundary=this.checked'><label for='boundaryChk'>Trace recoverability boundary (directional bisection; 2-state projects only)</label></div>";
    f.innerHTML = html;
  } else if (stage === "report") {
    f.innerHTML = "<div class='help-text'>Compiles everything computed so far into a report. Export as HTML or use your browser's Print dialog (Ctrl/Cmd+P) to save as PDF.</div>";
    $("runStageBtn").style.display = "none";
  }
  if (stage !== "report") { var btn = $("runStageBtn"); if (btn) btn.style.display = "block"; }
}


/* ===================== STAGE EXECUTION ===================== */

function buildPayload(stage) {
  var p = currentProject;
  var payload = { params: formState.params };

  if (p.category === "custom_network") {
    payload.network_spec = builderSpec;
    if (stage !== "build") payload.nominal_input = formState.nominal_input;
    if (stage === "equilibrium") {
      payload.state_guess = formState.custom_state_guess;
    }
    if (stage === "simulate" || stage === "ims_analysis") {
      if (stageResults.equilibrium) payload.x_star = stageResults.equilibrium.x_star;
    }
    if (stage === "simulate") {
      payload.disturbance = { type: "offset", value: formState.disturbance_value };
      payload.horizon = formState.horizon;
    }
    if (stage === "ims_analysis") {
      payload.sweep_range = formState.sweep_range; payload.sweep_points = formState.sweep_points;
      // The deterministic, manifold-residual-based assessment (the
      // PRIMARY recoverability signal per Definition IV.2) is computed
      // from a disturbance trajectory server-side -- but only if a
      // disturbance is actually included in this payload. Previously
      // this branch never sent one for the IMS Analysis stage
      // specifically (only for Simulate), so the deterministic
      // assessment silently never ran here, leaving Monte Carlo as the
      // ONLY thing actually computed regardless of Basic/Advanced mode.
      payload.disturbance = { type: "offset", value: formState.disturbance_value };
      // Monte Carlo and boundary tracing are validation tools, not the
      // primary recoverability signal -- gated behind Advanced mode so
      // Basic mode stays fast (one equilibrium, one manifold sweep, one
      // disturbance trajectory) rather than also running dozens of
      // additional simulations by default.
      payload.recoverability_enabled = !!formState.ims_advanced_mode;
      payload.radius = formState.radius; payload.n_samples = formState.n_samples; payload.recovery_tol = formState.recovery_tol;
      payload.horizon = formState.horizon;
      payload.trace_boundary = !!formState.ims_advanced_mode && !!formState.trace_boundary;
      payload.residual_projection_method = formState.residual_projection_method || "auto";
    }
    return payload;
  }

  if (p.category === "network_mrc") {
    payload.km = formState.km; payload.v_bus_init = formState.v_bus_init;
    if (stageResults.equilibrium) payload.x_star = stageResults.equilibrium.x_star;
    if (stage === "simulate" || stage === "ims_analysis") {
      // formState.disturbance_value is already 3 elements here (initialized
      // directly from this project's 3-element default_disturbance in
      // openProject() -- unlike the 2-state single_model/converter_topology
      // categories, this must NOT be padded with an extra element; doing so
      // previously caused a (3,) vs (4,) broadcast error against the
      // 3-state x_star, since x_star + disturbance is computed directly.
      payload.disturbance = formState.disturbance_value.slice();
      payload.horizon = formState.horizon;
    }
    return payload;
  }

  payload.nominal_input = formState.nominal_input;
  if (stage === "equilibrium" && p.category === "single_model") {
    payload.state_guess = [formState.guess0 !== undefined ? formState.guess0 : p.default_state_guess[0],
                            formState.guess1 !== undefined ? formState.guess1 : p.default_state_guess[1]];
  }
  if (stage === "simulate" || stage === "ims_analysis") {
    if (stageResults.equilibrium) payload.x_star = stageResults.equilibrium.x_star;
  }
  if (stage === "simulate") {
    payload.disturbance = { type: p.disturbance_type || "offset", value: formState.disturbance_value };
    payload.horizon = formState.horizon;
    if (p.category === "single_model") {
      payload.mrc_enabled = formState.mrc_enabled;
      payload.Q_diag = p.q_default; payload.R_diag = p.r_default;
      payload.u_min = p.u_min_default; payload.u_max = p.u_max_default;
    }
  }
  if (stage === "ims_analysis") {
    payload.sweep_range = formState.sweep_range; payload.sweep_points = formState.sweep_points;
    // Same fix as the custom_network branch above: send a disturbance
    // so the deterministic, manifold-residual assessment (the primary
    // recoverability signal) actually runs here, and gate Monte Carlo
    // / boundary tracing behind Advanced mode so Basic mode stays fast.
    payload.disturbance = { type: p.disturbance_type || "offset", value: formState.disturbance_value };
    payload.recoverability_enabled = !!formState.ims_advanced_mode;
    payload.radius = formState.radius; payload.n_samples = formState.n_samples; payload.recovery_tol = formState.recovery_tol;
    payload.horizon = formState.horizon;
    payload.trace_boundary = !!formState.ims_advanced_mode && !!formState.trace_boundary;
      payload.residual_projection_method = formState.residual_projection_method || "auto";
    if (p.category === "single_model") payload.state_guess = payload.x_star;
  }
  return payload;
}

/* Dependency invalidation: a changed upstream run invalidates every
   downstream result. Otherwise old trajectories, manifold analyses or
   controller verifications could be silently reported against a new model. */
/* Editing a completed stage makes its own result and all subsequent results
   stale. Event delegation keeps this rule independent of each form widget. */
function markWorkspaceStageDirty(event) {
  if (!currentProject || activeStage === "report" || activeStage === "design_mrc") return;
  var form = $("stageForm");
  if (!form || !form.contains || !form.contains(event.target)) return;
  if (stageResults[activeStage]) {
    delete stageResults[activeStage];
    invalidateDownstreamResults(activeStage);
    renderSidebar();
    var panel = $("stageResultsPanel");
    if (panel) panel.innerHTML = '<div class="note-box" role="status">Inputs changed. Re-run this stage to update results and unlock subsequent stages.</div>';
  }
}
document.addEventListener("input", markWorkspaceStageDirty);
document.addEventListener("change", markWorkspaceStageDirty);

function invalidateDownstreamResults(stage) {
  var dependencies = ["build", "equilibrium", "simulate", "ims_analysis", "design_mrc", "report"];
  var index = dependencies.indexOf(stage);
  if (index < 0) return;
  dependencies.slice(index + 1).forEach(function (key) { delete stageResults[key]; });
}

async function runStage(stage) {
  $("wsError").style.display = "none";
  var btn = $("runStageBtn");
  if (btn) { btn.disabled = true; btn.textContent = "Running\u2026"; }
  var controller = new AbortController();
  // A generous but finite timeout, specifically for IMS Analysis (by
  // far the most compute-intensive stage -- a manifold sweep plus a
  // full Monte-Carlo recoverability assessment, both scaling with the
  // network's state count). Without this, a genuinely slow request
  // (a large custom network, or high sweep/sample counts set in
  // Advanced mode) can be silently cut off by an intermediate proxy
  // (e.g. a Codespaces port-forwarding timeout) partway through
  // writing the response body, which produces a truncated JSON string
  // that fails to parse with a bare, unhelpful "Unexpected end of JSON
  // input" -- indistinguishable, from the browser's error alone, from
  // a genuine backend crash. Aborting client-side first, with a
  // specific message naming the likely cause and the fix (reduce
  // sweep points / Monte-Carlo samples in Advanced mode), is far more
  // actionable than either failure mode on its own.
  var timeoutMs = stage === "ims_analysis" ? 90000 : 30000;
  var timeoutId = setTimeout(function () { controller.abort(); }, timeoutMs);
  try {
    var payload = buildPayload(stage);
    var url = currentProject.category === "custom_network" ? "/api/custom_project/" + stage : "/api/project/" + currentProject.id + "/" + stage;
    var resp;
    try {
      resp = await fetch(url, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
        signal: controller.signal,
      });
    } catch (fetchErr) {
      if (fetchErr.name === "AbortError") {
        throw new Error(
          "Request timed out after " + (timeoutMs / 1000) + "s. This stage may be computationally heavy for " +
          "this network (more states/buses/converters and higher sweep-point or Monte-Carlo sample counts all " +
          "increase runtime) -- try reducing them in Advanced mode, or an intermediate connection (e.g. a " +
          "Codespaces port forward) may have its own timeout shorter than this stage needs."
        );
      }
      throw fetchErr;
    }
    var rawText = await resp.text();
    var data;
    try {
      data = JSON.parse(rawText);
    } catch (parseErr) {
      throw new Error(
        "The server's response could not be parsed as JSON (" + parseErr.message + "). This usually means the " +
        "response was cut off before it finished -- most often an intermediate proxy or connection closing a " +
        "slow request early, not a bug in the computation itself. Response received so far (" + rawText.length +
        " bytes): " + rawText.slice(0, 200) + (rawText.length > 200 ? "\u2026" : "")
      );
    }
    if (!resp.ok) throw new Error(data.error || ("HTTP " + resp.status));
    invalidateDownstreamResults(stage);
    stageResults[stage] = data;
    if (stage === "build" && currentProject.category === "custom_network") {
      // Custom networks don't know their state count until assembled;
      // seed the equilibrium-stage guess and state_short labels from
      // the real, just-built state_names rather than a fixed template.
      currentProject.state_short = data.state_names;
      formState.custom_state_guess = defaultStateGuess(data.state_names);
    }
    if (stage === "equilibrium" && currentProject.category === "custom_network") {
      // The hardcoded [0.0, 1.0] sweep-range default only makes sense
      // for a duty-ratio-style input; for a voltage-style input (e.g.
      // a PI controller's v_nom=24), it silently sweeps to values like
      // 0.5V -- confirmed directly this makes EVERY manifold point fail
      // to converge (a 100% failure rate, not just a slow one), which
      // is why "IMS Analysis" was timing out: 30 failed equilibrium
      // solves (plus Monte-Carlo simulation) adding up past the
      // request timeout. Scale the default sweep range to the actual
      // nominal_input value once it's known, with a floor on the
      // absolute span so a tiny nominal_input doesn't collapse to a
      // near-zero-width sweep.
      var nomVal = formState.nominal_input && formState.nominal_input[0];
      if (typeof nomVal === "number" && isFinite(nomVal) && nomVal !== 0) {
        var halfSpan = Math.max(Math.abs(nomVal) * 0.5, 0.5);
        formState.sweep_range = [nomVal - halfSpan, nomVal + halfSpan];
      }
    }
    // Stay on THIS stage to show its results -- previously this
    // immediately called goToStage(nextStageAfter(stage)), which
    // re-rendered #wsMain for the *next*, not-yet-run stage before the
    // user could ever see what was just computed (the results were
    // rendered, then overwritten, in the same synchronous tick). The
    // stepper's own "done" checkmark plus a "Continue" prompt now
    // handle moving forward, on the user's own action.
    renderWorkspace();
  } catch (err) {
    var box = $("wsError");
    box.style.display = "block";
    box.textContent = "Stage failed: " + (err && err.message ? err.message : String(err));
    console.error(err);
  } finally {
    clearTimeout(timeoutId);
    if (btn) { btn.disabled = false; btn.textContent = "Run: " + STAGES.find(function (s) { return s.key === stage; }).label; }
  }
}

function nextStageAfter(stage) {
  var idx = STAGES.findIndex(function (s) { return s.key === stage; });
  return STAGES[Math.min(idx + 1, STAGES.length - 1)].key;
}

/* ===================== DESIGN MRC CONTROLLER (in-project downstream stage) =====================
   The General MRC Designer, integrated as a project stage. It inherits the
   current project's assembled model, parameters, k_m, equilibrium and IMS
   results (the single source of truth) and runs feasibility -> synthesis ->
   closed-loop verification -> before/after on THAT model. Honest per-model:
   the analytic synthesis path is established only where a validated symbolic
   manifold + control-affine (f, G) form exist. */

function designerModelForProject(p) {
  if (!p) return null;
  if (p.category === "network_mrc") return "converter_cpl_paper";
  return null;  // no registered analytic Designer model for this assembled model
}

function designerParamsForProject() {
  var fp = formState.params || {};
  return { R: fp.R, L: fp.L, C: fp.C, P: fp.P };
}

function feasStatus(f) {
  if (f && f.mrc_established && f.establishment_basis === "analytic") return "supported";
  if (f && !f.mrc_established && (f.establishment_basis === "numeric_only" || f.establishment_basis === "insufficient_authority")) return "diagnostic";
  return "not_established";
}

function buildDesignerSim(model_id, params, km) {
  var dv = formState.disturbance_value || [-5, 0, 0];
  var horizon = formState.horizon || 0.02;
  var pert = {};
  if (model_id === "converter_cpl_paper") {
    // network_mrc disturbance order [v_bus, i_L, v_o] -> converter_cpl (i_l, v_b, v_o)
    pert = { v_b: dv[0] || 0, i_l: dv[1] || 0, v_o: dv[2] || 0 };
  }
  return { model_id: model_id, params: params, k_m: km, t_end: horizon, n_eval: 800,
           initial_perturbation: pert, disturbance: null };
}

async function postJson(url, body) {
  var resp = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  var data = await resp.json();
  if (!resp.ok) throw new Error((data && (data.detail || data.error)) || ("HTTP " + resp.status));
  return data;
}

async function runDesignMrc() {
  var p = currentProject;
  var model_id = designerModelForProject(p);
  if (!model_id) return;
  var btn = $("designMrcRunBtn"); if (btn) { btn.disabled = true; btn.textContent = "Designing MRC controller\u2026"; }
  var box = $("wsError"); if (box) box.style.display = "none";
  try {
    var params = designerParamsForProject();
    var km = (typeof formState.km === "number" && isFinite(formState.km)) ? formState.km : 500;
    var feas = await postJson("/api/mrc_designer/feasibility", { model_id: model_id, params: params });
    var result = { model_id: model_id, params: params, km: km, feasibility: feas, status: feasStatus(feas) };
    if (result.status === "supported") {
      var simReq = buildDesignerSim(model_id, params, km);
      result.synthesis = await postJson("/api/mrc_designer/synthesize", { model_id: model_id, params: params, k_m: km });
      result.verify = await postJson("/api/mrc_designer/verify", simReq);
    }
    invalidateDownstreamResults("design_mrc");
    stageResults.design_mrc = result;
    renderWorkspace();
  } catch (err) {
    var box2 = $("wsError"); if (box2) { box2.style.display = "block"; box2.textContent = "Design MRC failed: " + (err && err.message ? err.message : String(err)); }
    console.error(err);
  } finally {
    var b = $("designMrcRunBtn"); if (b) { b.disabled = false; b.textContent = "Run: Design MRC Controller"; }
  }
}

function dmCplx(z) {
  if (!z) return "\u2014";
  if (Math.abs(z.im) < 1e-9) return (+z.re).toPrecision(5);
  return (+z.re).toPrecision(5) + (z.im >= 0 ? " + " : " \u2212 ") + Math.abs(z.im).toPrecision(5) + "j";
}
function dmNum(v, p) {
  if (v === null || v === undefined || !isFinite(v)) return "\u2014";
  p = p || 4; var a = Math.abs(v);
  if (v !== 0 && (a < 1e-3 || a >= 1e5)) return v.toExponential(p - 1);
  return String(+v.toPrecision(p));
}

function dmStatusBadge(status) {
  if (status === "supported") return "<div style='display:inline-block;font-size:11px;font-weight:700;color:#3FE0A8;border:1px solid #3FE0A8;border-radius:4px;padding:3px 10px;'>MRC SYNTHESIS SUPPORTED</div>";
  if (status === "supported_reshaped") return "<div style='display:inline-block;font-size:11px;font-weight:700;color:#3FE0A8;border:1px solid #3FE0A8;border-radius:4px;padding:3px 10px;'>MRC SYNTHESIS SUPPORTED — RESHAPED MANIFOLD</div>";
  if (status === "diagnostic") return "<div style='display:inline-block;font-size:11px;font-weight:700;color:#6FC6FF;border:1px solid #6FC6FF;border-radius:4px;padding:3px 10px;'>DIAGNOSTIC / FEASIBILITY ONLY</div>";
  return "<div style='display:inline-block;font-size:11px;font-weight:700;color:#FFB454;border:1px solid #FFB454;border-radius:4px;padding:3px 10px;'>MRC SYNTHESIS NOT ESTABLISHED</div>";
}

function renderDesignMrcStage(el) {
  var p = currentProject;
  var model_id = designerModelForProject(p);
  var eq = stageResults.equilibrium, ims = stageResults.ims_analysis;

  var ctxPanel = document.createElement("div"); ctxPanel.className = "panel";
  var ch = "<div class='panel-title'>Inherited from this project (single source of truth)</div>" +
    "<div class='help-text' style='margin-bottom:8px;'>The MRC design stage does not recreate the model. It consumes the assembled model, parameters, equilibrium and IMS results produced by the earlier stages of <b>" + (p.label || "this project") + "</b>.</div><div class='info-grid'>";
  var fp = formState.params || {};
  ["R", "L", "C", "P"].forEach(function (k) { if (fp[k] !== undefined) ch += "<div class='info-card'><div class='lbl'>" + k + "</div><div class='val'>" + dmNum(fp[k]) + "</div></div>"; });
  if (typeof formState.km === "number") ch += "<div class='info-card'><div class='lbl'>k_m</div><div class='val'>" + dmNum(formState.km) + "</div></div>";
  ch += "</div>";
  if (eq && eq.x_star) ch += "<div class='panel-title' style='margin-top:12px;'>Project equilibrium x*</div><div class='eq-readout' style='font-size:12px;'>[" + eq.x_star.map(function (v) { return dmNum(v); }).join(", ") + "]</div>";
  if (ims && ims.residual_statistics) {
    var rs = ims.residual_statistics;
    ch += "<div class='panel-title' style='margin-top:12px;'>IMS analysis \u2014 manifold residual</div><div class='eq-readout' style='font-size:12px;'>max |e_m| = " + dmNum(rs.max) + " &middot; final = " + dmNum(rs.final) + " &middot; empirical contraction rate \u2248 " + dmNum(rs.empirical_contraction_rate) + " s\u207B\u00B9</div>";
  }
  ctxPanel.innerHTML = ch; el.appendChild(ctxPanel);

  if (p.category === "custom_network") { renderCustomMrcFeasibility(el); return; }

  if (!model_id) {
    var np = document.createElement("div"); np.className = "panel";
    np.innerHTML = "<div class='panel-title'>MRC Feasibility</div><div style='margin-bottom:8px;'>" + dmStatusBadge("not_established") + "</div>" +
      "<div class='help-text'>This project's assembled model has no validated analytic controlled-target manifold \u03C6(x) registered with the MRC Designer. Analytic MRC synthesis requires a symbolic manifold \u03C6(x) and a control-affine split x\u0307 = f(x) + G(x)u; without it only a numeric distance-to-manifold residual exists, which cannot on its own establish an MRC. The validated synthesis paths are the <b>Network + Auto-MRC</b> project (assembled Converter\u2013CPL model) and the <b>Stabilising MRC</b> benchmark.</div>";
    el.appendChild(np);
    appendDesignMrcClaims(el); appendContinueToReport(el); return;
  }

  var runPanel = document.createElement("div"); runPanel.className = "panel no-print";
  runPanel.innerHTML = "<div class='panel-title'>Design MRC Controller</div><div class='help-text'>Runs analytic feasibility A(x)=D\u03C6\u00B7G on the assembled model, then generic closed-form synthesis, closed-loop verification, and an open-loop vs MRC Before/After on identical conditions.</div>";
  var runBtn = document.createElement("button"); runBtn.className = "run-stage"; runBtn.id = "designMrcRunBtn";
  runBtn.textContent = "Run: Design MRC Controller"; runBtn.onclick = runDesignMrc;
  runPanel.appendChild(runBtn); el.appendChild(runPanel);

  var r = stageResults.design_mrc;
  if (r) renderDesignMrcResults(el, r);
  else { var ph = document.createElement("p"); ph.className = "placeholder-msg"; ph.textContent = "Run this stage to design and verify the MRC controller."; el.appendChild(ph); }
}

function renderDesignMrcResults(el, r) {
  var f = r.feasibility || {};
  var fpnl = document.createElement("div"); fpnl.className = "panel";
  var h = "<div class='panel-title'>MRC Feasibility \u2014 A(x) = D\u03C6(x)\u00B7G(x)</div><div style='margin-bottom:10px;'>" + dmStatusBadge(r.status) + "</div><div class='info-grid'>" +
    "<div class='info-card'><div class='lbl'>dim \u03C6</div><div class='val'>" + (f.dim_phi != null ? f.dim_phi : "\u2014") + "</div></div>" +
    "<div class='info-card'><div class='lbl'>dim u</div><div class='val'>" + (f.dim_u != null ? f.dim_u : "\u2014") + "</div></div>" +
    "<div class='info-card'><div class='lbl'>rank A</div><div class='val'>" + (f.rank_A != null ? f.rank_A : "\u2014") + "</div></div>" +
    "<div class='info-card'><div class='lbl'>cond(A)</div><div class='val'>" + dmNum(f.condition_number) + "</div></div></div>";
  if (f.A) h += "<div class='panel-title' style='margin-top:12px;'>A(x)</div><div class='eq-readout' style='font-size:12px;'>[" + f.A.map(function (row) { return row.map(function (v) { return dmNum(v); }).join(", "); }).join("; ") + "]</div>";
  h += "<div class='help-text' style='margin-top:8px;'>G(x): <b>" + (f.G_method || "\u2014") + "</b> &middot; \u03C6(x): <b>" + (f.manifold_method || "\u2014") + "</b> &middot; basis: <b>" + (f.establishment_basis || "\u2014") + "</b></div><div class='help-text' style='margin-top:6px;'>" + (f.reason || "") + "</div>";
  fpnl.innerHTML = h; el.appendChild(fpnl);

  if (r.status !== "supported") { appendDesignMrcClaims(el); appendContinueToReport(el); return; }

  var syn = r.synthesis || {};
  var sp = document.createElement("div"); sp.className = "panel";
  var sh = "<div class='panel-title'>Synthesized control law &nbsp; u = \u03BA(x)</div><div class='help-text'>generic relation: " + (syn.synthesis_relation || "") + "</div><div class='law-box' style='font-size:12.5px;word-break:break-word;'>" + (syn.control_law_symbolic || "") + "</div>";
  if (syn.manifold_roles) {
    var mr = syn.manifold_roles;
    sh += "<div class='help-text' style='margin-top:8px;'>IMS-analysis manifold: <span style='font-family:monospace;'>" + mr.ims_analysis_manifold + "</span><br>Candidate MRC target: <span style='font-family:monospace;'>" + mr.candidate_mrc_target + "</span><br>Validated controlled-invariant: <b>" + mr.validated_controlled_invariant + "</b></div>";
  }
  sp.innerHTML = sh; el.appendChild(sp);

  var v = r.verify || {}; var ls = v.local_stability || {}; var ce = v.contraction_evidence || {}; var eqv = v.equilibrium || {};
  var vp = document.createElement("div"); vp.className = "panel";
  var vh = "<div class='panel-title'>Closed-loop verification</div><div class='info-grid'>" +
    "<div class='info-card'><div class='lbl'>\u2016f_cl(x*)\u2016</div><div class='val'>" + dmNum(eqv.residual_norm, 3) + "</div></div>" +
    "<div class='info-card'><div class='lbl'>\u03BB\u22A5 vs \u2212k_m</div><div class='val'>" + dmCplx(ls.transverse_eigenvalue) + (ls.transverse_check_ok ? " \u2713" : " \u2717") + "</div></div>" +
    "<div class='info-card'><div class='lbl'>residual rel-err</div><div class='val'>" + dmNum(ce.max_rel_error, 3) + "</div></div></div>";
  if (ls.full_eigenvalues) vh += "<div class='help-text' style='margin-top:8px;'>closed-loop poles: " + ls.full_eigenvalues.map(dmCplx).join(", ") + "</div>";
  vh += "<div style='margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;'>" +
    "<span style='font-size:10.5px;border:1px solid #10B981;color:#10B981;border-radius:4px;padding:2px 7px;'>exact residual contraction: " + (ce.identity || "") + "</span>" +
    "<span style='font-size:10.5px;border-radius:4px;padding:2px 7px;border:1px solid " + (ls.locally_exponentially_stable ? "#3FE0A8;color:#3FE0A8" : "#FFB454;color:#FFB454") + ";'>local stability: " + (ls.locally_exponentially_stable ? "stable" : "NOT guaranteed") + "</span></div>";
  if (ls.scope_note) vh += "<div class='help-text' style='margin-top:8px;'>" + ls.scope_note + "</div>";
  vp.innerHTML = vh; el.appendChild(vp);

  // ---- Apply MRC to Converter (assembled Network Builder model) ----
  var applied = r.applied;
  var ap = document.createElement("div"); ap.className = "panel";
  ap.innerHTML = "<div class='panel-title'>Apply MRC to Converter (Network Builder)</div>" +
    "<div class='help-text'>Assign the synthesized law as the active controller of converter <b>conv</b> in the assembled network, then rerun the same network and disturbance to compare baseline vs MRC.</div>";
  if (!applied) {
    var applyBtn = document.createElement("button"); applyBtn.className = "run-stage"; applyBtn.id = "applyMrcBtn";
    applyBtn.textContent = "Apply MRC to Converter"; applyBtn.onclick = applyMrcToConverter;
    ap.appendChild(applyBtn);
  }
  el.appendChild(ap);

  if (applied) {
    var ac = (applied.converter && applied.converter.active_controller) || {};
    var cc = document.createElement("div"); cc.className = "panel";
    cc.innerHTML = "<div class='panel-title'>Converter controller configuration</div>" +
      "<div style='margin-bottom:8px;'><span style='display:inline-block;font-size:11px;font-weight:700;color:#3FE0A8;border:1px solid #3FE0A8;border-radius:4px;padding:3px 10px;'>MRC ACTIVE ON CONVERTER &#39;" + (applied.converter.id || "conv") + "&#39;</span></div>" +
      "<div class='info-grid'>" +
      "<div class='info-card'><div class='lbl'>Converter</div><div class='val'>" + (applied.converter.id || "conv") + "</div></div>" +
      "<div class='info-card'><div class='lbl'>Bus</div><div class='val'>" + (applied.converter.bus || "bus") + "</div></div>" +
      "<div class='info-card'><div class='lbl'>Electrical model</div><div class='val' style='font-size:11px;'>" + (applied.converter.electrical_model || "") + "</div></div>" +
      "<div class='info-card'><div class='lbl'>k_m</div><div class='val'>" + dmNum(ac.k_m) + "</div></div></div>" +
      "<div class='panel-title' style='margin-top:12px;'>Active controller</div>" +
      "<div class='eq-readout' style='font-size:12px;'>" + (ac.label || "") + " &middot; manifold " + (ac.manifold_residual || "") + "</div>" +
      "<div class='law-box' style='font-size:12px;word-break:break-word;margin-top:8px;'>u = " + (ac.law || "") + "</div>";
    el.appendChild(cc);

    var cl = r.closed_loop;
    var clp = document.createElement("div"); clp.className = "panel";
    clp.innerHTML = "<div class='panel-title'>Closed-loop simulation \u2014 baseline vs MRC (same assembled network)</div>" +
      "<div class='help-text'>Reruns the identical assembled network, equilibrium and disturbance with the converter open-loop (baseline) and with MRC active.</div>";
    if (!cl) {
      var clBtn = document.createElement("button"); clBtn.className = "run-stage"; clBtn.id = "clRunBtn";
      clBtn.textContent = "Run Closed-Loop Simulation (baseline vs MRC)"; clBtn.onclick = runNetworkClosedLoop;
      clp.appendChild(clBtn);
    }
    el.appendChild(clp);

    if (cl) {
      var bap = document.createElement("div"); bap.className = "panel";
      bap.innerHTML = "<div class='panel-title'>Before / After \u2014 baseline vs MRC</div>" +
        "<div class='help-text'>Manifold residual e_m(t) on the assembled network: baseline (converter open-loop) vs MRC.</div>" +
        "<div id='clResidChart'></div><div id='clVbChart' style='margin-top:14px;'></div>";
      el.appendChild(bap);

      var mp2 = document.createElement("div"); mp2.className = "panel";
      mp2.innerHTML = "<div class='panel-title'>Comparison metrics (assembled network)</div>" +
        "<table style='width:100%;border-collapse:collapse;font-size:12px;' data-testid='cl-metrics'>" +
        "<tr style='color:var(--text-dim);text-align:left;font-size:10px;text-transform:uppercase;'><th style='padding:3px 8px 3px 0;'>Metric</th><th>Baseline</th><th>MRC</th></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;'>final |e_m|</td><td>" + dmNum(Math.abs(cl.baseline.final_residual)) + "</td><td style='color:#6EE7B7;'>" + dmNum(Math.abs(cl.mrc.final_residual)) + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;'>final \u2016x\u2212x*\u2016</td><td>" + dmNum(cl.baseline.final_deviation) + "</td><td style='color:#6EE7B7;'>" + dmNum(cl.mrc.final_deviation) + "</td></tr>" +
        "</table><div class='help-text' style='margin-top:6px;'>" + (cl.disclaimer || "") + "</div>";
      var csvBtn2 = document.createElement("button"); csvBtn2.className = "secondary-btn no-print"; csvBtn2.textContent = "Export CSV (baseline vs MRC)";
      csvBtn2.onclick = function () { exportClosedLoopCsv(cl); };
      mp2.appendChild(csvBtn2); el.appendChild(mp2);
      setTimeout(function () { drawClosedLoopCharts(cl); }, 0);
    }
  }

  appendDesignMrcClaims(el); appendContinueToReport(el);
}

async function applyMrcToConverter() {
  var btn = $("applyMrcBtn"); if (btn) { btn.disabled = true; btn.textContent = "Applying\u2026"; }
  var box = $("wsError"); if (box) box.style.display = "none";
  try {
    var body = { params: designerParamsForProject(), km: formState.km || 500, v_bus_init: formState.v_bus_init || 400 };
    var res = await postJson("/api/network_mrc/apply", body);
    if (stageResults.design_mrc) stageResults.design_mrc.applied = res;
    renderWorkspace();
  } catch (e) {
    var b = $("wsError"); if (b) { b.style.display = "block"; b.textContent = "Apply MRC failed: " + (e && e.message ? e.message : String(e)); }
  } finally {
    var b2 = $("applyMrcBtn"); if (b2) { b2.disabled = false; b2.textContent = "Apply MRC to Converter"; }
  }
}

async function runNetworkClosedLoop() {
  var btn = $("clRunBtn"); if (btn) { btn.disabled = true; btn.textContent = "Simulating\u2026"; }
  var box = $("wsError"); if (box) box.style.display = "none";
  try {
    var eq = stageResults.equilibrium;
    var body = { params: designerParamsForProject(), km: formState.km || 500, v_bus_init: formState.v_bus_init || 400,
                 x_star: eq && eq.x_star, disturbance: (formState.disturbance_value || [-5, 0, 0]).slice(), horizon: formState.horizon || 0.02 };
    var res = await postJson("/api/network_mrc/closed_loop", body);
    if (stageResults.design_mrc) stageResults.design_mrc.closed_loop = res;
    renderWorkspace();
  } catch (e) {
    var b = $("wsError"); if (b) { b.style.display = "block"; b.textContent = "Closed-loop simulation failed: " + (e && e.message ? e.message : String(e)); }
  } finally {
    var b2 = $("clRunBtn"); if (b2) { b2.disabled = false; b2.textContent = "Run Closed-Loop Simulation (baseline vs MRC)"; }
  }
}

function drawClosedLoopCharts(cl) {
  var b = cl.baseline, m = cl.mrc; if (!b || !m) return;
  var t = b.t;
  var residEl = $("clResidChart");
  if (residEl && b.residual && m.residual) {
    var w = 640, h = 240, mg = { l: 64, r: 14, t: 16, b: 46 };
    var bPts = t.map(function (tv, i) { return [tv * 1000, b.residual[i]]; });
    var mPts = m.t.map(function (tv, i) { return [tv * 1000, m.residual[i]]; });
    var bounds = computeBounds([bPts, mPts], 0.1);
    residEl.innerHTML = "<div style='font-family:var(--display);font-weight:700;font-size:12px;margin:8px 0 6px;'>Manifold residual e_m (V)</div><canvas id='clResidCanvas' width='" + w + "' height='" + h + "' style='width:100%;max-width:" + w + "px;background:var(--panel-alt);border-radius:6px;'></canvas>" + chartLegendHtml([{ color: "#FF6B6B", label: "baseline (open-loop)" }, { color: "#3FE0A8", label: "MRC" }]);
    var ctx = $("clResidCanvas").getContext("2d");
    drawGrid(ctx, bounds, w, h, mg, "time (ms)", "e_m (V)", { tickFontSize: 13 });
    drawLine(ctx, [[bounds.xmin, 0], [bounds.xmax, 0]], bounds, w, h, mg, "#556", 1, [4, 3]);
    drawLine(ctx, bPts, bounds, w, h, mg, "#FF6B6B", 2);
    drawLine(ctx, mPts, bounds, w, h, mg, "#3FE0A8", 2.2);
  }
  var vbEl = $("clVbChart");
  if (vbEl && b.v_bus && m.v_bus) {
    var w2 = 640, h2 = 240, m2 = { l: 64, r: 14, t: 16, b: 46 };
    var bV = t.map(function (tv, i) { return [tv * 1000, b.v_bus[i]]; });
    var mV = m.t.map(function (tv, i) { return [tv * 1000, m.v_bus[i]]; });
    var vbStar = cl.x_star && cl.x_star[0];
    var bounds2 = computeBounds([bV, mV], 0.1);
    vbEl.innerHTML = "<div style='font-family:var(--display);font-weight:700;font-size:12px;margin:8px 0 6px;'>Bus voltage v_bus (V)</div><canvas id='clVbCanvas' width='" + w2 + "' height='" + h2 + "' style='width:100%;max-width:" + w2 + "px;background:var(--panel-alt);border-radius:6px;'></canvas>" + chartLegendHtml([{ color: "#FF6B6B", label: "baseline" }, { color: "#3FE0A8", label: "MRC" }, { color: "#FFB454", label: "v_bus*", dashed: true }]);
    var ctx2 = $("clVbCanvas").getContext("2d");
    drawGrid(ctx2, bounds2, w2, h2, m2, "time (ms)", "v_bus (V)", { tickFontSize: 13 });
    if (vbStar != null) drawLine(ctx2, [[bounds2.xmin, vbStar], [bounds2.xmax, vbStar]], bounds2, w2, h2, m2, "#FFB454", 1.2, [5, 4]);
    drawLine(ctx2, bV, bounds2, w2, h2, m2, "#FF6B6B", 2);
    drawLine(ctx2, mV, bounds2, w2, h2, m2, "#3FE0A8", 2.2);
  }
}

function exportClosedLoopCsv(cl) {
  var b = cl.baseline, m = cl.mrc, t = b.t;
  var rows = ["t_s,e_m_baseline,e_m_mrc,v_bus_baseline,v_bus_mrc"];
  for (var i = 0; i < t.length; i++) {
    rows.push([t[i], b.residual[i], m.residual[i], b.v_bus[i], m.v_bus[i]].join(","));
  }
  var blob = new Blob([rows.join("\n")], { type: "text/csv" });
  var a = document.createElement("a"); a.href = URL.createObjectURL(blob);
  a.download = "network_mrc_baseline_vs_mrc.csv"; a.click();
  setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
}

/* ---- General Network-Builder MRC capability (custom_network projects) ----
   Runs the REAL automatic MRC derivation pipeline
   (mrc_designer.auto_manifold.run_auto_mrc_pipeline, via
   /api/network_mrc/inspect|auto_apply|auto_closed_loop) on THIS project's
   own builderSpec -- the same Network Builder model already built and
   analyzed in the earlier stages, not a separate demo network. The result
   is never forced to SUPPORTED: it is read directly off the pipeline's own
   status (MRC_SYNTHESIS_SUPPORTED / MRC_FEASIBILITY_DIAGNOSTIC_ONLY /
   MRC_SYNTHESIS_NOT_ESTABLISHED). */

function customMrcStatusKey(pipelineStatus) {
  if (pipelineStatus === "MRC_SYNTHESIS_SUPPORTED") return "supported";
  // Bus-voltage-anchored second-candidate (M2, "reshaped manifold")
  // outcome: a genuine, feasibility-and-stability-gated SUPPORTED result
  // (see run_auto_mrc_pipeline / attempt_bus_voltage_manifold_reshaping
  // on the backend) -- must be its own status key, not silently folded
  // into "not_established" (that mismatch between the UI and the actual
  // pipeline result was found during end-to-end validation).
  if (pipelineStatus === "MRC_SYNTHESIS_SUPPORTED_VIA_RESHAPED_MANIFOLD") return "supported_reshaped";
  if (pipelineStatus === "MRC_FEASIBILITY_DIAGNOSTIC_ONLY") return "diagnostic";
  return "not_established";
}

function customMrcConverterCandidates() {
  return (builderSpec.converters || []).map(function (c) { return c.id; });
}

async function runCustomFeasibility() {
  var btn = $("customFeasBtn"); if (btn) { btn.disabled = true; btn.textContent = "Running automatic MRC derivation pipeline\u2026"; }
  var box = $("wsError"); if (box) box.style.display = "none";
  try {
    var convId = formState.mrc_converter_id || undefined;
    var body = { network_spec: builderSpec, nominal_input: formState.nominal_input, converter_id: convId };
    var res = await postJson("/api/network_mrc/inspect", body);
    var pr = res.pipeline_report || {};
    stageResults.design_mrc = {
      status: customMrcStatusKey(pr.status), custom: true, inspect: res,
      converter_id: pr.converter_id,
    };
    renderWorkspace();
  } catch (e) {
    var b = $("wsError"); if (b) { b.style.display = "block"; b.textContent = "Feasibility check failed: " + (e && e.message ? e.message : String(e)); }
  } finally {
    var b2 = $("customFeasBtn"); if (b2) { b2.disabled = false; b2.textContent = "Run: Design MRC Controller"; }
  }
}

function renderCustomMrcFeasibility(el) {
  var r = stageResults.design_mrc;
  var candidates = customMrcConverterCandidates();

  if (!r || !r.inspect) {
    var runPanel = document.createElement("div"); runPanel.className = "panel no-print";
    runPanel.innerHTML = "<div class='panel-title'>Design MRC Controller (assembled Network Builder model)</div>" +
      "<div class='help-text'>Runs the full automatic MRC derivation pipeline on THIS project's own assembled model: control-affine split f(x)+G(x)u, automatic construction of a candidate signed controlled-target manifold \u03C6(x) for the converter, D\u03C6\u00B7G feasibility, closed-form synthesis, independent numeric re-verification, and transverse/tangential stability separation. Honest per-model \u2014 never forced to SUPPORTED.</div>";
    if (candidates.length > 1) {
      runPanel.innerHTML += "<div class='field-group-label' style='margin-top:10px;'>Target converter</div>";
      var sel = document.createElement("select"); sel.id = "mrcConverterSelect";
      candidates.forEach(function (cid) {
        var opt = document.createElement("option"); opt.value = cid; opt.textContent = cid;
        if (cid === formState.mrc_converter_id) opt.selected = true;
        sel.appendChild(opt);
      });
      sel.onchange = function () { formState.mrc_converter_id = sel.value; };
      runPanel.appendChild(sel);
    } else if (candidates.length === 1) {
      formState.mrc_converter_id = candidates[0];
    }
    var b = document.createElement("button"); b.className = "run-stage"; b.id = "customFeasBtn";
    b.textContent = "Run: Design MRC Controller"; b.onclick = runCustomFeasibility;
    runPanel.appendChild(b); el.appendChild(runPanel);
    appendDesignMrcClaims(el); appendContinueToReport(el); return;
  }

  var f = r.inspect; var pr = f.pipeline_report || {}; var authOk = !!f.control_authority;
  var fp = document.createElement("div"); fp.className = "panel";
  var h = "<div class='panel-title'>MRC Feasibility \u2014 automatic derivation pipeline result</div>" +
    "<div style='margin-bottom:10px;'>" + dmStatusBadge(r.status) + "</div><div class='info-grid'>" +
    "<div class='info-card'><div class='lbl'>dim x</div><div class='val'>" + (f.dim_x != null ? f.dim_x : "\u2014") + "</div></div>" +
    "<div class='info-card'><div class='lbl'>dim u</div><div class='val'>" + (f.dim_u != null ? f.dim_u : "\u2014") + "</div></div>" +
    "<div class='info-card'><div class='lbl'>rank(D\u03C6\u00B7G)</div><div class='val'>" + (pr.rank_A != null ? pr.rank_A : "\u2014") + "</div></div>" +
    "<div class='info-card'><div class='lbl'>relative degree</div><div class='val'>" + (pr.relative_degree != null ? pr.relative_degree : "\u2014") + "</div></div></div>";
  h += "<div style='margin-top:10px;display:flex;flex-direction:column;gap:6px;'>" +
    "<div style='font-size:11.5px;'><span style='color:" + (authOk ? "#3FE0A8" : "#FFB454") + ";'>\u25CF</span> Control channel f(x)+G(x)u: <b>" + (authOk ? "PRESENT" : "ABSENT") + "</b> (G " + (authOk ? "enters" : "does not enter") + " the state dynamics)</div>";
  if (pr.candidate_phi) {
    h += "<div style='font-size:11.5px;'><span style='color:#3FE0A8;'>\u25CF</span> Candidate signed controlled-target manifold: <span style='font-family:monospace;'>" + pr.candidate_phi + "</span></div>";
  }
  h += "</div>";
  if (pr.converter_id) h += "<div class='help-text' style='margin-top:8px;'>Target converter: <b>" + pr.converter_id + "</b> (topology: " + (pr.topology || "\u2014") + ")</div>";
  h += "<div class='help-text' style='margin-top:6px;'>" + (pr.reason || f.reason || "") + "</div>";
  fp.innerHTML = h; el.appendChild(fp);

  if (r.status === "not_established") { appendDesignMrcClaims(el); appendContinueToReport(el); return; }

  var isReshaped = (r.status === "supported_reshaped");
  var sp = document.createElement("div"); sp.className = "panel";
  sp.innerHTML = "<div class='panel-title'>" + (isReshaped ? "M1 \u2014 current-anchored candidate \u03C6\u2081 (rejected: unstable reduced dynamics)" : "Synthesized control law &nbsp; u = \u03BA(x)") + "</div>" +
    "<div class='law-box' style='font-size:12.5px;word-break:break-word;'>" + (pr.control_law_latex || pr.derived_control_law || "") + "</div>";
  el.appendChild(sp);

  var ce = pr.contraction_residual || {};
  var vp = document.createElement("div"); vp.className = "panel";
  var vh = "<div class='panel-title'>" + (isReshaped ? "M1 closed-loop verification (diagnostic only, not the active controller)" : "Closed-loop verification") + "</div><div class='info-grid'>" +
    "<div class='info-card'><div class='lbl'>\u03BB\u22A5 vs \u2212k_m</div><div class='val'>" + dmCplx(pr.transverse_eigenvalue) + (pr.transverse_matches_km ? " \u2713" : " \u2717") + "</div></div>" +
    "<div class='info-card'><div class='lbl'>residual rel-err</div><div class='val'>" + dmNum(ce.max_relative_error, 3) + "</div></div>" +
    "<div class='info-card'><div class='lbl'>tangential stable</div><div class='val'>" + (pr.tangential_locally_stable ? "yes" : "no") + "</div></div></div>";
  if (pr.closed_loop_eigenvalues) vh += "<div class='help-text' style='margin-top:8px;'>closed-loop poles: " + pr.closed_loop_eigenvalues.map(dmCplx).join(", ") + "</div>";
  vh += "<div style='margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;'>" +
    "<span style='font-size:10.5px;border:1px solid #10B981;color:#10B981;border-radius:4px;padding:2px 7px;'>exact transverse residual identity: " + (ce.identity || "") + "</span>" +
    "<span style='font-size:10.5px;border-radius:4px;padding:2px 7px;border:1px solid " + (pr.tangential_locally_stable ? "#3FE0A8;color:#3FE0A8" : "#FFB454;color:#FFB454") + ";'>local tangential stability: " + (pr.tangential_locally_stable ? "stable" : "NOT guaranteed") + "</span></div>";
  vp.innerHTML = vh; el.appendChild(vp);

  if (isReshaped && pr.manifold_reshaping) {
    var mr = pr.manifold_reshaping;
    var chosen = mr.chosen_entry || {};
    var tnd = chosen.tangent_normal_decomposition || {};
    var rh = tnd.routh_hurwitz_2x2 || {};
    var feas = chosen.physical_feasibility || {};
    var mrp = document.createElement("div"); mrp.className = "panel";
    var mh = "<div class='panel-title'>M2 \u2014 bus-voltage-anchored reshaped candidate \u03C6\u2082 (ACTIVE, both transverse and reduced dynamics stable)</div>" +
      "<div class='law-box' style='font-size:12px;word-break:break-word;margin-bottom:10px;'>" + (mr.control_law2_latex || "") + "</div>" +
      "<div class='info-grid'>" +
      "<div class='info-card'><div class='lbl'>selected R_v</div><div class='val'>" + dmNum(mr.chosen_R_v) + "</div></div>" +
      "<div class='info-card'><div class='lbl'>K_i</div><div class='val'>" + dmNum(mr.K_i) + "</div></div>" +
      "<div class='info-card'><div class='lbl'>k_m</div><div class='val'>" + dmNum(mr.k_m) + "</div></div>" +
      "<div class='info-card'><div class='lbl'>A2(x) at candidate</div><div class='val'>" + dmNum(chosen.A2_center) + "</div></div>" +
      "<div class='info-card'><div class='lbl'>\u03BB\u22A5 (transverse)</div><div class='val'>" + dmCplx(chosen.transverse_eigenvalue) + "</div></div>" +
      "<div class='info-card'><div class='lbl'>\u03B1\u2225 (reduced)</div><div class='val'>" + dmNum(chosen.alpha_parallel) + "</div></div>" +
      "<div class='info-card'><div class='lbl'>trace(J\u2225)</div><div class='val'>" + dmNum(rh.trace) + "</div></div>" +
      "<div class='info-card'><div class='lbl'>det(J\u2225)</div><div class='val'>" + dmNum(rh.det) + "</div></div>" +
      "<div class='info-card'><div class='lbl'>Routh-Hurwitz</div><div class='val'>" + (rh.hurwitz_stable ? "STABLE" : "unstable") + "</div></div>" +
      "<div class='info-card'><div class='lbl'>equilibrium duty</div><div class='val'>" + dmNum(feas.duty_at_equilibrium) + "</div></div>" +
      "<div class='info-card'><div class='lbl'>duty feasible</div><div class='val'>" + (feas.feasible ? "yes" : "no") + "</div></div>" +
      "<div class='info-card'><div class='lbl'>saturated at eq.</div><div class='val'>" + (feas.duty_saturated ? "yes" : "no") + "</div></div></div>" +
      "<div class='help-text' style='margin-top:8px;'><b>" + (pr.classification || "") + "</b> \u2014 the reshaped manifold is only classified supported because BOTH \u03BB\u22A5&lt;0 and \u03B1\u2225&lt;0 (full Routh-Hurwitz, not trace alone) AND the equilibrium duty is within the converter's physical [0.02, 0.98] clamp.</div>";
    mrp.innerHTML = mh; el.appendChild(mrp);
  }

  // ---- Apply MRC to Converter (actual Network Builder converter) ----
  var applied = r.applied;
  var ap = document.createElement("div"); ap.className = "panel";
  ap.innerHTML = "<div class='panel-title'>Apply MRC to Converter</div>" +
    "<div class='help-text'>Assign the automatically-derived law as the active controller of converter <b>" + (pr.converter_id || "") + "</b> in this project's assembled network, then run baseline vs MRC on that identical model.</div>";
  if (!applied) {
    var applyBtn = document.createElement("button"); applyBtn.className = "run-stage"; applyBtn.id = "applyMrcBtn";
    applyBtn.textContent = "Apply MRC to Converter"; applyBtn.onclick = applyAutoMrcToConverter;
    ap.appendChild(applyBtn);
  }
  el.appendChild(ap);

  if (applied) {
    var ac = (applied.converter && applied.converter.active_controller) || {};
    var cc = document.createElement("div"); cc.className = "panel";
    cc.innerHTML = "<div class='panel-title'>Converter controller configuration</div>" +
      "<div style='margin-bottom:8px;'><span style='display:inline-block;font-size:11px;font-weight:700;color:#3FE0A8;border:1px solid #3FE0A8;border-radius:4px;padding:3px 10px;'>MRC ACTIVE ON CONVERTER &#39;" + (applied.converter.id || "") + "&#39;</span></div>" +
      "<div class='info-grid'>" +
      "<div class='info-card'><div class='lbl'>Converter</div><div class='val'>" + (applied.converter.id || "") + "</div></div>" +
      "<div class='info-card'><div class='lbl'>Bus</div><div class='val'>" + (applied.converter.bus || "") + "</div></div>" +
      "<div class='info-card'><div class='lbl'>Electrical model</div><div class='val' style='font-size:11px;'>" + (applied.converter.electrical_model || "") + "</div></div>" +
      "<div class='info-card'><div class='lbl'>Topology</div><div class='val'>" + (ac.topology || "") + "</div></div></div>" +
      "<div class='panel-title' style='margin-top:12px;'>Active controller</div>" +
      "<div class='eq-readout' style='font-size:12px;'>" + (ac.label || "") + "</div>" +
      "<div class='law-box' style='font-size:12px;word-break:break-word;margin-top:8px;'>" + (ac.law_latex || "") + "</div>";
    el.appendChild(cc);

    var cl = r.closed_loop;
    var clp = document.createElement("div"); clp.className = "panel";
    clp.innerHTML = "<div class='panel-title'>Closed-loop simulation \u2014 baseline vs MRC (same assembled network)</div>" +
      "<div class='help-text'>Reruns this project's identical assembled network from its own equilibrium under a matched disturbance, once with the original (pre-MRC) controller and once with MRC active.</div>";
    if (!cl) {
      var clBtn = document.createElement("button"); clBtn.className = "run-stage"; clBtn.id = "clRunBtn";
      clBtn.textContent = "Run Closed-Loop Simulation (baseline vs MRC)"; clBtn.onclick = runAutoNetworkClosedLoop;
      clp.appendChild(clBtn);
    }
    el.appendChild(clp);

    if (cl) {
      var bap = document.createElement("div"); bap.className = "panel";
      bap.innerHTML = "<div class='panel-title'>Before / After \u2014 baseline vs MRC</div>" +
        "<div class='help-text'>Inductor current i_L(t) and bus voltage v_bus(t) on the assembled network: baseline (original controller) vs MRC, from the identical disturbance.</div>" +
        "<div id='autoClIlChart'></div><div id='autoClVbChart' style='margin-top:14px;'></div>";
      el.appendChild(bap);

      var clc = cl.closed_loop_comparison || {};
      var cb = clc.baseline || {}, cm = clc.mrc || {};
      var mp2 = document.createElement("div"); mp2.className = "panel";
      mp2.innerHTML = "<div class='panel-title'>Comparison metrics (assembled network)</div>" +
        "<table style='width:100%;border-collapse:collapse;font-size:12px;' data-testid='cl-metrics'>" +
        "<tr style='color:var(--text-dim);text-align:left;font-size:10px;text-transform:uppercase;'><th style='padding:3px 8px 3px 0;'>Metric</th><th>Baseline</th><th>MRC</th></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;'>final \u2016x\u2212x*\u2016</td><td>" + dmNum(cb.final_deviation) + "</td><td style='color:#6EE7B7;'>" + dmNum(cm.final_deviation) + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;'>recovered within horizon</td><td>" + (cb.recovered ? "yes" : "no") + "</td><td style='color:#6EE7B7;'>" + (cm.recovered ? "yes" : "no") + "</td></tr>" +
        "</table><div class='help-text' style='margin-top:6px;'>" + (cl.disclaimer || "") + "</div>";
      var csvBtn2 = document.createElement("button"); csvBtn2.className = "secondary-btn no-print"; csvBtn2.textContent = "Export CSV (baseline vs MRC)";
      csvBtn2.onclick = function () { exportAutoClosedLoopCsv(clc); };
      mp2.appendChild(csvBtn2); el.appendChild(mp2);
      setTimeout(function () { drawAutoClosedLoopCharts(clc, "autoClIlChart", "autoClVbChart"); }, 0);

      // Baseline vs M1 vs M2, identical conditions -- only present for the
      // reshaped-manifold (M2) outcome. Shows the distinction explicitly:
      // M1 achieves exact transverse attraction to its manifold but has
      // UNSTABLE reduced dynamics, while M2 reshapes the manifold so both
      // the transverse and reduced dynamics are locally stable.
      if (cl.baseline_m1_m2_comparison) {
        var b3 = cl.baseline_m1_m2_comparison.baseline || {};
        var m1r = cl.baseline_m1_m2_comparison.m1 || {};
        var m2r = cl.baseline_m1_m2_comparison.m2 || {};
        var tp = document.createElement("div"); tp.className = "panel";
        var th = "<div class='panel-title'>Baseline vs M1 vs M2 — identical network, equilibrium, disturbance, solver, tolerances and horizon</div>" +
          "<table style='width:100%;border-collapse:collapse;font-size:12px;' data-testid='baseline-m1-m2-metrics'>" +
          "<tr style='color:var(--text-dim);text-align:left;font-size:10px;text-transform:uppercase;'><th style='padding:3px 8px 3px 0;'>Metric</th><th>Baseline</th><th>M1 (φ₁, current-anchored)</th><th>M2 (φ₂, reshaped, ACTIVE)</th></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;'>final ‖x−x*‖</td><td>" + dmNum(b3.final_deviation) + "</td><td>" + dmNum(m1r.final_deviation) + "</td><td style='color:#6EE7B7;'>" + dmNum(m2r.final_deviation) + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;'>recovered within horizon</td><td>" + (b3.recovered ? "yes" : "no") + "</td><td style='color:" + (m1r.recovered ? "#6EE7B7" : "#FF6B6B") + ";'>" + (m1r.recovered ? "yes" : "no") + "</td><td style='color:#6EE7B7;'>" + (m2r.recovered ? "yes" : "no") + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;'>saturated at any point</td><td>—</td><td>" + (m1r.saturated_at_any_point ? "yes" : "no") + "</td><td>" + (m2r.saturated_at_any_point ? "yes" : "no") + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;'>saturation fraction of horizon</td><td>—</td><td>" + dmNum(m1r.saturation_fraction_of_horizon, 3) + "</td><td>" + dmNum(m2r.saturation_fraction_of_horizon, 3) + "</td></tr>" +
          "</table><div class='help-text' style='margin-top:8px;'>M1 achieves fast transverse attraction to its manifold φ₁, but its reduced/tangential dynamics are unstable, so the state does not stay near equilibrium; M2 reshapes the target manifold (φ₂, bus-voltage-anchored) so that both the transverse AND reduced dynamics are locally stable. Finite-horizon simulation evidence on the actual assembled model — not a certified regional IMS guarantee.</div>";
        tp.innerHTML = th; el.appendChild(tp);
      }
    }
  }

  appendDesignMrcClaims(el); appendContinueToReport(el);
}

async function applyAutoMrcToConverter() {
  var btn = $("applyMrcBtn"); if (btn) { btn.disabled = true; btn.textContent = "Applying\u2026"; }
  var box = $("wsError"); if (box) box.style.display = "none";
  try {
    var convId = (stageResults.design_mrc && stageResults.design_mrc.converter_id) || formState.mrc_converter_id;
    var body = { network_spec: builderSpec, converter_id: convId };
    var res = await postJson("/api/network_mrc/auto_apply", body);
    if (stageResults.design_mrc) stageResults.design_mrc.applied = res;
    renderWorkspace();
  } catch (e) {
    var b = $("wsError"); if (b) { b.style.display = "block"; b.textContent = "Apply MRC failed: " + (e && e.message ? e.message : String(e)); }
  } finally {
    var b2 = $("applyMrcBtn"); if (b2) { b2.disabled = false; b2.textContent = "Apply MRC to Converter"; }
  }
}

async function runAutoNetworkClosedLoop() {
  var btn = $("clRunBtn"); if (btn) { btn.disabled = true; btn.textContent = "Simulating\u2026"; }
  var box = $("wsError"); if (box) box.style.display = "none";
  try {
    var convId = (stageResults.design_mrc && stageResults.design_mrc.converter_id) || formState.mrc_converter_id;
    var body = { network_spec: builderSpec, converter_id: convId };
    var res = await postJson("/api/network_mrc/auto_closed_loop", body);
    if (stageResults.design_mrc) stageResults.design_mrc.closed_loop = res;
    renderWorkspace();
  } catch (e) {
    var b = $("wsError"); if (b) { b.style.display = "block"; b.textContent = "Closed-loop simulation failed: " + (e && e.message ? e.message : String(e)); }
  } finally {
    var b2 = $("clRunBtn"); if (b2) { b2.disabled = false; b2.textContent = "Run Closed-Loop Simulation (baseline vs MRC)"; }
  }
}

function drawAutoClosedLoopCharts(clc, ilWrapId, vbWrapId) {
  var b = clc.baseline, m = clc.mrc; if (!b || !m || !b.t || !m.t) return;
  var ilEl = $(ilWrapId || "autoClIlChart");
  if (ilEl && b.i_L && m.i_L) {
    var w = 640, h = 240, mg = { l: 64, r: 14, t: 16, b: 46 };
    var bPts = b.t.map(function (tv, i) { return [tv * 1000, b.i_L[i]]; });
    var mPts = m.t.map(function (tv, i) { return [tv * 1000, m.i_L[i]]; });
    var bounds = computeBounds([bPts, mPts], 0.1);
    ilEl.innerHTML = "<div style='font-family:var(--display);font-weight:700;font-size:12px;margin:8px 0 6px;'>Inductor current i_L (A)</div><canvas id='" + (ilWrapId || "autoClIlChart") + "Canvas' width='" + w + "' height='" + h + "' style='width:100%;max-width:" + w + "px;background:var(--panel-alt);border-radius:6px;'></canvas>" + chartLegendHtml([{ color: "#FF6B6B", label: "baseline (original controller)" }, { color: "#3FE0A8", label: "MRC" }]);
    var ctx = $((ilWrapId || "autoClIlChart") + "Canvas").getContext("2d");
    drawGrid(ctx, bounds, w, h, mg, "time (ms)", "i_L (A)", { tickFontSize: 13 });
    drawLine(ctx, bPts, bounds, w, h, mg, "#FF6B6B", 2);
    drawLine(ctx, mPts, bounds, w, h, mg, "#3FE0A8", 2.2);
  }
  var vbEl = $(vbWrapId || "autoClVbChart");
  if (vbEl && b.v_bus && m.v_bus) {
    var w2 = 640, h2 = 240, m2 = { l: 64, r: 14, t: 16, b: 46 };
    var bV = b.t.map(function (tv, i) { return [tv * 1000, b.v_bus[i]]; });
    var mV = m.t.map(function (tv, i) { return [tv * 1000, m.v_bus[i]]; });
    var bounds2 = computeBounds([bV, mV], 0.1);
    vbEl.innerHTML = "<div style='font-family:var(--display);font-weight:700;font-size:12px;margin:8px 0 6px;'>Bus voltage v_bus (V)</div><canvas id='" + (vbWrapId || "autoClVbChart") + "Canvas' width='" + w2 + "' height='" + h2 + "' style='width:100%;max-width:" + w2 + "px;background:var(--panel-alt);border-radius:6px;'></canvas>" + chartLegendHtml([{ color: "#FF6B6B", label: "baseline" }, { color: "#3FE0A8", label: "MRC" }].concat(clc.v_nom != null ? [{ color: "#FFB454", label: "v_nom (target)", dashed: true }] : []));
    var ctx2 = $((vbWrapId || "autoClVbChart") + "Canvas").getContext("2d");
    drawGrid(ctx2, bounds2, w2, h2, m2, "time (ms)", "v_bus (V)", { tickFontSize: 13 });
    if (clc.v_nom != null) drawLine(ctx2, [[bounds2.xmin, clc.v_nom], [bounds2.xmax, clc.v_nom]], bounds2, w2, h2, m2, "#FFB454", 1.2, [5, 4]);
    drawLine(ctx2, bV, bounds2, w2, h2, m2, "#FF6B6B", 2);
    drawLine(ctx2, mV, bounds2, w2, h2, m2, "#3FE0A8", 2.2);
  }
}

function exportAutoClosedLoopCsv(clc) {
  var b = clc.baseline, m = clc.mrc; if (!b || !m || !b.t) return;
  var rows = ["t_s,i_L_baseline,i_L_mrc,v_bus_baseline,v_bus_mrc"];
  for (var i = 0; i < b.t.length; i++) {
    rows.push([b.t[i], b.i_L[i], (m.i_L && m.i_L[i] !== undefined) ? m.i_L[i] : "", b.v_bus[i], (m.v_bus && m.v_bus[i] !== undefined) ? m.v_bus[i] : ""].join(","));
  }
  var blob = new Blob([rows.join("\n")], { type: "text/csv" });
  var a = document.createElement("a"); a.href = URL.createObjectURL(blob);
  a.download = "custom_network_baseline_vs_mrc.csv"; a.click();
  setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
}

function appendDesignMrcClaims(el) {
  var c = document.createElement("div"); c.className = "panel";
  c.innerHTML = "<div class='panel-title'>Guarantee classification (kept strictly distinct)</div><div class='help-text' style='line-height:1.7;'>" +
    "<b>Ideal residual contraction</b> \u2014 exact (\u0117_m = \u2212k_m e_m) for the ideal unsaturated model.<br>" +
    "<b>Local equilibrium stability</b> \u2014 a linearisation claim about the equilibrium.<br>" +
    "<b>Observed finite-horizon recovery</b> \u2014 empirical, from one simulated scenario.<br>" +
    "<b>Certified regional IMS</b> \u2014 a stronger claim, NOT established by any of the above.</div>";
  el.appendChild(c);
}

function appendContinueToReport(el) {
  var cp = document.createElement("div"); cp.className = "panel no-print";
  cp.style.cssText = "text-align:center;background:var(--teal-dim);border-color:var(--teal);";
  var b = document.createElement("button"); b.className = "run-stage"; b.style.maxWidth = "320px"; b.style.margin = "0 auto";
  b.textContent = "\u2713 Continue to Generate Report \u2192"; b.onclick = function () { goToStage("report"); };
  cp.appendChild(b); el.appendChild(cp);
}
