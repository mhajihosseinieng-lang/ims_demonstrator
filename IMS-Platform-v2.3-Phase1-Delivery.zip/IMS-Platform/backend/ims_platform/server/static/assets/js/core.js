// IMS Platform / core.js — ordered classic script; public stage API stays stable.
/* ===================== GLOBAL STATE ===================== */
var projectsList = [];
var builderSpec = { buses: [], lines: [], loads: [], converters: [], sources: [], input_component_id: null };
var builderCounter = { bus: 0, line: 0, load: 0, converter: 0, source: 0 };
var currentProject = null;   // full project detail from /api/project/<id>
var stageResults = {};       // { build, equilibrium, simulate, ims_analysis }
var formState = {};          // current editable field values

var COLORS = {
  manifold: "#46E0B5", manifoldUnstable: "#FF6B6B",
  trajOpen: "#FFB454", trajClosed: "#6FC6FF",
  recRec: "#46E0B5", recNon: "#FF6B6B",
  // Quantity-type colors, requested for publication-quality
  // consistency (a print run of mostly-orange charts is hard to read
  // and doesn't visually distinguish voltage from current subplots):
  // voltage=blue, current=green, control/duty=purple, residual=red.
  voltage: "#6FC6FF", current: "#5FD98A", control: "#B389F9", residual: "#FF6B6B",
};

function $(id) { return document.getElementById(id); }

/* The only authority for switching between app surfaces. Never leave a
   previous view (including the embedded React MRC surface) visible. */
var APP_SURFACES = ["pmView", "builderView", "caseLibraryView", "iberianView",
  "gfmCaseView", "multiConverterCaseView", "stabMrcView", "analysisHubView",
  "mrcDesignerView", "wsView"];
function activateSurface(id, navLabel, breadcrumb) {
  if (APP_SURFACES.indexOf(id) === -1) throw new Error("Unknown platform surface: " + id);
  APP_SURFACES.forEach(function (surface) {
    var el = $(surface);
    if (el) el.style.display = surface === id ? "block" : "none";
  });
  var inWorkspace = id === "wsView";
  $("appShell").style.display = inWorkspace ? "none" : "flex";
  $("appFooter").style.display = inWorkspace ? "none" : "flex";
  if (breadcrumb !== undefined && $("crumbBar")) $("crumbBar").innerHTML = breadcrumb;
  if (navLabel) setAppNavActive(navLabel);
}


/* ===================== RECENT PROJECTS (real localStorage tracking) ===================== */

var RECENT_PROJECTS_KEY = "ims_recent_projects";
var RECENT_PROJECTS_MAX = 6;

function recordRecentProject(id, label) {
  try {
    var list = JSON.parse(localStorage.getItem(RECENT_PROJECTS_KEY) || "[]");
    list = list.filter(function (e) { return e.id !== id; });
    list.unshift({ id: id, label: label, ts: Date.now() });
    localStorage.setItem(RECENT_PROJECTS_KEY, JSON.stringify(list.slice(0, RECENT_PROJECTS_MAX)));
  } catch (e) { /* localStorage unavailable (e.g. private browsing) -- fail silently, not fatal */ }
}

function getRecentProjects() {
  try {
    return JSON.parse(localStorage.getItem(RECENT_PROJECTS_KEY) || "[]");
  } catch (e) { return []; }
}

function formatRelativeTime(ts) {
  var d = new Date(ts), now = new Date();
  var timeStr = d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  if (d.toDateString() === now.toDateString()) return "Today, " + timeStr;
  var yest = new Date(now); yest.setDate(now.getDate() - 1);
  if (d.toDateString() === yest.toDateString()) return "Yesterday, " + timeStr;
  return d.toLocaleDateString([], { month: "short", day: "numeric" }) + ", " + timeStr;
}

function renderRecentProjectsPanel() {
  var el = $("recentProjectsList"); if (!el) return;
  var recents = getRecentProjects();
  var badge = $("recentAnalysesCount"); if (badge) badge.textContent = recents.length;
  var strip = $("recentProjectsSection"); if (strip) strip.hidden = recents.length === 0;
  if (recents.length === 0) { el.innerHTML = ""; return; }
  el.innerHTML = recents.map(function (r) {
    return "<div class='recent-item' onclick=\"openProject('" + r.id + "')\">" +
      "<span class='recent-icon'>&#9635;</span>" +
      "<div class='recent-info'><b>" + r.label + "</b></div>" +
      "<span class='recent-time'>" + formatRelativeTime(r.ts) + "</span></div>";
  }).join("");
}


/* ===================== CANVAS PLOTTING (pure rendering, reused) ===================== */

function makeCanvas(container, heightPx) {
  container.innerHTML = "";
  var canvas = document.createElement("canvas");
  var w = container.clientWidth || 520;
  var dpr = Math.max(window.devicePixelRatio || 1, 2);
  canvas.width = w * dpr; canvas.height = heightPx * dpr;
  canvas.style.width = w + "px"; canvas.style.height = heightPx + "px";
  container.appendChild(canvas);
  var ctx = canvas.getContext("2d");
  ctx.scale(dpr, dpr);
  return { ctx: ctx, w: w, h: heightPx };
}

function computeBounds(pointSets, padFrac) {
  padFrac = padFrac || 0.12;
  var xs = [], ys = [];
  pointSets.forEach(function (pts) { pts.forEach(function (p) { if (p && Number.isFinite(p[0]) && Number.isFinite(p[1])) { xs.push(p[0]); ys.push(p[1]); } }); });
  if (!xs.length) return { xmin: -1, xmax: 1, ymin: -1, ymax: 1 };
  var xmin = Math.min.apply(null, xs), xmax = Math.max.apply(null, xs);
  var ymin = Math.min.apply(null, ys), ymax = Math.max.apply(null, ys);
  var xr = (xmax - xmin) || 1, yr = (ymax - ymin) || 1;
  return { xmin: xmin - xr * padFrac, xmax: xmax + xr * padFrac, ymin: ymin - yr * padFrac, ymax: ymax + yr * padFrac };
}

function chartLegendHtml(items) {
  // items: [{color, label, dashed:bool}]. Shared legend renderer so every
  // chart -- including single-trace ones with reference-threshold lines --
  // always labels what each color/line-style means, rather than leaving
  // the viewer to infer it from a bare title.
  var spans = items.map(function (it) {
    var swatch = it.dashed
      ? '<span style="display:inline-block;width:14px;height:1px;border-top:1.5px dashed ' + it.color + ';margin-right:4px;vertical-align:middle;"></span>'
      : '<span style="display:inline-block;width:9px;height:9px;background:' + it.color + ';border-radius:2px;margin-right:4px;"></span>';
    return '<span style="font-size:10.5px;color:var(--muted);">' + swatch + it.label + '</span>';
  });
  return '<div style="display:flex;gap:14px;margin-top:6px;flex-wrap:wrap;">' + spans.join('') + '</div>';
}

function mapPt(p, bounds, w, h, m) {
  var x = m.l + (p[0] - bounds.xmin) / (bounds.xmax - bounds.xmin) * (w - m.l - m.r);
  var y = h - m.b - (p[1] - bounds.ymin) / (bounds.ymax - bounds.ymin) * (h - m.t - m.b);
  return [x, y];
}

function formatTickValue(v) {
  // Adaptive precision: large magnitudes get fewer decimals, very
  // small/large magnitudes fall back to scientific notation, so tick
  // labels stay both readable and quantitatively meaningful across the
  // full range of values this platform's charts actually plot (residuals
  // as small as 1e-6, voltages/currents in the tens to hundreds).
  if (v === 0) return "0";
  var av = Math.abs(v);
  if (av >= 1e5 || av < 1e-3) return v.toExponential(1);
  if (av >= 100) return v.toFixed(0);
  if (av >= 10) return v.toFixed(1);
  if (av >= 1) return v.toFixed(2);
  return v.toFixed(3);
}

function drawGrid(ctx, bounds, w, h, m, xLabel, yLabel, opts) {
  opts = opts || {};
  var tickFont = opts.tickFontSize || 12.5;   // was 11.5 -- bumped per readability feedback (applies to ALL charts using drawGrid)
  var titleFont = opts.titleFontSize || 13;   // was 12.5
  var nx = 5, ny = 4;

  ctx.clearRect(0, 0, w, h);
  ctx.strokeStyle = "#1B2733"; ctx.lineWidth = 1;
  // Gridlines: at explicit tick positions when provided (so lines land
  // exactly under/beside the labels below), otherwise the old evenly-
  // spaced-by-count behaviour (unchanged default for every other chart
  // that calls drawGrid without opts).
  var xTickVals = opts.xTicks || null;
  var yTickVals = opts.yTicks || null;
  var xGridCount = xTickVals ? xTickVals.length - 1 : nx;
  var yGridCount = yTickVals ? yTickVals.length - 1 : ny;

  function xPix(val) { return m.l + (val - bounds.xmin) / (bounds.xmax - bounds.xmin) * (w - m.l - m.r); }
  function yPix(val) { return m.t + (bounds.ymax - val) / (bounds.ymax - bounds.ymin) * (h - m.t - m.b); }

  if (xTickVals) {
    xTickVals.forEach(function (v) {
      var gx = xPix(v);
      ctx.beginPath(); ctx.moveTo(gx, m.t); ctx.lineTo(gx, h - m.b); ctx.stroke();
    });
  } else {
    for (var i = 0; i <= nx; i++) {
      var gx0 = m.l + i / nx * (w - m.l - m.r);
      ctx.beginPath(); ctx.moveTo(gx0, m.t); ctx.lineTo(gx0, h - m.b); ctx.stroke();
    }
  }
  if (yTickVals) {
    yTickVals.forEach(function (v) {
      var gy = yPix(v);
      ctx.beginPath(); ctx.moveTo(m.l, gy); ctx.lineTo(w - m.r, gy); ctx.stroke();
    });
  } else {
    for (var j = 0; j <= ny; j++) {
      var gy0 = m.t + j / ny * (h - m.t - m.b);
      ctx.beginPath(); ctx.moveTo(m.l, gy0); ctx.lineTo(w - m.r, gy0); ctx.stroke();
    }
  }
  ctx.strokeStyle = "#4A6070"; ctx.lineWidth = 1.8;
  ctx.strokeRect(m.l, m.t, w - m.l - m.r, h - m.t - m.b);

  // Numerical tick VALUES. Two modes:
  //  - opts.xTicks/opts.yTicks given: use those EXACT values at their
  //    true data-relative pixel positions (fixes a real bug: without
  //    this, tick labels were auto-generated as N evenly-spaced points
  //    between bounds.xmin/xmax regardless of what data was actually
  //    plotted -- e.g. a severity axis spanning 0.2-1.0 auto-produced
  //    ticks at 0.2/0.36/0.52/0.68/0.84/1.0, which do not match the
  //    actual 0.2/0.4/0.6/0.8/1.0 severities the bars represent, and
  //    collided visually with the axis title below them).
  //  - no opts: unchanged behaviour (auto count-based), just larger font.
  ctx.fillStyle = "#CBD8E4"; ctx.font = tickFont + "px monospace";
  ctx.textAlign = "center"; ctx.textBaseline = "top";
  var tickLabelY = h - m.b + 8;
  if (xTickVals) {
    // xTickAutoReduce: pick a genuinely reduced, readable LABEL subset
    // when the actual data values are densely packed (e.g. a
    // parameter sweep deliberately sampled tighter near a boundary of
    // interest) -- selected greedily by minimum on-screen pixel gap,
    // always keeping the first and last value, rather than either
    // showing every value (illegible) or evenly subsampling by COUNT
    // (which could still land two close data points next to each
    // other). Gridlines/data points are untouched -- only which
    // values get an axis LABEL is reduced.
    var labelTickVals = xTickVals, labelTickLabels = opts.xTickLabels || null;
    if (opts.xTickAutoReduce && xTickVals.length > 2) {
      var minLabelGapPx = tickFont * 3.6;
      var xPixAll = xTickVals.map(function (v) { return xPix(v); });
      var keepIdx = [0];
      for (var ri = 1; ri < xTickVals.length; ri++) {
        if (xPixAll[ri] - xPixAll[keepIdx[keepIdx.length - 1]] >= minLabelGapPx) keepIdx.push(ri);
      }
      var lastIdx = xTickVals.length - 1;
      if (keepIdx[keepIdx.length - 1] !== lastIdx) {
        if (xPixAll[lastIdx] - xPixAll[keepIdx[keepIdx.length - 1]] < minLabelGapPx * 0.6) keepIdx[keepIdx.length - 1] = lastIdx;
        else keepIdx.push(lastIdx);
      }
      labelTickVals = keepIdx.map(function (i) { return xTickVals[i]; });
      labelTickLabels = opts.xTickLabels ? keepIdx.map(function (i) { return opts.xTickLabels[i]; }) : null;
    }
    if (opts.rotateXLabels) {
      // Rotate labels ~45 degrees rather than stacking them onto a
      // second row -- requested explicitly for dense sweeps (matches
      // the same approach already used in the matplotlib/report
      // version of this chart, so browser/HTML/PDF are visually
      // consistent). textAlign="right" with the rotation pivot at the
      // tick's own x position makes the label's right edge anchor at
      // the tick, reading diagonally down-left, the standard layout.
      ctx.textAlign = "right"; ctx.textBaseline = "middle";
      labelTickVals.forEach(function (v, idx) {
        var gx = xPix(v);
        ctx.save();
        ctx.translate(gx, tickLabelY + 4);
        ctx.rotate(-Math.PI / 4);
        ctx.fillText(labelTickLabels ? labelTickLabels[idx] : formatTickValue(v), 0, 0);
        ctx.restore();
      });
      ctx.textAlign = "center"; ctx.textBaseline = "top";
    } else {
      // Stagger alternating labels onto a second row when ticks are dense
      // (explicit, non-uniformly-spaced tick sets -- e.g. a parameter
      // sweep with more samples near an interesting boundary -- otherwise
      // overlap into an unreadable run of digits). Only engages when
      // labels are actually close together in PIXEL space, not just
      // whenever there happen to be many ticks.
      var xTickValsForStagger = labelTickVals, xTickLabelsForStagger = labelTickLabels;
      var minPixelGap = Infinity;
      var xPixPositions = xTickValsForStagger.map(function (v) { return xPix(v); });
      for (var k = 1; k < xPixPositions.length; k++) {
        minPixelGap = Math.min(minPixelGap, xPixPositions[k] - xPixPositions[k - 1]);
      }
      var approxLabelWidth = tickFont * 3.2; // rough monospace width for a "0.00"-style label
      var needsStagger = xTickValsForStagger.length > 1 && minPixelGap < approxLabelWidth;
      xTickValsForStagger.forEach(function (v, idx) {
        var gx = xPixPositions[idx];
        var ly = needsStagger && (idx % 2 === 1) ? tickLabelY + tickFont + 3 : tickLabelY;
        ctx.fillText(xTickLabelsForStagger ? xTickLabelsForStagger[idx] : formatTickValue(v), gx, ly);
      });
    }
  } else {
    for (var i2 = 0; i2 <= nx; i2++) {
      var gx2 = m.l + i2 / nx * (w - m.l - m.r);
      var xVal = bounds.xmin + (i2 / nx) * (bounds.xmax - bounds.xmin);
      ctx.fillText(formatTickValue(xVal), gx2, tickLabelY);
    }
  }
  ctx.textAlign = "right"; ctx.textBaseline = "middle";
  var tickLabelX = m.l - 9;
  if (yTickVals) {
    yTickVals.forEach(function (v, idx) {
      var gy = yPix(v);
      ctx.fillText(opts.yTickLabels ? opts.yTickLabels[idx] : formatTickValue(v), tickLabelX, gy);
    });
  } else {
    for (var j2 = 0; j2 <= ny; j2++) {
      var gy2 = m.t + j2 / ny * (h - m.t - m.b);
      var yVal = bounds.ymax - (j2 / ny) * (bounds.ymax - bounds.ymin);
      ctx.fillText(formatTickValue(yVal), tickLabelX, gy2);
    }
  }

  // Axis titles. Placed with an explicit gap below the tick labels (x)
  // and to the left of the tick labels (y) -- the previous fixed
  // offsets (h-6 for the x title, translate(13,..) for the y title)
  // could collide with tick labels depending on margin size; both are
  // now derived from the same margin the caller reserved, so as long as
  // the caller's margin is big enough (see the m.b/m.l values used by
  // the Iberian charts below) there is a guaranteed gap.
  ctx.fillStyle = "#DCE6EF"; ctx.font = titleFont + "px monospace";
  ctx.textAlign = "center"; ctx.textBaseline = "alphabetic";
  ctx.fillText(xLabel, m.l + (w - m.l - m.r) / 2, h - 6);
  if (yLabel) {
    // The y-axis title is drawn ROTATED, so its rendered length runs
    // along the plot's vertical extent (h - m.t - m.b), not its width --
    // a long title can literally run off the top/bottom of the canvas
    // (getting silently clipped by the canvas boundary) if that string,
    // at titleFont size, is longer than the available height. Caught by
    // pixel-inspecting an actual rendered chart: "Protection indicator
    // (0-1)" at the default title size overflowed past y=0. `opts.
    // yTitleFontSize` lets a caller with a long label shrink just the
    // y-title without affecting the x-title/tick font sizes.
    var yTitleFont = opts.yTitleFontSize || titleFont;
    ctx.font = yTitleFont + "px monospace";
    ctx.save(); ctx.translate(14, m.t + (h - m.t - m.b) / 2); ctx.rotate(-Math.PI / 2);
    ctx.fillText(yLabel, 0, 0); ctx.restore();
  }
}

function drawLine(ctx, pts, bounds, w, h, m, color, lineWidth, dash) {
  if (pts.length < 2) return;
  ctx.save();
  // Clip to the plot rectangle: a reference/threshold line (or any
  // series) must never render outside its own axes, regardless of
  // floating-point overshoot at the boundary or a caller passing a
  // point slightly outside [bounds.xmin,bounds.xmax]. Applied here
  // (not per-caller) so every chart that uses drawLine is covered.
  ctx.beginPath();
  ctx.rect(m.l, m.t, w - m.l - m.r, h - m.t - m.b);
  ctx.clip();
  ctx.strokeStyle = color; ctx.lineWidth = lineWidth || 2;
  ctx.lineJoin = "round"; ctx.lineCap = "round";
  if (dash) ctx.setLineDash(dash);
  ctx.beginPath();
  var pathOpen = false;
  pts.forEach(function (p) {
    if (!p || !Number.isFinite(p[0]) || !Number.isFinite(p[1])) { pathOpen = false; return; }
    var mp = mapPt(p, bounds, w, h, m);
    if (!pathOpen) { ctx.moveTo(mp[0], mp[1]); pathOpen = true; }
    else ctx.lineTo(mp[0], mp[1]);
  });
  ctx.stroke(); ctx.restore();
}

function drawMarker(ctx, p, bounds, w, h, m, color, shape, size) {
  var mp = mapPt(p, bounds, w, h, m);
  ctx.save(); ctx.fillStyle = color; ctx.strokeStyle = color;
  if (shape === "square") {
    ctx.fillRect(mp[0] - size / 2, mp[1] - size / 2, size, size);
  } else if (shape === "star") {
    ctx.beginPath();
    for (var i = 0; i < 5; i++) {
      var a1 = -Math.PI / 2 + i * 2 * Math.PI / 5, a2 = a1 + Math.PI / 5;
      var r1 = size, r2 = size * 0.45;
      ctx.lineTo(mp[0] + r1 * Math.cos(a1), mp[1] + r1 * Math.sin(a1));
      ctx.lineTo(mp[0] + r2 * Math.cos(a2), mp[1] + r2 * Math.sin(a2));
    }
    ctx.closePath(); ctx.fill();
  } else {
    ctx.beginPath(); ctx.arc(mp[0], mp[1], size / 2, 0, 2 * Math.PI); ctx.fill();
  }
  ctx.restore();
}

function drawScatter(ctx, pts, colorFn, bounds, w, h, m, size) {
  pts.forEach(function (p, i) {
    var mp = mapPt(p, bounds, w, h, m);
    ctx.fillStyle = colorFn(i);
    ctx.beginPath(); ctx.arc(mp[0], mp[1], size, 0, 2 * Math.PI); ctx.fill();
  });
}
