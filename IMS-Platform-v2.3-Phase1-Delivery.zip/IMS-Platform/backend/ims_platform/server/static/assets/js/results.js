// IMS Platform / results.js — ordered classic script; public stage API stays stable.
/* ===================== RESULTS RENDERING PER STAGE ===================== */

function renderStageResults(stage) {
  var el = $("stageResultsPanel");
  el.innerHTML = "";
  var data = stageResults[stage];

  if (stage === "report") { renderReportStage(el); return; }
  if (!data) { el.innerHTML = "<p class='placeholder-msg'>Run this stage to see results.</p>"; return; }

  if (stage === "build") {
    var ns = data.network_summary || {};
    var mo = data.model_order || {};
    var p = document.createElement("div"); p.className = "panel";
    p.innerHTML = "<div class='panel-title'>Network summary</div><div class='info-grid'>" +
      "<div class='info-card'><div class='lbl'>Buses</div><div class='val'>" + (ns.buses !== undefined ? ns.buses : "\u2014") + "</div></div>" +
      "<div class='info-card'><div class='lbl'>Converters</div><div class='val'>" + (ns.converters !== undefined ? ns.converters : "\u2014") + "</div></div>" +
      "<div class='info-card'><div class='lbl'>Loads</div><div class='val'>" + (ns.loads !== undefined ? ns.loads : "\u2014") + "</div></div>" +
      "<div class='info-card'><div class='lbl'>Lines</div><div class='val'>" + (ns.lines !== undefined ? ns.lines : "\u2014") + "</div></div>" +
      "<div class='info-card'><div class='lbl'>Controllers</div><div class='val'>" + (ns.controllers !== undefined ? ns.controllers : "\u2014") + "</div></div>" +
      "</div>";
    if (ns.converter_topologies && Object.keys(ns.converter_topologies).length) {
      p.innerHTML += "<div class='panel-title' style='margin-top:14px;'>Converter topologies</div><div class='info-grid'>" +
        Object.keys(ns.converter_topologies).map(function (t) {
          return "<div class='info-card'><div class='lbl'>" + t + "</div><div class='val'>" + ns.converter_topologies[t] + "</div></div>";
        }).join("") + "</div>";
    }
    if (ns.converter_control_modes && Object.keys(ns.converter_control_modes).length) {
      p.innerHTML += "<div class='panel-title' style='margin-top:14px;'>Control modes</div><div class='info-grid'>" +
        Object.keys(ns.converter_control_modes).map(function (t) {
          return "<div class='info-card'><div class='lbl'>" + t.replace("_", " ") + "</div><div class='val'>" + ns.converter_control_modes[t] + "</div></div>";
        }).join("") + "</div>";
    }
    if (data.topology_tree && data.topology_tree.length) {
      p.innerHTML += "<div class='panel-title' style='margin-top:14px;'>Topology tree</div>" +
        "<div class='eq-readout' style='font-size:12px;font-family:monospace;white-space:pre;'>" + data.topology_tree.join("\n") + "</div>";
    }
    if (data.component_chain && data.component_chain.length) {
      p.innerHTML += "<div class='panel-title' style='margin-top:14px;'>Component chain</div>" +
        "<div class='eq-readout' style='font-size:12px;'>" + data.component_chain.join("<br>&#8595;<br>") + "</div>";
    }
    el.appendChild(p);

    var mp = document.createElement("div"); mp.className = "panel";
    mp.innerHTML = "<div class='panel-title'>Mathematical model</div><div class='info-grid'>" +
      "<div class='info-card'><div class='lbl'>States</div><div class='val'>" + (mo.n_states !== undefined ? mo.n_states : data.state_names.length) + "</div></div>" +
      "<div class='info-card'><div class='lbl'>Inputs</div><div class='val'>" + (mo.n_inputs !== undefined ? mo.n_inputs : "\u2014") + "</div></div>" +
      "<div class='info-card'><div class='lbl'>Outputs</div><div class='val'>" + (mo.n_outputs !== undefined ? mo.n_outputs : "\u2014") + "</div></div>" +
      "</div>" +
      "<div class='panel-title' style='margin-top:14px;'>State variables</div>" +
      "<table style='width:100%;border-collapse:collapse;font-size:12px;'>" +
      "<tr style='color:var(--text-dim);text-align:left;font-size:10px;text-transform:uppercase;'><th style='padding:3px 8px 3px 0;'>State</th><th>Physical Meaning</th><th>Unit</th></tr>" +
      data.state_names.map(function (s, i) {
        var info = stateVariableInfo(s);
        return "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim);'>x" + (i + 1) + " (" + s + ")</td><td>" + info.meaning + "</td><td>" + info.unit + "</td></tr>";
      }).join("") + "</table>";
    if (data.engineering_outputs && data.engineering_outputs.length) {
      mp.innerHTML += "<div class='panel-title' style='margin-top:14px;'>Outputs</div>" +
        "<div class='eq-readout' style='font-size:12px;'>" + data.engineering_outputs.map(function (o) { return o.name + " <span style='color:var(--text-dim);font-size:10.5px;'>(" + o.kind + ")</span>"; }).join("<br>") + "</div>";
    }
    if (data.controller_description) {
      mp.innerHTML += "<div class='panel-title' style='margin-top:14px;'>Controller</div>" +
        "<div class='eq-readout' style='font-size:12px;'>" + data.controller_description + "</div>";
    }
    if (data.governing_equations && data.governing_equations.length) {
      mp.innerHTML += "<div class='panel-title' style='margin-top:14px;'>Governing equations</div>" +
        "<div class='law-box' style='font-size:12.5px;'>" + data.governing_equations.join("<br>") + "</div>";
    }
    if (data.admissible_envelope) {
      mp.innerHTML += "<div class='panel-title' style='margin-top:14px;'>Admissible operating envelope</div>" +
        "<div class='eq-readout' style='font-size:12px;'>" + data.admissible_envelope.description + "</div>" +
        "<div class='help-text' style='margin-top:4px;'>The exact bounds the model itself enforces (states outside this region are treated as inadmissible), not a separately-documented approximation.</div>";
    }
    el.appendChild(mp);

    if (data.control_law_str) {
      var lp = document.createElement("div"); lp.className = "panel";
      lp.innerHTML = "<div class='panel-title'>Automatically-derived MRC control law</div>" +
        "<div class='law-box'>u = " + data.control_law_str + "</div>" +
        "<div class='help-text' style='margin-top:8px;'>Derived symbolically by the Symbolic Engine \u2014 no linearisation, no Riccati equation. Symbolically identical to a published result (tests/test_mrc_synthesis.py).</div>";
      el.appendChild(lp);
    }
  }

  else if (stage === "equilibrium") {
    var p = document.createElement("div"); p.className = "panel";
    var eig = (data.eigenvalues || []).map(function (e) {
      return e.im === 0 ? e.re.toFixed(3) : (e.re.toFixed(3) + (e.im >= 0 ? "+" : "-") + Math.abs(e.im).toFixed(3) + "j");
    }).join(", ");
    p.innerHTML = "<div class='panel-title'>Equilibrium</div><div class='eq-readout'>" +
      "x* = [" + data.x_star.map(function (v) { return v.toFixed(4); }).join(", ") + "]<br>" +
      "stability: <b>" + (data.stable ? "STABLE" : "UNSTABLE") + "</b>" + (eig ? "<br>eigenvalues: " + eig : "") +
      "</div>";
    if (data.note) p.innerHTML += "<div class='note-box' style='margin-top:10px;'>" + data.note + "</div>";
    el.appendChild(p);

    if (data.x_star.length === 2) {
      var xpPanel = document.createElement("div"); xpPanel.className = "panel";
      xpPanel.innerHTML = "<div class='panel-title'>Equilibrium location (state plane)</div><div id='eqPlaneWrap'></div>";
      el.appendChild(xpPanel);
      var wrap = $("eqPlaneWrap");
      var labels = currentProject.state_short || ["x1", "x2"];
      var pad = Math.max(0.5, 0.3 * Math.max(Math.abs(data.x_star[0]), Math.abs(data.x_star[1]), 1));
      var bounds = { xmin: data.x_star[0] - pad, xmax: data.x_star[0] + pad, ymin: data.x_star[1] - pad, ymax: data.x_star[1] + pad };
      var m = { l: 58, r: 16, t: 14, b: 32 };
      var c = makeCanvas(wrap, 255);
      drawGrid(c.ctx, bounds, c.w, c.h, m, labels[0], labels[1]);
      drawMarker(c.ctx, data.x_star, bounds, c.w, c.h, m, "#DCE6EE", "star", 9);
      var help = document.createElement("div"); help.className = "help-text"; help.style.marginTop = "6px";
      help.textContent = "Equilibrium marked at [" + data.x_star.map(function (v) { return v.toFixed(4); }).join(", ") + "]; the full manifold and phase portrait appear at the IMS Analysis stage.";
      xpPanel.appendChild(help);
    }

    if (data.solver_diagnostics) {
      var sd = data.solver_diagnostics;
      var dp = document.createElement("div"); dp.className = "panel";
      dp.innerHTML = "<div class='panel-title'>Solver diagnostics</div><div class='info-grid'>" +
        "<div class='info-card'><div class='lbl'>Function evaluations</div><div class='val'>" + sd.function_evaluations + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Jacobian condition #</div><div class='val' style='font-size:13px'>" + sd.jacobian_condition_number.toExponential(2) + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Computation time</div><div class='val' style='font-size:13px'>" + (sd.computation_time_s * 1000).toFixed(2) + " ms</div></div>" +
        "</div>" +
        "<div class='help-text' style='margin-top:8px;'>Function evaluations are SciPy's own solver count (a modified Powell hybrid method, not literal textbook Newton iterations). A very large condition number indicates a near-singular Jacobian at this equilibrium \u2014 worth investigating, not necessarily an error.</div>";
      el.appendChild(dp);
    }

    if (data.component_operating_points && Object.keys(data.component_operating_points).length) {
      var cop = document.createElement("div"); cop.className = "panel";
      cop.innerHTML = "<div class='panel-title'>Component operating points</div>";
      Object.keys(data.component_operating_points).forEach(function (id) {
        var pt = data.component_operating_points[id];
        cop.innerHTML += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim);margin:10px 0 4px;'>" + id + " (" + pt.type + ")</div>" +
          "<div class='info-grid'>" +
          "<div class='info-card'><div class='lbl'>Bus</div><div class='val' style='font-size:12px'>" + pt.bus + "</div></div>" +
          "<div class='info-card'><div class='lbl'>Voltage</div><div class='val'>" + formatEng(pt.operating_voltage, "V") + "</div></div>" +
          "<div class='info-card'><div class='lbl'>Current</div><div class='val'>" + formatEng(pt.operating_current, "A") + "</div></div>" +
          "<div class='info-card'><div class='lbl'>Power</div><div class='val'>" + formatEng(pt.operating_power, "W") + "</div></div>" +
          "</div>";
      });
      cop.innerHTML += "<div class='help-text' style='margin-top:8px;'>Current and power computed via the same port-current relation the Automatic Model Builder itself uses to assemble the network's equations \u2014 not a separate, potentially-inconsistent formula.</div>";
      el.appendChild(cop);
    }

    if (data.electrical_operating_point) {
      var eop = data.electrical_operating_point;
      var epPanel = document.createElement("div"); epPanel.className = "panel";
      epPanel.innerHTML = "<div class='panel-title'>Electrical operating point</div><div class='info-grid'>" +
        "<div class='info-card'><div class='lbl'>Power angle \u03b4*</div><div class='val'>" + eop.delta.toFixed(4) + " rad</div></div>" +
        "<div class='info-card'><div class='lbl'>Electrical power P_e(\u03b4*)</div><div class='val'>" + eop.electrical_power.toFixed(4) + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Power setpoint P_set</div><div class='val'>" + eop.power_setpoint.toFixed(4) + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Power mismatch</div><div class='val'>" + eop.power_mismatch.toExponential(2) + "</div></div>" +
        "</div><div class='help-text' style='margin-top:8px;'>" +
        (eop.matches_setpoint ? "P_e(\u03b4*) matches P_set exactly \u2014 the equilibrium condition of the swing equation itself." : "P_e(\u03b4*) does not match P_set \u2014 unexpected; would indicate a solver or model inconsistency.") +
        "</div>";
      el.appendChild(epPanel);
    }
    if (data.transverse_stability) {
      var tsPanel = document.createElement("div"); tsPanel.className = "panel";
      tsPanel.innerHTML = "<div class='panel-title'>Transverse stability</div><div class='eq-readout'>" +
        "<b>" + (data.transverse_stability.is_hyperbolic ? "Normally hyperbolic" : "NOT normally hyperbolic") + "</b></div>" +
        "<div class='help-text' style='margin-top:6px;'>" + data.transverse_stability.description + "</div>";
      el.appendChild(tsPanel);
    }
    if (data.jacobian) {
      var jSummaryPanel = document.createElement("div"); jSummaryPanel.className = "panel";
      jSummaryPanel.innerHTML = "<div class='panel-title'>Jacobian summary</div><div class='info-grid'>" +
        "<div class='info-card'><div class='lbl'>Size</div><div class='val'>" + data.jacobian.length + " \u00d7 " + data.jacobian.length + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Rank</div><div class='val'>" + (data.jacobian_rank !== undefined && data.jacobian_rank !== null ? data.jacobian_rank + " / " + data.jacobian.length : "\u2014") + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Condition number</div><div class='val'>" + (data.solver_diagnostics && data.solver_diagnostics.jacobian_condition_number !== null && data.solver_diagnostics.jacobian_condition_number !== undefined ? data.solver_diagnostics.jacobian_condition_number.toExponential(2) : "singular/undefined") + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Spectral radius</div><div class='val'>" + (data.jacobian_spectral_radius !== undefined && data.jacobian_spectral_radius !== null ? data.jacobian_spectral_radius.toFixed(3) : "\u2014") + "</div></div>" +
        "</div>";
      el.appendChild(jSummaryPanel);
      var jPanel = document.createElement("div"); jPanel.className = "panel";
      jPanel.innerHTML = "<div class='panel-title'>Full Jacobian matrix (supplementary)</div>" +
        "<div class='help-text' style='margin-bottom:8px;'>The summary above is what's typically needed for stability assessment; the full \u2202f/\u2202x matrix below is provided for completeness/reproducibility, not as the primary diagnostic \u2014 particularly for larger networks, where the size/rank/condition-number summary is more directly useful.</div>" +
        buildMatrixTableHtml(data.jacobian, data.state_names);
      el.appendChild(jPanel);
    }
    if (data.characteristic_time_constants) {
      var tcPanel = document.createElement("div"); tcPanel.className = "panel";
      tcPanel.innerHTML = "<div class='panel-title'>Characteristic time constants (1/|Re(\u03bb)|)</div><div class='info-grid'>" +
        data.characteristic_time_constants.map(function (tc, i) {
          return "<div class='info-card'><div class='lbl'>Mode " + (i + 1) + "</div><div class='val'>" + (tc === null ? "\u2014" : tc.toFixed(4) + " s") + "</div></div>";
        }).join("") + "</div>";
      el.appendChild(tcPanel);
    }
  }

  else if (stage === "simulate") {
    if (data.note) { var n = document.createElement("div"); n.className = "note-box"; n.textContent = data.note; el.appendChild(n); }

    var ctrlPanel = document.createElement("div"); ctrlPanel.className = "panel";
    var ci = data.controller_info || {};
    ctrlPanel.innerHTML = "<div class='panel-title'>Controller assessment</div><div class='info-grid'>" +
      "<div class='info-card'><div class='lbl'>Type</div><div class='val' style='font-size:12px'>" + ci.type + "</div></div>" +
      "<div class='info-card'><div class='lbl'>Disturbed initial state</div><div class='val' style='font-size:11.5px'>[" +
        data.disturbed_state.map(function (v) { return v.toFixed(3); }).join(", ") + "]</div></div>" +
      (ci.note ? "<div class='info-card' style='grid-column:1/-1;'><div class='lbl'>Note</div><div class='val' style='font-size:11.5px;line-height:1.5;'>" + ci.note + "</div></div>" : "") +
      (ci.Q_diag ? "<div class='info-card'><div class='lbl'>Q diag</div><div class='val' style='font-size:12px'>[" + ci.Q_diag.join(", ") + "]</div></div>" : "") +
      (ci.R_diag ? "<div class='info-card'><div class='lbl'>R diag</div><div class='val' style='font-size:12px'>[" + ci.R_diag.join(", ") + "]</div></div>" : "") +
      (ci.km ? "<div class='info-card'><div class='lbl'>k_m (exact, provable)</div><div class='val'>" + ci.km + " s\u207b\u00b9</div></div>" : "") +
      (ci.estimated_contraction_rate !== undefined && ci.estimated_contraction_rate !== null ? "<div class='info-card'><div class='lbl'>Estimated contraction rate</div><div class='val'>" + ci.estimated_contraction_rate.toFixed(3) + " s\u207b\u00b9</div></div>" : "") +
      (data.control_effort ? "<div class='info-card'><div class='lbl'>Control effort (RMS)</div><div class='val'>" + data.control_effort.rms.toFixed(4) + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Control effort (peak)</div><div class='val'>" + data.control_effort.peak.toFixed(4) + "</div></div>" : "") +
      "</div>";
    if (ci.estimated_contraction_rate !== undefined && ci.estimated_contraction_rate !== null) {
      ctrlPanel.innerHTML += "<div class='help-text' style='margin-top:8px;'>Empirical fit to the closed-loop manifold-residual decay \u2014 not an exact, provable rate the way k_m is for IMS-native MRC.</div>";
    }
    el.appendChild(ctrlPanel);

    var plotPanel = document.createElement("div"); plotPanel.className = "panel";
    plotPanel.innerHTML = "<div class='panel-title'>State trajectories (every state)</div><div id='trajWrap'></div><div class='legend-row' id='trajLegend'></div>";
    el.appendChild(plotPanel);
    renderTrajectoryPlot(data);

    if (data.control_signal) {
      var csPanel = document.createElement("div"); csPanel.className = "panel";
      csPanel.innerHTML = "<div class='panel-title'>Control input u(t)</div><div id='controlSignalWrap'></div>" +
        "<div class='help-text'>The actual, automatically-derived MRC law evaluated continuously along the trajectory \u2014 not a fixed setpoint.</div>";
      el.appendChild(csPanel);
      renderControlSignalPlot(data);
    }

    if (data.electrical_power_open_loop) {
      var epPlotPanel = document.createElement("div"); epPlotPanel.className = "panel";
      epPlotPanel.innerHTML = "<div class='panel-title'>Electrical power P_e(t) = (E\u00b7V/X)\u00b7sin(\u03b4(t))</div><div id='elecPowerWrap'></div><div class='legend-row' id='elecPowerLegend'></div>";
      el.appendChild(epPlotPanel);
      renderElectricalPowerPlot(data, "elecPowerWrap", "elecPowerLegend", epPlotPanel);
    }

    var labels = currentProject.state_short || (data.trajectory_open_loop.x.map(function (_, i) { return "x" + (i + 1); }));
    function metricsTable(title, m) {
      var rows = labels.map(function (lbl, i) {
        var unit = stateVariableInfo(lbl).unit;
        var unitSuffix = unit && unit !== "\u2014" ? " " + unit : "";
        return "<tr><td>" + lbl + "</td><td>" + m.max_deviation[i].toFixed(4) + unitSuffix + "</td><td>" +
          m.steady_state_error[i].toExponential(2) + unitSuffix + "</td><td>" +
          (m.settling_time[i] === null ? "\u2014" : m.settling_time[i].toFixed(4) + " s") + "</td><td>" +
          m.overshoot_pct[i].toFixed(1) + "%</td></tr>";
      }).join("");
      return "<div class='panel-title' style='margin-top:" + (title ? "14px" : "0") + ";'>" + (title || "Performance metrics") + "</div>" +
        "<table style='width:100%;border-collapse:collapse;font-size:11.5px;'>" +
        "<tr style='color:var(--text-dim);text-align:left;font-family:var(--mono);font-size:10px;text-transform:uppercase;'>" +
        "<th style='padding:4px 6px;'>State</th><th style='padding:4px 6px;'>Max deviation</th><th style='padding:4px 6px;'>Steady-state error</th>" +
        "<th style='padding:4px 6px;'>Settling time</th><th style='padding:4px 6px;'>Overshoot</th></tr>" + rows + "</table>";
    }
    if (data.performance_metrics_open_loop) {
      var metricsPanel = document.createElement("div"); metricsPanel.className = "panel";
      var html = metricsTable(data.trajectory_closed_loop ? "Performance metrics \u2014 open loop" : "", data.performance_metrics_open_loop);
      if (data.performance_metrics_closed_loop) html += metricsTable("Performance metrics \u2014 closed loop", data.performance_metrics_closed_loop);
      metricsPanel.innerHTML = html;
      el.appendChild(metricsPanel);
    }
  }

  else if (stage === "ims_analysis") {
    var p = currentProject;
    if (data.note) { var n = document.createElement("div"); n.className = "note-box"; n.textContent = data.note; el.appendChild(n); }

    if (data.manifold_stats) {
      var ms = data.manifold_stats;
      var msPanel = document.createElement("div"); msPanel.className = "panel";
      msPanel.innerHTML = "<div class='panel-title'>Intrinsic manifold</div><div class='info-grid'>" +
        "<div class='info-card'><div class='lbl'>Continuation parameter</div><div class='val' style='font-size:11px'>" + ms.continuation_parameter + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Operating interval</div><div class='val' style='font-size:12px'>" + (ms.operating_interval ? "[" + ms.operating_interval[0].toFixed(3) + ", " + ms.operating_interval[1].toFixed(3) + "]" : "\u2014") + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Points</div><div class='val'>" + ms.n_points + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Dimension</div><div class='val'>" + ms.dimension + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Stable / unstable</div><div class='val'>" + ms.n_stable + " / " + ms.n_unstable + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Singular points</div><div class='val'>" + ms.n_singular_points + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Empirically persistent</div><div class='val' style='font-size:12px'>" + (ms.empirically_persistent ? "Yes" : "No") + "</div></div>" +
        (ms.max_curvature !== null && ms.max_curvature !== undefined ? "<div class='info-card'><div class='lbl'>Max curvature</div><div class='val' style='font-size:12px'>" + ms.max_curvature.toExponential(3) + "</div></div>" +
          "<div class='info-card'><div class='lbl'>Mean curvature</div><div class='val' style='font-size:12px'>" + ms.mean_curvature.toExponential(3) + "</div></div>" : "") +
        (ms.arc_length !== undefined ? "<div class='info-card'><div class='lbl'>Arc length</div><div class='val' style='font-size:12px'>" + ms.arc_length.toFixed(4) + "</div></div>" : "") +
        "</div>";
      if (ms.tangent_at_nearest) {
        msPanel.innerHTML += "<div class='panel-title' style='margin-top:14px;'>Tangent direction at operating point</div>" +
          "<div class='eq-readout' style='font-size:12px;'>[" + ms.tangent_at_nearest.map(function (v) { return v.toFixed(4); }).join(", ") + "]</div>";
      }
      if (ms.operating_region_stable) {
        var firstStateName = (currentProject.state_short && currentProject.state_short[0]) || "the first state";
        msPanel.innerHTML += "<div class='panel-title' style='margin-top:14px;'>Recommended operating region (stable branch, " + firstStateName + ")</div>" +
          "<div class='eq-readout' style='font-size:12px;'>[" + ms.operating_region_stable[0].toFixed(4) + ", " + ms.operating_region_stable[1].toFixed(4) + "]</div>" +
          "<div class='help-text' style='margin-top:4px;'>This is the range of <b>" + firstStateName + "</b> (not the swept parameter itself) traced along the stable-branch manifold \u2014 i.e. where this specific state stays consistent with the manifold as the input is varied. Not a claim about thermal, insulation, or other engineering limits the platform does not model.</div>";
      }
      msPanel.innerHTML += "<div class='help-text' style='margin-top:8px;'>\"Empirically persistent\" means no stability change was detected across this specific swept interval \u2014 not a claim of the general Fenichel persistence theorem, which concerns existence near M\u2080 for sufficiently small \u03b5, not any one traced range.</div>";
      if (ms.n_singular_points > 0) {
        msPanel.innerHTML += "<div class='help-text' style='margin-top:8px;'>Stability changes sign between consecutive manifold samples at " +
          ms.singular_points.map(function (sp) { return "\u03b1\u2248" + sp.alpha_midpoint.toFixed(4); }).join(", ") +
          " \u2014 normal hyperbolicity is lost there (a fold/termination of the fast equilibrium manifold).</div>";
      }
      el.appendChild(msPanel);
    }

    if (data.manifold) {
      var mp = document.createElement("div"); mp.className = "panel";
      mp.innerHTML = "<div class='panel-title'>Phase portrait &amp; intrinsic manifold</div><div id='phaseWrap'></div><div class='legend-row' id='phaseLegend'></div>";
      el.appendChild(mp);
      renderPhasePortrait(data);
    }
    if (data.manifold_residual_trajectory) {
      var rp = document.createElement("div"); rp.className = "panel";
      rp.innerHTML = "<div class='panel-title'>Manifold residual over time (distance to intrinsic manifold)</div><div id='residualWrap'></div>";
      el.appendChild(rp);
      renderResidualPlot("residualWrap", data.manifold_residual_trajectory.t, data.manifold_residual_trajectory.residual, "Time (s)");
      if (data.residual_statistics) rp.appendChild(residualStatsBlock(data.residual_statistics));
    } else if (data.residual && data.trajectory) {
      var rp = document.createElement("div"); rp.className = "panel";
      rp.innerHTML = "<div class='panel-title'>Manifold residual over time (distance to intrinsic manifold)</div><div id='residualWrap'></div>";
      el.appendChild(rp);
      renderResidualPlot("residualWrap", data.trajectory.t, data.residual, "Time (s)");
      if (data.residual_statistics) rp.appendChild(residualStatsBlock(data.residual_statistics));
    }
    if (data.recoverability_deterministic) {
      var det = data.recoverability_deterministic;
      var detPanel = document.createElement("div"); detPanel.className = "panel";
      var classColor = det.classification === "Recoverable" ? "var(--teal)" : det.classification === "Marginal" ? "#e0a030" : "#e05a5a";
      detPanel.innerHTML = "<div class='panel-title'>Recoverability assessment (deterministic, manifold-based)</div>" +
        "<div class='help-text' style='margin-bottom:12px;'>Computed directly from this trajectory's own manifold residual e_m(t) \u2014 per Definition IV.2 of the IMS framework, not a statistical estimate. This is the primary recoverability signal; the Monte-Carlo panel below validates it statistically over a neighborhood of disturbances.</div>" +
        (data.residual_projection_method ? "<div style='font-size:12px;margin-bottom:8px;'><b>Residual projection method:</b> " + ({ polyline: "Polyline", nearest_sample: "Nearest sample (legacy)", newton_refined: "Newton-refined" }[data.residual_projection_method] || data.residual_projection_method) + "</div>" : "") +
        "<div style='font-size:22px;font-weight:700;color:" + classColor + ";margin-bottom:14px;'>" + det.classification + "</div>" +
        "<div class='info-grid'>" +
        "<div class='info-card'><div class='lbl'>Max |e_m|</div><div class='val'>" + det.max_residual.toExponential(3) + "</div></div>" +
        "<div class='info-card'><div class='lbl'>RMS |e_m|</div><div class='val'>" + det.rms_residual.toExponential(3) + "</div></div>" +
        "<div class='info-card'><div class='lbl'>\u222b|e_m| dt</div><div class='val'>" + det.integral_abs_residual.toExponential(3) + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Final e_m</div><div class='val'>" + det.final_residual.toExponential(3) + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Recovery time</div><div class='val'>" + (det.recovery_time !== null ? det.recovery_time.toFixed(4) + " s" : "not reached") + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Contraction rate</div><div class='val'>" + (det.contraction_rate !== null ? det.contraction_rate.toFixed(2) + " /s" : "n/a") + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Recoverability margin</div><div class='val'>" + (det.recoverability_margin !== undefined ? det.recoverability_margin.toExponential(3) : "n/a") + "</div></div>" +
        "</div>";
      if (det.geometric_narrative) {
        detPanel.innerHTML += "<div class='panel-title' style='margin-top:14px;'>Geometric interpretation</div>" +
          "<p style='font-size:12.5px;line-height:1.6;'>" + det.geometric_narrative + "</p>";
      }
      if (data.recoverability_region_summary) {
        var rs = data.recoverability_region_summary;
        detPanel.innerHTML += "<div class='panel-title' style='margin-top:14px;'>Recoverability region &amp; boundary</div>" +
          "<p style='font-size:12px;line-height:1.6;color:var(--text-dim);'>" + rs.concept_explanation + "</p>" +
          "<p style='font-size:12.5px;line-height:1.6;'><b>Is this disturbance inside R?</b> " + (rs.inside_region ? "Yes" : "No") + " \u2014 " + rs.membership_explanation + "</p>" +
          "<p style='font-size:11.5px;line-height:1.6;color:var(--text-dim);font-style:italic;'>" + rs.boundary_note + "</p>";
      }
      if (data.manifold_residual_explanation) {
        detPanel.innerHTML += "<details style='margin-top:10px;'><summary style='cursor:pointer;font-size:11px;color:var(--text-dim);text-transform:uppercase;'>What is the manifold residual?</summary>" +
          "<p style='font-size:12px;line-height:1.6;margin-top:6px;'>" + data.manifold_residual_explanation + "</p></details>";
      }
      if (data.projection_method_validation_summary) {
        detPanel.innerHTML += "<details style='margin-top:10px;'><summary style='cursor:pointer;font-size:11px;color:var(--text-dim);text-transform:uppercase;'>Projection method validation</summary>" +
          "<p style='font-size:12px;line-height:1.6;margin-top:6px;'>" + data.projection_method_validation_summary + "</p></details>";
      }
      if (det.ims_conditions) {
        var ic = det.ims_conditions;
        var chk = function (v) {
          if (v === "SATISFIED") return "\u2713";
          if (v === "VIOLATED") return "\u2717";
          if (v === true) return "\u2713 (empirical)";
          if (v === false) return "\u2717 (empirical)";
          return "\u2014 not established";
        };
        detPanel.innerHTML += "<div class='panel-title' style='margin-top:14px;'>IMS conditions (Definition IV.3, tri-state)</div>" +
          "<div class='help-text' style='margin-bottom:8px;'>SATISFIED / VIOLATED are only reported when the underlying quantity was actually computed; \u201cnot established\u201d is a genuine third state (not a failure) for claims this pathway lacks the analytic structure to evaluate \u2014 e.g. transverse/reduced-dynamics stability requires the manifold's own target rate k_m, which the generic IMS Analysis pathway does not have. These are five separate claims, never inferred from one another.</div>" +
          "<div class='info-grid'>" +
          "<div class='info-card'><div class='lbl'>Full-system local stability</div><div class='val'>" + chk(ic.full_system_local_stability) + "</div></div>" +
          "<div class='info-card'><div class='lbl'>Normal hyperbolicity</div><div class='val'>" + chk(ic.normal_hyperbolicity) + "</div></div>" +
          "<div class='info-card'><div class='lbl'>Transverse contraction (analytic)</div><div class='val'>" + chk(ic.transverse_contraction) + "</div></div>" +
          "<div class='info-card'><div class='lbl'>Reduced dynamics stable (analytic)</div><div class='val'>" + chk(ic.reduced_dynamics_stable) + "</div></div>" +
          "<div class='info-card'><div class='lbl'>Empirical finite-horizon recovery</div><div class='val'>" + chk(ic.empirical_finite_horizon_recovery) + "</div></div>" +
          "<div class='info-card'><div class='lbl'>Certified regional IMS</div><div class='val'>" + chk(ic.certified_regional_ims) + "</div></div>" +
          "<div class='info-card'><div class='lbl'>Overall IMS status</div><div class='val'>" + ic.overall_status + "</div></div>" +
          "</div>";
      }
      if (det.limiting_state && det.classification !== "Recoverable") {
        detPanel.innerHTML += "<div class='panel-title' style='margin-top:14px;'>Supplementary diagnostic (not an IMS quantity)</div>" +
          "<div class='help-text' style='margin-bottom:6px;'>Not part of the IMS framework itself \u2014 a simple per-state decomposition of the manifold residual, offered only as an engineering starting point, not as the identified cause of recoverability loss (which is a geometric property of the manifold, not a single-state attribution).</div>" +
          "<p style='font-size:12.5px;line-height:1.6;'>" + det.note + "</p>";
      }
      el.appendChild(detPanel);
    }
    if (data.recoverability) {
      var rec = data.recoverability;
      var recPanel = document.createElement("div"); recPanel.className = "panel";
      recPanel.innerHTML = "<div class='panel-title'>Statistical validation (Monte Carlo)</div>" +
        "<div class='help-text' style='margin-bottom:10px;'>" + (rec.role || "Samples a neighborhood of disturbances to statistically validate the deterministic assessment above.") + "</div>" +
        (rec.interpretation ? "<p style='font-size:13px;line-height:1.6;margin:0 0 12px;'>" + rec.interpretation + "</p>" : "") +
        "<div id='recMapWrap'></div><div class='legend-row' id='recMapLegend'></div>" +
        "<div class='info-grid' style='margin-top:14px;'>" +
        "<div class='info-card'><div class='lbl'>Index</div><div class='val'>" + rec.index.toFixed(2) + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Recovered</div><div class='val'>" + rec.n_recoverable + "/" + rec.n_samples + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Margin</div><div class='val'>" + rec.margin.toFixed(3) + "</div></div>" +
        "<div class='info-card'><div class='lbl'>Risk</div><div class='val'><span class='risk-badge risk-" + rec.risk + "'>" + rec.risk + "</span></div></div>" +
        (rec.confidence_interval ? "<div class='info-card'><div class='lbl'>95% CI on index</div><div class='val' style='font-size:12px'>[" + rec.confidence_interval[0].toFixed(2) + ", " + rec.confidence_interval[1].toFixed(2) + "]</div></div>" : "") +
        "</div>";
      if (rec.worst_disturbance) {
        recPanel.innerHTML += "<div class='help-text' style='margin-top:8px;'>Worst (closest) unrecoverable disturbance sampled: [" +
          rec.worst_disturbance.map(function (v) { return v.toFixed(3); }).join(", ") + "]</div>";
      } else {
        recPanel.innerHTML += "<div class='help-text' style='margin-top:8px;'>All sampled disturbances recovered \u2014 no failing sample found within this radius.</div>";
      }
      if (data.recoverability_boundary) {
        var b = data.recoverability_boundary;
        recPanel.innerHTML += "<div class='panel-title' style='margin-top:14px;'>Critical boundary (traced)</div><div class='info-grid'>" +
          "<div class='info-card'><div class='lbl'>Directions sampled</div><div class='val'>" + b.n_directions + "</div></div>" +
          "<div class='info-card'><div class='lbl'>Boundary found</div><div class='val'>" + b.n_found + "/" + b.n_directions + "</div></div>" +
          "<div class='info-card'><div class='lbl'>Min radius</div><div class='val'>" + b.min_radius.toFixed(3) + "</div></div>" +
          "<div class='info-card'><div class='lbl'>Max radius</div><div class='val'>" + b.max_radius.toFixed(3) + "</div></div>" +
          "</div><div class='help-text' style='margin-top:6px;'>Traced via directional bisection from the equilibrium (dashed line on the map above) \u2014 an actual approximation of the recoverability region's boundary, not an index. Some directions may report \"beyond search radius\" if the boundary lies further out than searched.</div>";
      }
      el.appendChild(recPanel);
      renderRecoverabilityMap(data);

      if (data.recoverability_closed_loop) {
        var rc = data.recoverability_closed_loop;
        var cePanel = document.createElement("div"); cePanel.className = "panel";
        cePanel.innerHTML = "<div class='panel-title'>Controller effect on recoverability</div>" +
          "<table style='width:100%;border-collapse:collapse;font-size:12px;'>" +
          "<tr style='color:var(--text-dim);text-align:left;font-family:var(--mono);font-size:10px;text-transform:uppercase;'><th style='padding:4px 6px;'></th><th style='padding:4px 6px;'>Open loop</th><th style='padding:4px 6px;'>Closed loop (scheduled LQR)</th></tr>" +
          "<tr><td style='padding:4px 6px;color:var(--text-dim);'>Index</td><td style='padding:4px 6px;'>" + rec.index.toFixed(2) + "</td><td style='padding:4px 6px;'>" + rc.index.toFixed(2) + "</td></tr>" +
          "<tr><td style='padding:4px 6px;color:var(--text-dim);'>Margin</td><td style='padding:4px 6px;'>" + rec.margin.toFixed(3) + "</td><td style='padding:4px 6px;'>" + rc.margin.toFixed(3) + "</td></tr>" +
          "<tr><td style='padding:4px 6px;color:var(--text-dim);'>Risk</td><td style='padding:4px 6px;'><span class='risk-badge risk-" + rec.risk + "'>" + rec.risk + "</span></td><td style='padding:4px 6px;'><span class='risk-badge risk-" + rc.risk + "'>" + rc.risk + "</span></td></tr>" +
          "</table>" +
          "<div class='help-text' style='margin-top:8px;'>Same sampled disturbances in both cases (fixed random seed), so the comparison isolates the controller's effect rather than Monte-Carlo sampling variation.</div>";
        el.appendChild(cePanel);
      }
    }
  }
}

function residualStatsBlock(rs) {
  var div = document.createElement("div");
  div.style.marginTop = "10px";
  div.innerHTML = "<div class='info-grid'>" +
    "<div class='info-card'><div class='lbl'>Max residual</div><div class='val' style='font-size:12px'>" + rs.max.toExponential(3) + "</div></div>" +
    "<div class='info-card'><div class='lbl'>RMS residual</div><div class='val' style='font-size:12px'>" + rs.rms.toExponential(3) + "</div></div>" +
    "<div class='info-card'><div class='lbl'>Mean residual</div><div class='val' style='font-size:12px'>" + rs.mean.toExponential(3) + "</div></div>" +
    "<div class='info-card'><div class='lbl'>Final residual</div><div class='val' style='font-size:12px'>" + rs.final.toExponential(3) + "</div></div>" +
    (rs.empirical_contraction_rate !== null && rs.empirical_contraction_rate !== undefined ?
      "<div class='info-card'><div class='lbl'>Empirical contraction rate</div><div class='val' style='font-size:12px'>" + rs.empirical_contraction_rate.toFixed(3) + " s\u207b\u00b9</div></div>" : "") +
    "</div>";
  return div;
}

function renderTrajectoryPlot(data, wrapId, legendId) {
  wrapId = wrapId || "trajWrap"; legendId = legendId || "trajLegend";
  var wrap = $(wrapId);
  wrap.innerHTML = "";
  var ol = data.trajectory_open_loop;
  var cl = data.trajectory_closed_loop;
  var nStates = ol.x.length;
  var labels = currentProject.state_short || ol.x.map(function (_, i) { return "x" + (i + 1); });

  for (var s = 0; s < nStates; s++) {
    var row = document.createElement("div");
    row.style.marginBottom = "10px";
    var title = document.createElement("div");
    title.style.cssText = "font-family:var(--mono);font-size:10.5px;color:var(--text-dim);margin-bottom:4px;";
    title.textContent = stateVariableInfo(labels[s] || "").meaning || labels[s] || ("state " + (s + 1));
    row.appendChild(title);
    var plotDiv = document.createElement("div");
    row.appendChild(plotDiv);
    wrap.appendChild(row);

    var pts = ol.t.map(function (t, i) { return [t, ol.x[s][i]]; });
    var series = [pts];
    var ptsCl = null;
    if (cl) { ptsCl = cl.t.map(function (t, i) { return [t, cl.x[s][i]]; }); series.push(ptsCl); }
    var bounds = computeBounds(series);
    var c = makeCanvas(plotDiv, 150);
    var m = { l: 58, r: 16, t: 10, b: 30 };
    drawGrid(c.ctx, bounds, c.w, c.h, m, s === nStates - 1 ? "Time (s)" : "", axisLabelForState(labels[s] || ""));
    // Single trace: color by physical quantity type (voltage/current/
    // control) for at-a-glance distinction across subplots. With a
    // closed-loop comparison shown, keep the open/closed-loop
    // distinction instead, since that's the more important information
    // in that view.
    drawLine(c.ctx, pts, bounds, c.w, c.h, m, cl ? COLORS.trajOpen : colorForState(labels[s] || ""), 2.6);
    if (ptsCl) drawLine(c.ctx, ptsCl, bounds, c.w, c.h, m, COLORS.trajClosed, 2.6);
    drawMarker(c.ctx, pts[0], bounds, c.w, c.h, m, "#FF6B6B", "circle", 7);
  }

  var legend = '<span><span class="legend-swatch" style="background:' + COLORS.trajOpen + '"></span>Open loop</span>' +
    (cl ? '<span><span class="legend-swatch" style="background:' + COLORS.trajClosed + '"></span>Closed loop</span>' : "") +
    '<span><span class="legend-swatch" style="background:#FF6B6B;border-radius:50%;height:8px;width:8px;"></span>Disturbed initial state</span>';
  $(legendId).innerHTML = legend;
}

function renderControlSignalPlot(data, wrapId) {
  wrapId = wrapId || "controlSignalWrap";
  var wrap = $(wrapId);
  var t = data.trajectory_open_loop.t;
  var pts = t.map(function (tt, i) { return [tt * 1000, data.control_signal[i]]; });
  var bounds = computeBounds([pts], 0.1);
  var m = { l: 62, r: 16, t: 12, b: 30 };
  var c = makeCanvas(wrap, 230);
  drawGrid(c.ctx, bounds, c.w, c.h, m, "time (ms)", "u(t)");
  drawLine(c.ctx, pts, bounds, c.w, c.h, m, COLORS.trajClosed, 2.0);
}

function renderPhasePortrait(data, wrapId, legendId) {
  wrapId = wrapId || "phaseWrap"; legendId = legendId || "phaseLegend";
  var wrap = $(wrapId);
  var c = makeCanvas(wrap, 390);
  var M = data.manifold;
  var manifoldPts = M.points.filter(function (_, i) { return M.stable[i]; });
  var manifoldUnstable = M.points.filter(function (_, i) { return !M.stable[i]; });
  var allSeries = [M.points];
  var bounds = computeBounds(allSeries);
  var m = { l: 58, r: 16, t: 14, b: 32 };
  var labels = currentProject.state_short || ["x1", "x2"];
  drawGrid(c.ctx, bounds, c.w, c.h, m, axisLabelForState(labels[0]) + " (" + labels[0] + ")", axisLabelForState(labels[1]) + " (" + labels[1] + ")");
  if (manifoldPts.length > 1) drawLine(c.ctx, manifoldPts, bounds, c.w, c.h, m, COLORS.manifold, 2.4);
  if (manifoldUnstable.length > 1) drawLine(c.ctx, manifoldUnstable, bounds, c.w, c.h, m, COLORS.manifoldUnstable, 1.6, [4, 3]);
  if (stageResults.equilibrium) drawMarker(c.ctx, stageResults.equilibrium.x_star, bounds, c.w, c.h, m, "#DCE6EE", "star", 7);
  if (M.points.length <= 1) {
    // Too few continuation points to draw a manifold curve at all --
    // confirmed this happens for genuinely hard-to-continue networks
    // (e.g. widely mismatched source voltages fighting through a
    // low-impedance network), not necessarily a bug, but the chart was
    // previously left as a bare, unexplained empty grid. State this
    // plainly rather than leave it looking broken.
    c.ctx.save();
    c.ctx.fillStyle = "#9AA5B1"; c.ctx.font = "13px sans-serif"; c.ctx.textAlign = "center";
    c.ctx.fillText("Only " + M.points.length + " manifold point" + (M.points.length === 1 ? "" : "s") + " converged across the swept range \u2014",
      c.w / 2, c.h / 2 - 8);
    c.ctx.fillText("too few to draw a manifold curve. See equilibrium stability and sweep range below.", c.w / 2, c.h / 2 + 12);
    c.ctx.restore();
  }
  $(legendId).innerHTML = '<span><span class="legend-swatch" style="background:' + COLORS.manifold + '"></span>Intrinsic manifold (stable)</span>' +
    (manifoldUnstable.length ? '<span><span class="legend-swatch" style="background:' + COLORS.manifoldUnstable + '"></span>Unstable branch</span>' : "");
}

function renderResidualPlot(wrapId, t, residual, xLabel) {
  var wrap = $(wrapId);
  var c = makeCanvas(wrap, 255);
  var pts = t.map(function (tt, i) { return [tt, residual[i]]; });
  var bounds = computeBounds([pts], 0.08);
  var m = { l: 58, r: 16, t: 14, b: 32 };
  drawGrid(c.ctx, bounds, c.w, c.h, m, xLabel || "Time (s)", "Manifold Residual");
  drawLine(c.ctx, pts, bounds, c.w, c.h, m, COLORS.residual, 2.6);
}

function pointInPolygon(pt, poly) {
  // Standard ray-casting test. Used to verify (not just assume) whether
  // every recovered sample lies inside the traced boundary polygon --
  // the polygon is a finite straight-line approximation through a
  // limited number of sampled directions, so a recoverable sample can
  // legitimately fall just outside it if the true (possibly non-convex
  // or curved) recoverability region bulges out between two sampled
  // rays. This is a real, checked geometric property of the polygon
  // approximation, not an assumption.
  var x = pt[0], y = pt[1];
  var inside = false;
  for (var i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    var xi = poly[i][0], yi = poly[i][1];
    var xj = poly[j][0], yj = poly[j][1];
    var intersect = ((yi > y) !== (yj > y)) &&
      (x < (xj - xi) * (y - yi) / (yj - yi + 1e-15) + xi);
    if (intersect) inside = !inside;
  }
  return inside;
}

function renderRecoverabilityMap(data, wrapId, legendId) {
  wrapId = wrapId || "recMapWrap"; legendId = legendId || "recMapLegend";
  var wrap = $(wrapId);
  var c = makeCanvas(wrap, 345);
  var rec = data.recoverability;
  var boundary = data.recoverability_boundary;
  var series = [rec.samples];
  if (boundary) series.push(boundary.points.map(function (p) { return p.point; }));
  var bounds = computeBounds(series);
  var m = { l: 58, r: 16, t: 14, b: 32 };
  var labels = currentProject.state_short || ["x1", "x2"];
  drawGrid(c.ctx, bounds, c.w, c.h, m, labels[0], labels[1]);
  drawScatter(c.ctx, rec.samples, function (i) { return rec.labels[i] ? COLORS.recRec : COLORS.recNon; }, bounds, c.w, c.h, m, 4.5);
  var polygon = null, nOutside = 0, nRecoverable = 0;
  if (boundary) {
    var sorted = boundary.points.slice().sort(function (a, b) { return a.theta - b.theta; });
    polygon = sorted.map(function (p) { return p.point; });
    // Verify geometric consistency: check every recovered sample against
    // the actual plotted polygon, rather than assuming it holds.
    rec.samples.forEach(function (s, i) {
      if (rec.labels[i]) {
        nRecoverable++;
        if (!pointInPolygon(s, polygon)) nOutside++;
      }
    });
    var closedPoly = polygon.slice(); closedPoly.push(closedPoly[0]);
    drawLine(c.ctx, closedPoly, bounds, c.w, c.h, m, "#FFB454", 2.8, [6, 4]);
  }
  if (stageResults.equilibrium) drawMarker(c.ctx, stageResults.equilibrium.x_star, bounds, c.w, c.h, m, "#DCE6EE", "star", 10);
  if ($(legendId)) {
    $(legendId).innerHTML = '<span><span class="legend-swatch" style="background:' + COLORS.recRec + '"></span>Recovered sample</span>' +
      '<span><span class="legend-swatch" style="background:' + COLORS.recNon + '"></span>Non-recovered sample</span>' +
      (boundary ? '<span><span class="legend-swatch" style="background:#FFB454"></span>Traced critical boundary</span>' : "");
  }
  var captionId = wrapId + "_caption";
  var nStates = (stageResults.equilibrium && stageResults.equilibrium.x_star && stageResults.equilibrium.x_star.length) || 2;
  var captionHtml = "";
  if (boundary) {
    var shortNote = nOutside > 0
      ? nOutside + " of " + nRecoverable + " recovered samples fall just outside the traced polygon (expected interpolation artifact, not a classification error)."
      : "All " + nRecoverable + " recovered samples verified inside the traced polygon.";
    captionHtml += "<div style='font-size:10.5px;color:var(--text-dim);margin-top:6px;'>" +
      "Polygonal approximation through " + polygon.length + " sampled directions. " + shortNote +
      "</div>" +
      "<details style='margin-top:4px;'><summary style='font-size:10px;color:var(--text-dim);cursor:pointer;'>Technical notes on boundary approximation</summary>" +
      "<div style='font-size:10px;color:var(--text-dim);line-height:1.5;margin-top:4px;padding-left:2px;'>" +
      "The traced boundary is a closed polygon through sampled directions (straight-line interpolation between rays), not the exact recoverability boundary. " +
      "Where recovered samples fall outside it, this is expected where the true region's curvature bulges out between two sampled directions, not a classification error " +
      "(the same admissibility/residual/tolerance criterion classifies both the samples and the boundary). Increasing the number of sampled directions narrows this gap " +
      "but cannot eliminate it entirely for a finite polygon." +
      "</div></details>";
  }
  if (nStates > 2) {
    captionHtml += "<div style='font-size:10.5px;color:var(--text-dim);margin-top:4px;font-style:italic;'>" +
      "The recoverability boundary shown is a two-dimensional projection of the high-dimensional recoverability region onto the selected state variables." +
      "</div>";
  }
  if ($(captionId)) { $(captionId).innerHTML = captionHtml; }
  else if (wrap && wrap.parentNode && captionHtml) {
    var capEl = document.createElement("div"); capEl.id = captionId; capEl.innerHTML = captionHtml;
    wrap.parentNode.insertBefore(capEl, wrap.nextSibling);
  }
}


/* ===================== REPORT STAGE ===================== */

function renderReportStage(el) {
  if (!stageResults.ims_analysis) {
    el.innerHTML = "<p class='placeholder-msg'>Complete the IMS Analysis stage first.</p>";
    return;
  }
  var wrap = document.createElement("div"); wrap.id = "reportContent";
  wrap.innerHTML = buildReportBodyHtml(false);
  el.appendChild(wrap);
  populateReportFigures();

  var btnRow = document.createElement("div"); btnRow.className = "no-print";
  var htmlBtn = document.createElement("button"); htmlBtn.className = "secondary-btn"; htmlBtn.textContent = "Export HTML";
  htmlBtn.onclick = downloadHtmlReport;
  var pdfBtn = document.createElement("button"); pdfBtn.className = "secondary-btn"; pdfBtn.textContent = "Export PDF (Print)";
  pdfBtn.onclick = function () { printReportPdf(); };
  btnRow.appendChild(htmlBtn); btnRow.appendChild(pdfBtn);
  el.insertBefore(btnRow, wrap);
}

function buildMatrixTableHtml(matrix, stateNames) {
  // A dense matrix wider than this many columns will overflow any
  // reasonable page width and get physically cut off mid-number in
  // print/PDF export (confirmed directly: a 20-state Jacobian rendered
  // as one continuous row, cropped mid-digit, e.g. "-1000.0000
  // -1000.0000 -1000." at the page edge). Splitting into labeled
  // column blocks, stacked vertically, keeps every value fully
  // readable regardless of matrix size, rather than relying on
  // horizontal scroll (which print/PDF has no way to express).
  var MAX_COLS_PER_BLOCK = 8;
  var n = matrix.length;
  var precision = n > 12 ? 2 : 4;  // large matrices: less precision buys back page width
  var labels = stateNames || matrix.map(function (_, i) { return "x" + (i + 1); });
  var html = "";
  for (var startCol = 0; startCol < n; startCol += MAX_COLS_PER_BLOCK) {
    var endCol = Math.min(startCol + MAX_COLS_PER_BLOCK, n);
    html += "<div style='font-size:10px;color:var(--text-dim,#888);margin:6px 0 2px;'>Columns " + (startCol + 1) + "\u2013" + endCol +
      " of " + n + " (rows/cols correspond to state order above)</div>" +
      "<table style='font-family:monospace;font-size:" + (precision === 2 ? "10px" : "11px") + ";border-collapse:collapse;margin-bottom:8px;'>" +
      "<tr><td></td>" + labels.slice(startCol, endCol).map(function (l) { return "<td style='padding:2px 6px;color:var(--text-dim,#888);font-weight:700;'>" + l + "</td>"; }).join("") + "</tr>" +
      matrix.map(function (row, i) {
        return "<tr><td style='padding:2px 6px;color:var(--text-dim,#888);font-weight:700;'>" + labels[i] + "</td>" +
          row.slice(startCol, endCol).map(function (v) { return "<td style='padding:2px 6px;'>" + v.toFixed(precision) + "</td>"; }).join("") + "</tr>";
      }).join("") +
      "</table>";
  }
  return html;
}

function paramUnit(key) {
  // Infers an engineering unit from the platform's own parameter
  // naming convention (server.app._build_network_from_spec / model
  // param dicts): "C_bus1" -> F, "R_line1" -> \u03a9, "conv1_em_R_L" ->
  // \u03a9 (winding resistance, checked BEFORE the L pattern since the
  // name itself ends in "_L" but means resistance, not inductance),
  // "conv1_em_L" -> H, "conv1_em_v_in" / "src1_v_source" /
  // "load1_v_floor" -> V, "load1_P" -> W, "conv1_ctrl_d" ->
  // dimensionless (duty ratio), "Kp"/"Ki" -> controller gain (no fixed
  // SI unit). Returns "" (not a guessed unit) for anything that
  // doesn't match a known pattern, rather than claiming a unit that
  // might be wrong.
  var k = key;
  if (/(^|_)R(_|$)/.test(k)) return "\u03a9";
  if (/(^|_)L(_|$)/.test(k)) return "H";
  if (/(^|_)C(_|$)/.test(k)) return "F";
  if (/(^|_)v[_a-zA-Z]*(_|$)|(^|_)v$/.test(k)) return "V";
  if (/(^|_)P(_|$)/.test(k)) return "W";
  if (/(^|_)d($|_)/.test(k) && !/floor/i.test(k)) return "(dimensionless, duty ratio)";
  if (/kp|ki/i.test(k)) return "(controller gain)";
  return "";
}

function categorizeParam(key) {
  // Groups a parameter by the component type it belongs to, inferred
  // from the same naming convention paramUnit() parses. Matches the
  // request to group parameters (Electrical/Converter/Controller/
  // Load/Network) instead of one long flat list.
  if (/_ctrl_/.test(key)) return "Controller Parameters";
  if (/_em_/.test(key)) return "Converter Parameters";
  if (/^load\d*_/.test(key)) return "Load Parameters";
  if (/^src\d*_/.test(key)) return "Source Parameters";
  if (/^(C|R|L)_(bus|line)/.test(key)) return "Network Parameters";
  return "Other Parameters";
}

function buildCategorizedParamsTableHtml(paramsUsed) {
  var groups = {};
  var order = ["Network Parameters", "Converter Parameters", "Controller Parameters", "Load Parameters", "Source Parameters", "Other Parameters"];
  Object.keys(paramsUsed).forEach(function (k) {
    var cat = categorizeParam(k);
    (groups[cat] = groups[cat] || []).push(k);
  });
  var html = "";
  order.forEach(function (cat) {
    if (!groups[cat]) return;
    html += "<div style='font-size:10px;color:var(--text-dim,#888);text-transform:uppercase;margin:8px 0 2px;'>" + cat + "</div>" +
      "<table style='width:100%;border-collapse:collapse;font-size:11.5px;font-family:monospace;'>" +
      "<tr style='color:var(--text-dim,#888);text-align:left;font-size:9.5px;text-transform:uppercase;font-family:sans-serif;'><th style='padding:2px 8px 2px 0;'>Parameter</th><th>Value</th><th>Unit</th></tr>" +
      groups[cat].map(function (k) {
        return "<tr><td style='padding:2px 8px 2px 0;'>" + k + "</td><td>" + paramsUsed[k] + "</td><td style='color:var(--text-dim,#888);'>" + paramUnit(k) + "</td></tr>";
      }).join("") + "</table>";
  });
  return html;
}

function stateVariableInfo(name) {
  // Physical meaning and engineering unit for a state, inferred from
  // the Automatic Model Builder's own naming convention (matches
  // server.app._describe_state's parsing exactly, so these can't drift
  // out of sync with what the assembler actually names things).
  // Units for i_L / v_o (electrical-model states) and integral
  // controller states are stated per the platform's own physical
  // convention (SI: volts, amps) -- not inferred from any per-project
  // unit system, since this platform does not yet track per-project
  // base units (e.g. p.u. vs. SI) explicitly. This is a real,
  // acknowledged gap, not silently assumed away: see the per-unit note
  // in the report.
  if (name.startsWith("v_")) return { meaning: "Bus '" + name.slice(2) + "' Voltage", unit: "V" };
  if (name.startsWith("i_")) return { meaning: "Line '" + name.slice(2) + "' Current", unit: "A" };
  if (name.includes("_em_i_L")) return { meaning: "'" + name.split("_em_")[0] + "' Inductor Current", unit: "A" };
  if (name.includes("_em_v_o")) return { meaning: "'" + name.split("_em_")[0] + "' Output Voltage", unit: "V" };
  if (name.includes("_ctrl_e_int")) return { meaning: "'" + name.split("_ctrl_")[0] + "' Controller Integral State", unit: "V\u00b7s (voltage-error integral)" };
  if (name.includes("_ctrl_")) return { meaning: "'" + name.split("_ctrl_")[0] + "' Controller State", unit: "\u2014" };
  if (name.includes("_em_")) return { meaning: "'" + name.split("_em_")[0] + "' Electrical State", unit: "\u2014" };
  return { meaning: name, unit: "\u2014" };
}

function axisLabelForState(name) {
  // A short axis label with unit, distinct from stateVariableInfo's
  // fuller "meaning" text (which includes the bus/component name --
  // too verbose to repeat on every subplot's y-axis, especially with
  // many states). Falls back to the bare state name only when no unit
  // could be inferred, so the axis is never blank.
  var info = stateVariableInfo(name);
  if (info.unit === "V") return "Voltage (V)";
  if (info.unit === "A") return "Current (A)";
  if (info.unit.indexOf("duty") !== -1) return "Duty ratio";
  if (info.unit.indexOf("controller gain") !== -1) return "Gain";
  if (info.unit && info.unit !== "\u2014") return info.unit;
  return name;
}

function colorForState(name) {
  // Quantity-type color, requested for publication-quality
  // consistency: voltage=blue, current=green, control/duty=purple.
  // Falls back to the standard open-loop trace color (orange) for
  // anything that doesn't map to a known physical quantity type.
  var info = stateVariableInfo(name);
  if (info.unit === "V") return COLORS.voltage;
  if (info.unit === "A") return COLORS.current;
  if (info.unit.indexOf("duty") !== -1 || info.unit.indexOf("controller gain") !== -1) return COLORS.control;
  return COLORS.trajOpen;
}

function formatEng(value, unit) {
  // Automatic engineering-prefix scaling (e.g. 0.0008 s -> "0.80 ms",
  // 3500 V -> "3.50 kV"), matching standard engineering convention of
  // scaling by powers of 1000 with unit prefixes, not just showing raw
  // numbers with no unit. Falls back to a modest fixed precision for
  // values already in a sensible range.
  if (value === null || value === undefined || !isFinite(value)) return "\u2014";
  var abs = Math.abs(value);
  if (abs === 0) return "0 " + unit;
  var prefixes = [
    [1e9, "G"], [1e6, "M"], [1e3, "k"], [1, ""], [1e-3, "m"], [1e-6, "\u03bc"], [1e-9, "n"],
  ];
  for (var i = 0; i < prefixes.length; i++) {
    if (abs >= prefixes[i][0]) {
      return (value / prefixes[i][0]).toFixed(2) + " " + prefixes[i][1] + unit;
    }
  }
  return (value / 1e-9).toFixed(2) + " n" + unit;  // smaller than nano -- rare, but don't fall through with nothing
}

function figureSlot(id, forExport, caption) {
  if (forExport) {
    var el = $(id);
    if (!el) return "";
    var out = "";
    el.querySelectorAll("canvas").forEach(function (cv) {
      out += "<img src='" + cv.toDataURL("image/png") + "' style='max-width:100%;border:1px solid var(--border,#ddd);border-radius:6px;margin:6px 0;'>";
    });
    if (!out) return "";
    var captionText = "";
    if (caption) {
      window.reportFigureCounter = (window.reportFigureCounter || 0) + 1;
      captionText = "<div class='figure-caption' style='font-size:10.5px;color:var(--text-dim,#888);margin-top:4px;'><b>Figure " + window.reportFigureCounter + ".</b> " + caption + "</div>";
    }
    return "<div class='figure-wrap'>" + out + captionText + "</div>";
  }
  return "<div id='" + id + "'></div>" + (caption ? "<div style='font-size:10.5px;color:var(--text-dim,#888);margin-top:2px;'>" + caption + "</div>" : "");
}

function electricalPowerMetricsBlock(pm) {
  var div = document.createElement("div");
  div.style.marginTop = "10px";
  div.innerHTML = "<div class='info-grid'>" +
    "<div class='info-card'><div class='lbl'>Max deviation</div><div class='val'>" + pm.max_deviation.toFixed(4) + "</div></div>" +
    "<div class='info-card'><div class='lbl'>Steady-state error</div><div class='val' style='font-size:12px'>" + pm.steady_state_error.toExponential(2) + "</div></div>" +
    "<div class='info-card'><div class='lbl'>Settling time</div><div class='val'>" + (pm.settling_time === null ? "\u2014" : pm.settling_time.toFixed(4) + " s") + "</div></div>" +
    "<div class='info-card'><div class='lbl'>Overshoot</div><div class='val'>" + pm.overshoot_pct.toFixed(1) + "%</div></div>" +
    "</div>";
  return div;
}

function renderElectricalPowerPlot(data, wrapId, legendId, metricsHost) {
  wrapId = wrapId || "elecPowerWrap"; legendId = legendId || "elecPowerLegend";
  var wrap = $(wrapId);
  var epOl = data.electrical_power_open_loop;
  var epCl = data.electrical_power_closed_loop;
  var ptsOl = epOl.t.map(function (t, i) { return [t, epOl.power[i]]; });
  var series = [ptsOl];
  var ptsCl = null;
  if (epCl) { ptsCl = epCl.t.map(function (t, i) { return [t, epCl.power[i]]; }); series.push(ptsCl); }
  var bounds = computeBounds(series);
  var c = makeCanvas(wrap, 255);
  var m = { l: 58, r: 16, t: 14, b: 32 };
  drawGrid(c.ctx, bounds, c.w, c.h, m, "Time (s)", "P_e (p.u.)");
  drawLine(c.ctx, ptsOl, bounds, c.w, c.h, m, COLORS.trajOpen, 2.0);
  if (ptsCl) drawLine(c.ctx, ptsCl, bounds, c.w, c.h, m, COLORS.trajClosed, 2.0);
  if ($(legendId)) {
    $(legendId).innerHTML = '<span><span class="legend-swatch" style="background:' + COLORS.trajOpen + '"></span>Open loop</span>' +
      (ptsCl ? '<span><span class="legend-swatch" style="background:' + COLORS.trajClosed + '"></span>Closed loop</span>' : "");
  }
  // IMPORTANT: appendChild a fresh element here, never metricsHost.innerHTML +=
  // -- the host may already contain the live canvas `wrap` just drawn into
  // above, and re-serialising innerHTML on a parent that contains a
  // canvas discards its drawn pixel data (canvas raster content is not
  // part of the HTML serialisation), silently blanking the plot.
  if (metricsHost && data.electrical_power_metrics_open_loop) {
    metricsHost.appendChild(electricalPowerMetricsBlock(data.electrical_power_metrics_open_loop));
  }
}

function populateReportFigures() {
  var sim = stageResults.simulate, ims = stageResults.ims_analysis;
  if (sim && $("report_trajWrap")) renderTrajectoryPlot(sim, "report_trajWrap", "report_trajLegend");
  if (sim && sim.control_signal && $("report_controlWrap")) renderControlSignalPlot(sim, "report_controlWrap");
  if (sim && sim.electrical_power_open_loop && $("report_elecPowerWrap")) renderElectricalPowerPlot(sim, "report_elecPowerWrap", "report_elecPowerLegend");
  if (ims && ims.manifold && $("report_phaseWrap")) renderPhasePortrait(ims, "report_phaseWrap", "report_phaseLegend");
  if (ims && $("report_residualWrap")) {
    if (ims.manifold_residual_trajectory) renderResidualPlot("report_residualWrap", ims.manifold_residual_trajectory.t, ims.manifold_residual_trajectory.residual, "Time (s)");
    else if (ims.residual && ims.trajectory) renderResidualPlot("report_residualWrap", ims.trajectory.t, ims.residual, "Time (s)");
  }
  if (ims && ims.recoverability && $("report_recMapWrap")) renderRecoverabilityMap(ims, "report_recMapWrap", "report_recMapLegend");
  var dm = stageResults.design_mrc;
  if (dm && dm.custom && dm.closed_loop && dm.closed_loop.closed_loop_comparison && $("report_autoClIlWrap")) {
    drawAutoClosedLoopCharts(dm.closed_loop.closed_loop_comparison, "report_autoClIlWrap", "report_autoClVbWrap");
  }
}

function buildExecutiveSummaryHtml() {
  var eq = stageResults.equilibrium, ims = stageResults.ims_analysis;
  var stable = eq && eq.stable;
  var rec = ims && ims.recoverability;
  var det = ims && ims.recoverability_deterministic;
  var index = rec ? rec.index : (det ? null : null);
  var margin = rec ? rec.margin : (det ? det.recoverability_margin : null);
  var risk = rec ? rec.risk : null;

  var stabilityHtml = "<div class='dash-card'><div class='dash-lbl'>Equilibrium Stability</div>" +
    "<div class='dash-val'>" + (eq ? "<span class='risk-badge stability-badge-" + (stable ? "stable" : "unstable") + "'>" + (stable ? "STABLE" : "UNSTABLE") + "</span>" : "\u2014") + "</div></div>";
  var indexHtml = "<div class='dash-card'><div class='dash-lbl'>Recoverability Index</div>" +
    "<div class='dash-val'>" + (index !== null && index !== undefined ? index.toFixed(2) : "\u2014") + "</div></div>";
  var marginHtml = "<div class='dash-card'><div class='dash-lbl'>Recoverability Margin</div>" +
    "<div class='dash-val' style='font-size:20px;'>" + (margin !== null && margin !== undefined ? margin.toExponential(2) : "\u2014") + "</div></div>";
  var riskHtml = "<div class='dash-card'><div class='dash-lbl'>Risk Level</div>" +
    "<div class='dash-val'>" + (risk ? "<span class='risk-badge risk-" + risk + "'>" + risk + "</span>" : "\u2014") + "</div></div>";

  var findings = [];
  if (eq) findings.push("Equilibrium operating point is <b>" + (stable ? "stable" : "unstable") + "</b> under small-signal analysis.");
  if (risk) {
    var riskText = risk === "LOW" ? "a wide recoverability margin, indicating robust tolerance to large disturbances"
      : risk === "MEDIUM" ? "a moderate recoverability margin; some disturbance scenarios approach the recoverability boundary"
      : "a narrow recoverability margin; a significant fraction of sampled disturbances are non-recoverable";
    findings.push("Recoverability assessment classifies this operating point as <b>" + risk + " risk</b>, reflecting " + riskText + ".");
  }
  if (rec) findings.push(rec.n_recoverable + " of " + rec.n_samples + " sampled disturbance scenarios (" + (100 * rec.index).toFixed(0) + "%) returned to an admissible operating condition.");
  if (stageResults.build && stageResults.build.control_law_str) findings.push("A Manifold-Reshaping Control (MRC) law was synthesized for this network, directly targeting recoverability rather than equilibrium regulation alone.");
  var findingsHtml = findings.length ? "<ul class='exec-findings'>" + findings.map(function (f) { return "<li>" + f + "</li>"; }).join("") + "</ul>"
    : "<p style='font-size:12.5px;color:var(--text-dim,#888);'>Run the full analysis pipeline to populate the executive summary.</p>";

  var traceParts = [];
  if (currentProject && currentProject.id) traceParts.push("Project ID: <code>" + currentProject.id + "</code>");
  traceParts.push("Platform Version: v4.5");
  traceParts.push("Engine: Real Backend (Python)");
  if (eq && eq.solver_diagnostics && eq.solver_diagnostics.computation_time_s !== undefined) {
    traceParts.push("Equilibrium solve time: " + (eq.solver_diagnostics.computation_time_s * 1000).toFixed(2) + " ms");
  }
  var traceHtml = "<div style='font-size:10px;color:var(--text-dim,#888);margin-top:10px;padding-top:8px;border-top:1px solid var(--ims-line,var(--border-soft));'>" +
    traceParts.join(" &nbsp;&middot;&nbsp; ") + "</div>";

  return "<div class='panel exec-summary' style='order:0;'>" +
    "<div class='panel-title'>Executive Summary</div>" +
    "<div class='dash-grid'>" + stabilityHtml + indexHtml + marginHtml + riskHtml + "</div>" +
    findingsHtml + traceHtml +
    "</div>";
}

function buildReportBodyHtml(forExport) {
  window.reportFigureCounter = 0;
  var p = currentProject, b = stageResults.build, eq = stageResults.equilibrium,
      sim = stageResults.simulate, ims = stageResults.ims_analysis;
  var html = buildExecutiveSummaryHtml() + "<div class='panel' style='order:1;'><div class='panel-title'>Project information</div>" +
    "<p style='font-size:13px;line-height:1.6;'><b>" + p.label + "</b> &mdash; " + p.description + "</p>" +
    "<p style='font-size:11.5px;color:var(--text-dim, #888);'>Computed by the real ims_platform Python engine (equilibrium solving, manifold continuation, geometry-based recoverability assessment from the manifold residual, with optional Monte-Carlo statistical validation" +
    (b && b.control_law_str ? ", genuine Symbolic-Engine-derived MRC synthesis" : "") + "), not a browser reimplementation.</p></div>";

  // --- Network / topology ---
  if (b) {
    var ns = b.network_summary || {};
    html += "<div class='panel' style='order:2;'><div class='panel-title'>Network description</div>";
    if (ns.component_types) {
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin-bottom:4px;'>Topology</div>" +
        "<table style='width:100%;border-collapse:collapse;font-size:12px;margin-bottom:10px;'>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Buses</td><td>" + ns.buses + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Lines</td><td>" + ns.lines + "</td></tr>" +
        Object.keys(ns.component_types).map(function (t) {
          return "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>" + t + "</td><td>" + ns.component_types[t] + "</td></tr>";
        }).join("") + "</table>";
      if (ns.converter_topologies && Object.keys(ns.converter_topologies).length) {
        html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin-bottom:4px;'>Converter topologies</div>" +
          "<div style='font-size:12px;margin-bottom:8px;'>" +
          Object.keys(ns.converter_topologies).map(function (t) { return t + ": " + ns.converter_topologies[t]; }).join(", ") + "</div>";
      }
      if (ns.converter_control_modes && Object.keys(ns.converter_control_modes).length) {
        html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin-bottom:4px;'>Control modes</div>" +
          "<div style='font-size:12px;margin-bottom:8px;'>" +
          Object.keys(ns.converter_control_modes).map(function (t) { return t.replace("_", " ") + ": " + ns.converter_control_modes[t]; }).join(", ") + "</div>";
      }
    } else {
      html += "<table style='width:100%;border-collapse:collapse;font-size:12px;margin-bottom:10px;'>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Buses</td><td>" + (ns.buses !== undefined ? ns.buses : "\u2014") + "</td>" +
        "<td style='padding:3px 8px 3px 16px;color:var(--text-dim,#888);'>Converters</td><td>" + (ns.converters !== undefined ? ns.converters : "\u2014") + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Loads</td><td>" + (ns.loads !== undefined ? ns.loads : "\u2014") + "</td>" +
        "<td style='padding:3px 8px 3px 16px;color:var(--text-dim,#888);'>Lines</td><td>" + (ns.lines !== undefined ? ns.lines : "\u2014") + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Controllers</td><td colspan='3'>" + (ns.controllers !== undefined ? ns.controllers : "\u2014") + "</td></tr>" +
        "</table>";
    }
    if (b.topology_tree && b.topology_tree.length) {
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin-bottom:4px;'>Topology tree</div>" +
        "<div style='font-size:12px;font-family:monospace;line-height:1.8;white-space:pre;'>" + b.topology_tree.join("\n") + "</div>";
    }
    if (b.component_chain && b.component_chain.length) {
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Component chain</div>" +
        "<div style='font-size:12px;line-height:1.7;'>" + b.component_chain.join(" &#8594; ") + "</div>";
    }
    html += "</div>";
  }

  // --- Mathematical model ---
  if (b) {
    var mo = b.model_order || {};
    html += "<div class='panel' style='order:3;'><div class='panel-title'>Mathematical model</div>" +
      "<p style='font-size:12px;'>" + (mo.n_states !== undefined ? mo.n_states : b.state_names.length) + " states, " +
      (mo.n_inputs !== undefined ? mo.n_inputs : "\u2014") + " input(s), " + (mo.n_outputs !== undefined ? mo.n_outputs : "\u2014") + " output(s)</p>" +
      "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin-bottom:4px;'>State variables</div>" +
      "<table style='width:100%;border-collapse:collapse;font-size:12px;'>" +
      "<tr style='color:var(--text-dim,#888);text-align:left;font-size:10px;text-transform:uppercase;'><th style='padding:3px 8px 3px 0;'>State</th><th>Physical Meaning</th><th>Unit</th></tr>" +
      b.state_names.map(function (s, i) {
        var info = stateVariableInfo(s);
        return "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>x" + (i + 1) + " (" + s + ")</td><td>" + info.meaning + "</td><td>" + info.unit + "</td></tr>";
      }).join("") + "</table>" +
      "<p style='font-size:10.5px;color:var(--text-dim,#888);margin-top:4px;'>Units follow this platform's own SI convention (volts, amps); the platform does not yet track a per-project base-unit system (e.g. explicit per-unit/p.u. scaling), so values here are in the same units the network was built with.</p>";
    if (b.engineering_outputs && b.engineering_outputs.length) {
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Outputs</div>" +
        "<div style='font-size:12px;'>" + b.engineering_outputs.map(function (o) { return o.name + " (" + o.kind + ")"; }).join("<br>") + "</div>";
    }
    if (b.params_used) {
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Parameters</div>" +
        buildCategorizedParamsTableHtml(b.params_used) +
        "<p style='font-size:10.5px;color:var(--text-dim,#888);margin-top:4px;'>Units follow this platform's own SI convention; the platform does not yet track a per-project base-unit system (e.g. explicit per-unit/p.u. scaling), so values here are in the same units the network was built with. Units shown as blank are inferred from the parameter name and could not be determined with confidence \u2014 no unit is claimed rather than guessed.</p>";
    }
    if (b.controller_description) {
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Controller assignment</div>" +
        "<div style='font-size:12px;'>" + b.controller_description + "</div>";
    }
    if (b.governing_equations && b.governing_equations.length) {
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Governing equations</div>" +
        "<div class='law-box' style='font-size:12px;'>" + b.governing_equations.join("<br>") + "</div>";
    }
    if (b.admissible_envelope) {
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Admissible operating envelope</div>" +
        "<div style='font-size:12px;'>" + b.admissible_envelope.description + "</div>";
    }
    html += "</div>";
  }
  if (b && b.control_law_str) {
    html += "<div class='panel' style='order:7;'><div class='panel-title'>Derived control law</div><div class='law-box'>u = " + b.control_law_str + "</div></div>";
  }

  // --- Equilibrium analysis ---
  if (eq) {
    var eig = (eq.eigenvalues || []).map(function (e) {
      return e.im === 0 ? e.re.toFixed(3) : (e.re.toFixed(3) + (e.im >= 0 ? "+" : "-") + Math.abs(e.im).toFixed(3) + "j");
    }).join(", ");
    html += "<div class='panel' style='order:6;'><div class='panel-title'>Equilibrium analysis</div><div class='eq-readout'>x* = [" +
      eq.x_star.map(function (v) { return v.toFixed(4); }).join(", ") + "]<br>stability: <b>" + (eq.stable ? "STABLE" : "UNSTABLE") + "</b>" +
      (eig ? "<br>eigenvalues: " + eig : "") + (eq.residual_norm !== undefined ? "<br>residual norm: " + eq.residual_norm.toExponential(2) : "") + "</div>";
    if (eq.solver_diagnostics) {
      var sd = eq.solver_diagnostics;
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Solver diagnostics</div>" +
        "<table style='width:100%;border-collapse:collapse;font-size:12px;'>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Function evaluations</td><td>" + sd.function_evaluations + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Jacobian condition number</td><td>" + sd.jacobian_condition_number.toExponential(2) + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Computation time</td><td>" + (sd.computation_time_s * 1000).toFixed(2) + " ms</td></tr>" +
        "</table>";
    }
    if (eq.note) html += "<p style='font-size:11.5px;color:#a15c00;margin-top:8px;'>" + eq.note + "</p>";
    if (eq.component_operating_points && Object.keys(eq.component_operating_points).length) {
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Component operating points</div>" +
        "<table style='width:100%;border-collapse:collapse;font-size:12px;'>" +
        "<tr style='color:var(--text-dim,#888);text-align:left;font-size:10px;text-transform:uppercase;'><th style='padding:3px 8px 3px 0;'>Component</th><th>Type</th><th>Bus</th><th>Voltage</th><th>Current</th><th>Power</th></tr>" +
        Object.keys(eq.component_operating_points).map(function (id) {
          var pt = eq.component_operating_points[id];
          return "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>" + id + "</td><td>" + pt.type + "</td><td>" + pt.bus + "</td><td>" +
            formatEng(pt.operating_voltage, "V") + "</td><td>" + formatEng(pt.operating_current, "A") + "</td><td>" + formatEng(pt.operating_power, "W") + "</td></tr>";
        }).join("") + "</table>";
    }
    if (eq.electrical_operating_point) {
      var eop = eq.electrical_operating_point;
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Electrical operating point</div>" +
        "<table style='width:100%;border-collapse:collapse;font-size:12px;'>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Power angle \u03b4*</td><td>" + eop.delta.toFixed(4) + " rad</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>P_e(\u03b4*)</td><td>" + eop.electrical_power.toFixed(4) + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>P_set</td><td>" + eop.power_setpoint.toFixed(4) + " (match: " + (eop.matches_setpoint ? "exact" : "MISMATCH") + ")</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Power mismatch</td><td>" + eop.power_mismatch.toExponential(2) + "</td></tr>" +
        "</table>";
    }
    if (eq.transverse_stability) {
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Transverse stability</div>" +
        "<div style='font-size:12px;'><b>" + (eq.transverse_stability.is_hyperbolic ? "Normally hyperbolic" : "NOT normally hyperbolic") + "</b> \u2014 " + eq.transverse_stability.description + "</div>";
    }
    if (eq.jacobian) {
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Jacobian summary</div>" +
        "<table style='width:100%;border-collapse:collapse;font-size:12px;margin-bottom:10px;'>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Size</td><td>" + eq.jacobian.length + " \u00d7 " + eq.jacobian.length + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Rank</td><td>" + (eq.jacobian_rank !== undefined && eq.jacobian_rank !== null ? eq.jacobian_rank + " / " + eq.jacobian.length : "\u2014") + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Condition number</td><td>" + (eq.solver_diagnostics && eq.solver_diagnostics.jacobian_condition_number !== null && eq.solver_diagnostics.jacobian_condition_number !== undefined ? eq.solver_diagnostics.jacobian_condition_number.toExponential(2) : "singular/undefined") + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Spectral radius</td><td>" + (eq.jacobian_spectral_radius !== undefined && eq.jacobian_spectral_radius !== null ? eq.jacobian_spectral_radius.toFixed(3) : "\u2014") + "</td></tr>" +
        "</table>" +
        "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Appendix: full Jacobian matrix</div>" +
        "<p style='font-size:11px;color:var(--text-dim,#888);'>Supplementary \u2014 the summary above is typically what's needed for stability assessment; the full \u2202f/\u2202x matrix below is included for completeness and reproducibility.</p>" +
        buildMatrixTableHtml(eq.jacobian, eq.state_names);
    }
    if (eq.characteristic_time_constants) {
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Characteristic time constants</div>" +
        "<div style='font-size:12px;'>" + eq.characteristic_time_constants.map(function (tc, i) {
          return "Mode " + (i + 1) + ": " + (tc === null ? "\u2014" : tc.toFixed(4) + " s");
        }).join(", ") + "</div>";
    }
    html += "</div>";
  }

  // --- Simulation results ---
  if (sim) {
    html += "<div class='panel' style='order:5;'><div class='panel-title'>Simulation results</div>";
    html += "<p style='font-size:12px;'>Disturbed initial state: [" + sim.disturbed_state.map(function (v) { return v.toFixed(3); }).join(", ") + "]<br>" +
      "Controller: " + (sim.controller_info ? sim.controller_info.type : "\u2014") + "</p>";
    html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>State trajectories</div>" +
      figureSlot("report_trajWrap", forExport, "State Trajectories following the applied disturbance, shown against simulation time.") + "<div class='legend-row' id='report_trajLegend'></div>";
    function reportMetricsTable(title, m, labels) {
      var rows = labels.map(function (lbl, i) {
        var unit = stateVariableInfo(lbl).unit;
        var unitSuffix = unit && unit !== "\u2014" ? " " + unit : "";
        return "<tr><td style='padding:3px 8px 3px 0;'>" + lbl + "</td><td>" + m.max_deviation[i].toFixed(4) + unitSuffix + "</td><td>" +
          m.steady_state_error[i].toExponential(2) + unitSuffix + "</td><td>" + (m.settling_time[i] === null ? "\u2014" : m.settling_time[i].toFixed(4) + " s") +
          "</td><td>" + m.overshoot_pct[i].toFixed(1) + "%</td></tr>";
      }).join("");
      return "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>" + title + "</div>" +
        "<table style='width:100%;border-collapse:collapse;font-size:11.5px;'>" +
        "<tr style='color:var(--text-dim,#888);text-align:left;font-size:10px;text-transform:uppercase;'>" +
        "<th style='padding:3px 8px 3px 0;'>State</th><th>Max deviation</th><th>Steady-state error</th><th>Settling time</th><th>Overshoot</th></tr>" + rows + "</table>";
    }
    var labels = p.state_short || (sim.trajectory_open_loop.x.map(function (_, i) { return "x" + (i + 1); }));
    if (sim.performance_metrics_open_loop) html += reportMetricsTable("Performance metrics \u2014 open loop", sim.performance_metrics_open_loop, labels);
    if (sim.performance_metrics_closed_loop) html += reportMetricsTable("Performance metrics \u2014 closed loop", sim.performance_metrics_closed_loop, labels);
    if (sim.electrical_power_open_loop) {
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Electrical power P_e(t)</div>" +
        figureSlot("report_elecPowerWrap", forExport, "Electrical Power Response during the disturbance transient.") + "<div class='legend-row' id='report_elecPowerLegend'></div>";
      if (sim.electrical_power_metrics_open_loop) {
        var pm = sim.electrical_power_metrics_open_loop;
        html += "<table style='width:100%;border-collapse:collapse;font-size:12px;margin-top:6px;'>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Max deviation / steady-state error</td><td>" + pm.max_deviation.toFixed(4) + " / " + pm.steady_state_error.toExponential(2) + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Settling time / overshoot</td><td>" + (pm.settling_time === null ? "\u2014" : pm.settling_time.toFixed(4) + " s") + " / " + pm.overshoot_pct.toFixed(1) + "%</td></tr>" +
          "</table>";
      }
    }
    if (sim.control_signal) {
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Control input u(t)</div>" +
        figureSlot("report_controlWrap", forExport, "Control Signal applied by the closed-loop controller during the transient.");
    }
    html += "</div>";
  }

  // --- IMS / recoverability results ---
  if (ims) {
    html += "<div class='panel' style='order:4;'><div class='panel-title'>IMS analysis</div>";
    if (ims.manifold_stats) {
      var ms = ims.manifold_stats;
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin-bottom:4px;'>Intrinsic manifold</div>" +
        "<table style='width:100%;border-collapse:collapse;font-size:12px;margin-bottom:10px;'>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Continuation parameter</td><td>" + ms.continuation_parameter + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Operating interval</td><td>" + (ms.operating_interval ? "[" + ms.operating_interval[0].toFixed(3) + ", " + ms.operating_interval[1].toFixed(3) + "]" : "\u2014") + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Continuation points</td><td>" + ms.n_points + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Manifold dimension</td><td>" + ms.dimension + " (single-parameter continuation)</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Stable / unstable points</td><td>" + ms.n_stable + " / " + ms.n_unstable + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Singular (fold) points detected</td><td>" + ms.n_singular_points + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Empirically persistent (this interval)</td><td>" + (ms.empirically_persistent ? "Yes" : "No") + "</td></tr>" +
        (ms.max_curvature !== null && ms.max_curvature !== undefined ? "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Max / mean curvature</td><td>" + ms.max_curvature.toExponential(3) + " / " + ms.mean_curvature.toExponential(3) + "</td></tr>" : "") +
        (ms.arc_length !== undefined ? "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Arc length</td><td>" + ms.arc_length.toFixed(4) + "</td></tr>" : "") +
        (ms.tangent_at_nearest ? "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Tangent at operating point</td><td>[" + ms.tangent_at_nearest.map(function (v) { return v.toFixed(4); }).join(", ") + "]</td></tr>" : "") +
        (ms.operating_region_stable ? "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Recommended operating region</td><td>[" + ms.operating_region_stable[0].toFixed(4) + ", " + ms.operating_region_stable[1].toFixed(4) + "]</td></tr>" : "") +
        "</table>";
      if (ms.n_singular_points > 0) {
        html += "<p style='font-size:11.5px;color:#a15c00;'>Stability changes sign at " + ms.n_singular_points +
          " point(s) along the traced manifold \u2014 normal hyperbolicity is lost there (architecture doc \u00a71.6, a fold/termination of the fast equilibrium manifold).</p>";
      }
      if (ms.n_points <= 2) {
        html += "<p style='font-size:11.5px;color:#a15c00;'>Only " + ms.n_points + " manifold point" + (ms.n_points === 1 ? "" : "s") +
          " converged across the requested sweep range \u2014 too few to trace a meaningful manifold curve or compute arc length/curvature reliably (shown as 0 below is a consequence of this, not a separate finding). " +
          "This typically means the equilibrium does not persist under small variations of the swept input, which is itself informative: combined with the stability result above, it suggests this operating point may be structurally isolated or on a knife-edge rather than part of a robust operating range. " +
          "Consider a narrower sweep range closer to the equilibrium, or treat the eigenvalue-based stability result as the primary evidence for this network rather than the manifold geometry.</p>";
      }
    } else if (ims.manifold) {
      html += "<p style='font-size:12px;'>Intrinsic manifold traced at " + ims.manifold.points.length + " points.</p>";
    }
    html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Phase portrait</div>" +
      figureSlot("report_phaseWrap", forExport, "Intrinsic Manifold Phase Portrait, showing the traced stable branch and the equilibrium operating point.") + "<div class='legend-row' id='report_phaseLegend'></div>";
    if (ims.manifold_residual_trajectory || (ims.residual && ims.trajectory)) {
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Manifold residual over time</div>" +
        figureSlot("report_residualWrap", forExport, "Manifold Residual Evolution over the simulated trajectory (distance to the intrinsic manifold).");
      if (ims.residual_statistics) {
        var rs = ims.residual_statistics;
        html += "<table style='width:100%;border-collapse:collapse;font-size:12px;margin-top:8px;'>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Max / RMS / mean residual</td><td>" + rs.max.toExponential(3) + " / " + rs.rms.toExponential(3) + " / " + rs.mean.toExponential(3) + "</td></tr>" +
          (rs.empirical_contraction_rate !== null && rs.empirical_contraction_rate !== undefined ? "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Empirical contraction rate</td><td>" + rs.empirical_contraction_rate.toFixed(3) + " s\u207b\u00b9</td></tr>" : "") +
          "</table>";
      }
    }
    if (ims.recoverability_deterministic) {
      var det = ims.recoverability_deterministic;
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Recoverability assessment (deterministic, manifold-based)</div>" +
        "<p style='font-size:12px;line-height:1.6;color:var(--text-dim,#888);'>Computed directly from this trajectory's own manifold residual e_m(t), per Definition IV.2 of the IMS framework \u2014 the primary recoverability signal, not a statistical estimate.</p>" +
        "<table style='width:100%;border-collapse:collapse;font-size:12px;'>" +
        (ims.residual_projection_method ? "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Residual projection method</td><td><b>" + ({ polyline: "Polyline", nearest_sample: "Nearest sample (legacy)", newton_refined: "Newton-refined" }[ims.residual_projection_method] || ims.residual_projection_method) + "</b></td></tr>" : "") +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Classification</td><td><b>" + det.classification + "</b></td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Max |e_m|</td><td>" + det.max_residual.toExponential(3) + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>RMS |e_m|</td><td>" + det.rms_residual.toExponential(3) + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Integral of |e_m|</td><td>" + det.integral_abs_residual.toExponential(3) + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Final e_m</td><td>" + det.final_residual.toExponential(3) + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Recovery time</td><td>" + (det.recovery_time !== null ? det.recovery_time.toFixed(4) + " s" : "not reached") + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Contraction rate</td><td>" + (det.contraction_rate !== null ? det.contraction_rate.toFixed(2) + " s\u207b\u00b9" : "n/a") + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Recoverability margin</td><td>" + (det.recoverability_margin !== undefined ? det.recoverability_margin.toExponential(3) + (det.recoverability_margin >= 0 ? " (inside tolerance)" : " (tolerance exceeded)") : "n/a") + "</td></tr>" +
        "</table>";
      if (det.geometric_narrative) {
        html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Geometric interpretation</div>" +
          "<p style='font-size:12px;line-height:1.6;'>" + det.geometric_narrative + "</p>";
      }
      if (ims.recoverability_region_summary) {
        var rs = ims.recoverability_region_summary;
        html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Recoverability region &amp; boundary</div>" +
          "<p style='font-size:11.5px;line-height:1.6;color:var(--text-dim,#888);'>" + rs.concept_explanation + "</p>" +
          "<p style='font-size:12px;line-height:1.6;'><b>Is this disturbance inside R?</b> " + (rs.inside_region ? "Yes" : "No") + " \u2014 " + rs.membership_explanation + "</p>" +
          "<p style='font-size:11px;line-height:1.6;color:var(--text-dim,#888);font-style:italic;'>" + rs.boundary_note + "</p>";
      }
      if (ims.manifold_residual_explanation) {
        html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>What is the manifold residual?</div>" +
          "<p style='font-size:11.5px;line-height:1.6;color:var(--text-dim,#888);'>" + ims.manifold_residual_explanation + "</p>";
      }
      if (ims.projection_method_validation_summary) {
        html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Projection method validation</div>" +
          "<p style='font-size:11.5px;line-height:1.6;color:var(--text-dim,#888);'>" + ims.projection_method_validation_summary + "</p>";
      }
      if (det.ims_conditions) {
        var ic = det.ims_conditions;
        var chk2 = function (v) {
          if (v === "SATISFIED") return "Satisfied";
          if (v === "VIOLATED") return "Violated";
          if (v === true) return "Observed (empirical)";
          if (v === false) return "Not observed (empirical)";
          return "Not established";
        };
        html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>IMS conditions (Definition IV.3, tri-state)</div>" +
          "<p style='font-size:11.5px;color:var(--text-dim,#888);'>\"Not established\" is a genuine third state, not a failure \u2014 it means this pathway lacks the analytic structure (e.g. the manifold's own target rate k_m) to evaluate that specific claim. These are separate claims and are never inferred from one another.</p>" +
          "<table style='width:100%;border-collapse:collapse;font-size:12px;'>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Full-system local stability</td><td>" + chk2(ic.full_system_local_stability) + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Normal hyperbolicity</td><td>" + chk2(ic.normal_hyperbolicity) + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Transverse contraction (analytic)</td><td>" + chk2(ic.transverse_contraction) + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Reduced dynamics stable (analytic)</td><td>" + chk2(ic.reduced_dynamics_stable) + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Empirical finite-horizon recovery</td><td>" + chk2(ic.empirical_finite_horizon_recovery) + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Certified regional IMS</td><td>" + chk2(ic.certified_regional_ims) + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Overall IMS status</td><td><b>" + ic.overall_status + "</b></td></tr>" +
          "</table>";
      }
      if (det.limiting_state && det.classification !== "Recoverable") {
        html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Supplementary diagnostic (not an IMS quantity)</div>" +
          "<p style='font-size:11px;color:var(--text-dim,#888);margin-bottom:6px;'>Not part of the IMS framework itself \u2014 a simple per-state decomposition of the manifold residual, offered only as an engineering starting point, not as the identified cause of recoverability loss.</p>" +
          "<p style='font-size:12px;line-height:1.6;'>" + det.note + "</p>";
      }
    }
    if (ims.recoverability) {
      var r = ims.recoverability;
      html += (r.interpretation ? "<p style='font-size:13px;line-height:1.6;'>" + r.interpretation + "</p>" : "") +
        "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Statistical validation (Monte Carlo)</div>" +
        "<table style='width:100%;border-collapse:collapse;font-size:12px;'>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Recoverability index</td><td>" + r.index.toFixed(2) + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Recovered / sampled</td><td>" + r.n_recoverable + " / " + r.n_samples + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Recoverability margin</td><td>" + r.margin.toFixed(3) + "</td></tr>" +
        (r.confidence_interval ? "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Index 95% confidence interval</td><td>[" + r.confidence_interval[0].toFixed(2) + ", " + r.confidence_interval[1].toFixed(2) + "]</td></tr>" : "") +
        (r.worst_disturbance ? "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Worst (closest) unrecoverable disturbance</td><td>[" + r.worst_disturbance.map(function (v) { return v.toFixed(3); }).join(", ") + "]</td></tr>" : "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Worst unrecoverable disturbance</td><td>none \u2014 all sampled disturbances recovered</td></tr>") +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Risk level</td><td><span class='risk-badge risk-" + r.risk + "'>" + r.risk + "</span></td></tr>" +
        "</table>" +
        "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Recoverability map</div>" +
        figureSlot("report_recMapWrap", forExport, "Recoverability Map, showing sampled disturbances classified as recovered or non-recovered, with the traced recoverability boundary.") + "<div class='legend-row' id='report_recMapLegend'></div>";
      if (ims.recoverability_boundary) {
        var b = ims.recoverability_boundary;
        html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Critical boundary (traced)</div>" +
          "<table style='width:100%;border-collapse:collapse;font-size:12px;'>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Directions sampled</td><td>" + b.n_directions + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Boundary found</td><td>" + b.n_found + " / " + b.n_directions + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Min / max radius</td><td>" + b.min_radius.toFixed(3) + " / " + b.max_radius.toFixed(3) + "</td></tr>" +
          "</table>";
      }
      if (ims.recoverability_closed_loop) {
        var rc = ims.recoverability_closed_loop;
        html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Controller effect on recoverability</div>" +
          "<table style='width:100%;border-collapse:collapse;font-size:12px;'>" +
          "<tr style='color:var(--text-dim,#888);text-align:left;font-size:10px;text-transform:uppercase;'><th style='padding:3px 8px 3px 0;'></th><th>Open loop</th><th>Closed loop</th></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Recoverability index</td><td>" + r.index.toFixed(2) + "</td><td>" + rc.index.toFixed(2) + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Margin</td><td>" + r.margin.toFixed(3) + "</td><td>" + rc.margin.toFixed(3) + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Risk</td><td><span class='risk-badge risk-" + r.risk + "'>" + r.risk + "</span></td><td><span class='risk-badge risk-" + rc.risk + "'>" + rc.risk + "</span></td></tr>" +
          "</table>";
      }
    }
    if (ims.note) html += "<p style='font-size:11.5px;color:#a15c00;margin-top:8px;'>" + ims.note + "</p>";
    html += "</div>";
  }

  // --- Controller comparison (genuine 2-way: Open Loop vs Scheduled LQR;
  //     a 3rd IMS-MRC column is not added here since MRC synthesis is not
  //     available for this project's model -- see the Network + Auto-MRC
  //     project for that pathway instead of fabricating a column here) ---
  if (sim && sim.performance_metrics_open_loop && sim.performance_metrics_closed_loop && ims && ims.recoverability && ims.recoverability_closed_loop) {
    var mOL = sim.performance_metrics_open_loop, mCL = sim.performance_metrics_closed_loop;
    var rOL = ims.recoverability, rCL = ims.recoverability_closed_loop;
    var cmpLabels = p.state_short || mOL.max_deviation.map(function (_, i) { return "x" + (i + 1); });
    html += "<div class='panel' style='order:8;'><div class='panel-title'>Controller comparison</div>" +
      "<table style='width:100%;border-collapse:collapse;font-size:12px;'>" +
      "<tr style='color:var(--text-dim,#888);text-align:left;font-size:10px;text-transform:uppercase;'><th style='padding:3px 8px 3px 0;'>Metric</th><th>Open loop</th><th>Scheduled LQR</th></tr>" +
      "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Recoverability index</td><td>" + rOL.index.toFixed(2) + "</td><td>" + rCL.index.toFixed(2) + "</td></tr>" +
      "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Recoverability margin</td><td>" + rOL.margin.toFixed(3) + "</td><td>" + rCL.margin.toFixed(3) + "</td></tr>" +
      cmpLabels.map(function (lbl, i) {
        return "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Settling time (" + lbl + ")</td><td>" +
          (mOL.settling_time[i] === null ? "\u2014" : mOL.settling_time[i].toFixed(4) + " s") + "</td><td>" +
          (mCL.settling_time[i] === null ? "\u2014" : mCL.settling_time[i].toFixed(4) + " s") + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Overshoot (" + lbl + ")</td><td>" + mOL.overshoot_pct[i].toFixed(1) + "%</td><td>" + mCL.overshoot_pct[i].toFixed(1) + "%</td></tr>";
      }).join("") +
      (sim.control_effort ? "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Control effort (RMS)</td><td>\u2014</td><td>" + sim.control_effort.rms.toFixed(4) + "</td></tr>" : "") +
      "</table>" +
      "<div class='help-text' style='margin-top:8px;'>A 2-way comparison (Open Loop vs. Scheduled LQR, the Conventional Control Library) -- a 3rd IMS-native MRC column is not included here because genuine MRC synthesis is not yet implemented for this project's model; see the Network + Auto-MRC project for that pathway.</div>" +
      "</div>";
  }

  // --- MRC Controller design & closed-loop verification (custom_network
  //     projects: the automatically-derived MRC from THIS project's own
  //     Design MRC Controller stage, not a separate demo) ---
  if (stageResults.design_mrc && stageResults.design_mrc.custom) {
    var dm = stageResults.design_mrc, dmf = (dm.inspect || {}), dmpr = dmf.pipeline_report || {};
    html += "<div class='panel' style='order:7;'><div class='panel-title'>MRC Controller (automatically derived)</div>" +
      "<div style='margin-bottom:8px;'>" + dmStatusBadge(dm.status) + "</div>" +
      "<table style='width:100%;border-collapse:collapse;font-size:12px;'>" +
      "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Target converter</td><td>" + (dmpr.converter_id || "—") + "</td></tr>" +
      "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Topology</td><td>" + (dmpr.topology || "—") + "</td></tr>" +
      "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>rank(Dφ·G)</td><td>" + (dmpr.rank_A != null ? dmpr.rank_A : "—") + "</td></tr>" +
      "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Relative degree</td><td>" + (dmpr.relative_degree != null ? dmpr.relative_degree : "—") + "</td></tr>" +
      "</table>" +
      (dmpr.candidate_phi ? "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Candidate signed controlled-target manifold (M1, φ1)</div><div class='law-box' style='font-size:12px;'>" + dmpr.candidate_phi + "</div>" : "") +
      (dmpr.control_law_latex ? "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>M1 synthesized control law</div><div class='law-box' style='font-size:12px;word-break:break-word;'>" + dmpr.control_law_latex + "</div>" : "");

    // --- M1 (φ1, current-anchored) mathematical detail: transverse
    // contraction result, tangential/reduced eigenvalues, equilibrium
    // duty and saturation -- so the report shows the EXACT reason M1 was
    // accepted or rejected, not just a prose summary of it. All values
    // come straight from run_auto_mrc_pipeline's own report (never
    // recomputed client-side). ---
    if (dmpr.transverse_eigenvalue || dmpr.reduced_dynamics_status) {
      var tev1 = dmpr.transverse_eigenvalue || {};
      var tang1 = dmpr.tangential_eigenvalues || [];
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>M1 tangent / normal decomposition</div>" +
        "<table style='width:100%;border-collapse:collapse;font-size:12px;'>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Transverse eigenvalue (contraction λ⊥)</td><td>" + (tev1.re != null ? tev1.re.toFixed(4) + (tev1.im ? " ± " + Math.abs(tev1.im).toFixed(4) + "i" : "") : "—") + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Transverse identity (λ⊥ = -k_m)</td><td>" + (dmpr.transverse_matches_km ? "verified" : "not verified") + "</td></tr>" +
        (tang1.length ? "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Tangential / reduced eigenvalues</td><td>" + tang1.map(function (e) { return e.re.toFixed(4) + (e.im ? " ± " + Math.abs(e.im).toFixed(4) + "i" : ""); }).join(", ") + "</td></tr>" : "") +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Reduced dynamics status</td><td>" + (dmpr.reduced_dynamics_status || "—") + "</td></tr>" +
        (dmpr.saturation_note ? "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Equilibrium duty</td><td>" + dmpr.saturation_note.duty_at_equilibrium.toFixed(4) + (dmpr.saturation_note.saturated ? " (SATURATED)" : "") + "</td></tr>" : "") +
        "</table>";
    }
    html += "<p style='font-size:11.5px;color:var(--text-dim,#888);margin-top:8px;'>" + (dmpr.reason || dmf.reason || "") + "</p>";

    // --- M2 (φ2, bus-voltage-anchored / reshaped manifold) mathematical
    // detail, when manifold reshaping was attempted -- selected R_v/K_i/
    // k_m, M2's own control law, transverse contraction, tangential/
    // reduced eigenvalues, equilibrium duty, physical feasibility, and
    // the large-signal control-authority/dynamic-singularity check that
    // gates candidate selection -- all read directly from the chosen
    // grid-search entry, never re-derived or approximated here. ---
    var m2r = dmpr.manifold_reshaping;
    if (m2r && m2r.attempted) {
      var ce = m2r.chosen_entry || null;
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:14px 0 4px;'>M2 — manifold reshaping (bus-voltage-anchored, φ2)</div>" +
        "<table style='width:100%;border-collapse:collapse;font-size:12px;'>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>M2 search status</td><td>" + (m2r.status || "—") + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>K_i (integral gain)</td><td>" + (m2r.K_i != null ? m2r.K_i : "—") + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>k_m (contraction rate)</td><td>" + (m2r.k_m != null ? m2r.k_m : "—") + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Selected R_v (droop gain)</td><td>" + (m2r.chosen_R_v != null ? m2r.chosen_R_v : "— (no candidate selected)") + "</td></tr>" +
        "</table>" +
        (m2r.phi2_latex ? "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>M2 candidate manifold</div><div class='law-box' style='font-size:12px;'>" + m2r.phi2_latex + "</div>" : "") +
        (m2r.control_law2_latex ? "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>M2 synthesized control law</div><div class='law-box' style='font-size:12px;word-break:break-word;'>" + m2r.control_law2_latex + "</div>" : "");
      if (ce) {
        var tev2 = ce.transverse_eigenvalue || {};
        var decomp2 = ce.tangent_normal_decomposition || {};
        var tang2 = decomp2.tangential_eigenvalues || [];
        var pf2 = ce.physical_feasibility || {};
        var dsc2 = ce.dynamic_singularity_check || {};
        html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>M2 tangent / normal decomposition (chosen R_v=" + ce.R_v + ")</div>" +
          "<table style='width:100%;border-collapse:collapse;font-size:12px;'>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Transverse eigenvalue (contraction λ⊥)</td><td>" + (tev2.re != null ? tev2.re.toFixed(4) + (tev2.im ? " ± " + Math.abs(tev2.im).toFixed(4) + "i" : "") : "—") + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Transverse identity (λ⊥ = -k_m) verified</td><td>" + (decomp2.left_eigenvector_verified ? "yes" : "no") + "</td></tr>" +
          (tang2.length ? "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Tangential / reduced eigenvalues</td><td>" + tang2.map(function (e) { return e.re.toFixed(4) + (e.im ? " ± " + Math.abs(e.im).toFixed(4) + "i" : ""); }).join(", ") + "</td></tr>" : "") +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Reduced dynamics status</td><td>" + (ce.reduced_dynamics_status || "—") + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Equilibrium duty</td><td>" + (pf2.duty_at_equilibrium != null ? pf2.duty_at_equilibrium.toFixed(4) + (pf2.duty_saturated ? " (SATURATED)" : "") : "—") + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Physical feasibility</td><td>" + (pf2.feasible ? "feasible" : "infeasible") + (pf2.DphiG_conditioning_ratio != null ? " (Dφ·G conditioning ratio " + pf2.DphiG_conditioning_ratio.toExponential(2) + ")" : "") + "</td></tr>" +
          "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>Large-signal control-authority check</td><td>" + (dsc2.safe ? "PASSED — A(x)=Dφ·G stays bounded away from 0 along a real recovery simulation" : "FAILED" + (dsc2.reason ? " — " + dsc2.reason : "")) + "</td></tr>" +
          "</table>";
      } else if (m2r.math_stable_but_infeasible_entry) {
        html += "<p style='font-size:11.5px;color:var(--text-dim,#888);'>A mathematically stable R_v candidate was found (R_v=" + m2r.math_stable_but_infeasible_entry.R_v + ") but failed its physical-feasibility / large-signal control-authority check -- reported honestly, not silently offered as SUPPORTED.</p>";
      }
    }
    if (dm.applied) {
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Applied to converter</div>" +
        "<p style='font-size:12px;'>MRC is the active controller of converter <b>" + (dm.applied.converter && dm.applied.converter.id) + "</b> in this project's assembled network.</p>";
    }
    if (dm.closed_loop && dm.closed_loop.closed_loop_comparison) {
      var clc2 = dm.closed_loop.closed_loop_comparison, cb2 = clc2.baseline || {}, cm2 = clc2.mrc || {};
      html += "<div style='font-size:11px;text-transform:uppercase;color:var(--text-dim,#888);margin:10px 0 4px;'>Before / After — baseline vs MRC</div>" +
        "<table style='width:100%;border-collapse:collapse;font-size:12px;'>" +
        "<tr style='color:var(--text-dim,#888);text-align:left;font-size:10px;text-transform:uppercase;'><th style='padding:3px 8px 3px 0;'>Metric</th><th>Baseline</th><th>MRC</th></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>final ‖x−x*‖</td><td>" + (cb2.final_deviation !== undefined && cb2.final_deviation !== null ? cb2.final_deviation.toExponential(3) : "—") + "</td><td>" + (cm2.final_deviation !== undefined && cm2.final_deviation !== null ? cm2.final_deviation.toExponential(3) : "—") + "</td></tr>" +
        "<tr><td style='padding:3px 8px 3px 0;color:var(--text-dim,#888);'>recovered within horizon</td><td>" + (cb2.recovered ? "yes" : "no") + "</td><td>" + (cm2.recovered ? "yes" : "no") + "</td></tr>" +
        "</table>" +
        "<div style='margin-top:10px;'>" + figureSlot("report_autoClIlWrap", forExport, "Inductor current i_L, baseline vs MRC, on the assembled network.") + "</div>" +
        "<div style='margin-top:10px;'>" + figureSlot("report_autoClVbWrap", forExport, "Bus voltage v_bus, baseline vs MRC, on the assembled network.") + "</div>";
    }
    html += "</div>";
  }

  // --- Conclusions ---
  if (eq && ims && ims.recoverability) {
    var r = ims.recoverability;
    var interp = (eq.stable ? "The equilibrium is locally stable" : "The equilibrium is NOT locally stable") +
      ", with a recoverability index of " + r.index.toFixed(2) + " (" + r.risk + " risk) over the sampled disturbance set. " +
      (r.risk === "LOW" ? "The system recovers reliably from the tested disturbance range." :
       r.risk === "MEDIUM" ? "A non-trivial fraction of tested disturbances do not recover; consider tightening protection settings or enabling closed-loop control." :
       "The majority of tested disturbances do not recover at this operating point; re-dispatch or controller re-tuning is recommended before relying on it under contingency conditions.");
    if (ims.manifold_stats && ims.manifold_stats.operating_region_stable) {
      var reg = ims.manifold_stats.operating_region_stable;
      interp += " The stable branch of the traced manifold spans [" + reg[0].toFixed(3) + ", " + reg[1].toFixed(3) + "] in its first state coordinate; operating within that range keeps the system on a normally-hyperbolic branch of the intrinsic manifold, though this is not a claim about thermal, insulation, or other engineering limits the platform does not model.";
    }
    interp += " Identifying which specific component most limits recoverability would require a component-level sensitivity study, which this version does not compute -- stated here rather than left unaddressed.";
    var allRecovered = r.n_recoverable === r.n_samples;
    var keyFindings = [
      (eq.stable ? "\u2713" : "\u2717") + " " + (eq.stable ? "Stable" : "Unstable") + " equilibrium",
      "\u2713 Recoverability index: " + r.index.toFixed(2),
      "\u2713 Recoverability margin: " + r.margin.toExponential(2),
      "\u2713 " + r.risk + "-risk operating region",
      (allRecovered ? "\u2713 No unrecoverable trajectories observed" : "\u2717 " + (r.n_samples - r.n_recoverable) + " of " + r.n_samples + " sampled trajectories did not recover"),
    ];
    html += "<div class='panel' style='order:9;'><div class='panel-title'>Conclusions</div>" +
      "<div class='key-findings-box'>" + keyFindings.map(function (f) { return "<div class='key-finding-item'>" + f + "</div>"; }).join("") + "</div>" +
      "<p style='font-size:12.5px;line-height:1.6;'>" + interp + "</p></div>";
  }

  return html;
}

var IMS_LOGO_B64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAABqCAYAAAAGC2ywAACzLElEQVR42uy9d9hdV3klvnY59fby3a8XdVly7w0sU+1QEhJkSAhhIAlmSJt0khBkUVJmwiSkEZPqEAhIhEDoBmPJNrhX2erS19vt7fRdfn9cOeN4DCETEuxf9D7PffQ9956me/dZZ71rv+/awNk4G2fjbJyNs3E2zsbZOBtn42ycjf+iQZ6v17R79266ezcwNLSD7Np1iwKgBx/fQoBb9DN3YIxqKRUZ7LufHDjwFDlw4ACAg2rvXqgzx9Rnf+6z8V/5PtdaY9euXWzXrl3Arl3YBWDXrl36WfeGfsb98ux/6YEDOHNvHcCBAwdw4OABSf4ljPyXuM/I7t272Z137uGM0W+1DQPgALDPvFIAXADDAMYA5AGY/9eBCcA5w623vt3Yt283e56C9Nk4G9+1e2nPnj10z549/NZbHzK01oRSCkL+TcOeAjAA8O/4pISCMY4779R8z549XGtN/iPute/lzUv27dtNh4Z2kJe+9L1CqX8GZhNAYef5Gy770R8+f+QlL5kUBw6e/JHRUWc4XzJJuZLVpXKGgFJmcENKqVm9JlSjJqJmQ5Awiu/fMjPxwOc++zD/9GcePzQ3N3cUQB+AHHyxBEoptn//fty0+yYFcpZ5nY0XNkDt27ePDg0NkV27dilCqHoOkuMAoBvPPz9VzudfvfX8nWT7eZeRHdsvTJYXljfMnTj+atd1dcp1ieumwKkBKTWSJIHvB+h3PYReSDdtPu8fZqY3Lp166kHngQfuYsuLJ6NMOfzMoc8f7M8PsCT4lyA2uNduueUAuQW7FNlLAEC9oABrzx7QW27ZRxh7g3wGSJX+23+76oJXvOKclzCuv/+iC8ZGnUxSyhcVDCuERgShfSipAc1BqANCXYAYkIpAgwGwQKgJChPQJvy+QL0ai26L1leXe6e9tnXHga/e/9BffeyfHgSw+s/8VWu6f/9+ctNNN6mzaePZeCHEnj176C233EIAaEKpgv4Xw3bTzT/zi1Yxq1990Ytelm61omsylrljdHxcpfMVO4qNooQDjRSSBIgTIAgB3wOSeAAIjAKMAQYbHFBJQAtAS4BJgAmAEA8aASjTTRV3w1ZtiVara6vj4xNf+Kcv/pXSkP/0mS/c1gAw9y/yRa0p9oPc8tQteu/evfrfes+R/2ygIuQmeeYt+zd+9aVXnn9h7k3jk+lXb9pcGRkZzgAI0A2b6Hk1FUY9FSsFohlJlEF6sUYvVPB9DaU5HNNCJmUjn7Ohhda1VhddPwblpi4VsigWc9x1cshbExBxFkFHYWVON4Ke8bVvfvPRg7f8zh/elXjeU8/4Mtn+/Tfhppv2nwWvs/F8k0zoO9/5TrJr1y5JCHnm2Bz9xV//xYtd0379Bde+diiJkpcWKxtMYg5TL2RIAMT9ARjFAZBEEHECSAEoqaAUIBWIiDWSGEgiII4BrQigNCgBOAU4V8QxmLINwKAURAOmDdgWOD2TQ5oGYJiAUAIiqaG2cjQayle++MjDX1qplEY++Vv/681LHWD2n/NOSiGlpDfdtJ/s3/+dEQbynw1U5XJ5y8//3KU/+7KXVl66eYt9TrFMAfhoB4EWAtIPAhpEEYkiRRKpwR2GOImxUIvQjyiEAjQoNAi00jCZCSk44ggwuAXHtjEyXIZlEpxarmpmpDBSGtaVcl46dpoXnBFCVBZeW2B9sR/UVvsPPHHkyY//2i/8wVdx5stkjOLvxSfYTeQs6zob38PQmuwD6G5APQOk0le/5PKL3vzjP30BjOwP50e2b7TMyohgBbR6QKMJRH2NJBIy8JiKfEW1kpQZTKcdQlwbxOKAjAHfI4gCIPAV4oBASA2REBBCYJgDEErOgJfFANsAbFOjkAUMgyCKNJTWmmpAawWRQEMzaRkgtkl41iVIpwDTApTsoddf7fjh+lOt1trnH33iS3fv//Jf3wdAPA1ev/mbd3DggNq7d6/6ngDWvn272U037ZcAcPHFmy755V++9B3nnVf84Z07UymggV5QV422p5IIjBomafQFTq00sdb0EQQxylkT5VIa/RDQzEbaSiHj2mCMoev7WKp1cXK+g8UVH/1QwmAUls0xlEtjx8wEjBRHJwpR9yJ4sUIpk8ZEfliPlEYkY5T4SrGp8hSGUsNYm293+k31ids//9AX/uCDH/7c4MshUFoxAnJW6zob/2mxe/dutm/fPhBCns5GcMPLrr3urTff/GK3NP0anpm+LDGnsNYDag2gW4MKurFOIkAlmiYxQeRrEoUShBCYNgUkhYwBCg2DaTBKQcHAqQTlGlJQRMGAeXk9QCsNwyBghMC2gbQ7AC6REDA6AC7LVDBNCiWAOAK0BiyDgA7AFpxKbXEquQFiGYxkUqCFEpDJAEG/ppq104ury0fuOHDvZ7/yufs+8xkA8dNp4y233EL37t0rn00Y/kMAa8CqtCaE6KmpqQ2/+7uX/8qll+R/YvOWNAf6aPdrcq1ZJ72eTxk10QmAEytdrDR9CKWRtW1kLBddD5hd8tDoh1CUgDANRhlszlFImRirZLFpJguDU0QBRa2VoNMJoZiCooCUHBm7hJnxMTAe49hiFbW2B2owZN08NkxO65jEaqWxridGx/iOmfPA/SEEteTuO29/8I53/9L7/wzAOgDcqe/ku3C9JGeB62z8B4rnP/zDPyylHODUcG54w6+/9xduOv/KF78yNkavD9k0ql1gYRkIPAgEEUk8QrttSppNCT8ALJPCcYG0K8EogUgU2jUFrwtEoYYWgwexZWlksgyOy+DYCpASkU+gNBAlFF6XIAoIoAgcS6FUIigWOTI5AtMEIg9IIg0pCIgCAA2ZEEih4ZgEjg1wrkEBUELg2hqGoTWhUIZBtMUpz6YB1wI6/Qba/uITteqxz33z3i996rPfvO3xp4FKa02emQJ/1wHr7W+/xPjIRx5OAOB///Zr3n7dy+wPXnxpOq0QwQsTEfgJa/faRGsN13HQbPuYW2sjlgpZJ4uUayEMBJ446WN2uQU/FgiVRiA1EqlhmQzjQw6yjg2vq9FoSngBMF7JoDLkotYMcej0OlpeAG4aSBIFkjBsnhzG5HgejVaAaqML0zGQz6exY8NmlEpZLHeautpuyeHRIXr5+ZfSsjWJzpJe6zf7f/pjb/mZj3UWqqcB4M477+TXX3+9PJsqno3vWiaiNXsDZVJrBQDkV9+355oLL7jwZ8ZndrwySW/NHV4ETs5CxxGkoRPqtxTptxQJuxJRREC4RiZDYBmAimO0GyHiPoFWFJwZ4AygpobtcjBmglFAC4lWTSL0FESYgDMKg1GAKJg2h+uaSKUpOGcQISBCDSEAZlBYloZpEsQhQewPAIkRjWxKw3II/D5gcgLXJbDNQUpoUA3LBqAAAg2ilVKxVhRUWhYjuRzMfAnwg1U0GifvXqof/uv3fvgXvuz7/iqeUUf53QQsovU+SshNcuPExnNv/YtXvPfFL1KvM90GwpiKRDCutEbP64NBwI8pVusd9P0EOcdFymU4dLqL9WaMVj+CQSkci8PkHBIEjs1B4IAwjceeauCpYx30/BjEIAAHklgjk7Jx3vZhTIxmcHKxhceOVBEnGpQQ9LoxoDi2bx7GaDmLw6dWsdzswHYZxkfKuOT8bdgwNQnPF+gEvhqdKOix0iSbLs9AdVlt8Wjzb9/0Iz/9SdHtPvj0dC0h5KzGdTb+HZKJZm94A5V6MMvn/NJv/NpPbLvw6ndUNl+5Q1plHJ8Hjs8m0lIKXAhWXYqwPBch9CkYH7Cd4WEK26LoVCO01kPEfgJCCBg5U/FJCEyDghkciWTQSoMIAa0ZCGWABOJQgxKKdIYhk2ZgnCCJNaAJKCGglEEkFJFHQDSF0gopV6BU4IhDBuhB6sgo4LqA7QygxTQIDKZBNAGHBodUjBFtcAbLBHOsAZgJnUDDg1B+ksnYXarDTCSX6dzaiROPH/vGz/zVJ//067t376P7998kv2uA9TR1+9mffeXPveMnd/76OecGFZksJrFgvNsPiB8J9MMIjCrMrsR4+EgNUSxQztsYLZRxaL6DpZoHUAoQIBEKfk+BKGDrdAFJzLG0GsGyKGyHQEmg2Quw1vYRQ4NSgkBqBAGQsVO4bMcENo65OLXYxXrNh2lTmAZBHCiUMnls3zKEWquHQ7MNrPabCKMYruPg4nPPw8YN4+j1IpRLJW2nDGVql507di5Iz+qcfGr+937kprf9OYB1SgikUvQMcJ2Ns/EdPdj37LmTve99LxVKKQAofPRjH/3h0c3n/UyQ3b59qW3h+DGgUY9lLkVp1iGkU4+wvtJD1AcSQZAupJDPUdi2ht+TWD7dA4QEJxoyAqJYg1INN23CsS2IMEGn6aPfDiFiDS0pZAJoBhQrGZTKadg2RRJK9DoJONMgWgOagWgGEAo3ZcCxOJJoUERkMA0CAjvFQaAhYwLTpEinAMcmABmUQZhUa4NoaXHCCi4lrgt4UQ0dvzp3fO5hb3xoct/sylOd1dVHWcNbuieTdo7fc/Ae2UA6mb97zvn7z39Evet3b+48zbL+/YC1B/Tl3zzf+epXn4hv+8s33vK614/9eiZbR+hXhdLga7U6ekGARDEkwsKJuRCPn2iCcYqZkTSGchl87eEqvDgEt0yEYiDYRYlEKWNjLJfGk0f6OLXQBWUaQgKEMJTzDsZGUnBdglo/QpAA+TyHywwEIVBbj6EERzHnYLKSxTceW4MXhyiXbUATWLaFkaEcrjpvC3ztYaHWh5UmqNd8pN080vkU7n74KeRyeVx50YU6U8xL10jzCyYugOGllh/4xmN//o4f+4m/ALCstSY33XQT3b9/vzx7P56Nbw1Ue9j73ve+p4Eq80e3/tXbdlxy1TvTE9u3HlkHvvlAJJeOh4QpRUdGTMgwRH3Zh9fWiPwQUeTDdh1wy4Lf6iPpJSCMwk0xOK4JAop8OY98wYSME/RaAtX5JgI/gpYEIAxSDJhTKu3Adm3EUYLQB0yDozBkQSkg7EtYJoFlMFgmB+McUlKIBLAthk5dQksKRjUyGYp8kcIyCBybwrIIOAOIltq1qCyXKM/lgLDbxVr1qdOn5h+4Z7Vx+FN/9+WP3IlBQfe/7Uv8981mgP3DP0Aqham//ovv/5P/9rbpV4OsCq/fpwCha9U1dH0PmlBQmsH8coRmK4bWDOWsC1CKI7Nt+DGFm+aQiiDtWgA0Ov0Yvkdx+z0rkEIgneZQ0NCSIEk0en4C07Vw+c4RzIylQDTH/YeaeOJ0B5QpSKEgIgU/jDFUsHDh1goW130cX+ki7XKAESQATM5w7QWbEAQKC/UWZqZLyFgZbJwcxVApjy998wE8cOQUtm7ajKuvvFg7Q2k1nB1h105di6VDy+sPPvzgb/zm//iNvzyrb52Nbz0JtYe+//3vV2fE9PTe33r/T2y5/BU/PbTl4k1dyXDsWCwffaBHlk7G1HYpMo5Et9qF10xgcgIpFSyHIVdIodfsobHSBpEanA1u4SRWEAlDoZJHKucg6HpQsYJpmzC5ARCKOBIIegksiyOfT0FpgqAXQcQKgIFYEMhEoDTkIJV2kUQClqEhYgUpGOII8AOBdNpG1nWhY41MBgBjqAxRGJxACMDlSrsW1OgoY/k8UG8d7aw2jn3m0FMH9/3NZ3//IQBVnElVCaGQnxDslqcOEBw4AOyCumXvLf+sVWkNPKvm7P8dsK67DvzuuyGUwsRH//bG23/0zZPniLgn/LDOpSLwwwD9XhsKHGk3gwef7OH0ahtBqMApQyGfwh0PrENqgFEKRgkqJQeccGQdE4yYWK3FSAhBp+tjtebD6wsIQZBJGZiZyYOB4vhCGyvNGI5JsX1DHgkhODHXhRIClAFKU/R9CaU0XnTRGJKY4JHjNZjOGUFRavT9GBdtmYRlmrj/0Dw4J6CUYvPEBF7+okvBXI57nzqK1U4LG2c2YHxqUoNBXnX+pbxkVbD08MJdH/+zT773y5/97B2EELznPe/he/fuFWdv1bOs6tZbb+U333xzAoD90i/81Dsuf+Xrf06PX7tltsXRqiWiNhfQ2RMRlYlAoUwRdiPUFppgkDA4BRRBaTgFGQNrp5uIghCcEEAPOnCU1HBSNgqVIvxOH516GwQMnHFAA5QwgBCkcxlUhsswKEWn3oXvx2CMQyqJ0I8hEwLbcWGYDEQPspg4ErAMA4wDjmXAMBlEbCKXsUA0R5IMquHLQwQmBUii5FiZs9ExoN1/rH5s8b4/+/DfvvvDjaCxMgApik9+UrL9+/fjOy0U/W4xLPrQQ5ewSy99ePJv/uZVX3zLWwrbQq8q4ijgsQxhmBl0uh56XgSDM5xcCvD4yRYIZSCUYGYyj7serKPjS3BOQCiBxRmqNYUk1uDUwPHjHiyLIZO2MFpOIVt0oIVGEitoxXFkvolW2wc4hWFSJFIhCDWmx9KYHknj+EIPq3UfxCRQ0GCMIk4oXnbuDCYmXHztgRUEcQBAQyuCviexaXIIw5UMHji0AkUBJSX8MMHLrroY46NlrAU+uMthcAeaU9TaTX3OOVv1FRddQbGqwt6c96dv/f43/k8A61rrs6L8f2lBfR97wxveKLVWePvb3nbV9/3w7t/m09dcd99aBnOLELoW08ZCQMNIolKhKGQVGrUQ9eU+DAIEfQ/UclAeSUP6CZorXViMgRANFQMikYj9BG7KAZiF9YV56NiHYXAM3BMICOFQAsgX88gWMmjV+xCJQj5vwzAMtJshwiBBOuPAMg1EXowg8KEUYLlZGMSCaTBkshYICJJQQ0mG4ZE0KAy4LmAaDERKnXW4mB6DwayF6mrjng//2m+/6Vb/TAuc3qfZLU9B793779d6/58AS+t9jJCb5F98+MYHfvwdhcui/mkRxRGXCUAtB82+xOxCEwQa3LBxdK4HZg5cGEaG83jwiS56PYFCgUMJDS0Y/FjA8wCRWPjmAzVQBlAOKKLhBwqJJLjh2hkUijaq6xEeObqGrh+BsUFeLhMNrSlaXgLLNHD95eOIEgE/FmAGg0kJwlghCAkc08Zl547j+Nwajs814NocihJ0fIFsJoWNMyN49PAqer0AtmOg249x+XkbcXpxHdpk2LZ1BlMzU3BSKTzw2CEYaVu+6Nor2EXTF6E921+45/b73nXrez/w9yDA7k/uZvtvOqtt/RcKqgczUBrA0F9+7GO/MnrhNb90Sk7j3mMQKSlotOrT2UMtpAs2MjmN/to6GkseQl+DKIUk9OFkHNhpF+3FZSQhYFochDBQwiGFhmEYGJsaRRhE6HUTcKqg4gCRH0BEIZRSoNREaWgYhsHRqLWhxGDGXEPCSVnI5yuABJJYwOu0oaUEZQa0ZpDaxOhICbEPhKGAYVDkcxZc10WhYMOxCYI+hRZKTo9zNjMT4cTS7V/8h6++91fvfeihJ0EI7nzP1/n1e3dJgHzXHtr/ZsC69da3Gzff/JHk9i++8YMvvzH7C3GwKETc4FoDfT+GnwicXIoQJRK5dAoPP9VBN4gBpjE9lkenS/DNxxrIpDniBOj5GlFEkLIYtk/ncOykD6UkhKbo9RK0ugkkFLZvyWF+ycf8WoDJ0Qw2jGXR7cU4OdtFEEhopZAIjXLZwsRYGpRQlEopDBfT+MLBOfTDAQUWUiGKNUwNnLNhCLNLPb242oHtckIY1bFSpJh1cPEFU8mJ021jfbWnLdcEtxguu3gDefzJBXQ9D45tY8fOzXjJy67F3HId9WZDj8yMyE2btvBtua3onWj82Rtf+f17AFTPalv/ZbSqf5YC9r7/V1+37UWv+7C56Yrh++egG2uRptUOXTpcx+KJNlKFFByXorW8BhEImJYLrTQokShWcoi8ENW5BVBCwLkFAgZKOeJYwLYc5It5tOpNRF4CgzEwzsENC4bFASWghILjuOh1Pfi9Pjg3BxYzhEBLBW7ZyOYKMAjQawXQUsE0bYBquK4DDRMyAlQysKYpl11wxmCZDhzHQcoliD0ht2wwWC53zHvk0Gd+/YMff9cfDr6HO/nevf8x4/3fBFha72aE7Je//b5X/NYvv2vzryndkSquMYIQ9XYXnt9D2zewuB6ilLcQhSaW10OkswZSloVCzsFjT7XgxTFcl+DQ0QDNvkajK3DOphyOHPPQbPmglMI2TBQLNiyLI5fmePSpFtbbIYolE2GoIBKCoZyD4byNxWUfYaQwOupAxAqNXoy2LxEkGhPDKVx24QQeO7qC9XofhBEdx4ooARDFcN0Vm1FvdbBe85DKWiAKEALCtkzvgvM3Zg8/tUaWV1sIoMEI1RunKvrxp+aoZXKESYJCuYBXve7lCLsRhsaHEehICQZ17Y6reKZnH/vqP37t7R/6wAfuYozh3e9+N/12fVJn44WrVWmtKSFEDlvWhg/87V/ektn+yh97eL2MTg+Cdzr89MMLWF/sQQuCwlgGQauG9tIyKLPBTBtaMWRzaZRHM1g5tYR2tQtGFLQUgNag3ISUFENDZbipDKpLq1BSgjMDUBTQGkoRxFGMylgZ5UoZ1eUmOo06NCQIodB60HKTzRdg2Ba69RqgFXKFEejIhGkZyOYdhH6Mfk9CSY6x0QISDwA4rBSDYbrIZRiG8kxMDzHupk584ROf/sVf/4f7P/eE3qfZLTfdovfiP26Mf8eAdd11sO+6C+E73/myS3/tV6ceHJ+UMvJ6lKBLvEhjvb4GyzTgeQR+GMO1DSxUBbq9BAQE3DRw+FSAE7MdTIza8EONIBx8EYWciUQQfPPxJjSRIEQjEUCnp7BzyxA4ZZCJxErNR7Xlw7YZoCnanRgG43jl1eOgCvjywTX0oxh2ioOZFIxRRJGGxQx9yYWj4dJ6x+kEAUolFwYYVMLQb8SNbdtHkyjQzfsfOzWWcq2MSdlJRg1fSo1LLt8wlWglu17CCGXFoXJeL6+16aOPn4aEglAK+WIaW7dvQKfp4+oXXQU3X8BsfVlsmdrAzytvQ+3E+i3vfP2P/j6A7r59+9hNN910NkX8/0ns3r2bfeof/kFqpfDuX/uVN5534w/90Xrq8vIXvplIJ/SpXl8ipw/XAJgoDrkoTeXQWWuivdKAm0mDMxNCSAyNFGAgRrsWIeh7sEwGEUlIIaFUDL/rIZMtgIFj6fRgYogxBgoCaAqlKLQiGBsbQaIk1pdWwQ0LqZQLlcTo9ZrQSqNcGUUiBbrNJmzTAmMmRMIwNr4BBjXhdQIIoWC7HG46BRFqILbAbQuWQ2CbJirFdHz+dpjN9hf+6ad/99U/CEDe+vZbjZs/cnPyH/5k+E7z8jvvvI5ef/3B0h23v/qJl7y8WI6CGEhWqIKJTi+G1Bq2SbFc6yNJQtS6CZ444cE2CVKWDRCGheUYHU/AdYFjp2L0I4VYKpy3pYxGPYGdAvqhwGo1RLufYNumPDp1iaMnuyhXbGwcz8PzBI6caiGMJYaKFrZuyOPJo30wBmyZTuPI6Q66gYBtUsSx0kmswRgl4+O52euuHncXFn330UNrOgxU1usL6EgFQSiCiy6eyPhx3H7y0HIhlbK5UhpSEakVli++fKM5v9TKxkHiFvMuLrpyB8xUOlperpn9ICQr63WksjZmZkZx5NBJ7Ny+A1e++BrUop6SEPq6865mwWz7G7+35/ffdOTee+fPCPJnQeuFLqxrzW4a/I4Tt/7d37937Iob3nrHfB5339GS2bjH+osn0a57KI2OY2prGU7eRnO1hU61jSROEDdb6Hd6yGTTsC0bK8dOgREL3CCgSgGEApRASIkt552DJNJorrVhcBNJECHsdyFkBK0IGDEwNT2DbruLRq0N0zShlISUCSzbRsbJg1CJfr8Dr9+DY6UG/nGaoVCqQGkDEAbCXoD8UAZOykK3GcBkFoqlYYQhQSalkbJS6uIdhD554g8//8FP/PzrtNbyP7MGkXxnT5EJZ//+peCP/+iaj/7UT8/8qEg8KZMeUwkFYS56Xg9934dQAov1NiwDmFuJUWsLOKaJTlfBMCycnguRzhgoZk0sr0aIlIRSFI0OsLjmIZUmyGcdZFM2oIFaS+DwsSbyWY4gVPB9iYlKBqWChW5PwHZsHJ9vQSgNSYGMzbBtcxazpzwsLfgqnaF0dDiHlM3r7XrQn1vwqxdfOqFOLjeubLQ8lUqZVAkCSILQS3DJpTOnI5lMPfb4ArddS1MwQggDIQSbd4yhWe9h9ngNmZyNma2j3cZqPzW5eYyVRspYb3bQ8zoYKuRx/92PolzO47U/+FqUZibhq0AM58t8XI30Tzx0/Ef3/PRPf1ZrTckttwBnU8QXdAp442t+8Jof+R+/8FfOuddsvf0BiMN3LbO42SUyDEEpRa6cQmWYo7VSw/KpOsJ2B4hCKBkiiQJkiyU4aRfVU/MwzRQooYDSINBQSiAOfUxs2g7P76O+tIZ0NgPTSsF1MjAtC36vi6jvY3h8BI1qHb2WB8O0AKVABn5ToKCojM5AJhK11XkYpgVKLVBYGBoaQhgE6LS7yOVHYVs2GNfwuxLpTBqpdAppJwWVMJ1N2fr8c2Isr33qPe/587f8T0ZZIpWk+He6iH5XAWvfPrA3vpHIN71pw/f99m/t+MLIMJUi6TMCDhFpCJlgrTVwIPZDiXo3AKfA6eUQYawAzdHpawhl4PSCh3SGodelSBKNVJph2yYXR09LHJ/rQdEESlPEMXDNpRWsLIeYW/DQ6sUwmIYUQK0eYcNUDi++dApfumsJnSCEm+FQelAFH8YK2ycywtCMS8HatXUvmp/vUi11zrS5CUq+cfXVM/TIqdpVjZavLNugWkEzxtHvxY2LLphcAKPnPfbUMrdtTqABCoYkkZjZVNZSMXLyiUUMT+UAxrC21NKZvEs2TE/5o5umdWE8n+o3O7jjC3dDyBAvee0NOPeCC8E5kYob7NKJC8TRbzz10V9961t/ggDqPc8Qas/GC0JY/+ci0He9/7f+x8Wv3v37tcJm3PWVulh7pMOZa4I7gF/vIOx2kS0YWD9xAn4zgmlyQEsQSMRhiEwuDdO1sHbsBCzDAaEGGNjT1sJQQmN00yZ0Gutor1dhO86gn0YTEBBIIZHNDmF0cgtqa7Nor6+CMhOgFBQEQgqY3EFpZBjrqwvQiqJcHkO/1QdRJoYqE/D6TYSBD8YY3NQwDIOg124hXxiHZaVgUI7h4QKoTiXn7fQNJQ687R0feNVfn2nFw3/2RNK/BljkzjuvY9dff9C6/UuvuOflN+QvSPyOAhEsjgQivw2lOVo9CcMEPH/gnMAZxVo1QqIlvIDBshlqHYmldR9KacytJiAGBecUJrfQDwTSjon1aoDF9T7KRQu9DkEYSWzdmEG9JjC33INIFDJpjmzKwcmTAS68uIxOP8JyvQfb4QhjDcsCpkrpeMv08GMP3b829uTh6ng+bxGpNKCI0ppQSH3gsmun7WOzjSubDV85rkkViGaMkX4n6mzaUPacsj169Kl1YhocRANaE4ReLEbG8p6TcbMnHp+PhqYLdhxKxIFE5IdxKptWF117URL7gZqYHs/Nzq/g9PwcJs6ZQSldwgUXX6g70PrKDRfQUaQ+/8rrb/xlNBpHz8wingWtF8Is4Hv3CmgU/+QT+9+/9fpX/fe75xz1zS8tg3sxzVbS6FbrWD06i6jXxsj0MFZOnoT0AxiWAyUJQAmSOEIuV4CbdbB85Cg4PdOpDAZKGZQmgKKY2LgDjbU59JrrMCzrjI0LBaUcSkjYlovi8DgW546CM4ZcpoIkUAijQS2Va+dQKA9hfXUOmgCUGqDMQTE9BG7Y6LfbSKIAlJlw02kIGYNIEyZLwXKKoCAol7NIW6Vk5znaePDYBz78N/+455233vqQcfPNl4rvxaw3+fazgnsoIXvVz//8Je/+3d+58H1KJZLqGlNxC0IkSGIFQg14oUYkYnihRs+TIJRhrR5AEYL1eox83katKaEUUCxYmF9OsLgWwE4xrNQTNDsBGCUYyachQoKOL3F6vgfLYUikxsxoBr4nsbjsY3oyheNHumAWRaw0Nm8oIILE7HxPj424ZKRg6dOnfCwuBCcvubDEep7YeOpEW7kup4MWLqKgQFWi7z/viklrdq55Ya8XwnQ5tCaaUEq8XqRGx3MkU0iRk8eqyqCMagVAE4T9APlipjk8VSRrK61FSsm03wlzBjMQxbFK51Kn3UJ+vL5adS6/9kJYuSyqrQ5IykCn0cIlF16k25DyqvMu4+fmJhv3337X7t/+1d+482yh6fM7nn6oTE/vGPnd2/7kM+7WXVfcdrsvV4/U2eSQAREGmDu0iO56DZxpVCYrWJ89hV5tDQajoMwENU1AANl8CVYmg8WnDoFBgmgJpRTO1HuCKobJzReiurqEqNOAYRnQSpxpVQFkIpGyMyiPTGNp/ji0Ts6wMoJUqgCD2SCJjfzQKFaWT4BqgHELGgwy0RiZ2AThR+jUV2FyG6lsBbHqot+tY2T4YqiEAVKiUhkBhClffG2OPXH4Q1/408/8jx/SWovv5Thl3w7M3ve+u7TWzvj/+uBlf7dhxjKU6BCqW0RrBcpMSAWEUqEXCgSxBOMGgljDsTm6gYAfJxBEQ3Og2hToxwK9QKHTk5gazmK84uDIqR58X4BoYLUaYWg4hUrRxNKCj0Qp2DZFtRnBcRguv6SCBx9pgRkEzBw4NNSqAdKOiXNmsiSJNI6f6BE/UCSd5aWVVc8ZHcvIQtEx6jUPlsWhNciZnHtybbE7f+75Y/V22yt7Xqw1JVRLwHYN0m2H0nGs9uR0wW2ud8E50VoIGJy3vU5QC3rBl6e2jRVFIrLtatchGoRTSkI/LqbTrlGolPHYQ4e17/nEdVyMj09idGoSB++4h7ic0VrcF63YS9/4opf82OTMluzLrrnmy4wxvOc976EHDx48C1rPo9Ba8w0bNogf+m9v/sFf/8M/+Kcl4/Ltf/HpTuKvdfnGEYrG3BwOffMQom4XBqeY2L4BnfUatNIoVipwUmm42Ry4ZaM8Oonc2Ajqq3W46RxsOw3TTsE846Qr4wgTG7ehurIAr1OFabmDNhwlAQiIOIBjuygPT2N59gS0FmCUgWgNxgDf74CCYmbLTsyfOgolQnDDAgWFShTKIyPwe6uIoz445bCsDJhB0euswTKyyBbGEXRaKJWHEPVdcen5ec75/Z/b+1evf4PWOj5TEPs9G5/fErBuuGGzdeJEk/zSL+z47295y8ZXa+0pTjtMKzXwVNcCfT8GNAc3GLQGbIPDZAycDrxxDHNQ42oaDJ6voYhGECrU2gmaXQ+cGUinTIhEo9lIYBkEAMXyaoBtW7PwfYm+J2CaFG7KhNfTyKQNdLrxP1t6JYmGklJv21A+fuRYo+T3BbEcCq2JNh3DWF3zkpmpXNuyjVSz6oNzCiU0UUIrqdRkrxssXHT5aClWgubzdlzMu14ma6JYTJkqVGaxkHp0YttwMRbKKI1kSXkk489sG+tVxgujcaDcnZdvSFHGU91qvx5HsSmlDjqdrjk0WkRxtEKq1TpazTZWF5eRz2Rx1bVX4eTsAsJ2nyrL0PP9mv6B17zq6jf86JuLf/fhPz9w8ODBZPe+fezw/v1nQet7nwNSfeAACCH6tn1/9+arX/ffPn73yubMNx9oSLk4x7nfQHN5DUceOAzbYcgWsjjvqvMReiGE0KA6gddeRb9VRWt9ASKIAEqxcOhRyH4Xid9GHLQh4j6E8CCTGBt2Xo5us4Uo9ODaWWipIWUMrRMkiQ/HdlGqTGF57gQo1WCUg4IC0JBSwKIuhsY24PTpR2GZDqgi0FpBCYViYQRChfD66wCJkbKHYFg2+r06uDaQL06DSCDtZBF0XDU1UWZO5p7GH330+17SS0TvllsUAb63D9NvlRKSW2+9hN9888P03nte+eCV14ycG/g9bfE2VYogiTtgzIJIKJQG+mGIjh9BSSCMFIIwgmFydPoClFJQxnFkViKKJQAyEORDAaEYltdjjJUdJKHG4mqAQsnEyVM+TIdgx9YC5udCNPsRZqYzeOJQGyMTDvJZA0cPdyAlYJsUpYytnny0t3LuhYVU24sLzUakbdcgCtCaUhL24ubFF4x2Fxc7U2uLfZLKmsR2THCTRcJXqjTqHBiacjfc96XFJigZiWKV1YqUCYFOQnlq88Vj80Ekdi6dqvGUbTuUsJOWzU1m0XMIpc2rXn5RU2ilGqudTOQLVV9r5xqNmr31ovO6CyvrxTgKNaOMeF0PG2amcPUNu7DW7aDT7iKTz+jyeEX90NUvZ96JxvH/9et7Xv3Y/fefOKtrfW9j9+7d7FOf+geptbL+561//PHNL3vrD37xKVP5Sy1UDx2nK4tryOVs1JdWUJyYADUc2OkiuqsnsX5yDoQoIOlDqRhaRODcRG54Bq2VJRiMgYABSkPJGErFSII+xjeei06riV5rHbabBacODCMLykyIqA2qE5SGZrBw6jAYo2DMAlFkoGlBgkiC0ZHtWK0fQxw2YZh5ZFJj8Dp1ZLMzsJwUmrWTME0DUAxDo+eiW1uFFAFyuRlAp1Ao2ECS0ywekRdcVu/f+dA7X/3Vh//xG7t3f5Lt3/+9rx98TsDatq2UOXas0Xvd7s2v/+tbL9qfKyRSRCFjUNAEUGrQqxRGAmGUgDAOP0wgEgXTMLFW68J2KJbrMZodiVzGxpHZBN1QwDQHLEr5BLV2jNOrEcJIIG062L4xjceOdLGyFsB2CWIBbJkqgxHg0Ik2NFEII43hUQeZtIUjT7QxNeHi9FEfUiokidRbzy2Sei1CryvAbQalNbQGvF7kX3LNhNNrR8TvCXi9BF4vjlSkdNhXvcmNmcczeds89ODKuJu2NikNTSgFZYxE/ai149KZh9rtoLI6X9topZ2M0oNmeSW0YpQ+demLzjv52L2HpoYnhqZLw5Wi7ThSMt3Qtjn22P2HEPuRNg1Tx2FESsNluePSS6idsWk6n0a920GqkBavvPJlfFJnFv/yQ3/2jk//5V9+8czU+dmyh//keLq41wYm933zm3/QGrnqB7/8WCLF6WV6/IGTpNtJMDLhQIkQRCdordcgEoCBo7c2B9tJAUpC6wgyCQEpURgeQ2N5HhQUjHIQUOgzzCgJfUzMnItep4FGdR6WNShLGPQDMkBxWDyFmc0XYnn2OEKvBQINTQgYtwFiQMcSE2PnY71xCn6wCpNb0NAgxEQpNwNmuKitHYdhGKDKQC43hUQoaKFgMAOp1DC63SY2bb4AQc1NLrg4ZRw+/YF3ffLA+3/37Zfcanzk4f/4otD/55Twsssc++TJQL7rl3e+54qrcjtl7CnOONWaQ6kYUiTQGqDcBtEKjHIwRpEkyaDyllP4gYBrGSCawOYM3ODo+go9T6LjxWAGMD7iwo80fE+g0xMgTGFs1MHyWgypFBgFVusBtm7Oo1oN4AUCrkPRaSskCbBzZwFHD/chYgVmQDPOSLMVYXIqp72eICKWZ1oWlM6POGYc6WhsJOefOtGwQl+Ac84po9xyeaq27mVKpXQrm3fa9ZW+bRg0pQmhkFpxg7mrp6vVkemKEomaCv1YcZOBUkq5ySm0Lvbb/ZFcObvl1PH5VHWtRqq1Bgm8KMUl8S6/4mKEUcS9nkdELEiv1dEqScjKwgpRUYgtm7Yh6IX0sVNHle/S/I2veOWbcuUJ//tfcv03tNb8zIKTZ+M/Id5+663Gu97yFnH99Vdd/Qsf+os765O7Lj14KJDth06zw/cdJ8QwMbl1FFoFqM0voHbqBELPR65cQn9tDoZhDHr5dAytIqgoQH50Cq3lk1BxMEjhCANlBiizoITCyORO+F4XtbUTsCxnsFAg9OBeggREgpGxTZg7/RiSqAPLTcE0MiCaQCoBEYcYHzsXfb+OXmcJFncHTIRQyEQiW96IfmcJcdSE1glSdhlCJwiCKhyjgpRTgtdfh+26sPS4nB4t84R99bY//9w7fuXWtz9k7P38a5Pny+/zXIBFTpwI4j/+Y2fkF39u+4dGxywziSRhNCFax6BEg1IGAgoCBUoUlBIgDKCUgHMCw6LwghheJOB5amC8pwcmX/k0hdeX6IUCUg5qTjIOR7MpQTjHynqEiXEbYaQRhBqVkoW1lRhjYy78vkQQKVCiEYUCjsUBBXS7CQyLEWpQgBD0OrGcmMzSZtUHIUC+bJPYV2ishvC6cbJxW9mqr/fBGB3YCkmtDJOlG2v93uadY2teP9RhLy5SQrQeuLISApprrrce2bRzQ6fXD0aVUJQyQpTUYJzxXtcnhWL2CTftDgd+TCmltNf2yMrpZdKtthc2n7OhmbKd1eJQyaGc2+urq2RmwxROPHUMp48fw8TYBArpIjly8riqw1OvuvGVr7zupS+NL99+7l2cM/zmb54V4/8TxHX62ksvlb/2gb3XXPojP/fl2siLCo883hWr3zjOG2sdVEZyyFfyiLw65h54AHG/CwKgNDqO7vIstEwAaGgZQckYSdRHeXwbwn4ABcDNlgdpHDMA04RWEuXxHQj8HurLR2DZKWg5WGZZD5pdkUQexqfOR7u5jDCowzRdxIkPIUOYdh4EFIXMMBQF1tcPwzZdQA2mE1UiUaxsR7c1C+gYWkkYsGBZeXS8JTDCUMhthIgFZBIjk51RZWeKZoqH5j7yiZe/LdSifclrx9Re7MXzFrBuuGGz9eY3N8XP/dyFP/DGNw6/ATqW0AHRWmpKDUmZlpQwxThTjBJFqFYgWhNIMAaIJCSuzc/YpGpwboAyCdflWFjxwLnC2IgJCAbTBI6c7MNxKYZLLlyHYq3hIxACGzek4HkaubyJ6nqIVjfGtq151KoRAl9ibMTC/PEQmawBJ8Xg+RKGOTDeixNFPT/GxHQOzODoNCLEkYTlGDTwY4tRBKVyitXXPWJwCmgykPAJKmtzzfrmC4et2op3VAmZoYRamoIzxkxCyM5uvbM0Ol3J9nr+wLYRIFpIZXButKvtdHE4TxKhmIgkGKMwDIO3qk3ZD4IFLwgyfrW+PLFhgo9t2si5ZbKhyRFy+tgpLC/OQcYxNm/cRBZW1six6ry+/rprXnbu+Rdf9rVP/9OX7rrrrmD37t3s8OHDZ0Hruy+L0KcLIf/0r299/cR1P7L/3mhr5vC9y7Lx2AInjMDiMfxGA14osXzoMLjBAU2QLhTht6sIeg0QEBAtYdgpaFBUps6F1hSd+hyo9hD11xEHLSRRF0F3HSknAykTtFYOw3KcM43OclBcSjWSsIeRsZ0IwxCt1jxsOw0tB6Z8FBph0ILLCiiUNmBl6XEwogdOnhSQIkImMwYQCb8/B1ANm2Rg20PoBWuAFrB5HpZdQdzzkHJLSLEpMTYZ0Mfnfv8nD6/c+80DB8DfOn/980qS+L8A67d+66Vs//7Dzs/93I5bzjs/txk6ENwgnJoOIZxSgDNQl2liM8ItRg2XGaZDTdsktkEIIYkQSaS5YdJEaFCmYFoUOZeikDWxsB6i4yWYqDiYGHPgJxIL6yEyeYaJSQur1QiJFPACge1bCugHQKshIIRCzxOYHM/odkNIUEL9vkLPjzE0YkMpijCUGBTfEsRSYGJDEXEk0KyHsGwDIpFghKK15qvSqKOUAvPaCTnDtAjRUCJWo5C4Y+sFY87ybMM0LGOUEKoJI5pwpuNETAX94ND4hpGkulCPtBCOVppppQnhzPL7QVIeKxieFxJKCVFKacMy0l6zO14YLpX6YTyxdHKO+t1eZBiGuWHbZloaH0F9vakX5udJbW0V27duJyIGObJ6Slz/8pdsf9GLb3z5PU/MfurRg7f7e/bs4QcPHjyra31nk0ff0b63PvQQv3R83Pz13/qtP5m54W2/86VTJXP27hOatlqUaQ/1U0fQXF2DVSigO38SED5UEsGw03CyWfitOjK5YThuBmYmBx3HyBRGACRYfeogiPIg4z60GrgmSBkjmx1BujCG+spTMAwbRKoBq1IJQBVE2EWhMANm2KitH4FlF0A0BZCcqcpRYOAolKextPIwHCcDBgtCelAQMLiLbG4UrfpRcMOASHw47hASJRBFdVgkCydVgd9tI+2UYciKmBwfNxrqU3/3j3e9+7d2795jfvGLe5Pn2w/9fwFWtXqYzM9j26/88oW/MTY+ktIy5EePBsnXvtpZPnbc/+RXv9L69Be/1DrwpTvqB+69t3eQ6tQdp06FR0+dxLBSljtSyRpOOkU542BMCC01MUxKlFbgzIRtGmCUYL2RYKhiIZYE3CCoNxIYFodrM7SaCcJQwrQNZLIm5k/5sEyg30kAQsjO83M4cbhHGNXgJkG3JzA86qLXSSCFhiYalZE05o71UCg70FDwPTEwL5NKU0J5c81bmNlebrSrntJKpwCtldSEMcrraz07X0zV0jnbqq51lZUyc9wxiOkaxMnaUFrJXDmbVMaL3X7HD5203TJN8xQzWD+WagTQy6mM7bSrHUU5YwBVzDaZ3+t7lclRHifKVErb1WqNzh45hemZGWw4dxsxGNPtRofMnTqFoUIRxfwQffTU4eT8qy6ZePWNL3tFsZy//fff99vNfVqz/Wd1LfJv2I48Y3vyf6oW9tADBw7g0vFx+aGPfeJPJm/8ybd/9nErqR5eokNmSOpzp7H41FEkoY/MUAnN2ePgRMHNFZDOlzG+eSOCdgPcNgEVIon76HcasDMVOPk8Ooun4KRK4DwFRi1QZkCKBAa3kCuPY3H2/jOOC/xMaZMeFIbGfaTdCmy3hPWVx2FaaVCYgIoASFBKIeIYIyMXotleRCJaEMqDwQftPYHfxFBlKzqteUALUELBqQHTHEYU9AElkU6NQygBx84g52xSWaPCrOETC5+48y1v/NgPeMHe/QfU97qE4V/90a+7DvzgQYhX3DD19o/97bW3nj4RnDjw1aVbf/9/P3nXWjd4EkDwbY5lbtkytONX3jlz1fBU+od3np9/0cbNBCJpo9bqyzAKmWkamF1OEAuFMNHQjOLeJ3qwHQKmGE7MJej1BTI5gqee8FAaSSGdcrG20MN6NQajgB8onHN+AatzIer1EHaKIxYa3CDI5VzMnehieMyB3xYIfYAYBCPTrl463QUDI0oqQGqdxAp2ls+PTBXEyUdrQ6bDcjJRWistQeFRg82ff8V0vrHuJ1EsXG7yRhyJsohlmYLO2bb1idLk0BV+L8z0W92+ZZuW4VraSLlur93fmKmkit1qX3t173C/H2wRiSJSKcPNOro8MUKqSzUwTpEIiciLwm2XndcnWpfzxYI2nBR56vFDmJgcx8iOLYjjRL7q+1/LeCuq/dMf3fbzX/672z72X6Ts4ZnjUz/jPf3vBDW9Z88euve971XQ2vzSAw/9QW34kv++/25f9E7V+VgFOHHvk6gtrICIBOWpCYR+F1pJmLaJfnUNqXwF/dppdJbnoIkGlIBWGrZdQHZiGxqnHgEzDBBwUEJBKIcUEVy3iKHxrVifO4Yk6UErAi1DaC0ADUgdIsUryOVnsLLyAAzGQakLgECrgcNuEvko53dAMYpa9XFYVgoKBEpJWLyArDMKqT302quw7Dy0UMgWNsLrdsCYDcQxcvlxdDqrmJl5EazumBidYjje+cgbvnL/ez69e/e+50UJw7/6g+7evZvt379fvuOnL71xrGJd+J73fOOPAfQAgDECIV7PPvKR03Tr1rTetatyZtBUCVDRjH1KKvV/xtHLdw1d8/0/tOkd1+/Kvm7HuemUF/Z0q93UQhK6UPUQJwwp18ZjJ3t47HgH52xKodcBvnxHCxs3muh1AD+kaDUkMrnBYhFL8xGyeYLAIxgZT6PVTtDtJWCMIPAkMhkDqbSBxmoCv5/AMChCX+t0gTftNC1V5yIYBoUa1DqQwEua09vL82FfWNXF3ni6ZGUNk2swEsSRcijIyZktlejxB2YpkZQorYsALUMpLaLkPh3EfzFzxZYfnntk9gC1jJu4bRJGmdZQOwhjf71j17kX+y0/JpxUiCb5OJKVdr2lHdtekAabri9UYZkmpJIJ5/zg0OTE9rWFxYkt52/D5Lbt5PDh4+C2geHpKUhoef33vZwVAguLdz/yYx/89V/+6J1a8+sH9ib6/+egpf8fx7V+rv3f/va3Gx/5yEeSkZHpc37nLz/8cXXejRfu/3oou7NrrJwKcfq+p+B1Q3ADGJ4YBiEE6wsnEXWr8BtrsNMFGI6L5ulDsN384PAMA6uWsS2oLxyBluqMpiWgtIAQPohUGJ06H9WVk4BWMK0CGEuDMBPQGiLuQCc+hsrnYm31EAhVMIgNAFA6AqODdNJhBWSKW7C6ch+4aZzxSqCQOoYJA5XRK7G++CC4aQLaQtoag5kqo9E8hrQ5BdeqIErWYHIXY0Mvl0N6iCX5r336r776mh/at1uzm/Y/f62Pvi2tppTgjjtezA9cf1DtfZqzfpvYswd0167r6K5duxQhA9uUYpFfvnfv+b96441TP7Bpk6T11pw4vRixSDISRRa6nsZ9T7bQ9WNsnMng/ge6qDVCbNqcAWMWHnmoB6k0xiZNrC8rMEOj35VQYNiyLYtjR3uQSkErjTjUOPe8Ig4/2kIUaxCKgXVMXyYjM1av2xTFoKvAGCCV1kppkiSifv7V4/XGelD0PFlJIqmTUGqtIeM4SYbHso+brnXBwqmGa9kmtBwUYBFKEXW8e4fGSl9zcpkb548vlqy0vUFJDRWKk2G98/FMpdwsTVWumHvqBC2MDM24hfT5xdEyTMMM85VC4dSRWayeXlZaiEhp7VRGR+4pT4yec+L4sVy2UmQ7LriYSGZAEAVfJJBRrL7/za/HBqdCveX6W372Va/52zO1WvoFBlrkWazpXwOnfyur0s9IA/Wzyhb4R26+OXnpS39g64/v+dWveZuunPyHr/dE70iD560e5h9+BIEnYafTqMyMIGitY/HQU1CJD1AFw3BRGt+A1tIcCHcAnUCIEMLz4RbHENSOIgljcMM50zQvoXQMCIXS8Da0aicQhW1Qw4RWaqD4EwOEmWDaxcjopejUTyL010AIBziDVhEoAAIFHUsMj16B1eojABIwYpxZdEJDJCEqI+eh1V6DCQNSBqDERTF3LvphFVJ4sNkEUtlpeM0jGB25SrvxRjU+1Qm+cfxXrt54yZsOY/9+7Mfzdw0C9tzTuyA7d+5m+/Y9hdtum1cHv8PBcvAg9G23zau9ew/qPXtAb7nlOvZnfza7+KUvre5bWxO3Z1Pm5k0bUhtT6R7pdhOVsSkhTKHrKZhcQwkgm+eIYolmI8GWnWl0GhL9foIglBgbc6AEQd9T0FBIpEal4qJRiwGikckYWF0NUR5x0T/TvqOhNSWEep0kLo4aca8RC0qoqZQmlBGVylgkCGJlu0Z6fcWzKCUElBBCCeMmNzrNIFUZz61pQpygl4AySrXSGkprAhI1T658obxhzDQ4X+mutzxKSVpLscJNk4Wd7np2pJhysqkt7fVGJYlFpbHaJJ12L9WrdWe3nLtF58q50MmkJaO8U11f3xHrxB7dtoU1qk2yNDeHbCaD4eFhFHI5BFFMHrnvIeSnyxifGHvd1p0Xb3jlFVd8nlIqX//61/9nziCS5/ibfJuHIHmOfch3oDv9i5m8bwFw31anegYw0ltvfYjvvfm1ybvf/d5tr/0fP3XnwsjFE5/7alv0j61zm3lYfepJhKGC6XJkiin0Ww0sHDoCO1eAmS3BsLPIjW9E2Osg8gVk1EPitxC2V+Fmi0i8OmKvAWrYgFLQ0NAQ0EIiVzkP3dYioqANxi0QTcGICUpNEEahkhCVymY0ak8hCNdgmCU4VhFS+NAqhCICcdzDcPlCtLuLiOJ1MGoN/rOEQMgA+cwUlOLodI/BMvMgksO1KwA4orALrg3Y7gRUnMAxCjD0hBwddnnHuPO9X3nwdz81NPRO9sX5X3leG0s+J2Dt3Qvs3//vG/xPg9eePaAHDuymN910z+LffXx+f8apNIZHMy8+9xxi9nxfZjOMxuAIE4XKkI25hQhjYwaq63Jgem8xtOoRpCAgBkE+a2BtNYZpAf1egkx28IQJfQXTImjWY1DOUKrYaDcjcIMRQkBkojkYCdJpI+nWY5rKGZzbPIr8RHabkW2mzMS2ufD6MWOMUiUHrI1y5vSaPiY3D/NWvc+JIowQEK1ANJRFDdaqPjX356M7Zi4JusFDoh82GONZTUiBcV5srtZXKxtGCQjpxGE8ZdimoYXU3VbHWV9Y+2ammJsLAr86NDk6WpmeMpM44aZprHLTcPyuR+ur6wg9D4HnYahYxMT0NDl1cgE+i9UlV19x0YtecuNlX/nEJ/YfPnxY/Af0IJLv4DPybURu8q9sr7+D45JvA1A4A2TPZFV4xvv/omzh0kvHxU/87E+9+oaf+oX99yUbxu/4elV2n5jjJAoRtDvwe10wJqHCHsxcHvXFFViZFKBCRM1lcCIh/D5a80eh4gCQEYSI4GYqMFIFBI0lGFZq8MQ/4xijkxjZoZ3wO1WIsAPDyoASC5w5IIRBU0DHEYbL58H3ugiidXA6GNNCtqB0BNPMQSZtpJwyCHXQbB+FadpnikspNDQs6iCbn0GtehjcHIj4NhuBaRXhhQ0QRWEaOWgABrFgWyXlqDSziqdWP3r7D/3Yvt37xO998dXP+9ln9h99goMHoffuPax37wY7fpzEX71j+b7HDtufPndL6fpLLraHfS9MDMNgHR9IORT9QGFlNcKWjSmEocbSUoSJaQfNpgLjDGnXhGkQtFoDG+RuO0ZpyAYFR6sVgRKKIEiQzVswTQa/L8A5BWOUBh1hZgqWYWdML0qkCrqRBGjGsLgZ9GM7V3Ij34tjrWAD0FppQglRIlEWAR6oTBT0+lyjQ0GkVjomhLiE0Qo4H47D6MjQVOXqxlp7gQA+oaCEAIyxVL/Wbg5NDZ8fBFFRScWgoRhnpoyjcQCNyI+ys48fzUVRpLKlkpnNZNWWc7dbSSxoY72GTqOpM/kMWV9voNds4qJLLyEqBp2tLSbbL9i57W1vf+fVn/vKgUce+8iH1/ft28f2f3vQIt8lAKPfhuHob8GivtU2zwVw9FukdfTbgBl91vaDBYQHNVbyB378v//G9/3Mr/3F11Yq2QcfWFfR0Vnm1dfBLYreyjKoQaE0RWFyGq25E4i764hay4jba2BawCkMoblwGtw0wAiBlgk440gPTaK7Ngtq8jM2MAqggIoTFEfORRj5EFEP3EhBqwQaElrHkIghoj7KpS0I4wDd3gI4t8HhDOoJRRtK+YiiDgxeQb6wA43akyBUPb3yIAjjUEJguHwhOr11SNEHYza0TpB1NiERMZKkDQYLllOA159FoTiDpJuo8fECWe5/+ebTqwcerg7tYPPzB88C1tNx+PAgZb/zzuv4B977SPWv/2bh06PTY6946YtzYzppir7PqJRAPmfg1EIAK00wM+Pi8cc9DI2aMEwGRRjazRhOikMrAt8f1F3FMVCu2Fie82GYBIxT9HsJxmey6PcSKDFYdVYRTU2LI5W3+PpClxomT50Z4lpKQErVyhVc0W36jBnc0EqDKK0Z46y50ulUpnJrrmM+Uj1evcdwzUnK2RA1jbzhmBeEYbyFcSZTmRTtzq0dJFrPyUQlBDQnCa6UiajlKyWr3/bSzDI40YQwwzD8nifLE6MtUDYe9Pxcq9Um9WrD6da79IJLL8TQ2CiiKCZLp+cxPjmmAynJoQcexMT4KHKZAju+tCBTw4VNr3nFDW8+Nrf+wJ/9r98+deedd/LbbrtNfRdZFXkObeiZ79PvIG18JpDQZzGg52JH30qHeia4sWcd59nHY7t//ufNm264IX7Hu9+z98af+Y29Xz6WkbNHW8DSKm0sLCI3MYJ+rQpJgajXQX50FOuHH4K/Pg+tQlBoQFMUxzagubxwpruDQmkBAiA/uhGdleOQSRcq8aGEByUDxH4H5dFN8Pt1+K35QUeI6EGpCFrF0BAQUR/FwgbEMkSnfRyGYYMqBspMJEnzzP9CA0Igl92EeuMQGDdBYUNKD5RRKBkj446DsTw67VkYhgMCAqoI0u4mhFELSnqwrCKSpAtmMNhsVOb5CCPZ5Ts+d9/bf2Xfbs1+74vXvyDWGGD/2Se87bZ5tXs32LFj6H3uM8ufuuKKGeuCc52rie7L9QZIJmsR0+JotmPYGROMAfNzPsYnXHDG0W5H6LYTDI1Y6LYlNACpJEybgwDwvEHFu9JALCXKoy5a1QiUEeQqFnqtUIW+4LmyY/R7ycAaRwGEEuL3wm6hmDotEtmJ+onDCOEAYUrIkCp9pDZX+7vpC6Zf1O2Ejga5ljBKoVSolCaUMyLD5EBpsjzOis6KkXWzmbGC5ZayxMm6LJFiyMqlUk7KbgbN/l1aynYSJA4BzfWqzdHCeDkTC0UAaEIp6bY7+sThE6Q8OixHx8bWhsfGzPXVdZ7OZcDdlH7soYeIkAksatBG6At3rOJcd921N/FM+v5f/+8/dVJrzb5ND+K3Yz/PxXyeC5CeS1Oi3+LY+jnY1XOdm34bJkf+FRD8l2A1PW1e8oYX8a/9yd8Gt372C7+59VVvvmXfN1WyfmydxfOnaH1xEcVN0+iuLqNXXUBQXUBxdByt+eMIW2tgBgchGiJKkBudgt9YQdiuDrzWRR9KBMiNbERvfQ6x34IGBmCkJUTsY3jqPIRxiF59flAVr8RgXUBogGgkcRe5zCSElmg1jsAwTBAJMCONRLYASIAQiNhDObsDgagijJegEYNRGxYrIBF9EFCUchei0TwKxujgwSxDuO4YhJBQOoISCSw3i7C/inx+A2i/oEfGizi08OG3VrtPLO4/fBMBXhgdFOx7cdLDh6Hf8x7QAwe0v3XrW7989RVb9GUXZV4iVU8qYtNAU2TSHIEv0PWAVIphbSXB1q0ZzJ4MIKWGUEB51EK9JpAvUawtxSiVLUipEScanBMEPQHL5uCUgrsMcSwQBZImSpBc2YGUgEgG7QxagSBR2u9ED41uLLL6QvvzkLqmFGqAFpRSKSJhSqkWh6aKL+5UvYftnDOWKrvd1FDayo8VT2UqOUYY75hp5y0sZS1xy8xQzvNmylbuUN5jJj9RGi+W8hMlamadIF1Ki0w596AUSUUl4u+LUyO8udbIEqU5Mw1KAKwvLi9pQqLm8lpQmRwRtu1YheEhGiUCa3OL0BRorTZowomyxyvGReddfNOF117z8EsvvOiE1pru3bv3udjQt0vlvpVW9GxAeS5A089xHv0MRkWf9Rl5jvoq8hwaFZ7Fwp5mV0+/ninKq0suuYR9aO9e+Yfv+oB7230P3GJs3/Wbt90Zi+bpdR7MHyNhGKAwOYH1w0+hu3gcst9EZdM29Nbn0K8tgVIKJRIoIZAdGgcIg99tw82VwJwUmJ1GYXInREIhRQLTzoAyCsoYVOKjPLoNYRCjs3YS3LSglAShZxYxJQQi6aKQ2QBNLDQbh2BaNoiU4EYWQvagdDAQ0hMfaXsaplVEo30YlpEDgwWJCJTaYMRF1p5EqCLE4Ro4M6F0Ag4LZqqETu84bF4CZy6E7MKx86CyKEYLm3lsPvnFg4dv+R295xa69+BNL5jOCfa9OvFA29pLtN7Ntmz7woHzd4yxq68qXy9kX2hukGOnfDI2bOLhB31URg302wqUMTgOUK0KCKmQLhhg3IACkAQKQahQGXPQbQ5cIwg0WushxjZkEYQCrbUQls1AQBBFEuXhNHqtCGdEdBBK7bAbLabzzmx2KF1uHK/ebjhGGpxNE84vJARxv9k/MrylPD68fWijkJhnitb8RlAO6+Fcc6Eerz9y8pOO4z4ad4Pi6sNzq6EvXt5t9MZ7K63hxrHlA6snV/82VUxfo6X47bDRr3HbHrUL6XSqmB9KZ91KfnSo3FlrERHHLRklXCeiGPV8a2Rmpn/8ocdZv9lcK1cq3uSmzWnfj8j68grJV8pYOD5LpFbKGS7xTZs3/WhqeGrq9de9+LN33nknu21ujmJ+/tuxFPIdakTfKoV7Lub0TOCizzg2e9Yx9DPGInnGmNTPGp/0WWmgeebFn5kiXnnllfzBBx+M9u/fP/qeT376K+qcl77+o5+ryujkElf1FULcNNxcDosPP4K4swqVxChu2Izu+jy8tVnYqQLMVAFmuoBMZQqZsXH0211wywHREtJrwkpXEPXqCFsrIIxAyRDQCbQAipVzIcERhwHcTBmMWIOReMbBIQ7byGc3gxoFNJtPwLBsEKXBeRqaSEjpgxEKqSIwbaGQ345q61GYhgMKAwQUjFhIZA8WTSHjbkO99SgMw8HAxK+PdGoKfrAGKTvImBOgho0obKCQPU8bYY4MTbvq8dU/elOtdXztpoM30cN44fSnsu/1Bezde1h/6EObrbf95ONf275pApddnn2JYXXk4rImYayJaxM8ccjH1u02+h0NblEQJuH5GoEvMb0hBSkUem0BKRUoA7IZE51mgsFDTYNbHFoCQScZ0GZGkcQKzGBwXBNeJwJjREOBUEqc5kr3icpUYSaRqh31wrrWxDBMHqdLNkmXU6V+MziYda3M/EOzX+01g5dpgaLUahoEm1nK3uB1vCRdyl4Dy3iRJnSCGTQLojhl5LTsBPcR4EGA/uT6I0c/3mv7r+7V++d77T5tVlv58sTIXaPnTI6n0m7NSbueSuRiv9ES/UatNXPeOW59rT4z/+Rhq1+vs03bt1LLcbFwehZT2zZifWmN9FotyJShXnHj911y/tVXb3zL973q03puTv/lV75idZeW8Bwg8q2E62fP5ulnsZvnAjf6LUBGP8fMoH7WfvQ5GB47A0j0GcemAIxnXIc88zcf236ZeeSxB/y3/dRPjfzEh/7ii97WXRf+0+cXEjm3wM2ojSSOoCnH8kP3AYkPGUYozkwhCXtI+h4yk1vALBdCRZBeA8zJYu3JBxC31pH0aki6NViZIURBG2FzGdASIuxBxD3EXh22U4DXX0W3dgzQAlJEAAE4c8ANF4RQpN1hUFJEo34fTNMF0RyMOmDUGOhShA1kjihCpXgx2v0TEMoDJwNtamAdQqGlQC47A89vgSoJiQhKJzB5GtzMwOsvgIHDdccQJW04ZhFGMqbGh7exHrnv09984n9/CNft4n/6PC9jeN4BFgB8+ctNqfVudsHFX7rz/POmybk7Mi8J45aeW9RkZsbAymqCWBJs3GLiyJMhyqMmfF8h9gBiaORKBtYXEtgOQa+boDTsIIkUAl8gXzFRXw1gWhSmwxF6CpQOXB38box80UXkCyhJCAbvZ0HIVinV6ZHp8jnVI9UDlS3lnVbaMvxueLK73L2nP1+/jxnm6sjGoWvqy50HDNu4XGstz9yFDuH0wiSKdbqYNUIvDAiIq4TuQcgVwij3V6pVu1xgxQ2T1wX9cNLMODMayEFra+3ovBHHUU1xOmuK5NTEORvTIxsmBUAnG+vrtaHxUT+MolSv07GW5+aQTacxs2kj+u0usuUCPC8knXaLtEQgr7ryyote8/rdl1wwOfVkd2lp+crdu82lw4efBhL1LVK+ZzOjZ4LF06zIfBaLYs8aU9+OHT29n/Et9LBnntN4VspnDM6d5kCsATy9cgvbesklfO7QQ43LX37DW1/zrvd9ci5zzuavf2Ve2rV1TiMP63OLEJKht7qIqNsCIcDY9i2w8iV06w0QquCvnka/voCwvgQrOwqvuQYVh2DMACGAOzwDEXuIO6tgnA2q2CGgVYJsaRpx1EXkN2BaaUADWglI4UHIFnxvBdnUCDhPoduZh2VmzojvCRg3IaV/BowIRByilD0Xifbh+cswmDuAqjNGR1IEyFiTMMwUWp0n4NgFaBUOarHSM+j7qwAScBhw3BGIfoBMapM2RIYUR5h378nfuzmVHWp9/smTAnhhuX+w58uF7N17GB/84JXO299+z9euu3Y7vfYyZ9dKrSMiwejYGMfsksTYtAGdaCzOSZRGDbTWFVQCjM6Y6DQShCFA2WB5sGzeRiI0KAWiQCOOFQpDDqK+gEo0IDW0IEiEQLZgod+JwDiHJtDcZG6v7Q8VhzP98qbyq7sNf7413/iijGSKGXwTtc1We75299jGoXHLtTe3mn7GMHnujHmWQRiztUIaGl0366aCbtAhSp7SQJ9yRsyMe0HYDXN21j3XcqxC2ItSnDMDUknTtAr+etujBIVus2vOP/RUPQmipDQ20iiNDmeyxWJQmpwoNxstHkcJmrUGeo0mNm2ageumQU0Ovx+QJIzoYqclNu3ccc7Lb3jt66Ns6ct3/c1fLr/lLW8xHn/8cZwBLPYMMOHPeD0bSJ6tPdFnaUzsOUDt2e/LZ6WEeMZ5ybNAyTjzvg2kOGAODKRgncFKTQeuBRAAxFv27BFf//u/777lXb/5jtf96m9+5LjemL7/qwuyEPdZ1Oli9sjsP5tNqqCNdGUY49u3QEddLDx4D6LOOuJ2A1oDkBqp4hS0khC9KijRYASwihXE3SqS7jooY4MUT/qAiJAuTMH3aoj9OgzuAoPlmUAIQCmFjCMUijPQEKhVHwT4wHHB5CUYVgkiakDqAJQQCBkha0/Dcsqodw7DZKnB8QhAtIJGBCggm96KVucwNEugdAxODRgkBWKkEARVMBhwrFFIQVBwt0L5VFaGp1iSPvV79z/5+x+9pPQKNt/5eIIXWLDn08XcfvuS1Ho327r1s1/fsm3sld93Q3H65HwnKZdNlmiGMNAYHjZw6rAPajAoaESBRJwAlm2i14nBKUUUSrhZC/mijepyAMMerPUmhEYu76BTH6zKCwBxIOFmTU0pJVEowRglSmltpQxXKZVzMxZWj1Xv1IS41GAlAsIhVcQMHq8cXXly+sLpl4lY1sIgmaQG5yBgWukARPdDL1h2s6k1w+ZDIopWDYfnmWlOE8aGGaXorDVOpou5GWgg6AceJSQj42SFAmHQ7j1enKxkzEzabS6t5eur6+c012ut0AvTFjdKOy++EKbjot/r+/12T58+eYpms1lSKJWghESr1kAUhHS+URfjO7dkXnrN1bu1m+l8/E/++P47tcZte/c+Ow00MEAE8gyGRJ+Rkj0tzD5tLWA9uzjzGX+bzxhbzyWO82d89ky29/R2BpAyAOMM09IGoBlsZYFJG1IzwJajo+fFvr8ePHbggP17n/7MT1/yujf94QNrw+qRA3N6yIhZ/eRpnHxsDpnKGPLjwyBxH5QrqKiPsFXH7AP3gFAKSgxQZkILATtVALFcePWToJTBSpdgZEsIO00IIUD5oMZJCg9EA25pA/xOFUnUAefuP6/aDEIG+paIkC9sgFQK7cYxGPagsBRaQlMBkfTAWRacWEhkGyZJo1g8F6u1R8CZMVg0lWhoLaCJRCLaKLg74cfriJIqGLUgdACDpZF2tqDnLYNSwCIFmHYBSeSjlLtE674m2VHVuH/uwz/S650O5tqPvSAb59nz75IOkwMHdtOLL/rK5294xbYbdu40RuvNUEnNCGUMShLEkcLCyQDZPANlgBQC/ZZGvmyi25bgFoXUCuWKi2Y1BOUElBIEfgInbYKDIPQFKCeDnsBQkuJIGl4ngpZaGzYlTspS7XVPyVgdG9lYnm4st33DMAoAYSBIgVJbUyJUIL+26aKZy2qrbU/GMqWlOgWl1gEIyvhI0O1/I5VyVhIv+FtvsfkxpXVXxKKTRPETTKkjXrPzmaHpkbyOk3uCRudxAr0OqCblfKdX74TZ4aK08plW2A+LzDY3ev1+trZeZfXVNbJh21Yys3WLci1LaxBz9sQp6XV7YJQS23LQb/cR+x6t+n2l0kbqJS99xWs2Xnip8ZMXXvC1bdu2pbTWRhAExjOYFXkWS1JngIw+A2ieflnPSvXIMzQnAmQ4YFhAQs+kcE8D2Zl90hYQ41kszBpsa7ABiwIBiByYmmsLWpvQhgUl+dB0JV5fOtLWWru3/P0n/mnDrh98x+cfofLIPYs0ozy6evQ4Fk6sYWzrZqQLKfQWj6G5cBp+YwUWN9GYOwFmOWfwUEGJGKbjwEil0Vk+AitdhFMch5IR/OocZBJACw8yaUGEbRjcgVPeAr+9Di1jcCMDAg5CB9bHYBRaRCiUtiOWEt3mKRimC0gFSi0YRhZSBdDKh5AeQC04tIRK8Xys1Q8BEKD6DDElGiCAUD24GAbnebT8w+BsIOhLFcBmRTCaQ5CsgmqGbGYT/HANRXcTjKgky/kSa/EH//fjx/7si7t3a3b48AvTnuh5B1gHD0LfcsthvO996B853Prca1+18RWpbFLp9oVutBKSSRk4PRfBzTGsLEaY3GjDtBkWZkMMjdoQsUYUCdgOg4wAJ22g303A+YCe+/0EpREXXjc5MxVNIRMFyghMk0VhkPBUztbdmkco54bfC61sKd1lJt8Y+PEWZvENlLPtoKRIGct0q50eTKMztXVsZOXIwm1UqxUC0gTIokrkZ6XvPxj6yZwzlH9l6AUOOL+acj4FraGT5KhU0Woi9dHMWOnHrIzzmbDbO66E8JSQTWrZF/aq7UKmmKu6+ex6r9XJcMdJG6apYyHJ3NETDUWJTGfSDxTKxZViqVTuNztGt9UhvV4XpmnCNC0EPZ+0Q18FHOrSK6+4bsfl11z16Q//6ZEgCEpWbnhaRoQCTAwwyOAAtwChnpWqcSBlASYHTDbAnkQ+gyGxM6zIGBwDFFAcsDTgiTPpGwXSDIjV/wEr1wS4PdjPpLClDa45hOawlAWuLPAzrE4bNqCtTLmYbq0sFYa2nX/5X9z11Q/bO1/y4n+8KxHLjy1xUVsm7dVVSMVQ2TCJuLOC9SfvR6+6BoNTFCujaC4eO/PcodAyhoh9cMOEnc2hV1uAWxwBYxb8+jyi9hK0iqCTLrQOIOMAqdwk3OIM+vVZQCUDyxYtBxSTAEoLaBGjWNyGMOih3zk9WF9QClBmghlZKOGBQIEQBkopkqiNQm4LgjiGFv5A36IaBAogGhoSSCQK7vloBkcApv656ZlpjpQ7jjD0oRDA5kVwK4XYa2M4f4XmYZrwcqt99/HfePOv/Vov/NM/JS9Ydw/2fLyovXuBT35yN/uDP3i48/Ch7smXvnjox9xsgpV6hFKRkZOzCTIlA74vEAYEQ2MW6jWJOBYoli14HQXLYKivBBiZTKPfTSCkBmUEUg7oeq5ko9dJwMxBD02vFepcOcWdtLlUn++0CCV5AmjKebrb9FrjmytBr+uXCeNDhBCXUjoKSqaZa020ji/dMbxlbCUzlLmoemTx9+ws+5K/1v6i9IMlLWkFFFkr45bT4+XLWdaxneFiPj1ayqbHStvTY5VrDNd5kQJoZqz8OrOYuz49XioWNk45mZF8lWfd85IgQmlqtA7QDX7Hs0ApZYyDU+b2ak07kXJ85cQpFfV7txeHh51CsZBx3DRbXlwkfq+PoZFRGJSTZr1Jm3EgL7p+15aX3fTGqx84cPfx7vIcd0qVgpCxB6nDM7KUGgAIt2GxNAzDAOcGhB6wIUtag7TMBBxugnMXnBtgygbXDFyb4MoE1wxS0wGAmU8zJwaYFGAObM7BtQGmLVCWAyM2wAxoaoIxBk0caMpB1Jn0hbFssWD3qsvqhje9+fJf+tAHP1zPnrfh9nsT2Tp0kveOPwnDZoMiYh2jfvowmqeehJQxTCcFJ5NHffZJqEQMHBIIByiDk86iOLUTYRSCmhak7yPst0AYBeM2GOMg3IBWCrnyZnCngvbKU2fQnANaAJDQREFKH9AC+fwmeP01+P0FcNOElmLg526koEQfgBqU3lAGmSQoF86F1BHq7SdgmXkwag8KQ8nAXVQkPWStbYiUj1BVYRAHhFJoIZBLbUKQ1KFUBKoZUqlR9HsryKc2wZJTspDPsXX6jf95avFzXwTwgmjBeUEBFjBovr5zz3X8A397+HSlUjr9oquGX90KWopSxaSiWFyVmN5gYmUlQWnYgtIa7XoCwyAoFG3UV0NoDQitkM2b6LQiUE7AOEMQSBTHUlBSIQ4ktNIa0LBss8olXew2PMoNVtFnnmFK6aE4SZLyaMbuNHzNDW5qBUJALChVp5zPrjwx+5nCTOXGoa2j66uPLz5SKBRsZ2b4xbmJ0iuyw8WXEkrHrFzKsVOpRxMv/Fh/qb41aHqbo1ZQjxq9e/tLa5/sLdb+2ikVJnqrzS/315plGctJpbRJbWtDHAuZK+cL+UpRRV0/Ctt9T0nh6TiK/EaTl8fHl5Ik2rHw5GHWb7eVm05ZG7ZsZaEQmD9xEvlcCZliGfX1Ku0EfTGybcvwy7//B3d1Yxw5ec/XPl0aGxZEECRJPFhXCprCVA40T0NTG5q4YCQFRg2AGWCCgGs2SNM0hzZNaOJCGVlo7kJzB4AFzhgYtSAFhaU5mLIhQWByF4o40CQDZaYAOABxoSkDpUWAVaAkH1AJFjuZkp8xso1OfV78yN7f/uUffM/7f+ZYb9x94OFQtQ4dZn51BfmxIXRr6+g31tCvrqC7MgutBEwzBTuTQbe6BDtbRro8DStfBndSMEwXufHNaK+eQtjvIvE6UEqAcgNkoMJDQYAohezoTmhoeJ06eKoCbhTBuDtIAwmHiD1QMOQKG9HrLiGOauB8oI0xlgJhLlTSGTArkMGMoPCQSU2BsTQarSdhWg6ECgBCwGBDJD1IBDBJDq49iXZ0YiDEg0FrDZsV4dij6Pqz4NRC1pxGovsQYQ+l/MXKjFxmDDUWbn/k5h/fs0dHt912/QvaXps9ny/utoPzSut99OUv+6PHzts5Nnb5Zc4VS+ttkS+49NAxH0Mjg8r2KCHIF0w0qzGSRCKTs9GuxeAm4HsCbtqAEhpJpM7oVgxxJFCsOGjXAoAAqZxF2mtenxrUsRyz5vejEufMhAYoZzTyI8dyzMi0uRP0Yso4JVrpRMXifi3EIaXJeuvU6kczo6UPu2OlSWWwH+GWMRSHyWJ3vWN4PT/XX6o/aBE24S2sPRT3Q58w6mqtKppgBzgfU0Hci7udama0/Ka4F1b9em9H4sWpsN3nUatXbS6tr2bS9j8Ob52+0E2nQjvlfp0RNCHlo83Z0/NOqXwkPTT0Ys8Lc9WVVdbttDC2aRPGN27G2uISQs8Ht2y0Gi3a6HeVXS4617/iFS/bcOFlua/f9ldfThK/XpzYkA0CLw9GMgC1oGkGMOxBSkgZgBQ0GTAmpVLQRhrasKFoCYxkQZECoVkQ5YAZBBIETGcA7kBrG9pyQWkGGmmAGoDhgNICCM+BsnFQPgJKK6C0Am5tBqSbH8rU++tLrTBsTf3vO+5678bve9OPfv0JYs092YI3e5qaJIblmDj1+CGoRCLx2uiuzcF0UyhUxlGa3IwoCGE4KWitEfkd9BsrSLw2rEwO6yceQ9SpgSQhoGLoxIeOelDSQxK2waSEW5qG11yAX58HJQBiD1oGUEoObIyUQio9gkJxCzqNWcTBGigD1Bl9i1ITUnRAoEH0QDuV0oNj5uGmxlCvPwZumAPbGUqRiA4ABcZtiLiNUuYCdIN5EKpBCQehFFAapcy56AYrkCSErVNIpzai3n0E5fw5IHFWlUoWjd3jbzmx+NVHK5Wd9PDh/S9owCIvhGu8887r2PXXH3S/8rUXfdocbr604Un5hQMxa3QkxkctHD8eY2LGwaEHe0hiiVTaQtRXaLeCgUYlgeKQjdXF8Ezh6QCwysNptOshkkhCS4WwKwHosDycCdaXeoIQOvR0wz+hlCRSNDdsH15anW2l40ht1FLWlBf/fdQN7rVzqdXCZPlVzDYvZBTnBCudV1Vnlz0wtpWk01cZFtuipA5MyzidKeR21ZdWb9VCjzLXfQ2xrKvJYCG7WWjEzDLD4sbxYb/Z7Ykk5mB0GxibJUQL7UUntcbhoZnp8wmn3y9B7s4Usn7S87ZT07kv8fqTJJU+d3V5NdPrtAnjBkZmpjEyNQMtNUzbgpFJgxgGsmNDenrLFnXZuRez1hNH7v6DPe+/ef6uLzbc8tjlfj/IApSB6BCSJIBUA6YECSQhCJHQxAGlNkDpmWa5BJraIEpAD1YUglIxKLVASQqKxAMxnShAiTOlDoOHpmYOGBsCpZOgxgQhdAiUTxsGa8fV4/944xt+9Mhrfu6nPtibumLknm960l9pU+K1iYEE9cUFLDx5DOWZGVAQRJ0amMHBQMANC7X5w/Dq1UF5AKXQUiKVL8PNldFcOQ0Zh6CEgKhkYHWMBFolUFEIK1OGmaqg31yAjvug3B1oVXrgdwWtIUUMN1UG5yZ6rXlQzsGYBcgYhFiQSkPrHig5M+sHCqFC2CyPbH4jarVHACpBtQVKOYAEQkVQWoASGwVrAyIZIYhWYLIcQAmkipAxp2EZZTR7R2BQA2ljCpRT9PwTGCm8XDqxwwrTuPez9/34NXv2aLJ37wt/UV72QrjImZl53H03CR98NLnv5S+t/PjIeMAJd8jh0yFJ5yhUAihJADJwHQ0jgWzOQRQPGFUSKVgpA4bJEPpqUAEPoN+NURnNIPKTQbU7p1ppGAqaprJW4ndjzjllelDPpwmo47WDdmWyYHTWeqta6GURJ9X8WHk8W8n+bBLEXu3wyp9rRp/Kjhbf5HUDSU1jElq1kKhVgKxEzcYj3HFWs0NDN/jt7iEj7V5vuvaY4VqEO9Ykt2xOOY+jds93C5lhEYpGf7l6h+iHXtjqPhC1O4fjWutY6+TJbxCC46ZjJkuHjjda9dZlmtFLNGHjjDJrevs2wk0bgR/AbzQQeH1IaIR+gFw6hUw6jV69Q/xel657LbHpvB0brrv22h+PpaWO3vPVCSNV3kG4kdJK50CVAFExNLMAmhusM2WOgrExEGMYlI2BsBQ0zQLIglADhKZB+RBAC6BGBTA2gZnngJpbQOgIKJ8EIRY0c0B5EZzlCEgOhA0TZr+I2plzNLWyst6q/vgv/mzmh37z3b9yim9LHzjQkkm1y4ywR/xqFXNPHEa3Xsfk9m2wUin4zToivwcIAZ34WDnyKIJ2DZQNuh60ksgNT4IZHO3FIwMhnAyW5xp0wQNKJYAAMkObQcw0vPosCDQYT4FogkGNsIKSEYgiyOUnkYgEndYsCJUQ0oOI+jDMMjhPA3LQKKBUAkIpFBI4rIRCdifqjcehaTKoeCcWQDSECgfHV4mmmiCX3k66nZNgjAw0MwJQGMimt6LZPwFGGBw+DM0Z4riNVGocNCyqYtEiPePw2+dX7j1ZObiDHsb+F7yVNnmhXOi+fbvZTTftl3v2XPJ9P/Rj1heqcSDvfFDQQ8faZHjIxsJshHzWwIkTPrQCuGEg5dhYWukN1s8VGuWRNFZnfUANlq8P+glGp/NhrxkY9XWPmbYBrYlOhNSFSlr57UjEvrQHXfYAAdFJLML8UObedNb2Ttw3e2h0+9jVicQuvxNUpYImGjr2wm8UhrMdM+XsWD0y/2eM8i4ISaBUCIPaiGWcmx57reFaV3pt74QU8lwlZV/FmkDLSCu9KsP4mFZ6rbB54i0iitx+rfMEpYQRCl9r3SJar4sg1pmRoUvdkfLrgiiB1+4xYpqMUoZUKoWJbZu1Uyrrdr1GOisrMAwTCpR0mnWMz2zE1PYdEAaDVcpjaGpSXbzjHDqVLeL+L3z1K//rre88DoMOGen0UhL48yA6htYEhJVAjElQOgTCRkAIh9YJCDGgdAsQncGqDFqcKU0ACB8B5eOgtAQQF1D/X3vvHSdXWl4JnzfdULmqq5NaWSNpoiYCQxQDNmDWCWMNjrs2tvFi1gnvt2DvLho5rddxbT4bM4Y10TYSJhhsMjOCYWA8M8AkTVBWtzp35Rvf8Hx/3NJYOx/+re317poZvfq1OqiqVNV177nPc97znLMGorzY+XPLID2Ac2cYUR+Mh8Iv3WJic1m5Ujn6O+/67dlt+19246cfM3TsoS6pNOe6P8Ly409gsLqMSqOOsFpCb/k8Ns6eASNCpVkFsgS95XNg4ADnsHkCqSQqzUlkUR+j9fmiBWPjazYr7PCczuGFDZSbW5GOusgGywXpXtRTIHKFl1U+gu9VUSpPYTg4jzztQSi/AD1n4KkmLCXQ+TqEqMKTbQihkOfrkEyh2diH9Y1HQWwExjgYqSKowkUAFborZ7RtNa6yvf6SF6oyct0BVz6s0WjX9iHTOaLsPHyqola5DP38JJpqB5SYsSpVoj7n/uYzD/7Uvzp4kPjTobr6pqmwLpDwRAfELbd89okrr56e3ne1/2yntD11ljhZB08Avi+gNYdxHJk2aE+GyDMHbRyscxCSI/AVhr0M5Ii8ULI0MsueL0ye2dA5xhgDY5wxrS1vzlTkqBcXTnxFF8A4gM65ztHWpnq7fVn727vrg6ksNpIpUeOCVxhnFS54Y7jWv8v3w6X6TOuFw5XOezhjJRHI6xhxB6L1aHH5r4NGY5PTOo1Weg8zwctk3CNE9hSDPScEP8HJnogXVj9c2zrrhdVyOVpY/mOXpCsEx5xzDaG8q7JMXxMP00ZYq6jyxAQzWc7IWug8w+q5eRZ1u6xUqzC/XGE6zVm1WcPUpjkMewOcP1tEqwelMtI0ZZ3BiHrMuuue99zdL3/Naybnnzhx7+IjXznrBcESpBeRwTSkfz2UfwuEugJC7YBQW8HVVgi1GZzvglA7IdQexuVeSLUDQu6C8HYyqWYYlyUIqcBlgwk5wYSYgFDbmOCzjCiTki1ZHS24weLD33brdw/f8q63vSTbfdOuj9yd0NqZhHlZwnrzS1g8dgrkCLWJFrK4j6XHHkLc6aA+OYNqexL5cIhcE8L2Zni1SXiVSdRmdqA2PYckzqDTFF51CtIvQ3pB4a9ODsxaVBrbEVQmMVo9AZ30waVXTMaPswDJ5SCjUa5thvLL6HeOw+oRpPJAzoBDwvNbcDaHtSNwruBcBm0H0HqEktdGo7EbK6sPgFgEzhVABME9WFek53DG4YxBo3Ilz8xIJGYRUoZQIkRqOiirFnxvEv3hKUjmoeRNwYoMcTKP7ZMvQ9JNUWl61pZXDpxd+vza0aO38m+2EZxv+grrwvMlOsgYOxS85/03PrH3hW7uo3ck7mtfT/i2bRI6Y1hdMVjtFGrjUilApSrw8AN9eB6QpQ7T0zWcPzVAHhtUmgE6SzH8kkq9UAWdtbjwLmIMOrdoTJUB6/LeUuxxKQAHmMxEivNPV2fr7Xq7tGX5XLeZxq7GJQdpC3LESNvTOsp+1/QGH952077naGN+cP3Euf+cZ5mAlAGIlPB4xaZUbu7Z8tMu0w/2F5Yf50Jol+RrsHkHQAQgRogBEiy2rrnil4SS+5ylO3QUNyHkTnAxASHqICiTplvCiQnnNxu7oo0O8iiGzdMVa/Q6GafqE415rzVxQxIlNS6EmL1sD1pzc0iGERwRZDlEY3oKUzu3QVVr7oo9u/iMCvWjd//tO/7ra37wLrhIeBPbXqgR3Aqu6sSfYuhQEDrs735GuFCZUiFDpfHtCjkoK+xWQADnjIEM7OrKAxNTtT9/yzv/+HnNG577HV9dK7GHHxk5r5tws7qK7uIarDPwymXkWYrh8nlkUQ9BtYbA9xF3O4j7G3COwAhweQQvqEBVJ5D3lxBvLIFAYLCAzYvLtTNgzsCvbYdSHvIkRhr1IRgKsNExyOZwNoM1KZRXRqW+BXG0jnhwBlIUSg9yGpxJcNWANRHIxUX1RkU7aE1EnqojDCfZYLhkQ79qdJ76xDIIHoKj4KXAHJzNUfN3AyLAIDoOoQKQyVEJpjAcLWKyeQ36wyUQ5ZC2hkp9O3rREygHTWyrvdqkg4EMZwfvuuPBn/rRAwdIHPkXnILzdAcsFOEWRK//4Suu+qGfm/nSuutUPvKphKU2Z7u2V3DmbIYzCxkYcVRrAepNicceGiKKDKxxCMseuJZYXYpQqin0lmNAMDTbZfQ2EjiLgkNmgLUWk5vq6CxHcCmBrCOhBKu3your8/3HHExryxWbLl9fHAZZrC3nXLjcZE7b+1zuvg5n7tG94T2Te3a+1GtUXrB6fP6vjDHXcl8pbm3kwIXNsvmpXVteoJPskeF678vl6eYUhHphuV5JYdx1pLgPJplg9Cj3/FB4wVYu2E1Zou82WdbmUjTIUptzCIDn0lM+V75fm2ybUX9ANs/vNVpPZHG8U0mvV5mabkfxUK6trEAEIeZ27sLc9l3gvkLU70P5IaZ37YA3UafpTbNs7/YdWDt2Yv1Tf/TOw3f/xZE9bHLzt/CwQtZagIqYD8b+h8OJqECk8cFFF05aBnLFl+NrD5eKSSmRj2KDND7zvT9+YOk7f/xHbhpM7Qo//2CO7vmYzHKP5curABFKlQp0GqGzMI+ouwJPCPjVJnQaYbB0Clk0AhxARAjLFfjVJkyWId44D5vF4FwAlINsAqsjkMkQlOpQlRaszpH0F0HOgasQnHsQ3AMTEtYRJJOQfhVSljFaeww670HIoMgTdDkY88BkCGuGgHOFzgtFqK/VEUrBNDyvSr3+cQamHZxnfX9SFSR/BnIEMAvnYgRsEtXqbqwNH4LiPhgkLHIIkmgGuxHnPUT5OQiSqIQ7oZHDpDEmWldRJb6Omi0/2gg/ctO9D/7JcRpTGU8XwBLfbE/46FEQcKf8nbfevxyGTdr/ovq3Gm9gzpwjMTsXAtxHlhmMhoRmU2B1ScMLFUYjDcE5kkij3gxRKvsYdNPCTpYxOAClskKcaEjJceHMyjKDaitA3M1I+ZJVJ8p5Z2VowXEV56IddZMnZrZPUTxMKjozmgNr5Chmgk0CqPMg3B0lyU1EdHltU3u/MZZMqo2zLnVanyhNNawslyZL7dqry7OTPxw2K49z8G46GC2TdR8ZLW3MD1Y2RoPF9Wy0vM56S+s1HacbEGJyuNHb3Ftcq466gzAZjLyo25OD1Q02WFnW/aXl48LzR0J6vazXvS9aX5/XabqQJ0kelKuzM9u2U2NyikX9IRZPnUTUH6JUrkKGAbJMQwqPEedY6fVtbW5T5XmvfPmztl97g33svq8P0vWNgFWqSiivACkuACEBoQDpMSZ9xsafIRQbz0YVXA2KiQOpJLNZBjuK9b4brkp/8f/9tfJzv//f7Hmw31L3PRi5ZDVl2flVlqwPwRgDMyNsnHwUq6ceh0mG8D0JBoPh8imM1pfhLIHLAEG5gcrENLiQiNcXkfXXwRmHkByMOThr4BzBD6qotraAqQBRfxl5NACXfpFiA4CRhsv70EkPSkgElTZ0uoJ4uAIhQwhVAdkM5AyECgEu4fQQHAy8MKqFYw6wFrXKZWC8jOHoBOOcgUMyxp1wOkM53Fy0j5TCcQePQjQrV2F99AiYADjJ4vUzB0YM1XAHomQZDjF8XoUKKxiMTqNZ34U8Se2O5nXCqy++4/NfP/jeAwduE7cee3pwV9+0FdaFdd99N6qbbrpfv//w/nduuyF/7V98ZsV4vi/rlQoefmyA7qoGlwzRyCIdcYA7bKxm4CAEFQ/tyQoe/eoGfJ/DOSBLLZqTZfQ2YujcgbHC5D/PLKqtEMyyjvS86rATyTxzT7rdWuNy3xefm946efX502sVnVkuhQydsSectg9Bil1CqesdgXPBz1bqlTWdxO/2wpKGL17FuVhSpfALemlwBw/ktVKIbzN5+nuLDz72BIDrebV6LffDlzAu9jIudjGlJghkVOidDlvNOcFYKeoNbTZKNGMkmRSSEcFmaUp5/sVwYqJbbre3W1CYDqMpncS13NiQKYWw0UBzehqlWhPgAtzzoYIQqlSCVy6h2m5hYtMMwlqNarUGu3r3TgQbfffX7z48+sj7DvvJIPFRq8NTCo4YiMtCmM4l6AKZTQ7MWTCbQZCGsxp60DOIo8XL9+2Lv/O137/7Oa96lVgY+Xjk8ZRGA4NkkLDeWg+jzgAuGiBaP4982Ifne/BKVeR5hqSzgjwaQkoPKqhCqBJ4UIUzBml3GTruA06D8iFM0h97U3GochNBuQGjY6S9JehsBMFlIScohiAKADEZlCohqE4ATmPUm4ezSRGtxRQEL0N4DYAAk69D20GREUii0FgZDcUD1OuXIU46iON5cMFArthhhLOQsgxrNHzVgKERrEkx23geOsMnkNMAggXFGCEDnNGoVS9DGncgZYA4WkCzeTUG8VlISFTDvcSjwF17+c3RyfQdV93z0IfOM9zGgEOXAOtfwiICu/32G+Wb33xq5s8/fvPnBqWV3fd9fegu313jn/rkAMrjOL+QQnoCZ57IMDUXYHkhhnMEFXBs3dbE8WN9WFu0KXlq4YUSviexsTQq3CAMEVmwLM4XLr9hW2Ph5EaQjlLJpSBnwYgcAOZsbgd+4N01vbV13fJCR+QpJqUS0mrTIUPzEHyGjF112t5Tm6j1KzON79KZOWuh3rh6z9ceHL8kCcBsuuaavSIUt4GpJ+a/9sCfIc83yUbrZlEuvZJ5aq/w1CSThX8dWUvS91lYDsE5htHGQCej0aM2TXznXI+0WYDVD3DlO29i4odLE+2bwnoTqlSG0TnS4QBpEsMAkH4J9ekZNKdn4JcrEELAOgvpeWhMT2Ni82ZUmw2am5tjuzdvQvfEKXz0v/8FPv83d0L3R0C9Ca9cBZdBMYr4JGARmDXQSQTT3wBMgmuv2b164Ee/j7a84IXTK6yCxx7ViDcyUJoh6g2Q9CMkcYIsSmCGI5gsgbMJTNxFHkVw2oIHVYSVFogx6LgDPezC5IU9FpcSnBdWLbA5/LAO7nIIrhD31xGtnYHRCbgqQUiv2NkjC+c0yBKkX0FQmQCRRTo4D5t0ACGLCtE5ABycSxDjKL5TgLNwNi1iu6xFJZhBpTKLbu8s8rwDISTI6WKWmxwEL8ORgXUjgCmUeNNVKnM8StaR5h1IHhZaLw44k6LibwU4xzA+h4q/CcIyOD9A3F/CdOtKDDtDs3dmv2TlpT/49CP/4Wf3779DHj16i8HTbLFv5id/Qerw2jdc/+rXv7H9gfvOnEWjXBL33JPgzLyG7wlsdDTWVjVAHNIDVpYyTMyEYMShPIXz54bggsFZIM8tJqYr6JyPYHIHECFPrPMCOShVSvOKi3x1sbNHeKrqHIgIrPgLZI2NpCfnp7e2tvRXk1OjYb5LeKJskuyMy8zRsF5SpXrZcw53Rt3OhyQL9gfl8EU6tW/rnjp1Br4/CcAhyyIA6fR1V/8H4fvXx0nCdJK2nCUfjG2QNtZqt4M428kY506bvo3iv2pOtz5Rmpn5bgJuFoF/DJYGzlHDaiNJyrbWep+lIgRG+QE830NYqaBUrsApD9paGFt0wp6vwDwFxgX8oAQVhKi2p1CZbKPUbEJWKpjeNIXtk23kC8u499NHcdfRr2J5PYMRASBDCHCQc3DGAjpDs0R47o07sP9lz8em62/CopZ4+KTF+nIKijT0MIaOIpgogk0TmNwi6vWQDjqwUQfQKYQQEJ4PLgJYbaDjPtLhKsikheOCpWKshiyEVJClKrwggHMcerQGk2cga8C4BwYOZzK4LC5i5BmDV2rALzUAcCSDZeikC8YF+LjqYmAQ0ge4gDVJ4YdFDoCEUg04srB5jEppEkLVMOidAmAhuAciDWIERg5ClEBkYW1E4JyZbBi3a9el0qu11jfuh+fVi/0LBlhKoaiMUjCHXvQ4uFAIMYFKdReWN76KdmUPJIWWZ1W+a9dVj3/hzB8872Uv+5nBkSO3OnxzpYE//QGruIAfEIwdsW99+3M+cNO3iFu/drxnRjGXn/jkEFu3l3D2dAIwwtI5jeaUwtpqimazjNXlDJt3NbGyOEAS67HTo4MfKigusb4wKrgMzhCUVXft7GhjakudQNTorkY15SvPOcA596RKy1kikFvZvHvTiWE/0SunV/tBOeiWa+WtXHn368HgD7unls4DwRxKvFWu1W6tTjZfCMbuXn70+PuhdSAqlVniPHRpasPJyavKm2eez4WQ8craA6OTZ+8F3GkAgrfaN6nQf7Zfr8aiVq1LyTPS8Jx1M+WJ1t8EUtWHg/6PE9Gj2WA4SKNkzlq6lsa9rBtXIkIKCL8EVa5C+SV4ngcReOBKgnOF+uQUuOeDlyoIaw14lSq8cggZhlCVGrbMbcLezZMIrUO0uI7FpRHOrmfYGBmQtWiVBbbPhrh85yaw+gTOdYHT5zJ0NjTpxLB4lCAexjBxDpckMGkMlyWwaQqbZwARpAME49D5EFkSwdoEJonBrAEog9EaZDQYZ5BeCUoqWHLI0z7y4QZMGgNE4HwcO0qucGuQPrywCel5kCKAzbsY9RdgkyE4F2DcK8hwInDhgXEGazOQywrfq7EA2TmN3MSo+LOo1vcijpfQ6z0BT4VgXBSUNyMwcEhRBjkD7UZgHLB5FDWqe/u5TmeMTbnv1ZCnGxAygIOFMzmapSvQjU6AcQNYQiPcC0ccabaK6eb16C2vm93bXypZ/fz3ffq+n/nA/v0H5dGjh5521dXTArAugFaDfbr23//mqoeyam9uvc/dnXdFPPB9pMZhaTUHsw7R0KFS89DvWQy7FtXJAKVA4typHqTkIAvo3KI9XcXa/AhZZFCbDE1/JYnhUDPWdma2trLuxqiZxy7gjIHowm5+sRVmM3NKp+YD267dMgsutkb99LhOzLs6x04fQ4gGZDgHy9rS864joa7mglWqjWqdhQHTSfLX8XJHOaluEIJXibG2067vV/zF+tx0RfkqZ1J+3WRZOU3NVhEEKzbLQ5vlTySdzmkRx/cmnQ5HYcfZBTDZevazb3ba/Ipqtnb7pQoUF5wYYMFgXSGEBBU+4gUh7QDroMIQTnkIyxXIIIAqVVAqVyGCADwI4ZcDhLUaKo06arUq2hNNzLZb2NaoYCaQUABSAMsj4NwisLBI6HRyZGkOnWnoKEc2ypBEKdI4ho6HMMkAOo3AtIYjAtmC68mTEaLeGqweAo4gmIQXluEFFUiuAMHBJUOexci6q0j655HH/WJXyQvBuSqGgVxh8SWYgPADiKACP/Bh9Ag6TpCOOnB2WMR6g8aCfQ9gHGQ1nI1BROCQRQoOHKxNweGhWt0Cxjh6vVNgXEKJKvJ0AxAWjAkwYpCiWlwsKCt4rmxIlXBnbBlKUXKaSRagEu6A1h1YZLAmRsXfCWMzxNl5SObD4w0or4E8jtGs70QSDWxLXikmtpSPfebBH7/uAA67I7jV4mm65NPjZVxJfXak+4H3Lv7Yj71x04eXe11v07SkjQGxrdsDnFlIMDkjMYwM2jMlJPEIQhLiXoLSdBWlUCKNLbhg4OCIRhlqEwFGLIfTjoOoxj1OysnWxuqAWrP1/urJ7oIlbOKce+Aki4wecCbFJLNZ1l8bjNpbZ9d85YI8ygWAAEZNCcXqzFdXQ4nrBGNTBKb6/VHoZXqTVw5vrGyffcBESZwNouMm1l+QJW8n87zrTZanzrlGrV2VnLE5a5J5JNFHO4+dkDZze8HZbjizF35pxZtsbQ1b7ctUKZh1hNBamjBrGzyiDWIg0NjClxgHoQBdKSWEp8CEKghoRvAYgycVRKkM5XljApjAGRXWK56EVBJScGjn0E1yOB5hI/UBw3B8jeHMAmA7BF8TXGqQJhnyLIdNc2RRgiyKkUUjOJ3A5ho6SsBMYVdtdQYiDoJEqToNsNmxTMKCkYFJ+ohGKzB5PBZQMEgvgCrXIfwSXBZDZwMQATJsIfCqkKoEzoBMj2DSPrLBApzJAc4gPB+CpkCOgVxSzBO6FOQyMOsKDouJMVDlYOAoBVsQ+G3EyQrSdLmwT6Ycxg7ghRPI03UQOSivBsAUgCd82DxBrbSXWc7KcXQcnqwWWZp5BE9NIk2fQMCbYBQgSk5BKR9MSwSlKfSjR9As3QiCIJsRWpums/X8yz8OMH0YBxjD03c9bV7bHXfsl7fcctTc9uvX/pfrbvHefNcDG2Z1Tcqdu8u48ytdEHdgOYeUPvJYY+F0AiE5uBQIQw8r8xGkx+EMkOcGUzM1pInFxsqwUB4XvCxZbckLZV6uhgurJzuJDOTl4FwxxoiIwVlna1OVMyYxxzdOb9xdmShNVSZb1zAhHumdWbkzWet0ZL26jytvHwABKbZyLi6Dw5rJ8+NC0F3h3GyfE/6NFLwLjqYj/O1wuXuFyWmfy/MFMvHt9Z3bQr9cu54r1fTL4WrWG9SYs5Ro/UpHdEYnaWCTdLuzNCImZsCFIMaICc6k58ELQvjlEkQQQKgAnDHSScx0lsIxDhGWEJYqaG6agyiVAalQqtbghT5UuQyv1US5XnczU5N81+ZZVCTHyuoIZ7o+FqMy/NDH5jpQV8CoCyyezOGiHHmcIB5lSKMIeZwgS2OYeARoDe1ykM6g0xFg0idPbs4EHAE6S6DjPnS8Bp2sw5l0rAEjwDrAFZURVwoyqKNUnS0cE7IceTqAY1S0mjqCs7Zo1xgKIt05EOMAK0Z5yOWgfABrInAG0NiW3loNzjwE4Qw8fwrOxEjiQsTJuSjizRnBUQ44gufNADaHxggMokjH0Qla4R4klGMQPQpPhGAQAJcg6xD608jTVZTCTRiO5sEEAQ4oqy2wSiONl7C5/RL01zfsdPUKUZ6gP7rj2M++4cCBw+LIkadvdfW0AiwA7O333Sh/8qb76a1/et1dlcvwnC/cHds9l5fEseMZjh8foj3pw2eFp/vSUgJnOZLMYWIqRG81K6oszpElBtV6CZ4vcf5sB54nYTUVu4aOWJ7kw6m55uPGEN9Y7O9RgV8GgTnjbGW6YlxOp+J+vImI1QGWO0tnglppvVavZDrK/7Z7cuHTmdYtVSrdxJTcQtaeI22WTRw/CGvPzlxz+Su4513LhHgs7kVXZ2k6yKJYEpdXcaKBM9nnXK/3QQCrjWuueT6c+43yRKtvUy0gWM0LgkGS6Za17hoi51ltAMbhByFUKSRHxCwBztoCBNKCUPbCAKVKDdzzwIWCX64gqNdRqdchKxV45TK8Shl+s0Gbtm1l2zfPwRsNzcOfuVt+8eiDOLkcwakmStUGVLkG5lcwUXF42fMvwxXXPBuPHAfOn+w5HSd82OkhGfZhsiHyOAJZC+Yy6DQDEwrMOdh0hCzuwmTDwvWTcUi/AulVwBiDTTqw2bBQtnMJprxCPG8SmAtyBp0WDp/WwuUppFJFleQMCBd2/HgxS0gOzsQgk8JBg3EPUijotAutR5bzkJdLW1lY2o7MDJGO5os4eyHBXOEKWgj+x35XwgdgIFkFWvfICcuYZpiqXIXExuhEx6CEDxAv5snBC26RFGrlPeiNHgegIaAgESIob0FveBy1YBZlsdXRyGdzs7Pnl4IPX3vVVT/eP3LkQGFP+jRe4un0Ym6cXcIXv8jsasfc/12v3PydmUgrzgGGJEszi8FAoz0dYv5MhOaEh/7AgnMGawj1RoB4oMFFYWnOBYdSsoj7duN5ElfsCgoh/GE/aVSnyzPg3MtTw2GdrrSriUnM0VEv3u1XvJZzLgExyZWcTHqjc+lK9/bG1hlRnWy9otSo5dEg+rze6NztHK26OH986qpdU6WZyZ9jRAvLp+b/2/D02TvTjY2vq2r1ZlWtvEz6ypHVyyZNT5Xn5q6pbN36M1br52Sd/ge6xx759Oj8yvnR+sa5aBR5Lkr7VmeeKFW8SnvGq7Unct+TOtO5ytIMNklBxkCWK2hMTlKtOdHnjHsmz5jOc3AhEJRD+H4Av1qFX69B1qt2886d/Jprr2YNouEDH//UI+94868nd//1Fxsb6xsM2QgYLCHvnEWyegrJ0gl0zpzEvZ+7C8NTX8dzn7U5q05vVosrQB5lZHTOrNYw8QguT2DzHExwOG1AzkFICS+sQfkVSC8AEwJkEuRpH5zGcW1CQAZV6GyIfHgeWe8cstES8rgHpzOAHKwegQkFrzwBmBzORmBSQcgAXEg4GFidjm8PgEkwBlg9QJ4NUA5nUSltHZXKuzxwjw2Hp5GnS8X/z0QxEA0HwBZVIQvBZRnkMhgzhHUpfL/FdNTFZP0KpDZCd3QMSgSFDp2NEwcZgzUxQm8aAjWk2QKEDMEMUK5sRaI3IJyPcjCDdCTcdH0n5+XVn7n30Xd85aqrDvBjx652eJqvp127S3SQM3bIvflXnv3DL/wO+Z6HT2/o1Z6nFs5rzM8PsXV7A48/1Ee96WNjzSBLHJwhTMyU0VvJkYwMuOJgjCEZWTQmQqws9sGJwxoHsnRhwoQx5tYntjS95ZOdU7V6VTjjvtw51yVZVs+H4Jv90Ats7uaNdtMMbD0fRr/tBqMPtC6bK1XaE68iJvZx2C+ng+h0zvAdZLA3Wel9LMvyVHqiNDZHahCxCSh5PZcSfr0qmKemFbH7s17vC9HS6gbCYLdQqgUgslmWMeltLk+1b/Tqjc2WWCXvDygddFPSZoFLOSmUNyUadeWXK6SkYDqOrDXunKpWd4StFpVrNRZW6ggqNcjQgz856aqbp9k111zD6kIO7v2rTz38sbe+Y5Aur13GWhO7ZFhmjljRUnFZnPBcjFusIvXFdjou4Hr5p970H59o7H3FCx45IeXZR49THveZjrugLEYW95FHEbiSsFYjj7tja2EF5jRs1oe1BQiYZFjMIY71UVJ5ABOgC7czuiDbWbHbCS4KgFIlkE6K21BeqBKoCCctpBE5yGowRvD8KoLyNDgk8jRCliXIkyVw5RVvzVgESmzcjjIJIcogcrAmBpCDMY5cj1BRk0sTtata691jeWxXKp4oMyI35sQKbszZDKGahhc0kQ5H4DJHrgeoBNvhpEI0msdE9XJko3XbFjeL+kT46TtP/+TLnwmt4NMWsADgDtovb2FHzR+977nv3XYNfujeYwPzwKNaMksoVT2sLiVYWc7Qnizh7KkE0mOQSqBUCbFwYoBaI0A81IgGGq3pCtIow6CbQnAOZ2i8H0hkDTGnzfG9z9nlr57pffr8186d9BvhLBguY1JeSZzXSqXAELiNR2lM2p6F1h/Q3f6nAcxjGsH0piveFdYr35Nr2kCq/6S30Xuhzuy0s7ZCzp5m1p0FY4o4eUGrvlsoP8z7o4fyJN5gYA1wociaRylJzsHYfmXb1meVms0bTa79qNfbrtOMw+onyORfpDg777UnXxvOzF7ttZpQnscE43BMgJx1QSl4QliEQVhqVyYnyqrRIDU5SVuvvoLPTbYRnTn7qXe9+bbF7qNnX8RazV1CKTjriBhnYKIQi3JeSAYYK0YNQWDOgjOQMzlznY3TN7zoRQ+95g2/evV6vnXn1796hqKNdUTdZZZEw0IVDwenc1iXI0sGyKJu8cY6C8apGLMBh7MZTDocXz0EGONQXlA4gFpXaKUcK8IVx/ODRo+K9hEczowKUz1IkC3aSumV4fk1KOHDmARJvIQs64KoUKYr0YDJ+yBKCxed8dygECWAMTiXFNH147Bsm8dJuTzNK+WplV5vVQJ81pgOOPeKOUwIMCbhyMBDHY3GldgYfBWK1cCcD3IjlKu70Rk8hrI3jZLXoOHqmr187jtNx33puQ8s/uEDwK0cOHIJsL55q6wLQ7nNrR///M0fX5frV33ijp4zhomt2ypYXk3w4H0DbN5RQ2dNY9jXMNZhcraC3koOcoRBNwOIw1mgMVnGyny3kC8QA4jIOTCd6Mjz5Vp9ojYf+EG0cHxpIU/0NPfEFFPiGs5ESBbaCz0jPS9NR0mWjZJ7Xao/5kajT0/tu/KAzbOb+4trR0vt1iv8ZvXFXhAwxsTZLI6n4djX09HwEWbpMV4p/SzAvjhYWmswpV4BxspwrutyfQ9l2T0T22aOy8bEv3XO1eLesG/yfEp6quSFpRNciJNknOW18qv8UqnJuXBZHEud5MJaDS8swa9V87BcXxdCbqq0G+C1imtt384vu/Y6iCR7fOFLXzj4oV96k4/qtttEpb7D2bHh3YXDiHMQOLFxVXXBnoGN3QqIivAXISU3STTyhf38m37rT5hoPu/bH3p4wJbPnHCD9UU+7G2AUPBtgizAHLK0iyzqIYs2kI3WQDYD4wqq3IRQAUzcg8uHADeALbRb3GsAzIdJu7AmGT/LwqbL5TFIeAiDqXH7H8IL2xBSwNkUabyGPFmD1TE4l5CiiAOzLgUIELIMkw/AYCBUFQyqULm7rKjU4GBtBGYl1arbtWPO9YdnNLgrl9QmDmuhxw6kHBzECNwJtGs3oBsdB7EIgA9l65CqgsSsw2UxJlrXort6yuyovkSWW95tnz/xukP7cVAexdNTc/WMASwAOEgH+S/zQ+6HfvRZN33vjzTufWhhyd1974jtvbrJRpHBY4/1kWcCE5MhzjwRwRoHLoDpqToWzgyQjCwYY8hSC7+koKTCxsoASkk4R7DaEQPLyrVwY/1MZz2oBo32lgm7emZj2Rj3LOkpSeO9dnLOCqm48oW2GT2WDkd/Up9qzjGo1trpha+rauX1zFPXOOuGRFCC0eeUUvdX2u11kHu5ZXyHE9xxIc8xsFlnzPUgB6fNPcQo9KvlqmCqm4ySqw25HhNiigsB5GYDzn0OQsCvlF9trTneO3VyaJIsZEFpV2vHDr8xt4mbIggbfrmCcqOJsFUz2669Rm7dsnV0+iv3ffjIG97wUSCvyMaWOevocoBvhZAtAsqAaIPz2gW7GLooT5URCnX3k94y4/aLy0LbtDb/le/84dffd923//Rr58+XSw/c/WXnbMyZc4hHffTW5wGYIrRHSfh+CVYnSIZrMCaDMxrcEbjywWCR9E7D5H0wzgpvdFWDLE2CrIPLi6SaYmdQjDVWElxVwCyQxudgbQSjUzAicMbHVSIHH1eKljSc0xDw4YVtWD2CNX04suDEwYUHRwbOZAhlC6VgM2K9jDhddlKWOWMczlmU5By06cKxvHhkazBZuwmjeAmZW4MQEtaMUA+uREoZhoPjmKxdi9xENkjafPfczfd84uTBF+/f/yf26NFbLJ6GivZnHGABwME79stDtxw1b7v9lp+47Fn29vd88rxptauSc4b5pQFOPZGjPVlCPCQsz8cw1mJ2roaV+QRZ5gAqnMezNEdruoZRL0WeGjDBYTOL6kQF/bWRdYYEOYIKJNqb2+fWF7p+luhpKSWcdVTs2zBmnQMHv682WZ9mlpl0EL11NBjtg+d9PxOSMc49yvJjOorf5fr9P/e2zBwQEPVk/vxvA5gW9fp1MgxvIriKVyo9LEvlm4mxq3QcfSkdps9nQu6EFFXOmIIxIGuToN3qyDAUutft5Ul63gvKO4LJqZmJyy4r550ODTbWWWV6CrXJGchq2VW2zLB9z7qJKRIPfva//OafPvLJjx3j1ZmrQUw5Yxg4LEAeGK8U9sh8Ckw0APhgXDKwItqYUJxIjAkCr4GxEOSicSCgYs6tCM4WTXe5s+OqZz/wxt/52CtPLgbP/9u7HrT9tXMi9AVMFqG/egbRYBlGJxBCICi3IJWHPIsAZ8GFBJyDChsQMMizAUw+GqcvB+DjGSqAYHUGnfXgSBfZga4YxpayDIKAy3sYJ0eAgS5k24BBgXG/MFcFgWgEZ4bgKCQKjKMY17EGoayjFM7BOIcoWgAhKfzdHcB44eDAnYTHJ5GaBVhKMVm+GmkeI8mXiplDyiAcR6V8BTrR4whFC5VwE/rrS/aaue8SltZfcOe5//ClAzgsns4i0WccYF1Mwr/rvc/9hNqmX/H5r0Zmbq4qnzjeR79ncX4+x9YtZZw9GaHfz7F5aw15Qlg8F0EIAWcIRhcH/cRsDWuLIzhtETZCkCUMOwmYYATH4KwDFzJub24Go16iB6sjLsbJOy63moG+XmrWTNaP/5Jy2/Nrle/jnpp1jE3nuZEmy1byweiv7UbnL8rb5r4TjPHozMJ/hVKXcc/bDSF2uFHcl62GKs1Mfa/J8nvj46c/B09dLeq1A8zz9pCUllkbel6wVt88O0lcIouTYrzG8wJHDl6ljnh5AYwBlz3nuSjVa0jyzE1duYfv2rkT3eW1t7331lv/BMBW1Zyd1Gm+DrLlIpTCxiAuAO6BixCEEsAaYC4Dky3GmE9wFo4RGOVwlEHwEohXGINPAIHsGsglcDDC95Xtr571fXH+3/znI79amv22Z33tb0+53vJjLI82GCML50ZIBquIuksw2QgyKEGVJkAmg02L1syaBM5oqKACrkJkUQc2H4FJWQw1OwvGvTGfZcC5BBNeAUw2A+M+4CxM3gUXCoz5YCIo5g6fJOSTQvYwNtoDHISoFN5YzEOzchmUmEBndBa5WS/M/QhwROBMjEGQQNBQrAmbx1EYtshaV0mz85CyVDhHW4Yw2AzrCNZEmKjsRbd7ym5vvkTUmsFbP/Po63/m6WbMdwmwLlRZB8Fvu+0A27ftntrB27c8/ng8mBRe2X316x3uKQ+PPzJEue4D1mFpIUFY9iCFxGigMeoVRYI1gM4MSvUAfuihuzRCfbaGjfP9sajUjekcBucIRITmdGNEhsnu+e5yPkoTIeVjtXajmfTie6JOr8+UnOHKe44M1R7pB74MvKGA6JJ1Z7jvK+vcDS7Lfxt5Psi0nTVZFnCivLJpespx/tK003+fHg7nZbla9UJ/JBhr5Mb8K3AZlNuty8rtyTCNIpVGMXeOYOMEjHPyp6cZGU02jtiOa67Dtn1XYaO3Zrfv2ycaXqlz/wc++Lt3v/udv+tVq1scUw0TawHGc5AdR33BQYJgwIuwUx6A8zbgDLioAiiycDiTIDsCs1HhOyPKgHMQvHgM5wzADJzJhPL7MAY268S/9p5HXrCht/zXr351ww6XTjCnu3x98Qy8gMP3JJL+Gkb9VRiTwwur8MI6dBbBZn0wZuCMBhiH8BtwxsAk63AuL3RXzgB8nGgzlqoUf4ppJi6LfEuXD0GicEMlOJB14OMqrfihhnUxrEvI43VWr1wOJUtI8h4G0TIYGwdbuHHYNRMoVO62IPuZgctzmqzdbOP0PI+zc1zKMhhnIKNRLe1FpJcgXRlN/3IkWd8pXaft264+8+WFX7n5F37h8c6hQ4yeSa3gMwawAODwYYhbb4V985tvfNkLvqfxkUfXOmp50YlHT8Rsoh3goQcGmJ4J0O8YGA30exrTc1XMHx8WW9QWxZxhalBrlVBulLB0tg+bXUhZcYArRlwKc16GPNW6XAnSeqtxOhsmd1lL7f5i52yemUD5ai8p+SwhZYuN5xHJkibjznmNauyM2w7iD3HB9wlPRjKs3Gedeannqb5fr/aT7qDijK1wpcCleIy0zVyWDWHM1/yZmZfrNG31F85vtoXnm+IEhO0WwplNMHECZBFmt2zDxJ69lChjL7/+eqlG+UPHP/OZ7zn6zncO69N7Sv3BvEZCvPBDAYPvVFGyeuMYeuIgkoCUIOcBjCBYFcRCMJfBsOJsZTYFbAY2fhziVRAJMJYBzIxLFQbGbFgLWbKxPPzXb3rHgfb2V/7K1x/oY7C65koh8TOPfhFORyjV20Wl4hzSUQc2HYCUhzwawNmoMNODBAFQXg2ce8iiZRByMOcKvomNB5vpQlaGBpGG1YMiS0OnIMrAuV9wXVAFxlIOaxPAWXiyhDDYREpWECcDZq1Dmp+HlF6hnCdbOJwygnV6/BIViHIwQ2hUd5LOBcv0MhwNwEUJzmrUw+1wgqM3egzTpZsQeNtpffm42bPpxWrIvvqS+8/+3h3AYYFnWCt4YYlnwos8cgREdEB867d+9sSO7Y3y9Tc09ufI7RPHM15tSJADekONuc0VbGxoZKmF5wt4vsRgkIPL8fY88SKAdbqKwUYCo01xVaQx9lOxOUkExjkT6TBlySAetLfOXM8IZZvlD2dJHjKlXix8NcU5KxQBjDHGuVD1UstYO22SXJBzW/M4oWww/KKUPMvTxButd6qDlfUoT5Jynqb1dDA0ydp6NDi38Pl4ZfnPKju2/1C8ts47x092wNg2ElwF9Tomdu2AVyljtLIMJRg27d0LXm+4uB7yZ910I68z8V/+8FWv/rGzX/vaemlyW2m0eiqHMSlgcsBowGjYwMIyW0zljoaw0kBZC2ZSMKHBkIFsDLg+mF4D0yMwnYC7AThS5BhCOQMmI3A2BENWfJAGoxyMtNEmbrRmS/d8+j09yvonv+XbXz03jGrt9bWRmZ7dzLPhOvJkCJ3mSKMhwtokguoUBGNQfgU2HyFP1gGXA1bDZj1YPQTjEiYpBpudy0A2hdMRnI1AJoYzEZyJinEcPYSU5TExjycrKoAgWQmhmkEl3AwlGsjyHhtEp1lm1sE5R+C1YHQPTBS6KiILN9ZicaFALodHFbRq1yPON1iUnkXot+FIg4hQ9bdAqAqGySJ8VNGqXYP+xhk3W79ClurqTXed+MX3799/UJ49+++ekWD1jKmwntRnFfOG9KGP3fIOf4v5kQ8fXTcnT+dy12Ul3H9vDzt3tXDqiQjJ0CDTBlPTVaydj5GlBpwz5IlFvVVG1M9QqoQY9hJEgxTSk3Dj3NALFubkHDnjqNao9QdrgxOMs9nqRF0xKQbZKMvSNN9ERE0+NimRJR9GW2czw8AFc7mOpBCP+dWyl/ZHd2eDgScq5e9jnh9eeNvIWrJxfJ9k/O7m7stuGC2eXxytdSe9yYkXy3KZ16anEbbb6C2cQ9LtYnrHDrR37sQwS8zs1VfL5z73eQuPfvxv/ttHb7vtjznnkZuYqGBtTQHIiipq3AIWTd6FCxwfHzccKCkgJqDEx5YV48/MjSO+2NixTiKAQ8oNEBugzAHrAakFSg4gWdxPZIANwon2dLKxYK654VX+8171n9/by3ZedvLYcQO9IpPePMAkBt0FxMNlSD+AkD6kChAEZWRxH0m0BpsXeihrEhAI0g+h043xfqUAZwJgvJBdkC1AwxW7gLAE36+P7zeBUEwATMGRhdbrSPMVWB2BcQ7BAoBJOJdB8ibAHLRdBScBXLBL5oX3VlltQdnfhl58GoY6hQeXqIN0DI9VEIab0U1PgxmBemUrhG3Z0LRFvWruvfPczz/vwAGiI0fY09Ln6hJg/T2vl4jAGOPv/eAtX48b6dV/+dlV63sQoadgtI9BJ8eZ04UXFhjQbFWxeGpQ2NsCqNZDbJyPYZ1Ba6qBYTfGsJdA+Wp8FBXb4Tq3qE/UkKeaklHKGAHOOiN8TwblACoIDABpogyOMaRpjixKQQRN2i2GpRDCl+ejxfW7tM5yr1R5BfPUDcQFQMTIutjE0T1KiL+e2nfNi0adjSdsmm8N2xO3MM4niXuY3LOTzT/0ECTj2Hr5HvBKlQYut1c/73myXWosP/Sn7/6xez76oa+1L78c64891gdgcCHypgAn8XfETWH99BTQGpcgT35/8YnExx80BrwLj5Hjf3AJKQcAiQLkmCuAK+K1yS3lwdq8rNVmqt/3hj/7I1Z7zrPuv+chm3ROCs/jkH6AjaXHMOyeAUOhnSMA5fpWMOLQNgWgQSaF0TEYGTChMOqfhZQ+GHEwzgvpBbmx3IKPh60VpCpDiRJ0NoRzGplehTZ9ODIQTBUuo8QuSGPHIa2A5E1ouwiCLUKxyQLE0SxdCc7L6EWPFqGsTBU7lYyhxmYhvTJ62VlYnaFZ2Q3uUlLZdsy2d+Vd+sie+08dnsfT0PL4Ukv4P12H+J13gt74C/LLL37+7Hd7zbR0ZiFDs+EzJQWy1CGzFo4AYxyEx1Brl9DbSNGcLCFLNawjcMmRRCkaU1V4gYdokEBIAS44nLaoNgoSNRqmTMhCUMmFEOQc5XHG0jjl1gGyGkKWfEglnB+WskDJe2rtloKj1XRt4zDzxLQqVV7APf8K7nuB8BSTngfB8XC1PdmfueqqV2VxfIW15kam1I3ZYFi2WcrCqQnWP3cWjXYLm3bugCEi7XO6+SUvFVsa7fe/942/9IMnv3TnifbWy+X6ycciFPZVFwL4Lix9ERA99cpuLwIze1EVZsag5Mb3t0+5vxs/ZsFpQTtAE+BxIDLF98izeJCUy9N65FVX7v/M7/3pd3/3D/mNqT3PX14nM1g+zuEMvFIDSnKk2QAuTyE4g04H4FIgHa7DmMIihnMGEEF5FZQrO8CZB688Dd9vQ3kNcBlAiKBQnFsNa3Nk6QasGULny8j0arEjCDkGqkKZVdjNjO14xnuA1iaQqgTrIlhrUBJTqFWugLYxBvHj4HysT0PRLnJHqAW70EtPw1If1WATyqU69dfOmR1zzyfRyH7grkd+4ysHDlwljh37d89osHomVlhjEr6wVn7TwWe/5DmvLH/u6OPLdn7B8R1ba+xLX+ihPR3g+BODMWdlMbO5imQAGE0Y9WJo7UDEAMdgsqLSAnGsnF2HzgzCSgl+KUC/MyqI1/Gp6pwbt4yF8ttxAIKDjAMjlnPw0/Xp9ixj8t5sGNWYlNOMCw9c+I4hAENYaMC0DUuVSARebeP8ImyagiwRETkizps7tjIpOWqNGqQXQlVC29y+Sey6/FrXfeTEHx/5j29+AwDc+Lob1f2334+LKqWLPy4cH2IMMvwp31/89cW3dxdVaPai2/KLKraLq7UL95VjsJPjfy8M2mdnsTPcpE6dur//5l+54zei0rPe9JW7T+nBuful8Ijl+TpE4EFHHQw3zsJpAxlUocI60v7SuNUrgMtSDt+fhM1zGJeM5wELwp3IFmGqABgrHB0YCH5Qh87WijgvGj9ZGvtiMX6h/y8GoJmDcwlgCYqVUPKmwGUVUXYe5DJw5o193QsCn1sfleqcM7m2xo6U4iVMtfZh5fyjenPjRlWdrLz1sw/91M8cPkDi1meghOFShfUkCX+M7rhjv/yJH7375BWXTclb9rdf/MR837Una3xpNUKWGtSbCv2uhvIY+p0Uu3Y34axDZyOF9HmR2s4BLjlGoxhSCrSn64ClSCgh+utDrpQE4/zvNGGgseUuKwzjlCy214lAxqFSr6aj1c6DvcXV3VmaNrM4rmdZOpFlaajTVOV5imQwBBOchbWaWFtaYmAMXCoQ50z5AZ+79nLml8uwaQ7BJCZ2bLbbnnW92Ll5VyYz/Ks/ff3r3nqYSBwB2NLv/rm7CGD+vm3yiwGHXfQzuqhiemrF9dTH4ReB4sVV3AV+zHyDnxWPMxpRt7tEN9747erI+//jJ668fEd5y66bXjjMJlia5C4IS2zUWYaxDtXGJii/CpONoI2FCupw2RBChuBcQogA1mbwgjbY2OKYi8LW5YLdMRvnKbJiIBHMMShVhnPFriFnhS6LYMaBFBeSYQ2cS8BIoazmUPK3IMlXEOULhcMp84rEHGZgXAJJARq13einp1luYt6Qu1mjvgndzpppeZermaktH//UI7/8uhtv/E32B5+96RJYPZMBCwDe/e6zjuiAuOWFn/nca3/gCjG9mb94vmNMyZd8ZTVGveqBiGHUNwXQAGjUQwxHOXTuIDh/8rTiXCCJUgz7EeZ2TyurieeZgTGmIHjGfktPJh5zBib4+OJcXLarrbpLh8lKrvOrVTmc5MqrCiV9zjkxxohzBnLEgkoZtclp1l9bFzQWEkkpWW1iAjuv34c8zdBbWEalWcXsvj36sufcIGth5dzdH/jYaz76ll/67Ovuu0+9eW7O4OjRi0GFnvKZPeVrXAQ07hvcxz6llbRPqdrcU4AITwG2p4LfBSS4AGRuaekJe/DgHfz3f/PVn9q2qdW74trnPzuKKqVhp+Oq9RZLR130189C+TVU29uhpA/Pq8CaDDrvgwmBC4yTMzGEDGH1qHhPLrR3KNwdGFPgTIIJNY6O98cC0IKYB3TxWJzDjUl7wcooq20o+3PITR+j9FwRYEEAhyzmLrmDtjECUUO9sgeD7DzIJijLGTY5cQW6nfMucA0xUa8NFnoffvl6/NXe0tINAI7SJah6BreEFy+i/ZKxo+b33/H8z226Tr7ki08M9PHHEmUyDsE5Fs9F6Pc0Nm0uYX3JYnZzHWurEfrrCSTnMMYVEfa5RaniI4ssjCY0pmoFfTzMEEcZTGrHwQV87LkFEGNwxqHaaiAZxDbPUsGlBLliy20cuc4YZ7DGQXgqrs5OlXrrXUjlIyyFCPwAXEo0Nm/C8pkzgHaY2LPD1bbPYt/NN3MZ2U+99/U/+4PDxcWNw4cPi1tv/Ufrd9jf8/2F1o5d1OK5i4j2i1vEiwHw4hYTF93efYP/76ISplive9198vbbb9K/+nv3XLfYqX3m2AnZXjr5kPF9K/N0Fd214yCyKNWm4ZeqkH6I4crjyLKNwi7Z5XAuh1BVwAFW9wvyHSi0dIw9yVERDAiFSl7JMoztF0+HAXACkpfhyxZ82YB1Dnm2hsQswjEDAYLPpws7Ip7BgeBMhpI3Cc9vYZQsA84hYJOo1TeBjLRpLxWbJrf0N8z9L3/0/PvuOYAD4sgzxIXhUoX1D6XgcRZ05wF+842fvPNbXnjZy6+9KZz+6qMDUypLnkQOlbKCNkBYlhj2cySJwcymBkAC/U4MwQBnHYQQ8EMPUS+HI4domMA4h7ASolIvwS/5xaiPdXDGwDoLm2tUJ+rI0gx5nnPue8UAMWPMOcfIGObyPDdpPi85P97ctrmZx0lQqjeo2mwyxhiGG+vwmzXE/W7fc8xr7Njs6rs2ixtvuJm5bvxrf/y93//zv/jGN/ZHe0fyD978B/af4eL21Kv9U1tA+gb3+0b3wVOqsqdWWt+oqmD333877dv3raU/f88vzleC7POT0zOvLtevraSRsZz7XPpFpmLUXUQ6WITREfzSLATjhbfVmFO06QBChoUei7KCw2Ju7BpqC7AiDYKBQwpYC8m8wh5ZzqDsb0PgbwK4QJStIMrPwrh+MfKDIkaMMUB5UzB2BAGFRmkPIAIMkvNg5BDSDGqNrRjGCy6gPWKmsnloy6NXfO3073zlwIHD4sixQ5fA6lKF9Y2qLDAhGM3UZ7f81nuu/eSwMrzyz/5mzUzUlOxu5KiUffSHGquLOZTHoXOHiVYDWWxw/lQXzjg0J2vorw1hDcAkL0I2XZGVJ4SAHwSQvg8hBRgAndrMr4SetmBRbwimVOFsSig0XQRwIjCHJPSDk825TcH6+tquXGsQMVaAXIbW9Axmd25HvLLqMs7s3E371FXX33ji7Be+ftsnf+2X33+YSNx6222EQ/9L2+HsG7SM3/BX+Y98TPoHguL/776bN98cLCx8Jdmy5apdr/rhD/3a8nrzNd31gV5ffkCOomUmfIXh+nHk8SqC6mQRBuFSqLAFzjxY58AZBwHIo6XCQcKN8ZI9KQJ+MgEcxBCoJqxJQXDIbQRt+3DICoKPCm+sYvyGgXEO53J4chrSBQiCFjI9QmbXwZyBdDXUatvRj59wIW3l17S+fVib4S9/793f+uWnawjqJcD6Z1wHDkB88IOwROHcH7/vuZ/bCJK9f3Xnsp6aKCkOCaUEHntkMD6CGbLEolYpgUuFpK/R2xghGWRQvndhRGdsYFdcaQnFLiFZwGYWlXr1rAiCTWmcqqBcBpMSEAxEbBxA6mCzHPkwiSe2b7G91Y1qPIyJe4JxKRHWG6g265jZuhkr8+cpFeT23fIiEZD3yPlHz7zky7/zO6sH77hDHrrln8V+5Kngwr4B38X+iYDF/qmgd+ONr1P333+7AcB/4Ec//D4R3Px9S8tdWpy/D9FojQU1DybuIemtgwcKaXRyvMsHMOYVPvZBE05bWEogRAABD7jAWbkcRDGcS5CbwZipIzgRQfCgEIcSQGPnh4tlbM6mkDxArbILcAGieAEQBLIGHjVQqs2gNzhufTsrrpn71sHuHfte8fufuvISWF0CrH8SaG36rT969mf7jeSKj39pxVx/5axcmU9hMouVtQxxpOF5CkliUKqE2LR1Gitneuiu9BGNilEMKS+4b17wgiq8u50uhIR+JUTnfKfgs6QAkwJ8DIZwBDiCjnNMbplDluXor3dJlkus1p5AuVVH1h1iZvdOdAYdp9otfv0L90Mk+Xve/ZrXvgnA8v6DB+XRQ/+ijd3Y30Py/yMf4zKvXB7Wo2iFvvvA7W8Kq8//2ePnejKNOjbuPiqIa0gvAFmGNDqDeHgSXFXAmRp7UWkov4osWSr4KwgwKtQWRIW8jGDGvBVBsjacGwLcgo2rMHIXWkcNZ3NwkqgGs1BhHUm6AVhA0xCkDUpyFn4wjd7ocVfGVn7F5LcOtu3c8vI//uzNX7kEVpcA658GWn8JSw4zv/vOF/9ZVMlvufvRkQ29kM+f6bJWo4yNlQwbaxFkILBp8xTmz67D931USiGy1GCwniCOMhBjEEqBy/EuoQPIEGrNOtaXNshqx9g4VoqLsa5nHEigowTVVguOCL31DtWm2qw+PQXnDEarXey87hqKoV04NSGuuP7Zve6xc7/+oV/4f36LcQ6ytpBeP3OOYfGKV/y++OQnfzb76X//yVcsr5Y+srze8OO0p0cbD6t+5zhkKURtYjfi9eNI42U4bcCFgIODVFWADEy6DiYULgiuCh8tN+azCkASFEIghKUBOPfgSMPaBM7kEMxHyWvAUxVkNkFsuuBOI/SnYaMUlWAKTAqsDR83E+xyuWvy2cOJ2dmXvf9LL/vK6258u7r9/p/Ul87AS6T7P2odOwY6+BbwL97Fhp/8yJl3/7sfu5nPzQW3bOQJS51zozhh7akKyqUAkvkYJRmSVMPkFoNeDCKg1qqg3q4hCIt4c+MKHySXWzSnmuh3hsiTnDEUHAoR4EzRBpJ1sGmOcrUCVa3CkMXUljkmpEBvbRWKMWy95kpnWwGf27GFb92060R/of+yD/3cz3/kwMGD3iN33ulw6NAzbRvcnTjxSfeKV/y+/2fv+aHHPZd95bprn7XHUWVbkvquUmtTNlhg2XAdpfouKIQIqzOAY4A1MHkPUlVgSQOMntRlPdmhkiuiuxgDIQNnAazLYa2BQIBQTqIa7kDoT8BAY5RtwLocSobg4FA2xGTremgMsNF53MwFN8mtjav7DvplH3noNfcc3H+H/N0vf++lyupShfW/tDjRQTB2yP3iweffduXzm//+a71e+dFTIzPYyMV0s8k2TU7hy3efQqcXgSxBQEJrB60dlOehUgsRlHxIqWBzg6BaQhTl2DjXA6yDzV2x588luBIQSoCDQYUlNLfMYW1hFVmUIBkNEXgeprduIfKEDbfOyN1792Y1Vn77H9762l8CEB2mw+JWduszflfpxhvfru6//yf15s0IX/ldn/i15ZXqz8/PaxCLTDY8JZksI47OQ+ddlOtzYPBg8yHIZgBjiEYnQMyCrIFzxU6hIwMOKqyXnYQnJqBUFYL78EQTxsaIzQrSfB2Ag+I+yFlwyxD6kyiXpqGz3PX7J9iO+ovZZGv2Ew8vv+s/nVz/+Ff37z8ojx49dAmsLgHWP8/vh+gAZ+yI/c9vfu6ztjy3dmRYom1/eywCQdpBLxOSKzDDsLQ0QmdjBJ0VfuBEDHYcCe8soTXZgCoFiPo5PK5gM4fxP4MEBzHAOSBNc0xsnsPS2UXYNEez2URjsk0ZJ5vEQ7ll92XYsfPyh/2l4U+//f/5xTsZY3jLW97CDx065C69XRfa+gPiyJHDDmD08m85+OPN9iv+02on2NbtdY0zMZcVn/dXvoY4mgd4AKUq4ILD89tgzsDotaKwsnnh3kAo+CpeWP0Zm4EzHzrrILdDWLLgYEVV5nIwB/iyAa88A0MjSoYbZsp7jmp6JStL9Kefe/z1PwnAPRMtji8B1v+BdZgOiFvZEQtg9v0ffuVPR9XwZxdzXbrr3iXqR5krqVCUggAwAsNOhtWVIdIoh3OF0VxY9lFqhNhYKebXrLGwuYHTRcAhcQ4mBax12LJnO3wvQBpbBI0qZdY6UhCTczOYLDWjIOFvf8/P/ac3A9BExBl7ZjpP/kOO7de97u3y9tt/Uu/ff2Bm29Z/+3txMvN9S2s9DAc965UkG2w8yo3pw+hB4ZNFBn5pE7LoPJhiYE4Abky+Ozv2gs9BsGAEKN6ANSMQIziTAwQoGcJXTThOGMVrlhkjdrZuRrs0d8q45Z/75ONv/NhBED+E2/BMd164BFj/G9fBgwf5L//yIUcEvPy7rnjhd/7ry38xD+y3HVsd4rFTkesNUyedEFUvZMxxkHZIRjkIEl5J4fz5LsAliDPAFpwV5UWboQIFLiVmt82hPj2J5dUN100ScpyJnbu2Y2ZidjRRnXznqTu++gd//d/edgqM4eClquofWG0dFkeO3OoA0Mtu+dXXzWx58U9n+eTVUcpx7tzXbBxvMMETbt0IJu6CkYDjGqlZLDIDAYAk2AUPLYzJeLIQrgQBBWtzeKoBIQW0G9AoWnM2z9hUeDmfa2yPwlDefl/+m7++9MQT65d2Ai8B1v+VFhEA3vEXt76oNM3+/bk4+44zgxiPP97DwpmB07FzQjM+M91kW/duRq8bM20KvkobwBgqqqzMwWhHyTBGc3bCUejRarcvW1um0J6axVRpotMKWu/qPLzwtvcd+o0TRbV3WNzKbn1Gm7j9Ey43fHrf3eHKg5+JAZQPfM8HfyCs7HoTw8zO+XPrWNs4hjxbNsQiDrIs8CdZEp1FanrgrsgZBOPgJMG5ByV8COGDuQACVXhBnaLhIkXpMpHWouLVUK82UfHFZ3a2K294+xdeexwALrWAlwDr/1K1BX7bbQUhDwAHf+uWF4Xbqj+RAt/S15hZXE8RdQ00Z1hcHMBZMpxzOGKwhuC0gzWELDdwmmRzqoHZvXMIahW0GxOuLCr3L5/q3Ll67/zbvnjkyOkCqEjcCrhnkFzhf0u1deWVB+jQIeYA1F/1bX9xAJj5abL1faNIYjicR5ydAawzpeom9AZnmeDBOFW6mDEsciYtrBuSzTPirsRKakIwN0S1WoEi0w3K8r8nbOEDn7vvl+4FgHFV9YzKD7wEWP8ST4DDB8ThA1fSBeC6cvPm1gt+Ys9Lt+3bcn2Wym+zJW+62xnNUiCKERBjkOYOeW5hiYOTQq3cGArOYsH9uzrd9FG1bv7yzw790UMYOx4cpsPiVhy4BFT/jKsAkJeYMX74N1zxI8+uNb7lOzj87wmC9mSeeLWQTyJzIwxHCzDWFPOfJoVzGRgjSCEQqCoCruBxf1mrhbPg/fd5yd9+8G+OHVket47sNnYbO3SJq7oEWP+yrtwHxJU/tcoO3XL0Ym4iPHjwoPj81z59Q3vv1J5nv2iPm9tcdYOhUStrQ7WwNKDjXzmFqWrzUx9624eWACRPvimc4QP2A+JW3OouDk2+tP55j/0DB4h/8IPCEj2JJ8FVV33XZN1/6Uu3TO6rr6yf+MFaaTvn1ofgDNYZJHqEOD7je0oc3TL5nHsfnz+cX/Mi/6O3334o/jtAPCinjh6jS04Ll9a//JPg8AFx8I6DkvN/3LWAiPjBOw7KgwcP8ksXkv+z79lBHOT7998hGft7f+3/U4E1Yxz79x8ch2lcWpcqrG/O3y0dPHiQH7vqGDtw4AAeufORJ3/fd95Z/HX0xUcdDuGSNOFfzHtG2L//NvFi3Aa8GO7YsSMMAI4cOUDAbSDcRpwJestbLL/zzjs5jt6Jozh0iZ+6tC6tS+vSurQurUvr0rq0Lq1L69K6tC6t/73r/wOVbMsyqVNCrgAAAABJRU5ErkJggg==";
function buildFullReportDocument() {
  var body = buildReportBodyHtml(true);
  var p = currentProject;
  var now = new Date();
  var dateStr = now.toLocaleDateString("en-US", { day: "2-digit", month: "short", year: "numeric" });
  var timeStr = now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
  var eq = stageResults.equilibrium, ims = stageResults.ims_analysis;
  var rec = ims && ims.recoverability;
  var riskLevel = rec ? rec.risk : "\u2014";

  var doc = "<!DOCTYPE html><html><head><meta charset='utf-8'><title>IMS Report \u2014 " + p.label + "</title>" +
    "<style>" +
    "@import url('https://fonts.googleapis.com/css2?family=Inter+Tight:wght@700;800&family=Inter:wght@400;500;600;700&display=swap');" +
    ":root{--ims-teal:#3FE0A8;--ims-green:#22C55E;--ims-purple:#9B6EFA;--ims-blue:#4F8FFF;--ims-ink:#111318;--ims-dim:#6B7684;--ims-line:#E4E7EC;--ims-panel:#F7F9FA;}" +
    "*{box-sizing:border-box;}" +
    "body{font-family:'Inter',-apple-system,Segoe UI,Roboto,Arial,sans-serif;margin:0;padding:0;background:#fff;color:var(--ims-ink);line-height:1.55;font-size:13px;}" +
    "@page{size:A4;margin:26mm 16mm 22mm;}" +
    /* --- Cover page --- */
    ".cover{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:40px 20px;page-break-after:always;background:linear-gradient(180deg,#0B0D13 0%,#0B0D13 100%);color:#fff;}" +
    ".cover-logo-img{height:88px;width:auto;margin-bottom:14px;}" +
    ".header-logo-img{height:22px;width:auto;vertical-align:middle;}" +
    ".cover-sub{font-family:'Inter',sans-serif;font-size:11px;letter-spacing:4px;text-transform:uppercase;color:#9AA5B1;margin-bottom:64px;}" +
    ".cover-title{font-family:'Inter Tight',sans-serif;font-weight:800;font-size:32px;letter-spacing:-0.5px;margin-bottom:10px;}" +
    ".cover-project{font-size:16px;color:#C7D0DA;margin-bottom:48px;}" +
    ".cover-meta{display:grid;grid-template-columns:repeat(2,auto);gap:10px 40px;font-size:12.5px;color:#C7D0DA;text-align:left;border-top:1px solid rgba(255,255,255,0.15);padding-top:24px;}" +
    ".cover-meta b{color:#fff;font-weight:600;}" +
    ".cover-risk{margin-top:40px;padding:8px 22px;border-radius:999px;font-family:'Inter',sans-serif;font-weight:700;font-size:13px;letter-spacing:1px;}" +
    /* --- Repeating branded header (screen + print) --- */
    ".report-header{display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:2px solid var(--ims-teal);margin-bottom:18px;}" +
    ".report-header-brand{display:flex;align-items:center;gap:9px;font-family:'Inter Tight',sans-serif;font-weight:800;font-size:14px;color:var(--ims-ink);}" +
    ".report-header-brand span{color:var(--ims-teal);}" +
    ".report-header-meta{font-size:10.5px;color:var(--ims-dim);text-align:right;}" +
    /* --- Body content wrapper --- */
    ".report-content{max-width:880px;margin:0 auto;padding:0 20px 40px;}" +
    "h1.report-title{font-family:'Inter Tight',sans-serif;font-weight:800;font-size:22px;letter-spacing:-0.4px;margin:8px 0 4px;}" +
    /* Print-specific rules placed LAST so they aren't overridden by the
       general .report-content rule above in the cascade -- this ordering
       bug previously caused the print margin-top to compute as 0px,
       which is why the fixed header was overlapping page content. */
    "@media print{" +
    "  body{margin:0;}" +
    "}" +
    /* --- Panels / sections --- */
    ".panel{border:1px solid var(--ims-line);border-radius:10px;padding:22px 26px;margin-bottom:22px;background:#fff;}" +
    "table{break-inside:avoid;page-break-inside:avoid;} img,canvas,.figure-wrap{break-inside:avoid;page-break-inside:avoid;max-width:100%;}" +
    ".dash-grid{break-inside:avoid;page-break-inside:avoid;}" +
    "h1,h2,.panel-title,.figure-caption{break-after:avoid;page-break-after:avoid;}" +
    ".panel-title{font-family:'Inter',sans-serif;font-weight:700;font-size:10.5px;text-transform:uppercase;letter-spacing:0.06em;color:var(--ims-dim);margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid var(--ims-line);}" +
    ".exec-summary{background:var(--ims-panel);border-color:var(--ims-line);}" +
    ".exec-findings{margin:12px 0 0;padding-left:18px;font-size:12.5px;line-height:1.7;}" +
    ".exec-findings li{margin-bottom:4px;}" +
    ".key-findings-box{display:flex;flex-direction:column;gap:6px;background:var(--ims-panel);border:1px solid var(--ims-line);border-radius:8px;padding:12px 16px;margin-bottom:12px;}" +
    ".key-finding-item{font-family:monospace;font-size:12.5px;color:var(--ims-ink);}" +
    /* --- Dashboard cards --- */
    ".dash-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:4px;}" +
    ".dash-card{background:#fff;border:1px solid var(--ims-line);border-radius:8px;padding:12px 14px;}" +
    ".dash-lbl{font-size:9.5px;text-transform:uppercase;letter-spacing:0.05em;color:var(--ims-dim);margin-bottom:6px;}" +
    ".dash-val{font-family:'Inter Tight',sans-serif;font-weight:800;font-size:22px;color:var(--ims-ink);}" +
    ".dash-good{color:#0A8A5C;} .dash-bad{color:#C0392B;}" +
    ".law-box{background:var(--ims-panel);border-radius:8px;padding:12px;font-family:monospace;white-space:pre-wrap;word-break:break-all;}" +
    /* --- Tables --- */
    "table{border-collapse:collapse;width:100%;margin-bottom:4px;}" +
    "td,th{padding:6px 9px;border-bottom:1px solid var(--ims-line);font-size:12.5px;font-variant-numeric:tabular-nums;}" +
    "th{font-family:'Inter',sans-serif;font-weight:600;text-transform:uppercase;font-size:9.5px;letter-spacing:0.04em;color:var(--ims-dim);text-align:left;background:var(--ims-panel);}" +
    "tr:nth-child(even) td{background:#FBFCFD;}" +
    /* --- Risk badges --- */
    ".risk-badge{font-family:'Inter',sans-serif;font-weight:700;padding:3px 11px;border-radius:999px;font-size:11px;letter-spacing:0.02em;}" +
    ".risk-LOW{background:#E3F9EF;color:#0A8A5C;} .risk-MEDIUM{background:#FFF4E0;color:#A15C00;} .risk-HIGH{background:#FDE8E8;color:#C0392B;}" +
    ".stability-badge-stable{background:#E3F9EF;color:#0A8A5C;} .stability-badge-unstable{background:#FDE8E8;color:#C0392B;}" +
    /* --- Footer --- */
    ".report-footer{display:flex;align-items:center;justify-content:space-between;padding:10px 0;margin-top:20px;border-top:1px solid var(--ims-line);font-size:9.5px;color:var(--ims-dim);}" +
    "</style></head><body>" +
    /* Cover page */
    "<div class='cover'>" +
    "<img src='" + IMS_LOGO_B64 + "' alt='IMS' class='cover-logo-img'>" +
    "<div class='cover-sub'>Intrinsic Manifold Stability Platform</div>" +
    "<div class='cover-title'>Recoverability Analysis Report</div>" +
    "<div class='cover-project'>" + p.label + "</div>" +
    "<div class='cover-meta'>" +
    "<div>Project</div><div><b>" + p.label + "</b></div>" +
    "<div>Analysis Type</div><div><b>IMS / Recoverability Assessment</b></div>" +
    "<div>Date &amp; Time</div><div><b>" + dateStr + ", " + timeStr + "</b></div>" +
    "<div>Platform Version</div><div><b>v4.5 (Real Backend)</b></div>" +
    "<div>Engine Version</div><div><b>ims_platform core v1.0</b></div>" +
    "<div>Report ID</div><div><b>IMS-" + p.id.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 10) + "-" + now.getTime().toString(36).toUpperCase() + "</b></div>" +
    "<div>Equilibrium Stability</div><div><b>" + (eq ? (eq.stable ? "STABLE" : "UNSTABLE") : "\u2014") + "</b></div>" +
    "<div>Risk Classification</div><div><b>" + riskLevel + "</b></div>" +
    "</div>" +
    (riskLevel !== "\u2014" ? "<div class='cover-risk risk-" + riskLevel + "'>" + riskLevel + " RISK</div>" : "") +
    "<div style='margin-top:36px;font-size:10px;letter-spacing:0.05em;color:#7A8590;'>GENERATED BY IMS PLATFORM</div>" +
    "</div>" +
    /* Repeating header */
    "<div class='report-header'>" +
    "<div class='report-header-brand'><img src='" + IMS_LOGO_B64 + "' alt='IMS' class='header-logo-img'><span>IMS</span> Platform Explorer &mdash; Recoverability Analysis Report</div>" +
    "<div class='report-header-meta'>" + p.label + " &nbsp;|&nbsp; " + dateStr + "</div>" +
    "</div>" +
    "<div class='report-content'>" +
    "<h1 class='report-title'>" + p.label + "</h1>" +
    body +
    "</div>" +
    "<div class='report-footer'>" +
    "<div style='display:flex;align-items:center;gap:8px;'><img src='" + IMS_LOGO_B64 + "' alt='IMS' style='height:13px;width:auto;'>Generated by IMS Platform Explorer &mdash; Version 4.5 &mdash; " + dateStr + ", " + timeStr + "</div>" +
    "<div>&copy; IMS Platform &mdash; Intrinsic Manifold Stability</div>" +
    "</div>" +
    "</body></html>";
  return doc;
}

function downloadHtmlReport() {
  var doc = buildFullReportDocument();
  var blob = new Blob([doc], { type: "text/html" });
  var url = URL.createObjectURL(blob);
  var a = document.createElement("a"); a.href = url; a.download = "ims_report_" + currentProject.id + ".html";
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function printReportPdf() {
  // Print the same verified, print-fitted standalone report template used
  // for HTML export -- not the live app page itself, which is laid out
  // for a wide screen (sidebar, wide tables) and was never built to fit a
  // printable page width. Opening it in a new window and printing that
  // window reuses the one already-tested-correct template rather than
  // maintaining a second, different print stylesheet for the live app.
  var doc = buildFullReportDocument();
  var win = window.open("", "_blank");
  if (!win) { alert("Please allow pop-ups for this site to export the PDF."); return; }
  win.document.open();
  win.document.write(doc);
  win.document.close();
  var printed = false;
  var doPrint = function () { if (printed || win.closed) return; printed = true; win.focus(); win.print(); };
  win.onload = doPrint;
  // Fallback in case onload doesn't fire reliably for a document.write()
  // target in some browsers -- print once the document is clearly ready.
  setTimeout(doPrint, 700);
}
