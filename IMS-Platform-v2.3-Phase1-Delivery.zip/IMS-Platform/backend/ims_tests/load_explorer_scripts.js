/* Read the real production scripts in the exact order declared by explorer.html. */
const fs = require("fs");
const path = require("path");
module.exports = function loadExplorerScripts() {
  const staticDir = path.join(__dirname, "..", "ims_platform", "server", "static");
  const html = fs.readFileSync(path.join(staticDir, "explorer.html"), "utf8");
  const scripts = [...html.matchAll(/<script\s+src="(\/assets\/js\/[^"]+)"\s+defer><\/script>/g)].map(m => m[1]);
  if (!scripts.length) throw new Error("No production Explorer scripts found");
  return scripts.map(src => fs.readFileSync(path.join(staticDir, src.slice(1)), "utf8")).join("\n;\n");
};
