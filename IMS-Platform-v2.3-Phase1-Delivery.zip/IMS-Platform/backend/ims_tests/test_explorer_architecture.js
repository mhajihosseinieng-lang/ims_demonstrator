/* Browser-neutral checks of shipped interface architecture and SVG scientific clarity. */
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const staticRoot = path.join(__dirname, '..', 'ims_platform', 'server', 'static');
const html = fs.readFileSync(path.join(staticRoot, 'explorer.html'), 'utf8');
const css = fs.readFileSync(path.join(staticRoot, 'assets/css/explorer.css'), 'utf8');
const script = require('./load_explorer_scripts')();
const scripts = [...html.matchAll(/<script src="(\/assets\/js\/[^\"]+)" defer><\/script>/g)].map(x=>x[1]);
assert.deepStrictEqual(scripts, [
 '/assets/js/core.js', '/assets/js/views.js', '/assets/js/workspace.js',
 '/assets/js/results.js', '/assets/js/services.js'
]);
for (const src of scripts) assert(fs.existsSync(path.join(staticRoot, src.slice(1))));
assert(/rel="stylesheet" href="\/assets\/css\/explorer.css"/.test(html));
assert(/@media\(max-width:560px\)/.test(css));
assert(!html.includes('>Soon</span>'), 'Unimplemented nav items should not be presented');
assert(/id="heroTrajectoryPathWide"/.test(html));
assert(/id="heroTrajectoryPathWide"/.test(html), 'Animated trajectory must exist');
assert(/id="heroManifoldPathWide"/.test(html), 'Manifold must exist');
assert(/NOT SIMULATION DATA/.test(html), 'Hero must disclose schematic nature');
assert(!html.includes('class="qa-row"'), 'No duplicate hero quick actions');
const trajectory = html.match(/id="heroTrajectoryPathWide"[^>]*d="([^"]+)"/);
assert(trajectory, 'Hero trajectory must have SVG path data');
const values = [...trajectory[1].matchAll(/-?\d+(?:\.\d+)?/g)].map(x=>Number(x[0]));
assert(values.length === 20, 'Trajectory should have a move and three cubic Bezier segments');
assert(values.every(Number.isFinite), 'Trajectory coordinates must be finite');
assert.deepStrictEqual(values.slice(-2), [962,198], 'Trajectory must end at marked equilibrium');
assert(/<mpath href="#heroTrajectoryPathWide"/.test(html), 'Animation must follow actual trajectory');
assert(/class="hero-disturbance-marker"/.test(html));
assert(/class="hero-equilibrium-marker"/.test(html));
const stageBlock = script.split('var STAGES = [')[1].split('];')[0];
const stages = [...stageBlock.matchAll(/\{ key: "([a-z_]+)", label:/g)].map(m=>m[1]);
assert.deepStrictEqual(stages, ['build','equilibrium','simulate','ims_analysis','design_mrc','report']);
assert(/function activateSurface/.test(script), 'One central view switcher');
assert(/function invalidateDownstreamResults/.test(script), 'Upstream re-runs must invalidate stale downstream results');
console.log('PASS architecture assets, clean navigation, 6-stage order, animated recovery path, exact endpoint marker');
