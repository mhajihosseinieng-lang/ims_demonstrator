"""Shared Mongo handle — import `client`/`db` from here (server.py, routers, seed.py)."""

import logging
import os
from pathlib import Path

from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING, DESCENDING, IndexModel

load_dotenv(Path(__file__).parent.parent / ".env")

mongo_url = os.environ["MONGO_URL"]
# MongoDB is NOT required by any IMS/MRC functionality (ims_platform/,
# routers/four_state.py, routers/analysis.py, routers/mrc_designer.py never
# touch `db`) -- only the unrelated legacy `/api/status` demo endpoint does.
# serverSelectionTimeoutMS is set low so that a clean launch with no MongoDB
# running fails FAST (milliseconds, not the driver's 30s default) instead of
# hanging or spamming repeated retry noise into the logs.
client = AsyncIOMotorClient(mongo_url, serverSelectionTimeoutMS=1500)
db = client[os.environ["DB_NAME"]]

logger = logging.getLogger(__name__)

# One entry per collection: every field a route filters, sorts, or dedupes on. Applied by ensure_indexes() at startup.
INDEXES: dict[str, list[IndexModel]] = {
    "status_checks": [IndexModel([("timestamp", DESCENDING)], name="timestamp_desc")],
}


async def ensure_indexes() -> None:
    """Best-effort index setup for the legacy /api/status demo endpoint.

    Never blocks or fails application boot: this is scheduled as a
    fire-and-forget background task by server.py's lifespan, and a clean
    launch with no MongoDB configured is a fully supported, expected case
    for the IMS/MRC workflow (Explorer, Network Builder, MRC design, M1/M2
    reshaping, closed-loop verification, and report/PDF generation never
    touch the database). A single INFO-level line reports the skip instead
    of an alarming per-index ERROR/connection-refused traceback.
    """
    try:
        await client.admin.command("ping")
    except Exception as exc:
        logger.info(
            "MongoDB not reachable at %s (%s) -- skipping status_checks indexing. "
            "This is expected and harmless: no IMS/MRC route requires a database.",
            mongo_url, exc.__class__.__name__,
        )
        return
    for collection, models in INDEXES.items():
        for model in models:  # one at a time so a bad spec skips only itself
            try:
                await db[collection].create_indexes([model])
            except Exception as exc:  # never block boot on an index; the log line names what to fix
                logger.error("ensure_indexes(%s.%s): %s", collection, model.document["name"], exc)
