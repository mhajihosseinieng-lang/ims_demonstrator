# IMS Platform architecture · UI refactor

## Entry points

- `/explorer.html` is the primary UI, served by the existing Flask application mounted in FastAPI. It now contains semantic application markup, rather than embedding the entire frontend implementation.
- `/assets/css/explorer.css` holds the design system, components, and responsive layout.
- `/assets/js/core.js` owns UI state, safe plotting primitives, history and shared helpers.
- `/assets/js/views.js` handles projects, Analysis Hub, case navigation and Network Builder.
- `/assets/js/workspace.js` handles the workspace pipeline, payload submission and MRC design.
- `/assets/js/results.js` renders charts, analysis results and the report workflow.
- `/assets/js/services.js` handles documentation, authentication, health status and app boot.
- `frontend/` remains the React/Vite codebase for the specialised `/mrc` and `/mrc-designer` surfaces.
- `backend/ims_platform/` contains the scientific models, numerical analysis, MRC synthesis, simulation and report engine. **No numerical solver/control backend was modified in this interface refactor.**

Scripts are intentionally **ordered classic scripts**, not ES modules: existing inline event handlers and tests rely on global function names. The files share the public legacy state contract but isolate concerns so future migration to module imports can be incremental. Do not reorder the script tags without retesting.

## Scientific workflow (source of truth: `STAGES` in `workspace.js`)

1. Build model (network topology and parameters).
2. Solve equilibrium (nominal operating point).
3. Baseline simulation (open-loop/pre-control dynamics).
4. IMS analysis (manifold/residual, stability and recoverability).
5. MRC synthesis and verification (**optional**; feasibility is model dependent).
6. Report review and export (available after IMS even if MRC synthesis is unsupported).

The landing strip reflects the actual execution order. Completed stages remain visible until the user advances; the `report` stage is not gated on optional MRC. Changes to a completed stage’s input form also invalidate that stage and its downstream dependents, avoiding mixed-parameter reports.

## Schematic versus scientific data

The SVG in the landing hero is a **conceptual** manifold, with a single smooth C1 cubic Bézier trajectory sampled from a continuously differentiable exponentially contracting offset to the manifold. The terminal state lies on the illustrative manifold. It does **not** represent solver output. Quantitative time-series graphics elsewhere in the platform continue to render actual solver samples; they are not visually smoothed, because that could obscure overshoot, discontinuities or instabilities.

## Testing

`node backend/ims_tests/test_explorer_stage_navigation.js` and other JS tests use `backend/ims_tests/load_explorer_scripts.js` to load the actual ordered scripts. `backend/ims_tests/test_explorer_architecture.js` checks the navigation hierarchy, real asset paths, SVG geometric continuity and stage order. Run backend pytest suite where runtime dependencies are available; see README.
