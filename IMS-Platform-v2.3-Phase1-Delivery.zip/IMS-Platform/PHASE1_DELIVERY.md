# IMS Platform — Phase 1 navigation and Hero alignment

## Implemented
- Six-stage Hero workflow in scientific order: Model → Equilibrium → Baseline Simulation → IMS/ROA → Optional MRC → Report.
- Reworded Hero to distinguish IMS analysis from optional controller synthesis and avoid a blanket validated-engine claim.
- Navigation renamed for clearer roles: Model Builder, IMS Analysis, Controller Design · MRC.
- Preserved Case Library as scenario entry and Projects as workspace entry; did not delete existing examples or scientific engines.
- Preserved animated conceptual manifold visual and its conceptual-data disclaimer.
- Retained previous Emergent frontend branding cleanup.

## Remaining before Phase 1 acceptance
- Deduplicate the underlying example registry across home cards, Case Library, and Analysis Hub using canonical IDs (not by deleting working routes).
- Review all workspace screens for responsive layout and accessibility in an actual browser.
- Run full backend and frontend suites, API smoke tests, and end-to-end model→report flow.
- Choose independent hosting to remove Emergent from the actual URL: source changes alone cannot change a hosting-provider hostname.

## Scientific guardrails from the uploaded IMS/MRC monograph
- IMS is controller-independent; MRC is downstream and optional.
- Transverse contraction is not full-state stability; check reduced/tangential dynamics separately.
- Recoverability/ROA maps are numerical estimates or sections unless rigorously certified.
- Do not promote a candidate manifold to verified IMS without all required checks.

This package is an incremental interface patch, not a completed four-phase release.
