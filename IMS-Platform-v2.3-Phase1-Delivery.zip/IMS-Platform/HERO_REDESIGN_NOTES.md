# IMS Platform — engineering interface refresh

The platform now has a smooth C1 recovery schematic with a geometrically consistent endpoint on the depicted manifold. Its labels explicitly identify it as **conceptual artwork, not a simulation result**. Scientific charts remain faithful to solver samples (and handle non-finite values safely).

The project landing page is full-width and ordered as: **Hero → Recent Projects (if any) → Example Projects**. The hero no longer repeats a second set of quick actions. All sidebar entries are functional, and the active view is managed centrally. There is a six-stage pipeline matching the actual workspace logic, including baseline simulation and optional MRC design/verification. Backend online/offline status comes from `/api/health`.

Source files and module responsibilities are documented in `ARCHITECTURE.md`. The Python solver, model equations, synthesis and backend HTTP API are preserved.

## Test coverage

- JS regression tests `backend/ims_tests/test_explorer_*.js`, `test_gfi_report_content.js` and `test_project_builder_ui.js` run against shipped ordered assets.
- Browser interaction checks confirmed navigation and stage behaviour at 1600px, 390px and 320px.
- Trajectory path continuity and endpoint marker are checked by `backend/ims_tests/test_explorer_architecture.js`.
- Full Python test suite was **not** run in the editing environment because required runtime dependencies are missing. Run it after installing `backend/requirements.txt`.
