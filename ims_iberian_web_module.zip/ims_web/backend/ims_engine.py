"""
IMS engine -- web-app wrapper around the validated Increment 5A-8C physics.

This module makes exactly ONE generalization to the frozen equations:
K_PV's "on" value (previously hardcoded at 5.0) becomes a genuine
parameter, K_PV_nominal, so the "dynamic voltage support" slider in the
UI is backed by real computation across its whole range, not a toggle
between two frozen cases. This is a direct, physically meaningful
extension of Increment 4a's own droop-gain parameter -- not a new
mechanism, not a new equation.

Everything else (the algebraic network equations, the two protection
latches and their thresholds, the staged-disturbance operator and its
validated escalation ratios, the fold locations) is reused verbatim from
the frozen chain. Where the UI asks for something the frozen chain does
NOT support (current limiting, GFM penetration, an automated
intervention optimizer), this engine does not fake it -- see
NOT_IMPLEMENTED in api.py.
"""
import numpy as np
from layerA_equilibria_7i import full_g_param
from layerA_equilibria import Xc, Enom, nQ, Qset

tau_I, tau_Q = 0.002, 0.03
V_TRIP = 1.10          # Bus4 Volt-VAR overvoltage protection threshold (frozen, 5A)
V3_TRIP = 1.05          # Bus3 shunt-reactor overvoltage protection threshold (frozen, 7H)
V_BASELINE = [0.961317, 0.985606, 0.882601, 0.977715]
IQ2_BASELINE = 0.100177
E2_BASELINE = 1.000632
FOLD_IQ2_MODE11 = -0.201347   # independently verified Mode(1,1) algebraic fold (7L-1)

# Validated escalation ratios from the ENTSO-E 355 -> 727 -> 928 MW sequence
# (ratios only -- no MW-to-pu unit correspondence is claimed; see docs/methodology.md)
ESCALATION_RATIO_2 = 727.0 / 355.0   # ~2.0479
ESCALATION_RATIO_3 = 928.0 / 727.0   # ~1.2764


def solve_V(iq2, K_PV, Bsh3, V_guess, tol=1e-13, max_iter=40):
    """Newton solve of the algebraic network, given the current protection mode."""
    V = np.array(V_guess, dtype=float)
    for _ in range(max_iter):
        g = full_g_param(V[0], V[1], V[2], V[3], iq2, K_PV, Bsh3)
        if np.max(np.abs(g)) < tol:
            return V, True
        h = 1e-7
        J = np.zeros((4, 4))
        for j in range(4):
            Vp = V.copy(); Vp[j] += h
            Vm = V.copy(); Vm[j] -= h
            J[:, j] = (full_g_param(*Vp, iq2, K_PV, Bsh3) - full_g_param(*Vm, iq2, K_PV, Bsh3)) / (2 * h)
        try:
            dV = np.linalg.solve(J, -g)
        except np.linalg.LinAlgError:
            return V, False
        if np.any(V + dV <= 0):
            return V, False
        V = V + dV
    return V, False


def solve_V_continuation(iq2_target, K_PV, Bsh3, V_guess, iq2_seed=None, n_steps=20):
    """
    Fallback for large jumps in i_q2 (e.g. a disturbance applied from a
    warm-start far from the target): steps i_q2 gradually from iq2_seed
    to iq2_target, re-solving V at each intermediate point. This is a
    standard continuation/homotopy approach -- it changes no physics,
    only how the Newton solve is warm-started, matching the same
    escalating-fallback philosophy used throughout the validated Layer B
    tracker (local Newton -> wider search -> continuation).
    """
    if iq2_seed is None:
        iq2_seed = iq2_target
    V, ok = solve_V(iq2_target, K_PV, Bsh3, V_guess)
    if ok:
        return V, True
    V_cur = np.array(V_guess, dtype=float)
    for frac in np.linspace(0, 1, n_steps + 1)[1:]:
        iq2_step = iq2_seed + frac * (iq2_target - iq2_seed)
        V_cur, ok = solve_V(iq2_step, K_PV, Bsh3, V_cur)
        if not ok:
            return V_cur, False
    return V_cur, True


def local_eigenvalues(iq2, E2, V, K_PV, Bsh3):
    """
    The 'conventional small-signal' comparison quantity: eigenvalues of
    the full 2x2 (i_q2,E2) Jacobian at the CURRENT state (not necessarily
    an equilibrium -- this is the standard local-stability check a
    conventional tool would report at the current operating point).
    """
    Xg1, X12, X13, X24 = 0.4, 0.4, 0.5, 0.2
    Vgrid = 1.0
    Bsh4 = 0.0
    V1, V2, V3, V4 = V
    Jg = np.array([
        [(2*V1-Vgrid)/Xg1 + (2*V1-V2)/X12 + (2*V1-V3)/X13, -V1/X12, -V1/X13, 0.0],
        [V2/X12, iq2-(2*V2-V1)/X12-(2*V2-V4)/X24, 0.0, V2/X24],
        [V3/X13, 0.0, 2*Bsh3*V3-(2*V3-V1)/X13, 0.0],
        [0.0, V4/X24, 0.0, 2*Bsh4*V4-(2*V4-V2)/X24-K_PV],
    ])
    dg_diq2 = np.array([0.0, V2, 0.0, 0.0])
    try:
        dV_diq2 = -np.linalg.solve(Jg, dg_diq2)
    except np.linalg.LinAlgError:
        return None
    dFf_diq2 = -(1.0 / Xc) * dV_diq2[1] - 1.0
    dFf_dE2 = 1.0 / Xc
    dFs_diq2 = -nQ * (dV_diq2[1] * iq2 + V2)
    dFs_dE2 = -1.0
    A = np.array([[dFf_diq2/tau_I, dFf_dE2/tau_I],
                  [dFs_diq2/tau_Q, dFs_dE2/tau_Q]])
    eigs = np.linalg.eigvals(A)
    return eigs


def run_scenario(diq2=0.0, E2_stage_times=None, E2_stage_deltas=None,
                  K_PV_nominal=5.0, t_max=0.35, dt=5e-6, sample_every=100):
    """
    Run the full hybrid cascade: baseline equilibrium -> disturbance
    (staged if E2_stage_times/deltas given) -> possible Bus4 trip ->
    possible Bus3 trip -> relaxation.

    Returns a dict with the full sampled trajectory, protection event
    log, peak voltages, and final-state recoverability quantities.
    Genuine algebraic collapse (the trajectory has no feasible operating
    point -- a real physical outcome, not a numerical error) is reported
    as status='collapsed', with whatever partial trajectory was traced
    before collapse included -- never silently dropped.
    """
    if E2_stage_times is None:
        E2_stage_times = []
        E2_stage_deltas = []
    schedule = sorted(zip(E2_stage_times, E2_stage_deltas), key=lambda x: x[0])
    sched_idx = 0

    iq0 = IQ2_BASELINE + diq2
    E0 = E2_BASELINE
    s_PV, s_sh3 = 0, 0
    K_PV = K_PV_nominal
    Bsh3 = -0.05

    y = np.array([iq0, E0], dtype=float)
    V_seed, ok_seed = solve_V(IQ2_BASELINE, K_PV, Bsh3, V_BASELINE)
    V_ref = [V_seed if ok_seed else np.array(V_BASELINE)]
    events = []
    trace = []
    peak_V = np.array([0.0, 0.0, 0.0, 0.0])

    def check_protection(t):
        nonlocal s_PV, s_sh3, K_PV, Bsh3
        T_PV = (s_PV == 0) and (V_ref[0][3] >= V_TRIP)
        T_sh3 = (s_sh3 == 0) and (V_ref[0][2] >= V3_TRIP)
        if not (T_PV or T_sh3):
            return
        s_PV_new = 1 if T_PV else s_PV
        s_sh3_new = 1 if T_sh3 else s_sh3
        K_PV_new = 0.0 if s_PV_new == 1 else K_PV_nominal
        Bsh3_new = 0.0 if s_sh3_new == 1 else -0.05
        Vp, ok = solve_V_continuation(y[0], K_PV_new, Bsh3_new, V_ref[0], iq2_seed=y[0])
        if not ok:
            return
        s_PV, s_sh3, K_PV, Bsh3 = s_PV_new, s_sh3_new, K_PV_new, Bsh3_new
        V_ref[0] = Vp
        events.append(dict(t=t, bus4_trip=bool(T_PV), bus3_trip=bool(T_sh3),
                            mode=[s_PV, s_sh3]))

    def apply_disturbance(dE2, t):
        iq2_before = y[0]
        y[1] = y[1] + dE2
        Vp, ok = solve_V_continuation(y[0], K_PV, Bsh3, V_ref[0], iq2_seed=iq2_before)
        if not ok:
            return False
        V_ref[0] = Vp
        events.append(dict(t=t, disturbance_dE2=dE2, iq2=float(y[0]), E2=float(y[1])))
        return True

    def rhs(y, iq2_prev):
        V, ok = solve_V_continuation(y[0], K_PV, Bsh3, V_ref[0], iq2_seed=iq2_prev)
        if not ok:
            return None
        V_ref[0] = V
        f1 = ((y[1] - V[1]) / Xc - y[0]) / tau_I
        f2 = (-y[1] + Enom - nQ * (V[1] * y[0] - Qset)) / tau_Q
        return np.array([f1, f2])

    def finalize(status):
        fold_distance = float(y[0] - FOLD_IQ2_MODE11) if s_sh3 == 1 else None
        eigs = local_eigenvalues(y[0], y[1], V_ref[0], K_PV, Bsh3) if status != 'collapsed' else None
        return dict(
            status=status,
            events=events,
            trace=trace,
            peak_V=peak_V.tolist(),
            final_state=dict(iq2=float(y[0]), E2=float(y[1]), V=V_ref[0].tolist(),
                              mode=[s_PV, s_sh3]),
            fold_distance_mode11=fold_distance,
            local_eigenvalues=[complex(e).real for e in eigs] if eigs is not None else None,
            tripped_bus4=bool(s_PV == 1),
            tripped_bus3=bool(s_sh3 == 1),
        )

    V0, ok0 = solve_V_continuation(y[0], K_PV, Bsh3, V_ref[0], iq2_seed=IQ2_BASELINE)
    if not ok0:
        # Genuine collapse at the very first disturbance application --
        # record it as such, with the pre-disturbance baseline in the trace.
        seed_V = list(V_seed if ok_seed else V_BASELINE)
        trace.append(dict(t=0.0, iq2=IQ2_BASELINE, E2=E2_BASELINE,
                           V=seed_V, mode=[0, 0]))
        peak_V = np.array(seed_V)
        y[0] = iq0  # reflect the attempted (infeasible) target for reporting
        return finalize('collapsed')
    V_ref[0] = V0
    peak_V = np.maximum(peak_V, V0)
    check_protection(0.0)
    while sched_idx < len(schedule) and schedule[sched_idx][0] <= 0.0:
        apply_disturbance(schedule[sched_idx][1], 0.0)
        sched_idx += 1
        check_protection(0.0)
    trace.append(dict(t=0.0, iq2=float(y[0]), E2=float(y[1]), V=V_ref[0].tolist(),
                       mode=[s_PV, s_sh3]))

    n_steps = int(t_max / dt)
    status = 'completed'
    iq2_prev = y[0]
    for step in range(n_steps):
        k1 = rhs(y, iq2_prev)
        if k1 is None:
            status = 'collapsed'; break
        k2 = rhs(y + dt/2*k1, iq2_prev)
        if k2 is None:
            status = 'collapsed'; break
        k3 = rhs(y + dt/2*k2, iq2_prev)
        if k3 is None:
            status = 'collapsed'; break
        k4 = rhs(y + dt*k3, iq2_prev)
        if k4 is None:
            status = 'collapsed'; break
        y = y + (dt/6) * (k1 + 2*k2 + 2*k3 + k4)
        t = (step + 1) * dt

        V_chk, ok_chk = solve_V_continuation(y[0], K_PV, Bsh3, V_ref[0], iq2_seed=iq2_prev)
        if not ok_chk:
            status = 'collapsed'; break
        V_ref[0] = V_chk
        iq2_prev = y[0]
        peak_V = np.maximum(peak_V, V_ref[0])

        while sched_idx < len(schedule) and schedule[sched_idx][0] <= t:
            if not apply_disturbance(schedule[sched_idx][1], t):
                status = 'collapsed'; break
            sched_idx += 1
            check_protection(t)
        if status != 'completed':
            break

        check_protection(t)

        if step % sample_every == 0:
            trace.append(dict(t=t, iq2=float(y[0]), E2=float(y[1]),
                               V=V_ref[0].tolist(), mode=[s_PV, s_sh3]))

    trace.append(dict(t=(step+1)*dt if status != 'completed' else n_steps*dt,
                       iq2=float(y[0]), E2=float(y[1]),
                       V=V_ref[0].tolist(), mode=[s_PV, s_sh3]))

    return finalize(status)


def iberian_staged_schedule(severity_scale=1.0, timing_ms=(5, 10)):
    """
    The validated three-stage disturbance protocol (Increment 8), scaled
    by a single severity factor and using the ENTSO-E escalation RATIOS
    (not MW magnitudes -- see docs/methodology.md for why).
    """
    dE2_1 = 0.499368 * severity_scale
    dE2_2 = dE2_1 * ESCALATION_RATIO_2
    dE2_3 = dE2_2 * ESCALATION_RATIO_3
    t1, t2 = timing_ms[0] / 1000.0, timing_ms[1] / 1000.0
    return [0.0, t1, t2], [dE2_1, dE2_2, dE2_3]
