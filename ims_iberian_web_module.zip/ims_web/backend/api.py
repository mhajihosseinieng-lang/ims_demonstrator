"""
IMS Platform -- Iberian 2025 Inspired Overvoltage Cascade module.
Flask backend. Every numeric result returned by these endpoints comes
from the validated ims_engine.py (frozen Increment 5A-8C physics, with
K_PV_nominal generalized as described in ims_engine.py's own docstring).

Endpoints that would require model capability the frozen chain does not
have (current limiting, GFM penetration, an automated intervention
sweep) are listed under NOT_IMPLEMENTED and return a clear 501 response
rather than fabricated numbers.
"""
from flask import Flask, jsonify, request, send_from_directory
import os
import numpy as np

import ims_engine as eng

app = Flask(__name__, static_folder=None)

FRONTEND_DIR = os.path.join(os.path.dirname(__file__), '..', 'frontend')

NOT_IMPLEMENTED = {
    'current_limiting': (
        "Converter current limiting (Imax) was tested as a candidate second "
        "protection mechanism (Increment 7A-7E) and found NOT to provide "
        "causal cascade evidence in the pre-registered survey -- see "
        "docs/methodology.md. It is not wired to a UI control because doing "
        "so would misrepresent a tested-and-rejected mechanism as a live one."
    ),
    'gfm_penetration': (
        "GFM penetration (rho_GFM) requires a multi-converter network "
        "topology the frozen model does not have (a single aggregated GFL "
        "converter at Bus2). This is listed in the platform roadmap as a "
        "structural model extension, not a parameter sweep of the existing "
        "model."
    ),
    'renewable_output_axis': (
        "The frozen model has no renewable-output-share state or parameter. "
        "The validated 2D boundary map (severity vs. converter timescale, "
        "Increment 7M/7N) is offered instead -- see /api/recoverability_map."
    ),
    'auto_intervention_sweep': (
        "An automated K_PV/Imax/Qshunt/rho_GFM sweep that recommends "
        "specific interventions was scoped in the original proposal audit "
        "and explicitly identified as not yet built. The manual dynamic-Q "
        "comparison (/api/compare) demonstrates the same underlying "
        "capability for the one parameter (K_PV) that is validated."
    ),
}


def jsonable(r):
    """Recursively convert numpy types to plain Python for JSON serialization."""
    if isinstance(r, dict):
        return {k: jsonable(v) for k, v in r.items()}
    if isinstance(r, (list, tuple)):
        return [jsonable(v) for v in r]
    if isinstance(r, (np.floating, np.integer)):
        return r.item()
    if isinstance(r, np.ndarray):
        return r.tolist()
    return r


@app.route('/')
def index():
    return send_from_directory(FRONTEND_DIR, 'index.html')


@app.route('/<path:path>')
def static_files(path):
    return send_from_directory(FRONTEND_DIR, path)


@app.route('/api/run_scenario', methods=['POST'])
def api_run_scenario():
    """
    Body: { diq2, severity_scale, timing_ms: [t1,t2], K_PV_nominal }
    Runs the staged Iberian-inspired disturbance protocol and returns the
    full trajectory, protection events, peak voltages, and recoverability
    quantities.
    """
    body = request.get_json(force=True) or {}
    diq2 = float(body.get('diq2', -1.0))
    severity_scale = float(body.get('severity_scale', 1.0))
    timing_ms = tuple(body.get('timing_ms', [5, 10]))
    K_PV_nominal = float(body.get('K_PV_nominal', 5.0))

    times, deltas = eng.iberian_staged_schedule(severity_scale, timing_ms)
    result = eng.run_scenario(diq2=diq2, E2_stage_times=times, E2_stage_deltas=deltas,
                               K_PV_nominal=K_PV_nominal, t_max=0.15, dt=2e-5, sample_every=60)
    result['schedule'] = dict(stage_times_s=times, stage_deltas=deltas,
                               stage_times_labels=['t=0 (355 MW-equivalent)',
                                                    f't={timing_ms[0]}ms (727 MW-equivalent)',
                                                    f't={timing_ms[1]}ms (928 MW-equivalent)'])
    return jsonify(jsonable(result))


@app.route('/api/compare', methods=['POST'])
def api_compare():
    """
    Body: { diq2, severity_scale, timing_ms, K_PV_a, K_PV_b }
    Runs the SAME disturbance under two different K_PV_nominal values
    (e.g. 0 = fixed-PF baseline, 5 = dynamic Q support) for direct
    side-by-side comparison -- the exact "Scenario A vs B" comparison
    the proposal describes.
    """
    body = request.get_json(force=True) or {}
    diq2 = float(body.get('diq2', -1.0))
    severity_scale = float(body.get('severity_scale', 1.0))
    timing_ms = tuple(body.get('timing_ms', [5, 10]))
    K_PV_a = float(body.get('K_PV_a', 0.0))
    K_PV_b = float(body.get('K_PV_b', 5.0))

    times, deltas = eng.iberian_staged_schedule(severity_scale, timing_ms)
    r_a = eng.run_scenario(diq2=diq2, E2_stage_times=times, E2_stage_deltas=deltas,
                            K_PV_nominal=K_PV_a, t_max=0.15, dt=2e-5, sample_every=60)
    r_b = eng.run_scenario(diq2=diq2, E2_stage_times=times, E2_stage_deltas=deltas,
                            K_PV_nominal=K_PV_b, t_max=0.15, dt=2e-5, sample_every=60)
    return jsonify(jsonable(dict(scenario_a=r_a, scenario_b=r_b,
                                  K_PV_a=K_PV_a, K_PV_b=K_PV_b)))


@app.route('/api/recoverability_map', methods=['GET'])
def api_recoverability_map():
    """
    The validated 2D boundary: disturbance severity (E2 stage-1 delta) vs.
    converter current-loop timescale (tau_I), reusing the pre-registered
    50-case grid methodology from Increment 7M/7N. This substitutes for
    the proposal's "renewable output" axis, which the frozen model does
    not have a parameter for (see NOT_IMPLEMENTED['renewable_output_axis']).
    """
    severities = [1.5, 2.0, 2.5, 3.0, 3.5]
    tau_I_values = [0.002, 0.004, 0.006, 0.010]
    grid = []
    for tau_I in tau_I_values:
        eng.tau_I = tau_I
        for E0 in severities:
            r = eng.run_scenario(diq2=-1.0, E2_stage_times=[0.0], E2_stage_deltas=[E0 - eng.E2_BASELINE],
                                  K_PV_nominal=5.0, t_max=0.01, dt=2e-5, sample_every=1000)
            grid.append(dict(tau_I=tau_I, E2_initial=E0, status=r['status'],
                              tripped_bus4=r.get('tripped_bus4'), tripped_bus3=r.get('tripped_bus3')))
    eng.tau_I = 0.002  # restore frozen default
    return jsonify(jsonable(dict(grid=grid, note=(
        "Axes are disturbance severity (converter slow-state displacement) "
        "and converter current-loop timescale, matching the pre-registered "
        "Increment 7M/7N study -- not renewable output share, which this "
        "reduced-order model has no parameter for."
    ))))


@app.route('/api/case_library', methods=['GET'])
def api_case_library():
    return jsonify([
        dict(id='cpl_collapse', name='Converter-CPL Voltage Collapse',
             available=False, note='Roadmap item -- not yet implemented.'),
        dict(id='weak_grid_gfl', name='Weak-Grid GFL Synchronization',
             available=False, note='Roadmap item -- not yet implemented.'),
        dict(id='gfm_current_limit', name='GFM Current-Limit Recovery',
             available=False, note='Roadmap item -- not yet implemented.'),
        dict(id='iberian_2025', name='Iberian 2025 Inspired Overvoltage Cascade',
             available=True, note='Fully validated -- Increments 5A through 8C.'),
        dict(id='multi_converter', name='Multi-Converter Fault Recovery',
             available=False, note='Roadmap item -- not yet implemented.'),
    ])


@app.route('/api/not_implemented/<feature>', methods=['GET', 'POST'])
def api_not_implemented(feature):
    msg = NOT_IMPLEMENTED.get(feature, "This feature is not implemented in the current model.")
    return jsonify(dict(implemented=False, feature=feature, reason=msg)), 501


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5050, debug=False)
