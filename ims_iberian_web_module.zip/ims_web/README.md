# IMS Platform — Iberian 2025 Inspired Overvoltage Cascade Module

A web front-end for the "Iberian 2025 Inspired Overvoltage Cascade"
demonstration described in the funding-presentation proposal, wired to the
validated Increment 1–8C physics engine. Flask backend + single-page
frontend, matching the architecture pattern of the existing IMS Platform
Explorer, built as a standalone module ready to be integrated into it.

## Quick start

```bash
cd backend
pip install flask numpy scipy
python3 api.py
```

Then open **http://localhost:5050** in a browser.

No build step, no npm install — Chart.js is bundled locally in
`frontend/chart.umd.min.js` so the app works even without internet access
to a CDN (fonts still load from Google Fonts if available; the page has a
graceful system-font fallback if not).

## What you'll see

1. **Stress test** — configure dynamic voltage support, disturbance
   severity, and staging speed, then click RUN STRESS TEST. Every result
   is computed live by the validated engine.
2. **Live cascade** — the ENTSO-E event timeline (355→727→928 MW-equivalent)
   animates against the model's real trajectory, with a recoverability
   margin gauge driven by the actual fold-distance computation.
3. **Dynamic Q support comparison** — runs the identical disturbance twice
   (fixed power factor vs. dynamic support) and shows the outcome side by
   side — this is Increment 4a's own validated finding, now interactively
   explorable.
4. **Recoverability map** — the validated severity-vs-timescale boundary
   study (Increments 7M/7N), substituting honestly for the proposal's
   renewable-output axis, which this model has no parameter for.
5. **Conventional vs. IMS** — a local-eigenvalue check next to the
   fold-distance margin, at whatever state your last stress test reached.
6. **Case library** — matches the proposal's exact concept; only the
   Iberian 2025 Inspired case is real, the rest are honestly marked as
   roadmap items, not implemented.
7. **Methodology** — states plainly what is validated and what is not.
   Read `docs/methodology.md` for the full technical version.

## Project structure

```
backend/
  ims_engine.py     the physics engine (validated Increment 5A-8C chain,
                     generalized so K_PV — dynamic Q support — is a real
                     adjustable parameter instead of a fixed toggle)
  api.py            Flask REST API + static file serving
  layerA_*.py, layerB_*.py, sim_*.py, run_8c_full.py
                     frozen model files the engine imports (unmodified)
frontend/
  index.html         single-page app
  app.js             wires the UI to the API — nothing here computes
                      or fabricates results, only fetch() + render
  chart.umd.min.js    bundled Chart.js (no CDN dependency)
docs/
  methodology.md      full technical scope document
```

## Integrating into the existing IMS Platform Explorer

This module is deliberately self-contained (its own Flask app, its own
routes) so it can be mounted as a blueprint or a separate route namespace
inside the existing platform rather than requiring a rewrite. The engine
(`ims_engine.py`) has no dependency on anything Flask-specific — it's a
pure Python module that could be called from any backend. The frontend is
a single HTML/JS/CSS bundle with no build tooling, so it can be dropped
into an existing static-file directory and linked from the platform's own
navigation/case-library UI.

## What this demonstrates vs. what it doesn't

See the in-app Methodology section, or `docs/methodology.md` for the full
version. In short: the causal two-trip cascade, the dynamic-Q-support
effect, and the temporal-staging effect are all genuinely validated and
live-computed here. Converter current limiting and GFM penetration are
visibly marked as not wired — one was tested and rejected, the other
requires a model extension this reduced-order network doesn't have.

## Full traceability record

This module's engine is a thin, web-interactive wrapper around the
complete Increment 1–8C research chain. The full traceability record
(every pre-registered protocol, negative result, and implementation bug
found and fixed along the way) is a separate deliverable — see the
`ims_full_demonstrator_1_to_8c.zip` package delivered earlier in this
project, which includes a command-line reproduction script and the
complete `docs/` traceability tree by increment.
