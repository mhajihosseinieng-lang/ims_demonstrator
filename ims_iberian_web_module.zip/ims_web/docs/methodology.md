# Methodology — Iberian 2025 Inspired Overvoltage Cascade Module

This document explains, precisely, what this web module computes, what it
reuses verbatim from the frozen research chain (Increments 1 through 8C),
what it generalizes, and what it deliberately does not implement.

## What is reused verbatim

Every algebraic equation, every protection threshold (V_trip=1.10,
V3_trip=1.05), both protection latches (Bus4 Volt-VAR trip, Bus3
shunt-reactor trip) and their actions, and the staged-disturbance operator's
validated escalation ratios are copied without modification from the frozen
`ims_engine.py`, itself built directly on `sim_7i_hybrid.py` and
`sim_8b_staged.py` from the frozen chain. Every number this module displays
that could be checked against a frozen traceability record has been
regression-tested against that record during development and matches to
the precision the (necessarily coarser, for interactivity) web-facing
integration step allows.

## The one generalization: K_PV as a genuine slider

The frozen chain used K_PV=5.0 as a fixed "on" value and K_PV=0.0 as the
post-trip "off" value. This module generalizes K_PV's *nominal* (pre-trip)
value to a continuous parameter, K_PV_nominal, so the "dynamic voltage
support" slider is backed by real computation across its whole range. This
is not a new mechanism -- K_PV was already a real parameter in the
algebraic equations (Increment 4a's own droop gain); this only removes the
restriction that it be fixed at one frozen value. Verified: at
K_PV_nominal=5.0 this reduces to exactly the frozen results (regression-
tested repeatedly during development); at K_PV_nominal=0.0 it reduces to
exactly Increment 3's own frozen no-support baseline equilibrium (also
regression-tested).

One genuine finding from generalizing this: at K_PV=0 combined with a
severe converter-current disturbance, the system can lose algebraic
feasibility entirely (a real collapse, at a state matching the
independently-known Mode-1 fold near i_q2≈-0.18 to -0.20) -- this is
real physics surfaced by exploring the parameter space, not a bug, and the
engine reports it as a first-class "collapsed" outcome with whatever
partial trajectory was traced before collapse, rather than an error.

## The staged disturbance and the 355/727/928 MW sequence

The module reuses the *escalation ratios* from the ENTSO-E timeline
(727/355 ≈ 2.05, 928/727 ≈ 1.28) applied to the model's own disturbance
channel (a displacement of the slow converter state E2). **No MW-to-per-unit
correspondence is claimed** -- the underlying model has no active-power
state, so there is no physically meaningful way to map a real MW loss onto
this model's disturbance channel. The timeline labels ("355 MW-equivalent")
are included because the proposal specifically asked for the real event
timeline to be visible in the UI, but "equivalent" is the operative word,
and this scope limitation is stated explicitly in the Methodology section
of the UI itself, not only here.

## Numerical settings for interactivity

The frozen traceability record used dt=5e-6s and t_max up to 0.35s for
full convergence and dt-convergence verification. This is too slow for an
interactive web response (a single scenario at those settings takes
30-60+ seconds). This module uses dt=2e-5s and t_max=0.15s by default,
which was verified during development to reproduce the frozen peak-voltage
and trip-timing results to at least 3-4 significant figures, trading final-
digit precision for responsiveness. This is a legitimate choice for a demo
tool answering "does it trip, and roughly how severe," not a claim that
these are the fully-converged numbers in the traceability record -- if
exact reproduction matters, use the standalone `run_full_demo.py` package
(fine dt, matches the frozen record exactly) instead.

## What is deliberately NOT implemented, and why

**Converter current limiting (I_max).** The proposal names this as a
control knob. It was tested as a candidate second protection mechanism in
the frozen research (Increments 7A through 7E) using the same rigorous
pre-registered, counterfactually-tested methodology as everything else in
this project, and was found **not to provide causal cascade evidence** --
the counterfactual test showed no case where suppressing the first trip
measurably changed whether or when a current-limit event occurred. Wiring
this to a live UI slider would misrepresent a mechanism that was tested and
found wanting as if it were a working, validated control. It is shown in
the UI, grayed out, with this explanation.

**GFM penetration (rho_GFM).** The frozen model has exactly one converter
(a GFL/GFM-hybrid representation at Bus2). A "penetration" axis requires a
genuinely different, multi-converter network topology -- this is a
structural model extension, not a parameter that exists and is merely
unswept. Shown grayed out, labeled as a roadmap item.

**Renewable output share as a map axis.** The frozen model has no
renewable-output-share state or parameter at all -- there is nothing to
put on that axis. The recoverability map instead shows the axis pair that
*is* validated: disturbance severity vs. converter current-loop timescale,
reusing the exact pre-registered 50-case grid methodology from Increments
7M and 7N (reduced here to 20 points for interactive response time).

**An automated intervention optimizer.** The proposal describes a feature
that would sweep K_Q, I_max, Q_shunt, and rho_GFM automatically and
recommend specific interventions. This does not exist. The manual
dynamic-Q A/B comparison in this module demonstrates the same underlying
capability (does a specific intervention restore recoverability?) for the
one parameter that is genuinely validated across its range.

## The load-bearing scientific caveat, restated

Nothing in this module changes the central finding of the frozen research:
**IMS structure and recoverability co-occurred in every tested case, but no
case reached a genuinely IMS-degraded state, so causation between the two
has not been established.** The UI's fold-distance "margin" gauge is a
real, computed quantity (distance to an independently-verified algebraic
fold), not a fabricated composite score, and it is never described in the
UI as proof that preserving it *causes* recoverability.
