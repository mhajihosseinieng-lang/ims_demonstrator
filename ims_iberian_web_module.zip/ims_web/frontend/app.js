// IMS Platform -- Iberian 2025 Inspired module frontend logic.
// Every number rendered here comes from a live fetch() to the Flask
// backend, which runs the validated ims_engine.py. Nothing here computes
// or fabricates results itself.

const API = '';

let lastRunResult = null;
let voltageChart = null;
let stateChart = null;
let mapChart = null;

// ---------- helpers ----------
function fmt(x, digits = 4) {
  if (x === null || x === undefined) return '—';
  return Number(x).toFixed(digits);
}

function marginFromFoldDistance(foldDist) {
  // Maps fold-distance (typically 0 to ~0.4 in this model) onto a 0-100
  // gauge position. This is a real, computed quantity (not fabricated),
  // scaled for display -- the scaling itself is a presentation choice,
  // not a new physical claim.
  if (foldDist === null || foldDist === undefined) return null;
  const clamped = Math.max(0, Math.min(foldDist, 0.4));
  return (clamped / 0.4) * 100;
}

function statusFromResult(r) {
  if (r.status === 'collapsed') return { label: 'NON-RECOVERABLE', cls: 'status-collapsed' };
  if (r.tripped_bus4 || r.tripped_bus3) {
    if (r.fold_distance_mode11 !== null && r.fold_distance_mode11 > 0.15) {
      return { label: 'RECOVERED (WITH CASCADE)', cls: 'status-recoverable' };
    }
    return { label: 'MARGINAL', cls: 'status-critical' };
  }
  return { label: 'RECOVERABLE (NO TRIP)', cls: 'status-recoverable' };
}

// ---------- slider labels ----------
const kpvSlider = document.getElementById('kpv-slider');
const kpvVal = document.getElementById('kpv-val');
kpvSlider.addEventListener('input', () => { kpvVal.textContent = Number(kpvSlider.value).toFixed(1); });

const severitySlider = document.getElementById('severity-slider');
const severityVal = document.getElementById('severity-val');
severitySlider.addEventListener('input', () => { severityVal.textContent = Number(severitySlider.value).toFixed(2) + '×'; });

const timingSlider = document.getElementById('timing-slider');
const timingVal = document.getElementById('timing-val');
const TIMING_OPTIONS = [[5, 10], [10, 20], [20, 40]];
timingSlider.addEventListener('input', () => {
  const [t1, t2] = TIMING_OPTIONS[timingSlider.value];
  timingVal.textContent = `${t1} / ${t2} ms`;
});

// ---------- stress test ----------
const runBtn = document.getElementById('run-stress-test');
const resultsPanel = document.getElementById('results-panel');

async function runStressTest() {
  runBtn.disabled = true;
  runBtn.textContent = 'RUNNING…';
  resultsPanel.innerHTML = '<div class="results-empty">Running stress test on the validated model…</div>';

  const [t1, t2] = TIMING_OPTIONS[timingSlider.value];
  const body = {
    diq2: 0.0,
    severity_scale: Number(severitySlider.value),
    timing_ms: [t1, t2],
    K_PV_nominal: Number(kpvSlider.value),
  };

  try {
    const resp = await fetch(`${API}/api/run_scenario`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
    });
    const r = await resp.json();
    lastRunResult = r;
    renderResults(r);
    renderTimeline(r, [t1, t2]);
    renderCharts(r);
    renderConventionalVsIMS(r);
  } catch (e) {
    resultsPanel.innerHTML = `<div class="results-empty">Error contacting the model server: ${e}</div>`;
  } finally {
    runBtn.disabled = false;
    runBtn.textContent = 'RUN STRESS TEST';
  }
}
runBtn.addEventListener('click', runStressTest);

function renderResults(r) {
  const st = statusFromResult(r);
  const peakV4 = r.peak_V ? r.peak_V[3] : null;
  const marginPct = marginFromFoldDistance(r.fold_distance_mode11);

  resultsPanel.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
      <h3 style="margin:0;">Result</h3>
      <span class="status-pill ${st.cls}"><span class="pip"></span>${st.label}</span>
    </div>
    <div class="result-grid">
      <div class="result-stat">
        <div class="stat-label">Bus4 trip</div>
        <div class="stat-value" style="color:${r.tripped_bus4 ? 'var(--red)' : 'var(--green)'}">${r.tripped_bus4 ? 'YES' : 'NO'}</div>
      </div>
      <div class="result-stat">
        <div class="stat-label">Bus3 trip</div>
        <div class="stat-value" style="color:${r.tripped_bus3 ? 'var(--red)' : 'var(--green)'}">${r.tripped_bus3 ? 'YES' : 'NO'}</div>
      </div>
      <div class="result-stat">
        <div class="stat-label">Peak Bus4 voltage</div>
        <div class="stat-value">${fmt(peakV4)} pu</div>
      </div>
      <div class="result-stat">
        <div class="stat-label">Fold-distance margin</div>
        <div class="stat-value">${r.fold_distance_mode11 !== null ? fmt(r.fold_distance_mode11) : 'n/a'}</div>
      </div>
    </div>
    <p style="font-size:12.5px;">${r.status === 'collapsed'
      ? 'The trajectory reached a state with no feasible algebraic operating point -- a genuine loss of recoverability, not a numerical error.'
      : 'Final state reached at t=150ms of simulated time.'}</p>
  `;
}

function renderTimeline(r, timingMs) {
  const stages = [
    { t: 0, label: '12:32:57\n355 MW-equiv.' },
    { t: timingMs[0], label: `12:33:16\n727 MW-equiv.` },
    { t: timingMs[1], label: `12:33:17\n928 MW-equiv.` },
  ];
  const track = document.getElementById('timeline-track');
  document.querySelectorAll('.timeline-marker, .timeline-marker-label').forEach(el => el.remove());
  const maxT = Math.max(timingMs[1] * 1.6, 15);
  stages.forEach(s => {
    const pct = (s.t / maxT) * 100;
    const marker = document.createElement('div');
    marker.className = 'timeline-marker';
    marker.style.left = pct + '%';
    track.appendChild(marker);
    const label = document.createElement('div');
    label.className = 'timeline-marker-label';
    label.style.left = pct + '%';
    label.innerHTML = s.label.replace('\n', '<br>');
    track.appendChild(label);
  });

  // Animate: sweep cursor across, lighting up markers and moving the gauge
  // needle based on the REAL trace's fold-distance evolution over time.
  const cursor = document.getElementById('timeline-cursor');
  const progress = document.getElementById('timeline-progress');
  const needle = document.getElementById('gauge-needle');
  const readout = document.getElementById('margin-readout');
  const markers = document.querySelectorAll('.timeline-marker');

  let animT = 0;
  const animDurationMs = 3500;
  const startTime = performance.now();

  function animate(now) {
    const frac = Math.min((now - startTime) / animDurationMs, 1);
    animT = frac * maxT;
    const pct = frac * 100;
    cursor.style.left = pct + '%';
    progress.style.width = pct + '%';

    markers.forEach((m, i) => {
      if (animT >= stages[i].t) m.classList.add('hit');
    });

    // find nearest trace point to animT (in ms)
    if (r.trace && r.trace.length) {
      let nearest = r.trace[0];
      for (const pt of r.trace) {
        if (pt.t * 1000 <= animT) nearest = pt; else break;
      }
      const tripped = nearest.mode && nearest.mode[1] === 1;
      let marginPct;
      if (tripped) {
        const dist = nearest.iq2 - (-0.201347);
        marginPct = marginFromFoldDistance(dist);
      } else {
        marginPct = 75; // pre-trip: healthy default position, not yet in post-cascade mode
      }
      needle.style.left = (marginPct !== null ? marginPct : 50) + '%';
      readout.textContent = tripped ? `fold-distance = ${fmt(nearest.iq2 - (-0.201347))}` : 'pre-cascade';
    }

    if (frac < 1) requestAnimationFrame(animate);
  }
  requestAnimationFrame(animate);
}

function renderCharts(r) {
  if (typeof Chart === 'undefined') {
    console.warn('Chart.js failed to load (no network access to the CDN) -- skipping chart rendering.');
    return;
  }
  const trace = r.trace || [];
  const labels = trace.map(p => (p.t * 1000).toFixed(2));
  const v4 = trace.map(p => p.V ? p.V[3] : null);
  const iq2 = trace.map(p => p.iq2);
  const e2 = trace.map(p => p.E2);

  if (voltageChart) voltageChart.destroy();
  voltageChart = new Chart(document.getElementById('chart-voltage'), {
    type: 'line',
    data: { labels, datasets: [
      { label: 'V4 (pu)', data: v4, borderColor: '#4A9EFF', backgroundColor: 'transparent', pointRadius: 0, borderWidth: 2 },
      { label: 'Trip threshold', data: labels.map(() => 1.10), borderColor: '#E5484D', borderDash: [4,4], pointRadius: 0, borderWidth: 1 },
    ]},
    options: { responsive: true, maintainAspectRatio: false,
      scales: { x: { title: { display: true, text: 'ms', color: '#8B93A3' }, ticks: { color: '#565F72', maxTicksLimit: 6 }, grid: { color: '#232938' } },
                y: { ticks: { color: '#565F72' }, grid: { color: '#232938' } } },
      plugins: { legend: { labels: { color: '#8B93A3', boxWidth: 12, font: { size: 10 } } } } }
  });

  if (stateChart) stateChart.destroy();
  stateChart = new Chart(document.getElementById('chart-state'), {
    type: 'line',
    data: { labels, datasets: [
      { label: 'i_q2', data: iq2, borderColor: '#2ECC71', backgroundColor: 'transparent', pointRadius: 0, borderWidth: 2, yAxisID: 'y' },
      { label: 'E2', data: e2, borderColor: '#F5A623', backgroundColor: 'transparent', pointRadius: 0, borderWidth: 2, yAxisID: 'y1' },
    ]},
    options: { responsive: true, maintainAspectRatio: false,
      scales: {
        x: { title: { display: true, text: 'ms', color: '#8B93A3' }, ticks: { color: '#565F72', maxTicksLimit: 6 }, grid: { color: '#232938' } },
        y: { position: 'left', ticks: { color: '#2ECC71' }, grid: { color: '#232938' } },
        y1: { position: 'right', ticks: { color: '#F5A623' }, grid: { display: false } },
      },
      plugins: { legend: { labels: { color: '#8B93A3', boxWidth: 12, font: { size: 10 } } } } }
  });
}

function renderConventionalVsIMS(r) {
  const eig = r.local_eigenvalues ? Math.max(...r.local_eigenvalues) : null;
  document.getElementById('sbs-eigenvalue').textContent = eig !== null ? fmt(eig, 2) : '—';
  document.getElementById('sbs-eigenvalue').style.color = (eig !== null && eig < 0) ? 'var(--green)' : 'var(--red)';
  const margin = r.fold_distance_mode11;
  document.getElementById('sbs-margin').textContent = margin !== null ? fmt(margin, 4) : (r.status === 'collapsed' ? 'COLLAPSED' : 'n/a (no trip)');
  document.getElementById('sbs-margin').style.color = margin !== null && margin > 0.15 ? 'var(--green)' : 'var(--red)';

  let footer = 'Run a stress test above to populate this comparison.';
  if (eig !== null) {
    if (eig < 0 && (margin === null || margin > 0.15)) {
      footer = 'Both tools agree at this operating point.';
    } else if (eig < 0 && r.status === 'collapsed') {
      footer = 'Local eigenvalues were negative earlier in the trajectory, yet the system lost algebraic feasibility -- the two answers diverge.';
    } else {
      footer = 'Same operating point, different large-signal answer.';
    }
  }
  document.getElementById('sbs-footer').textContent = footer;
}

// ---------- comparison A/B ----------
const compareBtn = document.getElementById('run-compare');
compareBtn.addEventListener('click', async () => {
  compareBtn.disabled = true;
  compareBtn.textContent = 'RUNNING…';
  try {
    const [t1, t2] = TIMING_OPTIONS[timingSlider.value];
    const resp = await fetch(`${API}/api/compare`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ diq2: 0.3, severity_scale: 0.1, timing_ms: [t1, t2], K_PV_a: 0.0, K_PV_b: 5.0 })
    });
    const r = await resp.json();
    document.getElementById('compare-grid').style.display = 'grid';

    const a = r.scenario_a, b = r.scenario_b;
    const stA = statusFromResult(a), stB = statusFromResult(b);
    document.getElementById('compare-a-status').className = 'status-pill ' + stA.cls;
    document.getElementById('compare-a-status').innerHTML = `<span class="pip"></span>${stA.label}`;
    document.getElementById('compare-a-trip4').textContent = a.tripped_bus4 ? 'YES' : 'NO';
    document.getElementById('compare-a-trip3').textContent = a.tripped_bus3 ? 'YES' : 'NO';
    document.getElementById('compare-a-peak').textContent = fmt(a.peak_V ? a.peak_V[3] : null) + ' pu';

    document.getElementById('compare-b-status').className = 'status-pill ' + stB.cls;
    document.getElementById('compare-b-status').innerHTML = `<span class="pip"></span>${stB.label}`;
    document.getElementById('compare-b-trip4').textContent = b.tripped_bus4 ? 'YES' : 'NO';
    document.getElementById('compare-b-trip3').textContent = b.tripped_bus3 ? 'YES' : 'NO';
    document.getElementById('compare-b-peak').textContent = fmt(b.peak_V ? b.peak_V[3] : null) + ' pu';
  } catch (e) {
    alert('Error running comparison: ' + e);
  } finally {
    compareBtn.disabled = false;
    compareBtn.textContent = 'RUN COMPARISON';
  }
});

// ---------- recoverability map ----------
async function loadMap() {
  try {
    const resp = await fetch(`${API}/api/recoverability_map`);
    const r = await resp.json();
    const tauIs = [...new Set(r.grid.map(g => g.tau_I))];
    const datasets = tauIs.map((tau, idx) => {
      const points = r.grid.filter(g => g.tau_I === tau).map(g => ({
        x: g.E2_initial, y: (g.tripped_bus3 && g.tripped_bus4) ? 1 : 0
      }));
      const colors = ['#4A9EFF', '#2ECC71', '#F5A623', '#E5484D'];
      return {
        label: `tau_I = ${(tau*1000).toFixed(0)} ms`,
        data: points, showLine: true, borderColor: colors[idx % 4],
        backgroundColor: colors[idx % 4], pointRadius: 4, borderWidth: 2,
      };
    });
    if (mapChart) mapChart.destroy();
    mapChart = new Chart(document.getElementById('chart-map'), {
      type: 'scatter',
      data: { datasets },
      options: { responsive: true,
        scales: {
          x: { title: { display: true, text: 'Disturbance severity (E2 initial)', color: '#8B93A3' }, ticks: { color: '#565F72' }, grid: { color: '#232938' } },
          y: { title: { display: true, text: 'Both protections tripped', color: '#8B93A3' }, ticks: { color: '#565F72', stepSize: 1, callback: v => v === 1 ? 'YES' : 'NO' }, min: -0.2, max: 1.2, grid: { color: '#232938' } },
        },
        plugins: { legend: { labels: { color: '#8B93A3', boxWidth: 12, font: { size: 10 } } } } }
    });
  } catch (e) { console.error(e); }
}

// ---------- case library ----------
async function loadCaseLibrary() {
  try {
    const resp = await fetch(`${API}/api/case_library`);
    const cases = await resp.json();
    const list = document.getElementById('case-list');
    list.innerHTML = cases.map(c => `
      <div class="case-item ${c.available ? 'available' : ''}">
        <div class="case-radio"></div>
        <div class="case-name">${c.name}</div>
        <div class="case-tag">${c.available ? 'available' : 'roadmap'}</div>
      </div>
    `).join('');
  } catch (e) { console.error(e); }
}

// ---------- init ----------
loadMap();
loadCaseLibrary();
