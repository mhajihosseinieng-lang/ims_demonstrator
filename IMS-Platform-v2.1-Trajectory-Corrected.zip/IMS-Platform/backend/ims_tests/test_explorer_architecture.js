/* Browser-neutral checks of shipped interface architecture and SVG scientific clarity. */
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const staticRoot = path.join(__dirname, '..', 'ims_platform', 'server', 'static');
const html = fs.readFileSync(path.join(staticRoot, 'explorer.html'), 'utf8');
const css = fs.readFileSync(path.join(staticRoot, 'assets/css/explorer.css'), 'utf8');
const script = require('./load_explorer_scripts')();
const scripts = [...html.matchAll(/<script src="(\/assets\/js\/[^\"]+)" defer><\/script>/g)].map(x=>x[1]);
assert.deepStrictEqual(scripts, [
 '/assets/js/core.js', '/assets/js/views.js', '/assets/js/workspace.js',
 '/assets/js/results.js', '/assets/js/services.js'
]);
for (const src of scripts) assert(fs.existsSync(path.join(staticRoot, src.slice(1))));
assert(/rel="stylesheet" href="\/assets\/css\/explorer.css"/.test(html));
assert(/@media\(max-width:560px\)/.test(css));
assert(!html.includes('>Soon</span>'), 'Unimplemented nav items should not be presented');
assert.strictEqual((html.match(/class="hero-step"/g) || []).length, 6);
assert(/id="heroRecoveryPath"/.test(html));
assert(/NOT SIMULATION DATA/.test(html));
assert(!html.includes('class="qa-row"'), 'No duplicated hero quick actions');
// Parse all SVG cubic Bézier pieces and verify position + first-derivative continuity.
const trajectory = html.match(/id="heroRecoveryPath"\s+d="([^"]+)"/);
assert(trajectory, 'Ship a single recovery path');
const pathData = trajectory[1];
const number = '-?\\d+(?:\\.\\d+)?';
const move = pathData.match(new RegExp(`^M\\s*(${number}),(${number})`));
assert(move, 'Trajectory should start at the disturbance marker');
const segRegex = new RegExp(`C\\s*(${number}),(${number})\\s+(${number}),(${number})\\s+(${number}),(${number})`, 'g');
const segments = [...pathData.matchAll(segRegex)].map(m=>m.slice(1).map(Number));
assert(segments.length >= 40, 'Use smooth cubic curve, not a broken polyline');
const pos = [Number(move[1]),Number(move[2])];
const startMarker = html.match(/<circle id="heroDisturbanceMarker" cx="([^"]+)" cy="([^"]+)"/);
assert(startMarker && Math.abs(Number(startMarker[1])-pos[0]) < 0.01 && Math.abs(Number(startMarker[2])-pos[1]) < 0.01);
assert(/id="heroDisturbanceLabel"/.test(html));
assert(/id="heroEquilibriumLabel"/.test(html));
for (let i=1;i<segments.length;i++) {
 const prev=segments[i-1],next=segments[i];
 const joint=[prev[4],prev[5]];
 const left=[joint[0]-prev[2],joint[1]-prev[3]];
 const right=[next[0]-joint[0],next[1]-joint[1]];
 assert(Math.hypot(left[0]-right[0], left[1]-right[1])<0.004, 'C1 tangent continuity lost at '+i);
}
const target=segments.at(-1).slice(4,6);
const endpointMarker = html.match(/<circle id="heroEquilibriumMarker" cx="([^"]+)" cy="([^"]+)"/);
assert(endpointMarker && Math.abs(Number(endpointMarker[1])-target[0])<0.01 && Math.abs(Number(endpointMarker[2])-target[1])<0.01, 'Endpoint marker must match trajectory endpoint');
assert(/id="heroManifoldPath"/.test(html), 'The manifold must be independently shown');
assert(html.includes('transverse contraction') || html.includes('transverse deviation'));
// Recoverability schematic has a nonzero initial residual and vanishing endpoint residual.
const yManifold = (x)=>235-24*Math.sin(Math.PI*(x-120)/420)-19*(x-120)/420;
assert(Math.abs(pos[1] - yManifold(pos[0]))>100);
assert(Math.abs(target[1] - yManifold(target[0]))<0.01);
const stageBlock = script.split('var STAGES = [')[1].split('];')[0];
const stages = [...stageBlock.matchAll(/\{ key: "([a-z_]+)", label:/g)].map(m=>m[1]);
assert.deepStrictEqual(stages, ['build','equilibrium','simulate','ims_analysis','design_mrc','report']);
assert(/function activateSurface/.test(script), 'One central view switcher');
assert(/function invalidateDownstreamResults/.test(script), 'Upstream re-runs must invalidate stale downstream results');
console.log('PASS architecture assets, clean navigation, 6-stage order, C1 recovery path, exact endpoint marker');
