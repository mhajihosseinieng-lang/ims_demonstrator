// IMS Platform / views.js — ordered classic script; public stage API stays stable.
/* ===================== PROJECT MANAGER ===================== */

async function loadProjects() {
  try {
    var resp = await fetch("/api/projects");
    if (!resp.ok) throw new Error("HTTP " + resp.status);
    projectsList = await resp.json();
    if (!Array.isArray(projectsList)) throw new Error("Unexpected project data");
    renderProjectGrid();
  } catch (err) {
    var grid = $("projectGrid");
    if (grid) grid.innerHTML = '<div class="error-box" role="alert">Projects could not be loaded. Confirm the IMS backend is running and refresh this page. (' + String(err.message || err) + ')</div>';
  }
}

var projectViewMode = "grid";

function setProjectView(mode) {
  projectViewMode = mode;
  $("gridViewBtn").classList.toggle("active", mode === "grid");
  $("listViewBtn").classList.toggle("active", mode === "list");
  renderProjectGrid();
}

function renderProjectGrid() {
  var grid = $("projectGrid");
  grid.className = "project-grid" + (projectViewMode === "list" ? " list-view" : "");
  grid.innerHTML = "";
  var catIcons = { single_model: "&#9670;", converter_topology: "&#9633;", network_mrc: "&#9711;", custom_network: "&#8982;" };
  // Tiny decorative topology glyphs so each card gives an at-a-glance
  // visual cue of its structure (single node / bridge / mesh network /
  // irregular network) without cluttering the layout.
  var topoIcons = {
    single_model: '<svg viewBox="0 0 28 28" width="20" height="20" fill="none"><rect x="9" y="9" width="10" height="10" rx="2" stroke="currentColor" stroke-width="1.4" opacity="0.85"/><line x1="14" y1="2" x2="14" y2="9" stroke="currentColor" stroke-width="1.2" opacity="0.55"/><line x1="14" y1="19" x2="14" y2="26" stroke="currentColor" stroke-width="1.2" opacity="0.55"/><line x1="2" y1="14" x2="9" y2="14" stroke="currentColor" stroke-width="1.2" opacity="0.55"/><line x1="19" y1="14" x2="26" y2="14" stroke="currentColor" stroke-width="1.2" opacity="0.55"/></svg>',
    converter_topology: '<svg viewBox="0 0 28 28" width="20" height="20" fill="none"><line x1="6" y1="3" x2="6" y2="25" stroke="currentColor" stroke-width="1.3" opacity="0.6"/><line x1="22" y1="3" x2="22" y2="25" stroke="currentColor" stroke-width="1.3" opacity="0.6"/><line x1="6" y1="9" x2="14" y2="9" stroke="currentColor" stroke-width="1.3" opacity="0.85"/><line x1="14" y1="9" x2="14" y2="19" stroke="currentColor" stroke-width="1.3" opacity="0.85"/><line x1="14" y1="19" x2="22" y2="19" stroke="currentColor" stroke-width="1.3" opacity="0.85"/><circle cx="6" cy="9" r="1.6" fill="currentColor" opacity="0.9"/><circle cx="22" cy="19" r="1.6" fill="currentColor" opacity="0.9"/></svg>',
    network_mrc: '<svg viewBox="0 0 28 28" width="20" height="20" fill="none"><line x1="7" y1="21" x2="21" y2="21" stroke="currentColor" stroke-width="1.2" opacity="0.55"/><line x1="7" y1="21" x2="14" y2="6" stroke="currentColor" stroke-width="1.2" opacity="0.55"/><line x1="21" y1="21" x2="14" y2="6" stroke="currentColor" stroke-width="1.2" opacity="0.55"/><circle cx="14" cy="6" r="2.2" fill="currentColor" opacity="0.9"/><circle cx="7" cy="21" r="2.2" fill="currentColor" opacity="0.9"/><circle cx="21" cy="21" r="2.2" fill="currentColor" opacity="0.9"/></svg>',
    custom_network: '<svg viewBox="0 0 28 28" width="20" height="20" fill="none"><line x1="5" y1="8" x2="16" y2="5" stroke="currentColor" stroke-width="1.1" opacity="0.5"/><line x1="16" y1="5" x2="23" y2="14" stroke="currentColor" stroke-width="1.1" opacity="0.5"/><line x1="5" y1="8" x2="10" y2="22" stroke="currentColor" stroke-width="1.1" opacity="0.5"/><line x1="10" y1="22" x2="23" y2="14" stroke="currentColor" stroke-width="1.1" opacity="0.5"/><circle cx="5" cy="8" r="2" fill="currentColor" opacity="0.85"/><circle cx="16" cy="5" r="2" fill="currentColor" opacity="0.85"/><circle cx="23" cy="14" r="2" fill="currentColor" opacity="0.85"/><circle cx="10" cy="22" r="2" fill="currentColor" opacity="0.85"/></svg>'
  };
  // Category accent colors, matching the reference: green=network, blue=single model, orange=converter, purple=control/custom.
  var catColors = { single_model: "var(--blue-dim)", converter_topology: "var(--amber-dim)", network_mrc: "var(--teal-dim)", custom_network: "var(--purple-dim)" };
  var catIconColors = { single_model: "var(--blue)", converter_topology: "var(--amber)", network_mrc: "var(--teal)", custom_network: "var(--purple)" };
  var query = (($("projectSearchInput") && $("projectSearchInput").value) || "").toLowerCase();
  var filterCat = ($("projectFilterSelect") && $("projectFilterSelect").value) || "";
  var filtered = projectsList.filter(function (p) {
    if (filterCat && p.category !== filterCat) return false;
    if (query && p.label.toLowerCase().indexOf(query) === -1 && p.description.toLowerCase().indexOf(query) === -1) return false;
    return true;
  });
  if (filtered.length === 0) {
    grid.innerHTML = "<div class='recent-empty' style='grid-column:1/-1;'>No projects match your search.</div>";
    return;
  }
  filtered.forEach(function (p, i) {
    var card = document.createElement("div");
    card.className = "project-card";
    card.style.animationDelay = Math.min(i * 45, 360) + "ms";
    card.innerHTML =
      "<div class='project-card-top'>" +
      "<div class='project-card-icon' style='background:" + (catColors[p.category] || "var(--panel-alt)") + ";color:" + (catIconColors[p.category] || "var(--text)") + ";'>" + (catIcons[p.category] || "&#9633;") + "</div>" +
      "<div class='project-card-top-right'>" +
      "<div class='project-card-topo' style='color:" + (catIconColors[p.category] || "var(--text-dim)") + ";' aria-hidden='true'>" + (topoIcons[p.category] || "") + "</div>" +
      '<span class="cat-badge cat-' + p.category + '">' + p.category.replace("_", " ") + '</span>' +
      "</div>" +
      "</div>" +
      '<h3>' + p.label + '</h3>' +
      '<p>' + p.description + '</p>' +
      '<button onclick="openProject(\'' + p.id + '\')">Open &rarr;</button>';
    grid.appendChild(card);
  });
}

/* ===================== EXPLORER ANALYSIS HUB (shared framework) ===================== */
/* Common hub: lists every analysis registered in the shared framework
   (/api/analysis/registry) and routes to each through the standard workflow.
   Runnable analyses (e.g. Stabilising MRC) open their analysis surface;
   connected validated cases open their existing, unchanged views. */
function showAnalysisHub() {
  activateSurface("analysisHubView", "Analysis Hub", '<b onclick="showProjectManager()">Projects</b> &rsaquo; Analysis Hub');
  var v = $("analysisHubView");
  v.innerHTML = '<div style="color:#8aa;">Loading analyses...</div>';
  fetch("/api/analysis/registry").then(function (r) { return r.json(); }).then(function (data) {
    renderAnalysisHub(data);
  }).catch(function (e) {
    v.innerHTML = '<div style="color:#f88;">Failed to load analysis registry: ' + e + '</div>';
  });
}

function renderAnalysisHub(data) {
  var v = $("analysisHubView");
  var OUT = [
    ["equilibrium", "Equilibrium"], ["manifold_residual", "Manifold residual"],
    ["residual_trajectory", "Residual trajectory"], ["contraction_evidence", "Contraction"],
    ["local_stability", "Local stability"], ["finite_horizon_recovery", "Recovery"],
    ["solver_constraint_status", "Solver/constraint"], ["report_export", "Report/export"]
  ];
  var stages = (data.workflow_stages || []).join('  &rsaquo;  ');
  var html = '<div style="font-size:12px;letter-spacing:.16em;text-transform:uppercase;color:#5fd6b0;">Explorer</div>'
    + '<h1 style="font-size:30px;margin:6px 0 4px 0;">Analysis Hub</h1>'
    + '<p style="color:#9fb0c0;max-width:760px;">One shared engine for every validated IMS study. '
    + 'Standard workflow: <span style="color:#cdd;">' + stages + '</span></p>'
    + '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:16px;margin-top:18px;">';
  (data.analyses || []).forEach(function (a) {
    var badges = OUT.filter(function (o) { return a.supported_outputs && a.supported_outputs[o[0]]; })
      .map(function (o) {
        return '<span style="font-size:10px;border:1px solid #2b6;color:#7de;border-radius:4px;padding:1px 6px;margin:0 4px 4px 0;display:inline-block;">' + o[1] + '</span>';
      }).join('');
    var runnable = a.standardized;
    var tag = runnable
      ? '<span style="font-size:10px;color:#0a0f16;background:#5fd6b0;border-radius:4px;padding:2px 7px;font-weight:700;">RUNNABLE</span>'
      : '<span style="font-size:10px;color:#0a0f16;background:#e6b34d;border-radius:4px;padding:2px 7px;font-weight:700;">VALIDATED CASE</span>';
    html += '<div class="analysis-card" style="border:1px solid #22303f;border-radius:10px;padding:16px;background:#0f1622;cursor:pointer;"'
      + ' onclick="openAnalysis(' + escapeJsAttr(JSON.stringify(a)) + ')">'
      + '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">'
      + '<span style="font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:#7f93a6;">' + (a.category || '') + '</span>' + tag + '</div>'
      + '<h3 style="margin:8px 0 6px 0;font-size:17px;">' + a.title + '</h3>'
      + '<p style="color:#93a4b5;font-size:13px;min-height:56px;">' + (a.description || '') + '</p>'
      + '<div style="margin-top:8px;">' + badges + '</div>'
      + '<div style="margin-top:10px;font-size:11px;color:#6f8296;">' + (a.guarantee_scope || '') + '</div>'
      + '</div>';
  });
  html += '</div>';
  v.innerHTML = html;
}

function escapeJsAttr(s) { return s.replace(/&/g, '&amp;').replace(/'/g, '&#39;').replace(/"/g, '&quot;'); }

function openAnalysis(a) {
  if (typeof a === "string") { try { a = JSON.parse(a); } catch (e) { return; } }
  var entry = a.entry || {};
  var fn = entry.view_fn;
  if (fn === "openProject" && entry.project_id && typeof window.openProject === "function") {
    return window.openProject(entry.project_id);
  }
  if (fn && typeof window[fn] === "function") { return window[fn](); }
  // Fallback: unknown routing -> Case Library.
  if (typeof window.showCaseLibrary === "function") return window.showCaseLibrary();
}

function setAppNavActive(label) {
  document.querySelectorAll(".app-nav-item").forEach(function (el) {
    el.classList.toggle("active", el.textContent.trim().indexOf(label) === 0);
  });
}

/* ===================== STABILISING MRC (verified four-state analysis) ===================== */
/* Native Explorer analysis surface. Reuses the verified /api/four_state/* backend
   through an embedded React workspace at /mrc. The IMS Platform supplies the
   chrome (header, sidebar, breadcrumb); the analysis renders inside. */
function showStabilizingMRC() {
  activateSurface("stabMrcView", "Stabilising MRC", '<b onclick="showProjectManager()">Projects</b> &rsaquo; Stabilising MRC');
  var f = $("stabMrcFrame");
  if (f && !f.getAttribute("src")) f.setAttribute("src", "/mrc?embedded=1");
}

/* The General MRC Designer is no longer a standalone Explorer workflow. It now
   lives inside every project workspace as the downstream "Design MRC Controller"
   stage (after IMS Analysis), inheriting the project's assembled model, params,
   equilibrium and IMS results as the single source of truth. See
   renderDesignMrcStage / runDesignMrc below. */

function showProjectManager() {
  activateSurface("pmView", "Projects", '<b onclick="showProjectManager()">Projects</b>');
  currentProject = null; stageResults = {};
  setAppNavActive("Projects");
  renderRecentProjectsPanel();
}

function openBuilderView() {
  builderSpec = { buses: [], lines: [], loads: [], converters: [], sources: [], input_component_id: null };
  builderCounter = { bus: 0, line: 0, load: 0, converter: 0, source: 0 };
  activateSurface("builderView", "New Project", '<b onclick="showProjectManager()">Projects</b> &rsaquo; New Project');
  renderBuilder();
  setAppNavActive("New Project");
}

/* ===================== CASE LIBRARY ===================== */

async function showCaseLibrary() {
  activateSurface("caseLibraryView", "Case Library", '<b onclick="showProjectManager()">Projects</b> &rsaquo; Case Library');
  try {
    var resp = await fetch("/api/case_library");
    var cases = await resp.json();
    renderCaseLibraryGrid(cases);
  } catch (e) {
    $("caseLibraryGrid").innerHTML = '<div class="error-box">Could not load case library: ' + e + '</div>';
  }
}

function renderCaseLibraryGrid(cases) {
  var html = "";
  cases.forEach(function (c) {
    var clickable = c.available;
    var onclick = "";
    if (c.kind === "iberian_scenario") onclick = 'showIberianScenario()';
    else if (c.kind === "gfm_current_limit") onclick = 'showGfmCurrentLimitCase()';
    else if (c.kind === "multi_converter_fault") onclick = 'showMultiConverterCase()';
    else if (c.available && c.project_id) onclick = 'openProject(\'' + c.project_id + '\')';
    var statusBadge = clickable
      ? '<span style="font-size:9px;font-weight:700;color:var(--teal);border:1px solid var(--teal);border-radius:3px;padding:2px 8px;letter-spacing:.03em;white-space:nowrap;">ACTIVE &mdash; ANALYSIS AVAILABLE</span>'
      : '<span style="font-size:9px;font-weight:700;color:var(--muted);border:1px solid var(--border);border-radius:3px;padding:2px 8px;letter-spacing:.03em;white-space:nowrap;">COMING SOON &mdash; NOT YET IMPLEMENTED</span>';
    html += '<div class="case-card' + (clickable ? ' clickable' : '') + '" style="' + (clickable ? '' : 'opacity:0.6;') + '" ' +
      (clickable ? 'onclick="' + onclick + '"' : '') + '>' +
      '<div style="margin-bottom:8px;">' + statusBadge + '</div>' +
      '<div style="font-family:var(--display);font-weight:700;font-size:14px;margin-bottom:6px;">' + c.name + '</div>' +
      '<div style="font-size:11.5px;color:var(--muted);line-height:1.5;">' + c.description + '</div>' +
      '</div>';
  });
  $("caseLibraryGrid").innerHTML = html;
}

/* ===================== IBERIAN 2025 SCENARIO ===================== */

var iberianParams = { KQ: 0.0, Q_avail: 0.05, Imax: 1.3, gfm_fraction: 0.0 };
var iberianSliderDefs = [
  { key: "KQ", label: "Renewable dynamic voltage support (K\u1D64)", min: 0, max: 20, step: 0.5, fmt: function (v) { return v.toFixed(1); } },
  { key: "Q_avail", label: "Shunt reactor availability", min: 0, max: 1, step: 0.05, fmt: function (v) { return Math.round(v * 100) + "%"; } },
  { key: "Imax", label: "Converter current limit (p.u.)", min: 0.5, max: 5.0, step: 0.1, fmt: function (v) { return v.toFixed(2); } },
  { key: "gfm_fraction", label: "Grid-forming penetration (\u03C1_GFM)", min: 0, max: 1, step: 0.05, fmt: function (v) { return Math.round(v * 100) + "%"; } },
];
var iberianBaselineData = null;

async function showIberianScenario() {
  activateSurface("iberianView", "Case Library", '<b onclick="showProjectManager()">Projects</b> &rsaquo; <span onclick="showCaseLibrary()" style="cursor:pointer;">Case Library</span> &rsaquo; Iberian Scenario');
  if (!$("iberianView").dataset.built) {
    buildIberianViewSkeleton();
    $("iberianView").dataset.built = "1";
  }
  renderIberianSliders();
  if (!iberianBaselineData) {
    try {
      var resp = await fetch("/api/iberian/summary");
      iberianBaselineData = await resp.json();
      $("iberianDisclaimer").textContent = iberianBaselineData.disclaimer || "";
      renderIberianEventTimeline(iberianBaselineData.event_timeline || []);
    } catch (e) { /* non-fatal: sliders/charts still work once Run is clicked */ }
  }
}

function buildIberianViewSkeleton() {
  $("iberianView").innerHTML =
    '<div style="margin-bottom:22px;">' +
    '<div style="font-family:var(--mono);font-size:11px;color:var(--amber);letter-spacing:0.06em;text-transform:uppercase;margin-bottom:6px;">Case Library &rsaquo; Event Scenario</div>' +
    '<h1 style="font-family:var(--display);font-size:26px;margin:0 0 8px;">Can this grid survive the next disturbance?</h1>' +
    '<p class="sub" style="max-width:820px;">Iberian 2025-Inspired Overvoltage Cascade &mdash; a reduced-order, illustrative test system built from the mechanism class described in ENTSO-E\'s 20 March 2026 final report on the 28 April 2025 Iberian Peninsula event: insufficient dynamic voltage/reactive-power support, current limiting, delayed overvoltage protection, and cascading disconnection.</p>' +
    '<div id="iberianDisclaimer" style="font-size:11px;color:var(--muted);border-left:2px solid var(--amber);padding:8px 12px;background:rgba(255,180,84,0.06);border-radius:0 6px 6px 0;max-width:820px;"></div>' +
    '</div>' +
    '<div style="display:grid;grid-template-columns:300px 1fr;gap:20px;align-items:start;">' +
    '<div class="side-panel" style="position:static;width:auto;max-width:none;padding:18px;">' +
    '<div style="font-family:var(--display);font-weight:700;font-size:13px;margin-bottom:4px;">Stress-test controls</div>' +
    '<div style="font-size:11px;color:var(--muted);margin-bottom:14px;">Same scripted disturbance every time (355&#8201;/&#8201;727&#8201;/&#8201;928&#8201;MW-equivalent loss events). These four knobs are the only thing that changes.</div>' +
    '<div id="iberianSliders"></div>' +
    '<button class="hero-cta-btn hero-cta-primary" style="width:100%;margin-top:10px;padding:11px 0;" onclick="iberianRunStressTest()">RUN STRESS TEST</button>' +
    '<button class="secondary-btn" style="width:100%;margin-top:8px;" onclick="iberianRunCounterfactual()">Compare baseline vs. dynamic-Q</button>' +
    '<button class="secondary-btn" style="width:100%;margin-top:8px;" onclick="iberianRunBoundaryMap()">Trace recoverability boundary (1-D)</button>' +
    '<button class="secondary-btn" style="width:100%;margin-top:8px;" onclick="iberianRun2DBoundaryMap()">2-D boundary map (K\u1D64 &times; severity)</button>' +
    '<button class="secondary-btn" style="width:100%;margin-top:8px;" onclick="iberianRunGfmComparison()">GFM 0% / 20% / 40% comparison</button>' +
    '<button class="secondary-btn" style="width:100%;margin-top:8px;" onclick="iberianRunRecommendations()">Get recommended interventions</button>' +
    '<button class="secondary-btn" style="width:100%;margin-top:8px;border-color:var(--purple);color:var(--purple);" onclick="iberianRunImsGeometry()">True IMS Geometry</button>' +
    '<div style="margin-top:18px;padding-top:14px;border-top:1px solid var(--border);">' +
    '<button class="secondary-btn" style="width:100%;" onclick="generateReport(\'iberian_2025_overvoltage_cascade\', iberianParams, {severity:1.0, include_counterfactual:true, include_boundary:true, include_recommendations:true, include_ims_geometry:true}, \'iberianReportActions\')">GENERATE FINAL REPORT</button>' +
    '<div id="iberianReportActions" style="margin-top:8px;"></div>' +
    '</div>' +
    '<div id="iberianEventTimeline" style="margin-top:18px;"></div>' +
    '</div>' +
    '<div>' +
    '<div id="iberianVerdictBar"></div>' +
    '<div id="iberianWarningBar"></div>' +
    '<div id="iberianVoltChartWrap"></div>' +
    '<div id="iberianMarginChartWrap"></div>' +
    '<div id="iberianCounterfactual"></div>' +
    '<div id="iberianBoundaryChart"></div>' +
    '<div id="iberianBoundary2DChart"></div>' +
    '<div id="iberianGfmChart"></div>' +
    '<div id="iberianRecommendations"></div>' +
    '<div id="iberianImsGeometry"></div>' +
    '<div id="iberianCompareStrip"></div>' +
    '</div></div>';
}

function renderIberianSliders() {
  var html = "";
  iberianSliderDefs.forEach(function (d) {
    var v = iberianParams[d.key];
    html += '<div style="margin-bottom:16px;">' +
      '<div style="display:flex;justify-content:space-between;font-size:11.5px;color:var(--text);margin-bottom:4px;">' +
      '<span>' + d.label + '</span><span id="iberianVal_' + d.key + '" style="font-family:var(--mono);color:var(--teal);">' + d.fmt(v) + '</span></div>' +
      '<input type="range" min="' + d.min + '" max="' + d.max + '" step="' + d.step + '" value="' + v + '" ' +
      'style="width:100%;" oninput="iberianOnSlider(\'' + d.key + '\', this.value)"/></div>';
  });
  $("iberianSliders").innerHTML = html;
}

function iberianOnSlider(key, value) {
  iberianParams[key] = parseFloat(value);
  var def = iberianSliderDefs.filter(function (d) { return d.key === key; })[0];
  $("iberianVal_" + key).textContent = def.fmt(iberianParams[key]);
}

function renderIberianEventTimeline(events) {
  var html = '<div style="font-family:var(--display);font-weight:700;font-size:12px;margin-bottom:8px;">Scripted disturbance timeline</div>';
  events.forEach(function (e) {
    html += '<div style="font-size:10.5px;color:var(--muted);padding:5px 0;border-top:1px solid var(--border);line-height:1.4;">' + e.label + '</div>';
  });
  $("iberianEventTimeline").innerHTML = html;
}

async function iberianRunStressTest() {
  $("iberianVerdictBar").innerHTML = '<div class="sub">Running stress test&hellip;</div>';
  $("iberianWarningBar").innerHTML = "";
  ["iberianBoundaryChart", "iberianBoundary2DChart", "iberianGfmChart", "iberianRecommendations"].forEach(function (id) { $(id).innerHTML = ""; });
  try {
    var resp = await fetch("/api/iberian/stress_test", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ params: iberianParams, severity: 1.0 }),
    });
    var data = await resp.json();
    if (data.error) { $("iberianVerdictBar").innerHTML = '<div class="error-box">' + data.error + '</div>'; return; }
    if (!iberianBaselineData) { iberianBaselineData = data; renderIberianEventTimeline(data.event_timeline || []); }
    $("iberianDisclaimer").textContent = data.disclaimer || "";
    iberianRenderResults(data);
    iberianFetchWarning();
  } catch (e) {
    $("iberianVerdictBar").innerHTML = '<div class="error-box">Request failed: ' + e + '</div>';
  }
}

async function iberianFetchWarning() {
  try {
    var resp = await fetch("/api/iberian/pre_incident_warning", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ params: iberianParams, severity: 1.0, include_ims_warning: true }),
    });
    var data = await resp.json();
    if (data.error) return;
    var w = data.warning, wi = data.ims_warning;
    if (!w.available) return;
    var html = "";
    html += '<div style="margin-bottom:6px;"><span class="metric-kind-tag-live" style="display:inline-block;font-size:8.5px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;border-radius:3px;padding:2px 7px;color:#6FC6FF;background:rgba(111,198,255,0.10);border:1px solid rgba(111,198,255,0.35);">Conventional / physical metric</span></div>';
    if (w.genuinely_leads) {
      html += '<div style="display:flex;gap:10px;align-items:center;padding:10px 14px;border-radius:6px;background:var(--purple-dim);border:1px solid var(--purple);margin-bottom:10px;font-size:11.5px;">' +
        '<span style="font-size:16px;">&#9888;</span><div><b style="color:var(--purple);">Early warning (voltage margin): t=' + w.t_warning.toFixed(2) + 's</b> &mdash; ' + w.interpretation +
        ' <span style="color:var(--muted);">(actual threshold crossing at t=' + w.t_overvoltage_trip.toFixed(2) + 's)</span></div></div>';
    } else if (w.t_overvoltage_trip == null) {
      html += '<div style="font-size:11px;color:var(--muted);margin-bottom:10px;">Voltage never exceeded the overvoltage-trip threshold on this trajectory &mdash; no warning to show.</div>';
    }
    if (wi && wi.available) {
      html += '<div style="margin-bottom:6px;"><span style="display:inline-block;font-size:8.5px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;border-radius:3px;padding:2px 7px;color:#B18CFF;background:rgba(177,140,255,0.10);border:1px solid rgba(177,140,255,0.35);">IMS geometric diagnostic</span></div>';
      if (wi.genuinely_leads) {
        html += '<div style="display:flex;gap:10px;align-items:center;padding:10px 14px;border-radius:6px;background:var(--purple-dim);border:1px solid var(--purple);margin-bottom:12px;font-size:11.5px;">' +
          '<span style="font-size:16px;">&#9888;</span><div><b style="color:var(--purple);">Early warning (manifold distance d_M): t=' + wi.t_warning.toFixed(2) + 's</b> &mdash; ' + wi.interpretation + '</div></div>';
      } else {
        html += '<div style="font-size:11px;color:var(--muted);margin-bottom:12px;">' + wi.interpretation + '</div>';
      }
    }
    $("iberianWarningBar").innerHTML = html;
  } catch (e) { /* non-fatal */ }
}

function iberianRenderResults(data) {
  if (!data.baseline_ok) {
    $("iberianVerdictBar").innerHTML = '<div class="error-box">' + data.message + '</div>';
    $("iberianVoltChartWrap").innerHTML = ""; $("iberianMarginChartWrap").innerHTML = ""; $("iberianCompareStrip").innerHTML = "";
    return;
  }
  var s = data.summary;
  var vColor = s.verdict === "RECOVERABLE" ? "var(--teal)" : (s.verdict === "AT RISK" ? "var(--amber)" : "#FF6B6B");
  var vBg = s.verdict === "RECOVERABLE" ? "var(--teal-dim)" : (s.verdict === "AT RISK" ? "var(--amber-dim)" : "rgba(255,107,107,0.12)");

  $("iberianVerdictBar").innerHTML =
    '<div style="display:flex;gap:16px;align-items:center;padding:16px 18px;border-radius:8px;background:' + vBg + ';border:1px solid ' + vColor + ';margin-bottom:16px;">' +
    '<div style="font-family:var(--display);font-weight:800;font-size:20px;color:' + vColor + ';">' + s.verdict + '</div>' +
    '<div style="flex:1;font-size:11.5px;color:var(--text);">' +
    'Peak voltage at the renewable cluster: <b>' + s.max_v_es_sw.toFixed(3) + '</b> p.u. (trip threshold ' + data.v_trip.toFixed(2) + ') &middot; ' +
    'Settled voltage margin: <b>' + s.min_voltage_margin.toFixed(3) + '</b> p.u. &middot; ' +
    'Peak overvoltage-protection indicator: <b>' + (s.peak_trip_timer * 100).toFixed(0) + '%</b>' +
    '</div></div>';

  drawIberianVoltageChart(data);
  drawIberianMarginChart(data);

  $("iberianCompareStrip").innerHTML =
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:16px;">' +
    '<div class="side-panel" style="position:static;width:auto;padding:16px;">' +
    '<div style="font-size:10.5px;color:var(--muted);text-transform:uppercase;letter-spacing:0.05em;">Conventional (small-signal)</div>' +
    '<div style="font-family:var(--display);font-weight:800;font-size:18px;color:var(--teal);margin-top:4px;">STABLE</div>' +
    '<div style="font-size:11px;color:var(--muted);margin-top:4px;">All eigenvalues in the open left half-plane at the pre-disturbance operating point.</div></div>' +
    '<div class="side-panel" style="position:static;width:auto;padding:16px;">' +
    '<div style="font-size:10.5px;color:var(--muted);text-transform:uppercase;letter-spacing:0.05em;">IMS (large-signal)</div>' +
    '<div style="font-family:var(--display);font-weight:800;font-size:18px;color:' + vColor + ';margin-top:4px;">' + s.verdict + '</div>' +
    '<div style="font-size:11px;color:var(--muted);margin-top:4px;">Same operating point. Different large-signal answer once the scripted disturbance is applied.</div></div>' +
    '</div>';
}

function drawIberianVoltageChart(data) {
  var t = data.trajectory.t;
  var traces = data.voltage_traces;
  var busColors = { v_es_c: "#6FC6FF", v_es_sw: "#3FE0A8", v_pt: "#B18CFF", v_emb: "#FFB454" };
  var busLabels = { v_es_c: "Central Spain", v_es_sw: "SW renewable cluster", v_pt: "Portugal", v_emb: "Embedded zone" };
  var allVals = []; Object.keys(traces).forEach(function (k) { allVals = allVals.concat(traces[k]); });
  var ymin = Math.min.apply(null, allVals.concat([data.v_trip])) - 0.02;
  var ymax = Math.max.apply(null, allVals.concat([data.v_trip])) + 0.02;
  var bounds = { xmin: t[0], xmax: t[t.length - 1], ymin: ymin, ymax: ymax };
  var w = 640, h = 280, m = { l: 60, r: 14, t: 16, b: 46 };

  var html = '<div style="margin-top:8px;"><div style="font-family:var(--display);font-weight:700;font-size:12px;margin-bottom:6px;">Bus voltage response</div>' +
    '<canvas id="iberianVoltCanvas" width="' + w + '" height="' + h + '" style="width:100%;max-width:' + w + 'px;background:var(--panel-alt);border-radius:6px;"></canvas>' +
    '<div style="display:flex;gap:14px;margin-top:6px;flex-wrap:wrap;">';
  Object.keys(traces).forEach(function (k) {
    html += '<span style="font-size:10.5px;color:var(--muted);"><span style="display:inline-block;width:9px;height:9px;background:' + busColors[k] + ';border-radius:2px;margin-right:4px;"></span>' + (busLabels[k] || k) + '</span>';
  });
  html += '<span style="font-size:10.5px;color:#FF6B6B;"><span style="display:inline-block;width:14px;height:1px;border-top:1px dashed #FF6B6B;margin-right:4px;vertical-align:middle;"></span>Overvoltage trip threshold</span>';
  html += '</div>';
  html += '<div style="font-size:10px;color:var(--muted);margin-top:8px;line-height:1.5;max-width:640px;">' + (data.voltage_plot_note || "The implemented network has 5 buses; the Continental Europe equivalent bus is a fixed/infinite bus (1.0 p.u. by construction, not a dynamic state) and so has no trace of its own -- the 4 traces above are the model's complete set of dynamic bus voltages.") + '</div>';
  html += '</div>';
  // IMPORTANT: this writes to its OWN dedicated container
  // (iberianVoltChartWrap), never appended-to via innerHTML += on a
  // container that already holds a live, drawn canvas. An earlier
  // version had this chart's canvas and the margin chart's canvas
  // sharing one container, with the margin chart's render doing
  // `container.innerHTML += newHtml` -- reading+reassigning innerHTML
  // re-serialises the DOM from its TAGS only; a <canvas> tag carries no
  // record of what was drawn on it, so that re-serialisation silently
  // destroyed this chart's already-rendered pixels (the canvas element
  // is recreated with nothing drawn on it, and nothing re-draws it
  // afterwards). That was the entire cause of the "empty Bus voltage
  // response" bug -- not a data problem; the trajectory data was
  // correct the whole time.
  $("iberianVoltChartWrap").innerHTML = html;

  var ctx = $("iberianVoltCanvas").getContext("2d");
  drawGrid(ctx, bounds, w, h, m, "time (s)", "voltage (p.u.)");
  drawLine(ctx, [[bounds.xmin, data.v_trip], [bounds.xmax, data.v_trip]], bounds, w, h, m, "#FF6B6B", 1.4, [5, 4]);
  Object.keys(traces).forEach(function (k) {
    var pts = t.map(function (tv, i) { return [tv, traces[k][i]]; });
    drawLine(ctx, pts, bounds, w, h, m, busColors[k] || "#fff", 2);
  });
  (data.event_timeline || []).forEach(function (e) {
    var mp = mapPt([e.t, bounds.ymin], bounds, w, h, m);
    ctx.save(); ctx.strokeStyle = "rgba(255,180,84,0.5)"; ctx.setLineDash([2, 3]);
    ctx.beginPath(); ctx.moveTo(mp[0], m.t); ctx.lineTo(mp[0], h - m.b); ctx.stroke(); ctx.restore();
  });
}

function drawIberianMarginChart(data) {
  var t = data.trajectory.t;
  var timer = data.trip_timer_trace;
  var bounds = { xmin: t[0], xmax: t[t.length - 1], ymin: 0, ymax: 1 };
  var w = 640, h = 230, m = { l: 64, r: 14, t: 16, b: 46 };
  var html = '<div style="margin-top:14px;"><div style="font-family:var(--display);font-weight:700;font-size:12px;margin-bottom:6px;">' +
    'Overvoltage-protection indicator (0 = clear, 1 = tripped)</div>' +
    '<canvas id="iberianMarginCanvas" width="' + w + '" height="' + h + '" style="width:100%;max-width:' + w + 'px;background:var(--panel-alt);border-radius:6px;"></canvas>' +
    chartLegendHtml([
      { color: "#B18CFF", label: "Protection indicator" },
      { color: "#FFB454", label: "Trip threshold (0.5)", dashed: true },
    ]) + '</div>';
  // Own dedicated container (iberianMarginChartWrap) -- see the note in
  // drawIberianVoltageChart for why this matters.
  $("iberianMarginChartWrap").innerHTML = html;
  var ctx = $("iberianMarginCanvas").getContext("2d");
  drawGrid(ctx, bounds, w, h, m, "time (s)", "Protection indicator", {
    yTicks: [0, 0.25, 0.5, 0.75, 1.0],
    tickFontSize: 13,
    yTitleFontSize: 11,   // the full "Overvoltage-protection indicator (0-1)" wording (already in the
                           // heading above) does not fit rotated in this chart's height at normal size --
                           // verified by pixel-inspecting an actual render, where it ran off the canvas
                           // edge; shortened + sized specifically to fit within (h - m.t - m.b).
  });
  drawLine(ctx, [[bounds.xmin, 0.5], [bounds.xmax, 0.5]], bounds, w, h, m, "#FFB454", 1.2, [4, 3]);
  var pts = t.map(function (tv, i) { return [tv, timer[i]]; });
  drawLine(ctx, pts, bounds, w, h, m, "#B18CFF", 2.2);
}

async function iberianRunCounterfactual() {
  $("iberianCounterfactual").innerHTML = '<div class="sub" style="margin-top:14px;">Running baseline and dynamic-Q counterfactual (two full simulations)&hellip;</div>';
  try {
    var resp = await fetch("/api/iberian/counterfactual", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ severity: 1.0 }),
    });
    var data = await resp.json();
    if (data.error) { $("iberianCounterfactual").innerHTML = '<div class="error-box">' + data.error + '</div>'; return; }
    renderIberianCounterfactual(data);
  } catch (e) {
    $("iberianCounterfactual").innerHTML = '<div class="error-box">Request failed: ' + e + '</div>';
  }
}

function renderIberianCounterfactual(data) {
  var vColorB = "#FF6B6B", vColorD = "#3FE0A8";
  var html = '<div style="margin-top:20px;">' +
    '<div style="font-family:var(--display);font-weight:700;font-size:13px;margin-bottom:2px;">Baseline vs. dynamic-Q counterfactual</div>' +
    '<div style="font-size:10.5px;color:var(--muted);margin-bottom:10px;max-width:640px;line-height:1.5;">' + data.note + '</div>' +
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;">' +
    '<div class="side-panel" style="position:static;width:auto;padding:14px;border-color:' + vColorB + ';">' +
    '<div style="font-size:10px;color:var(--muted);text-transform:uppercase;">Baseline &mdash; K\u1D64 = ' + data.kq_baseline.toFixed(1) + ' (fixed power factor)</div>' +
    '<div style="font-family:var(--display);font-weight:800;font-size:18px;color:' + vColorB + ';margin-top:4px;">' + data.baseline.summary.verdict + '</div></div>' +
    '<div class="side-panel" style="position:static;width:auto;padding:14px;border-color:' + vColorD + ';">' +
    '<div style="font-size:10px;color:var(--muted);text-transform:uppercase;">Dynamic-Q &mdash; K\u1D64 = ' + data.kq_dynamic_q.toFixed(1) + '</div>' +
    '<div style="font-family:var(--display);font-weight:800;font-size:18px;color:' + vColorD + ';margin-top:4px;">' + data.dynamic_q.summary.verdict + '</div></div>' +
    '</div>' +
    '<table style="width:100%;border-collapse:collapse;font-size:11px;">' +
    '<tr style="border-bottom:1px solid var(--border);"><td style="padding:6px 4px;color:var(--muted);">Metric</td>' +
    '<td style="padding:6px 4px;color:' + vColorB + ';text-align:right;">Baseline</td>' +
    '<td style="padding:6px 4px;color:' + vColorD + ';text-align:right;">Dynamic-Q</td></tr>';
  data.comparison_table.forEach(function (row) {
    html += '<tr style="border-bottom:1px solid var(--border);"><td style="padding:6px 4px;color:var(--text);">' + row.metric + '</td>' +
      '<td style="padding:6px 4px;text-align:right;font-family:var(--mono);">' + row.baseline + '</td>' +
      '<td style="padding:6px 4px;text-align:right;font-family:var(--mono);">' + row.dynamic_q + '</td></tr>';
  });
  html += '</table>' +
    '<div style="font-size:10px;color:var(--muted);margin-top:8px;">Fixed for both runs: Q_avail=' + data.fixed_params.Q_avail +
    ', Imax=' + data.fixed_params.Imax + ', gfm_fraction=' + data.fixed_params.gfm_fraction + '. Only K\u1D64 differs.</div></div>';
  $("iberianCounterfactual").innerHTML = html;
}

async function iberianRunBoundaryMap() {
  $("iberianBoundaryChart").innerHTML = '<div class="sub" style="margin-top:14px;">Tracing recoverability boundary&hellip;</div>';
  try {
    var resp = await fetch("/api/iberian/boundary_map", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ params: iberianParams }),
    });
    var data = await resp.json();
    if (data.error) { $("iberianBoundaryChart").innerHTML = '<div class="error-box">' + data.error + '</div>'; return; }
    drawIberianBoundary(data);
  } catch (e) {
    $("iberianBoundaryChart").innerHTML = '<div class="error-box">Request failed: ' + e + '</div>';
  }
}

function drawIberianBoundary(data) {
  var pts = data.points.filter(function (p) { return p.recoverable !== null; });
  var w = 640, h = 240, m = { l: 64, r: 14, t: 16, b: 46 };
  var html = '<div style="margin-top:20px;"><div style="font-family:var(--display);font-weight:700;font-size:12px;margin-bottom:6px;">' +
    'Recoverability vs. disturbance severity (current slider settings)</div>' +
    '<canvas id="iberianBoundaryCanvas" width="' + w + '" height="' + h + '" style="width:100%;max-width:' + w + 'px;background:var(--panel-alt);border-radius:6px;"></canvas>' +
    '<div style="font-size:10.5px;color:var(--muted);margin-top:8px;line-height:1.5;">' +
    'Severity 1.0&#215; = the documented 355/727/928 MW-equivalent event magnitudes.<br/>' +
    'Recoverability score: 0 = NON-RECOVERABLE, 0.5 = AT RISK, 1 = RECOVERABLE (a direct encoding of the verdict, not an independently measured continuous quantity).' +
    '</div></div>';
  $("iberianBoundaryChart").innerHTML = html;
  if (!pts.length) return;
  var ctx = $("iberianBoundaryCanvas").getContext("2d");
  var scoreOf = { "RECOVERABLE": 1.0, "AT RISK": 0.5, "NON-RECOVERABLE": 0.0 };
  var xs = pts.map(function (p) { return p.severity; });
  // Bounds pad a little past the actual data so the outermost bars/ticks
  // aren't drawn flush against the plot border.
  var xPad = (xs.length > 1 ? (xs[1] - xs[0]) : 0.1) * 0.6;
  var bounds = { xmin: Math.min.apply(null, xs) - xPad, xmax: Math.max.apply(null, xs) + xPad, ymin: 0, ymax: 1.5 };
  // Explicit ticks at the ACTUAL simulated severities (not an auto count-
  // based interpolation between xmin/xmax, which previously produced
  // mismatched labels like 0.36/0.52/0.68/0.84 that don't correspond to
  // any simulated point and collided with the axis title below them).
  drawGrid(ctx, bounds, w, h, m, "Disturbance severity (\u00D7 documented magnitude)", "Recoverability score", {
    xTicks: xs,
    yTicks: [0.0, 0.5, 1.0, 1.5],
    tickFontSize: 13,
  });
  var barW = Math.max(18, (w - m.l - m.r) / (xs.length * 2.2));
  pts.forEach(function (p) {
    var color = p.verdict === "RECOVERABLE" ? "#3FE0A8" : (p.verdict === "AT RISK" ? "#FFB454" : "#FF6B6B");
    var score = scoreOf[p.verdict];
    var mpTop = mapPt([p.severity, score], bounds, w, h, m);
    var mpBot = mapPt([p.severity, 0], bounds, w, h, m);
    if (score > 0) {
      ctx.fillStyle = color;
      ctx.fillRect(mpTop[0] - barW / 2, mpTop[1], barW, mpBot[1] - mpTop[1]);
    } else {
      // score === 0 (NON-RECOVERABLE) draws a zero-height bar, which is
      // otherwise indistinguishable from "no data was simulated at this
      // severity" -- draw an explicit marker + "0.0" label instead, so a
      // viewer can immediately tell "measured, and the value is zero"
      // apart from "not evaluated". Score mapping/verdict/data unchanged;
      // this is purely a rendering choice for the already-zero value.
      var baseX = mpBot[0], baseY = mpBot[1];
      ctx.fillStyle = color;
      ctx.beginPath(); ctx.arc(baseX, baseY, 5, 0, 2 * Math.PI); ctx.fill();
      ctx.strokeStyle = "#06120E"; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.fillStyle = color; ctx.font = "11px monospace";
      ctx.textAlign = "center"; ctx.textBaseline = "alphabetic";
      ctx.fillText("0.0", baseX, baseY - 10);
    }
  });
}

/* ---- 2-D boundary map (KQ x severity), rendered as a colour grid ---- */
async function iberianRun2DBoundaryMap() {
  $("iberianBoundary2DChart").innerHTML = '<div class="sub" style="margin-top:14px;">Computing 2-D boundary (this runs ~30 simulations)&hellip;</div>';
  try {
    var resp = await fetch("/api/iberian/boundary_map_2d", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        params: iberianParams, x_param: "KQ",
        x_values: [0, 4, 8, 12, 16, 20], severities: [0.2, 0.4, 0.6, 0.8, 1.0],
      }),
    });
    var data = await resp.json();
    if (data.error) { $("iberianBoundary2DChart").innerHTML = '<div class="error-box">' + data.error + '</div>'; return; }
    drawIberianBoundary2D(data);
  } catch (e) {
    $("iberianBoundary2DChart").innerHTML = '<div class="error-box">Request failed: ' + e + '</div>';
  }
}

function drawIberianBoundary2D(data) {
  var vColor = { "RECOVERABLE": "#3FE0A8", "AT RISK": "#FFB454", "NON-RECOVERABLE": "#FF6B6B" };
  var html = '<div style="margin-top:20px;"><div style="font-family:var(--display);font-weight:700;font-size:12px;margin-bottom:2px;">' +
    '2-D recoverability boundary: ' + data.x_label + ' &times; disturbance severity</div>' +
    '<div style="font-size:10.5px;color:var(--muted);margin-bottom:8px;">Every cell is an independent simulated stress test &mdash; not interpolated.</div>' +
    '<table style="border-collapse:collapse;font-family:var(--mono);font-size:10px;">';
  html += '<tr><td></td>';
  data.severities.forEach(function (s) { html += '<td style="padding:4px 8px;color:var(--muted);text-align:center;">' + s.toFixed(1) + '\u00D7</td>'; });
  html += '</tr>';
  data.x_values.forEach(function (xv, i) {
    html += '<tr><td style="padding:4px 8px;color:var(--muted);text-align:right;">' + xv.toFixed(0) + '</td>';
    data.grid[i].forEach(function (cell) {
      var color = cell.verdict ? vColor[cell.verdict] : "#333";
      html += '<td style="padding:8px 10px;background:' + color + ';text-align:center;color:#06120E;font-weight:700;" title="' + (cell.final_v_es_sw != null ? cell.final_v_es_sw.toFixed(3) : "") + '"></td>';
    });
    html += '</tr>';
  });
  html += '</table>';
  html += '<div style="font-size:10px;color:var(--muted);margin-top:6px;">rows = ' + data.x_label + ', columns = disturbance severity. Green = recoverable, amber = at risk, red = non-recoverable.</div></div>';
  $("iberianBoundary2DChart").innerHTML = html;
}

/* ---- GFM 0/20/40% comparison, reported honestly across severities ---- */
async function iberianRunGfmComparison() {
  $("iberianGfmChart").innerHTML = '<div class="sub" style="margin-top:14px;">Running GFM comparison&hellip;</div>';
  try {
    var resp = await fetch("/api/iberian/gfm_comparison", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ params: iberianParams, gfm_fractions: [0.0, 0.2, 0.4], severities: [0.4, 0.6, 0.8, 1.0] }),
    });
    var data = await resp.json();
    if (data.error) { $("iberianGfmChart").innerHTML = '<div class="error-box">' + data.error + '</div>'; return; }
    drawIberianGfmComparison(data);
  } catch (e) {
    $("iberianGfmChart").innerHTML = '<div class="error-box">Request failed: ' + e + '</div>';
  }
}

function drawIberianGfmComparison(data) {
  var vColor = { "RECOVERABLE": "#3FE0A8", "AT RISK": "#FFB454", "NON-RECOVERABLE": "#FF6B6B" };
  var html = '<div style="margin-top:20px;"><div style="font-family:var(--display);font-weight:700;font-size:12px;margin-bottom:8px;">GFM penetration comparison</div>';
  html += '<table style="border-collapse:collapse;font-family:var(--mono);font-size:10px;"><tr><td></td>';
  data.rows[0].points.forEach(function (p) { html += '<td style="padding:4px 8px;color:var(--muted);text-align:center;">' + p.severity.toFixed(1) + '\u00D7</td>'; });
  html += '</tr>';
  data.rows.forEach(function (row) {
    html += '<tr><td style="padding:4px 8px;color:var(--muted);text-align:right;">' + Math.round(row.gfm_fraction * 100) + '% GFM</td>';
    row.points.forEach(function (p) {
      var color = p.verdict ? vColor[p.verdict] : "#333";
      html += '<td style="padding:8px 10px;background:' + color + ';text-align:center;color:#06120E;font-weight:700;" title="' + (p.final_v_es_sw != null ? p.final_v_es_sw.toFixed(3) : "") + '"></td>';
    });
    html += '</tr>';
  });
  html += '</table>';
  html += '<div style="font-size:11px;color:var(--muted);margin-top:8px;max-width:640px;line-height:1.5;">' + data.note + '</div></div>';
  $("iberianGfmChart").innerHTML = html;
}

/* ---- intervention recommendation engine ---- */
async function iberianRunRecommendations() {
  $("iberianRecommendations").innerHTML = '<div class="sub" style="margin-top:14px;">Searching interventions (real simulations, not a formula)&hellip;</div>';
  try {
    var resp = await fetch("/api/iberian/recommendations", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ params: iberianParams, severity: 1.0 }),
    });
    var data = await resp.json();
    if (data.error) { $("iberianRecommendations").innerHTML = '<div class="error-box">' + data.error + '</div>'; return; }
    renderIberianRecommendations(data);
  } catch (e) {
    $("iberianRecommendations").innerHTML = '<div class="error-box">Request failed: ' + e + '</div>';
  }
}

function renderIberianRecommendations(data) {
  var html = '<div style="margin-top:20px;"><div style="font-family:var(--display);font-weight:700;font-size:12px;margin-bottom:4px;">Recommended interventions</div>' +
    '<div style="font-size:10.5px;color:var(--muted);margin-bottom:10px;">Baseline verdict at these sliders: <b>' + data.baseline_verdict + '</b></div>';
  data.strategies.forEach(function (s) {
    var color = s.achievable ? "var(--teal)" : "var(--muted)";
    html += '<div style="display:flex;justify-content:space-between;gap:12px;padding:8px 0;border-top:1px solid var(--border);font-size:11.5px;">' +
      '<span style="color:var(--text);">' + s.label + '</span>' +
      '<span style="font-family:var(--mono);color:' + color + ';text-align:right;">' + s.value_label + '</span></div>';
  });
  html += '<div style="font-size:10px;color:var(--muted);margin-top:10px;">' + data.note + '</div></div>';
  $("iberianRecommendations").innerHTML = html;
}

/* ---- shared recommendation-engine renderer (GFM / Multi-Converter) ---- */
function renderRecommendationsGeneric(data, targetElId) {
  var html = '<div style="margin-top:20px;"><div style="font-family:var(--display);font-weight:700;font-size:12px;margin-bottom:4px;">Recommended interventions</div>' +
    '<div style="font-size:10.5px;color:var(--muted);margin-bottom:10px;">Baseline verdict at these sliders: <b>' + data.baseline_verdict + '</b>' +
    (data.limiting_converter ? ' &middot; Limiting converter/bus: <b>' + data.limiting_converter + '</b>' : '') + '</div>';
  data.strategies.forEach(function (s) {
    var color = s.achievable ? "var(--teal)" : "var(--muted)";
    html += '<div style="display:flex;justify-content:space-between;gap:12px;padding:8px 0;border-top:1px solid var(--border);font-size:11.5px;">' +
      '<span style="color:var(--text);">' + s.label + '</span>' +
      '<span style="font-family:var(--mono);color:' + color + ';text-align:right;">' + s.value_label + '</span></div>';
  });
  if (data.not_applicable_levers && data.not_applicable_levers.length) {
    html += '<div style="font-size:10px;color:var(--muted);margin-top:10px;border-left:2px solid var(--border);padding-left:8px;">Not applicable to this case: ' + data.not_applicable_levers.join(' ') + '</div>';
  }
  if (data.limiting_converter_note) {
    html += '<div style="font-size:10px;color:var(--muted);margin-top:6px;">' + data.limiting_converter_note + '</div>';
  }
  html += '<div style="font-size:10px;color:var(--muted);margin-top:10px;">' + data.note + '</div></div>';
  $(targetElId).innerHTML = html;
}

async function gfmCaseRunRecommendations() {
  $("gfmCaseRecommendations").innerHTML = '<div class="sub" style="margin-top:20px;">Searching interventions (real simulations)&hellip;</div>';
  try {
    var resp = await fetch("/api/gfm_current_limit/recommendations", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ params: gfmCaseParams }),
    });
    var data = await resp.json();
    if (data.error) { $("gfmCaseRecommendations").innerHTML = '<div class="error-box">' + data.error + '</div>'; return; }
    renderRecommendationsGeneric(data, "gfmCaseRecommendations");
  } catch (e) {
    $("gfmCaseRecommendations").innerHTML = '<div class="error-box">Request failed: ' + e + '</div>';
  }
}

async function multiConvRunRecommendations() {
  $("multiConvRecommendations").innerHTML = '<div class="sub" style="margin-top:20px;">Searching interventions across both converters (real simulations, may take a little while)&hellip;</div>';
  try {
    var resp = await fetch("/api/multi_converter_fault/recommendations", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ params: multiConvParams }),
    });
    var data = await resp.json();
    if (data.error) { $("multiConvRecommendations").innerHTML = '<div class="error-box">' + data.error + '</div>'; return; }
    renderRecommendationsGeneric(data, "multiConvRecommendations");
  } catch (e) {
    $("multiConvRecommendations").innerHTML = '<div class="error-box">Request failed: ' + e + '</div>';
  }
}

/* ---- True IMS Geometry ---- */
async function iberianRunImsGeometry() {
  $("iberianImsGeometry").innerHTML = '<div class="sub" style="margin-top:20px;">Computing intrinsic manifold, d_M(t), \u03bb\u22a5(t), \u03b3_IMS, and the Region of Attraction (ROA) slice (this runs several dozen real simulations, ~10-20s)&hellip;</div>';
  try {
    var resp = await fetch("/api/iberian/ims_geometry", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ params: iberianParams, severity: 1.0, roa_n_v: 7, roa_n_timer: 5 }),
    });
    var data = await resp.json();
    if (data.error) { $("iberianImsGeometry").innerHTML = '<div class="error-box">' + data.error + '</div>'; return; }
    if (!data.available) { $("iberianImsGeometry").innerHTML = '<div class="error-box">' + (data.message || "IMS geometry not available") + '</div>'; return; }
    renderIberianImsGeometry(data);
  } catch (e) {
    $("iberianImsGeometry").innerHTML = '<div class="error-box">Request failed: ' + e + '</div>';
  }
}

function renderIberianImsGeometry(data) {
  var mt = data.manifold_trace, g = data.gamma_ims, roa = data.roa_slice;
  var html = '<div style="margin-top:22px;padding-top:16px;border-top:2px solid var(--purple);">' +
    '<div style="font-family:var(--display);font-weight:800;font-size:14px;color:var(--purple);margin-bottom:4px;">True IMS Geometry</div>' +
    '<div style="font-size:10.5px;color:var(--muted);margin-bottom:14px;max-width:640px;">' + data.manifold_definition + '</div>';

  // d_M(t) chart
  var w = 640, h = 200, m = { l: 60, r: 14, t: 16, b: 46 };
  var t = mt.t;
  var boundsD = { xmin: t[0], xmax: t[t.length-1], ymin: 0, ymax: Math.max.apply(null, mt.d_M) * 1.1 + 0.01 };
  html += '<div style="font-family:var(--display);font-weight:700;font-size:12px;margin:10px 0 6px;">Manifold distance d_M(t)</div>' +
    '<canvas id="imsGeoDmCanvas" width="' + w + '" height="' + h + '" style="width:100%;max-width:' + w + 'px;background:var(--panel-alt);border-radius:6px;"></canvas>' +
    chartLegendHtml([{ color: "#B18CFF", label: "d_M(t) = |timer - timer*(v)|" }]);

  // lambda_perp(t) chart
  var boundsL = { xmin: t[0], xmax: t[t.length-1], ymin: Math.min.apply(null, mt.lambda_perp) - 0.3, ymax: 0.3 };
  html += '<div style="font-family:var(--display);font-weight:700;font-size:12px;margin:14px 0 6px;">Transverse rate \u03bb\u22a5(t)</div>' +
    '<canvas id="imsGeoLambdaCanvas" width="' + w + '" height="' + h + '" style="width:100%;max-width:' + w + 'px;background:var(--panel-alt);border-radius:6px;"></canvas>' +
    chartLegendHtml([{ color: "#6FC6FF", label: "\u03bb\u22a5(t)" }, { color: "#FF6B6B", label: "Contracting / expanding boundary (0)", dashed: true }]) +
    '<div style="font-size:10px;color:var(--muted);margin-top:4px;">' + (mt.transversally_contracting_throughout ? "Transversally contracting throughout this trajectory (\u03bb\u22a5(t) < 0 everywhere)." : "NOT contracting at every point -- see chart.") + '</div>';

  // gamma_IMS table
  html += '<div style="font-family:var(--display);font-weight:700;font-size:12px;margin:16px 0 6px;">\u03b3_IMS</div>' +
    '<table style="width:100%;font-size:11px;border-collapse:collapse;">' +
    '<tr style="border-bottom:1px solid var(--border);"><td style="padding:5px 4px;color:var(--muted);">\u03bb\u22a5 (pre-disturbance eq.)</td><td style="padding:5px 4px;text-align:right;font-family:var(--mono);">' + g.lambda_perp_analytic.toFixed(4) + ' /s</td></tr>' +
    '<tr style="border-bottom:1px solid var(--border);"><td style="padding:5px 4px;color:var(--muted);">Slowest network eigenvalue</td><td style="padding:5px 4px;text-align:right;font-family:var(--mono);">' + g.lambda_slow_network.toFixed(4) + ' /s</td></tr>' +
    '<tr style="border-bottom:1px solid var(--border);"><td style="padding:5px 4px;color:var(--muted);">\u03b5 (operational ratio)</td><td style="padding:5px 4px;text-align:right;font-family:var(--mono);">' + g.epsilon_operational.toFixed(4) + '</td></tr>' +
    '<tr style="border-bottom:1px solid var(--border);"><td style="padding:5px 4px;color:var(--text);font-weight:700;">\u03b3_IMS = |\u03bb\u22a5|\u00b2 / |\u03bb_slow|</td><td style="padding:5px 4px;text-align:right;font-family:var(--mono);color:var(--purple);font-weight:700;">' + g.gamma_ims.toFixed(4) + '</td></tr>' +
    '</table>';
  if (g.timescale_separation_is_weak) {
    html += '<div style="font-size:10px;color:var(--amber);border-left:2px solid var(--amber);padding:6px 10px;background:rgba(255,180,84,0.06);margin-top:8px;">Time-scale separation at this operating point is WEAK (ratio &asymp; ' + (Math.abs(g.lambda_perp_analytic)/Math.abs(g.lambda_slow_network)).toFixed(2) + ', not &laquo;1). The manifold construction is exact regardless, but classical asymptotic O(&epsilon;)-closeness guarantees are not strongly established here.</div>';
  }

  // ROA slice grid
  html += '<div style="font-family:var(--display);font-weight:700;font-size:12px;margin:16px 0 4px;">Region of Attraction (ROA) slice</div>' +
    '<div style="font-size:10px;color:var(--muted);margin-bottom:8px;max-width:640px;">2-D slice through (' + roa.v_state + ', ' + roa.timer_state + '), all other state coordinates frozen at the values below. Each cell = one independently simulated trajectory.</div>' +
    '<div id="imsGeoRoaGrid"></div>';

  html += '</div>';
  $("iberianImsGeometry").innerHTML = html;

  var ctxD = $("imsGeoDmCanvas").getContext("2d");
  drawGrid(ctxD, boundsD, w, h, m, "time (s)", "d_M", { tickFontSize: 12 });
  drawLine(ctxD, t.map(function (tv, i) { return [tv, mt.d_M[i]]; }), boundsD, w, h, m, "#B18CFF", 2.0);

  var ctxL = $("imsGeoLambdaCanvas").getContext("2d");
  drawGrid(ctxL, boundsL, w, h, m, "time (s)", "\u03bb\u22a5 (1/s)", { tickFontSize: 12 });
  drawLine(ctxL, [[boundsL.xmin, 0], [boundsL.xmax, 0]], boundsL, w, h, m, "#FF6B6B", 1.2, [4, 3]);
  drawLine(ctxL, t.map(function (tv, i) { return [tv, mt.lambda_perp[i]]; }), boundsL, w, h, m, "#6FC6FF", 2.0);

  drawRoaGrid(roa);
}

function drawRoaGrid(roa) {
  var nV = roa.v_values.length, nT = roa.timer_values.length;
  var w = 620, h = 300, m = { l: 70, r: 14, t: 10, b: 46 };
  var html = '<canvas id="imsGeoRoaCanvas" width="' + w + '" height="' + h + '" style="width:100%;max-width:' + w + 'px;background:var(--panel-alt);border-radius:6px;"></canvas>' +
    chartLegendHtml([{ color: "#3FE0A8", label: "Recoverable (inside ROA)" }, { color: "#FF6B6B", label: "Non-recoverable (outside ROA)" }]);
  $("imsGeoRoaGrid").innerHTML = html;
  var ctx = $("imsGeoRoaCanvas").getContext("2d");
  var cellW = (w - m.l - m.r) / nV, cellH = (h - m.t - m.b) / nT;
  ctx.clearRect(0, 0, w, h);
  for (var i = 0; i < nT; i++) {
    for (var j = 0; j < nV; j++) {
      var cell = roa.grid[i][j];
      ctx.fillStyle = cell.recoverable ? "#3FE0A8" : "#FF6B6B";
      // row 0 = timer_values[0] (bottom of physical axis, low timer) -- draw bottom-up
      var yTop = m.t + (nT - 1 - i) * cellH;
      ctx.fillRect(m.l + j * cellW, yTop, cellW - 1, cellH - 1);
    }
  }
  ctx.strokeStyle = "#4A6070"; ctx.lineWidth = 1.5;
  ctx.strokeRect(m.l, m.t, w - m.l - m.r, h - m.t - m.b);
  ctx.fillStyle = "#CBD8E4"; ctx.font = "11px monospace"; ctx.textAlign = "center"; ctx.textBaseline = "top";
  roa.v_values.forEach(function (v, j) {
    ctx.fillText(v.toFixed(2), m.l + (j + 0.5) * cellW, h - m.b + 6);
  });
  ctx.textAlign = "right"; ctx.textBaseline = "middle";
  roa.timer_values.forEach(function (tm, i) {
    ctx.fillText(tm.toFixed(2), m.l - 8, m.t + (nT - 1 - i + 0.5) * cellH);
  });
  ctx.save(); ctx.fillStyle = "#DCE6EF"; ctx.font = "12px monospace"; ctx.textAlign = "center";
  ctx.fillText(roa.v_state + " (p.u.), initial condition", m.l + (w - m.l - m.r) / 2, h - 8);
  ctx.translate(16, m.t + (h - m.t - m.b) / 2); ctx.rotate(-Math.PI / 2);
  ctx.fillText("trip_timer, initial condition", 0, 0);
  ctx.restore();
}

/* ===================== GFM CURRENT-LIMIT RECOVERY CASE ===================== */

var gfmCaseParams = { Imax: 0.4 };

async function showGfmCurrentLimitCase() {
  activateSurface("gfmCaseView", "Case Library", '<b onclick="showProjectManager()">Projects</b> &rsaquo; <span onclick="showCaseLibrary()" style="cursor:pointer;">Case Library</span> &rsaquo; GFM Recovery');
  if (!$("gfmCaseView").dataset.built) {
    $("gfmCaseView").innerHTML =
      '<div style="margin-bottom:22px;">' +
      '<div style="font-family:var(--mono);font-size:11px;color:var(--teal);letter-spacing:0.06em;text-transform:uppercase;margin-bottom:6px;">Case Library &rsaquo; Fault Ride-Through</div>' +
      '<h1 style="font-family:var(--display);font-size:26px;margin:0 0 8px;">GFM Current-Limit Recovery</h1>' +
      '<p class="sub" style="max-width:820px;">A single grid-forming converter (a Thevenin voltage source behind a fixed internal reactance, with its own current limit) at the point of common coupling of a weak grid. A temporary heavy local load (a fault) is applied and cleared; the converter\'s own current rating determines how deep the voltage dip goes.</p>' +
      '<div id="gfmCaseDisclaimer" class="sub" style="font-size:11px;color:var(--muted);border-left:2px solid var(--teal);padding:8px 12px;background:rgba(63,224,168,0.06);border-radius:0 6px 6px 0;max-width:820px;"></div>' +
      '</div>' +
      '<div style="display:grid;grid-template-columns:300px 1fr;gap:20px;align-items:start;">' +
      '<div class="side-panel" style="position:static;width:auto;max-width:none;padding:18px;">' +
      '<div style="font-family:var(--display);font-weight:700;font-size:13px;margin-bottom:4px;">Stress-test controls</div>' +
      '<div style="font-size:11px;color:var(--muted);margin-bottom:14px;">Same 150 ms local fault every time. Current limit is the only thing that changes.</div>' +
      '<div id="gfmCaseSliders"></div>' +
      '<button class="hero-cta-btn hero-cta-primary" style="width:100%;margin-top:10px;padding:11px 0;" onclick="gfmCaseRunStressTest()">RUN STRESS TEST</button>' +
      '<button class="secondary-btn" style="width:100%;margin-top:8px;" onclick="gfmCaseRunSweep()">Trace Imax sensitivity</button>' +
      '<button class="secondary-btn" style="width:100%;margin-top:8px;" onclick="gfmCaseRunRecommendations()">Get recommended interventions</button>' +
      '<button class="secondary-btn" style="width:100%;margin-top:8px;border-color:var(--purple);color:var(--purple);" onclick="gfmCaseRunImsGeometry()">True IMS Geometry</button>' +
      '<div style="margin-top:18px;padding-top:14px;border-top:1px solid var(--border);">' +
      '<button class="secondary-btn" style="width:100%;" onclick="generateReport(\'gfm_current_limit_recovery\', gfmCaseParams, {include_sweep:true, include_recommendations:true, include_ims_geometry:true}, \'gfmCaseReportActions\')">GENERATE FINAL REPORT</button>' +
      '<div id="gfmCaseReportActions" style="margin-top:8px;"></div>' +
      '</div></div>' +
      '<div><div id="gfmCaseVerdictBar"></div><div id="gfmCaseChart"></div><div id="gfmCaseCurrentChart"></div><div id="gfmCaseSweepChart"></div><div id="gfmCaseRecommendations"></div><div id="gfmCaseImsGeometry"></div></div>' +
      '</div>';
    $("gfmCaseView").dataset.built = "1";
  }
  renderGfmCaseSliders();
  try {
    var resp = await fetch("/api/gfm_current_limit/stress_test", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ params: {} }),
    });
    var data = await resp.json();
    $("gfmCaseDisclaimer").textContent = data.disclaimer || "";
  } catch (e) { /* non-fatal */ }
}

function renderGfmCaseSliders() {
  var v = gfmCaseParams.Imax;
  $("gfmCaseSliders").innerHTML =
    '<div style="margin-bottom:16px;">' +
    '<div style="display:flex;justify-content:space-between;font-size:11.5px;color:var(--text);margin-bottom:4px;">' +
    '<span>Converter current limit (Imax, p.u.)</span><span id="gfmCaseVal_Imax" style="font-family:var(--mono);color:var(--teal);">' + v.toFixed(2) + '</span></div>' +
    '<input type="range" min="0.1" max="4.0" step="0.05" value="' + v + '" style="width:100%;" ' +
    'oninput="gfmCaseParams.Imax=parseFloat(this.value); $(\'gfmCaseVal_Imax\').textContent=gfmCaseParams.Imax.toFixed(2);"/></div>';
}

async function gfmCaseRunStressTest() {
  $("gfmCaseVerdictBar").innerHTML = '<div class="sub">Running stress test&hellip;</div>';
  $("gfmCaseSweepChart").innerHTML = "";
  $("gfmCaseCurrentChart").innerHTML = "";
  try {
    var resp = await fetch("/api/gfm_current_limit/stress_test", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ params: gfmCaseParams }),
    });
    var data = await resp.json();
    if (data.error) { $("gfmCaseVerdictBar").innerHTML = '<div class="error-box">' + data.error + '</div>'; return; }
    if (!data.baseline_ok) { $("gfmCaseVerdictBar").innerHTML = '<div class="error-box">' + data.message + '</div>'; return; }
    var s = data.summary;
    var vColor = s.verdict === "RECOVERABLE" ? "var(--teal)" : (s.verdict === "AT RISK" ? "var(--amber)" : "#FF6B6B");
    var vBg = s.verdict === "RECOVERABLE" ? "var(--teal-dim)" : (s.verdict === "AT RISK" ? "var(--amber-dim)" : "rgba(255,107,107,0.12)");
    $("gfmCaseVerdictBar").innerHTML =
      '<div style="display:flex;gap:16px;align-items:center;padding:16px 18px;border-radius:8px;background:' + vBg + ';border:1px solid ' + vColor + ';margin-bottom:16px;">' +
      '<div style="font-family:var(--display);font-weight:800;font-size:20px;color:' + vColor + ';">' + s.verdict + '</div>' +
      '<div style="flex:1;font-size:11.5px;color:var(--text);">Minimum voltage during fault: <b>' + s.min_v_poc.toFixed(3) + '</b> p.u. (critical threshold ' + data.v_critical.toFixed(2) + ', at-risk ' + data.v_at_risk.toFixed(2) + ') &middot; Settled voltage: <b>' + s.final_v_poc.toFixed(3) + '</b> p.u. &middot; Peak current utilization: <b>' + (s.peak_current_utilization * 100).toFixed(0) + '%</b>' + (s.current_limit_active ? ' <span style="color:#FF6B6B;">(current-limited)</span>' : '') + '</div></div>';
    var w = 640, h = 260, m = { l: 60, r: 14, t: 16, b: 46 };
    var t = data.trajectory.t, v = data.voltage_trace;
    var bounds = { xmin: t[0], xmax: t[t.length - 1], ymin: Math.min.apply(null, v) - 0.05, ymax: Math.max.apply(null, v) + 0.05 };
    $("gfmCaseChart").innerHTML = '<div style="margin-top:8px;"><div style="font-family:var(--display);font-weight:700;font-size:12px;margin-bottom:6px;">Point-of-connection voltage response</div>' +
      '<canvas id="gfmCaseCanvas" width="' + w + '" height="' + h + '" style="width:100%;max-width:' + w + 'px;background:var(--panel-alt);border-radius:6px;"></canvas>' +
      chartLegendHtml([
        { color: "#3FE0A8", label: "v_poc" },
        { color: "#FF6B6B", label: "Critical (non-recoverable) threshold", dashed: true },
        { color: "#FFB454", label: "At-risk threshold", dashed: true },
      ]) + '</div>';
    var ctx = $("gfmCaseCanvas").getContext("2d");
    drawGrid(ctx, bounds, w, h, m, "time (s)", "voltage (p.u.)", { tickFontSize: 13 });
    drawLine(ctx, [[bounds.xmin, data.v_critical], [bounds.xmax, data.v_critical]], bounds, w, h, m, "#FF6B6B", 1.2, [4, 3]);
    drawLine(ctx, [[bounds.xmin, data.v_at_risk], [bounds.xmax, data.v_at_risk]], bounds, w, h, m, "#FFB454", 1.2, [4, 3]);
    drawLine(ctx, t.map(function (tv, i) { return [tv, v[i]]; }), bounds, w, h, m, "#3FE0A8", 2.2);

    // Current-limit utilization chart, own dedicated container (see
    // drawIberianVoltageChart's note on why charts must never share a
    // container with innerHTML +=).
    if (data.current_trace) {
      var ci = data.current_trace;
      var w2 = 640, h2 = 230, m2 = { l: 60, r: 14, t: 16, b: 46 };
      var bounds2 = { xmin: t[0], xmax: t[t.length - 1], ymin: 0, ymax: 1.15 };
      $("gfmCaseCurrentChart").innerHTML = '<div style="margin-top:14px;"><div style="font-family:var(--display);font-weight:700;font-size:12px;margin-bottom:6px;">Converter current utilization (|i| / Imax)</div>' +
        '<canvas id="gfmCaseCurrentCanvas" width="' + w2 + '" height="' + h2 + '" style="width:100%;max-width:' + w2 + 'px;background:var(--panel-alt);border-radius:6px;"></canvas>' +
        chartLegendHtml([
          { color: "#B18CFF", label: "|i| / Imax" },
          { color: "#FF6B6B", label: "Current limit (1.0)", dashed: true },
        ]) + '</div>';
      var ctx2 = $("gfmCaseCurrentCanvas").getContext("2d");
      drawGrid(ctx2, bounds2, w2, h2, m2, "time (s)", "|i| / Imax", { yTicks: [0, 0.25, 0.5, 0.75, 1.0], tickFontSize: 13 });
      drawLine(ctx2, [[bounds2.xmin, 1.0], [bounds2.xmax, 1.0]], bounds2, w2, h2, m2, "#FF6B6B", 1.4, [5, 4]);
      drawLine(ctx2, t.map(function (tv, i) { return [tv, ci[i]]; }), bounds2, w2, h2, m2, "#B18CFF", 2.2);
    }
  } catch (e) {
    $("gfmCaseVerdictBar").innerHTML = '<div class="error-box">Request failed: ' + e + '</div>';
  }
}

async function gfmCaseRunSweep() {
  $("gfmCaseSweepChart").innerHTML = '<div class="sub" style="margin-top:14px;">Sweeping Imax&hellip;</div>';
  try {
    var resp = await fetch("/api/gfm_current_limit/sweep", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
    var data = await resp.json();
    var pts = data.points.filter(function (p) { return p.verdict; });
    if (!pts.length) { $("gfmCaseSweepChart").innerHTML = ""; return; }
    var w = 640, h = 260, m = { l: 64, r: 24, t: 16, b: 56 };
    var xs = pts.map(function (p) { return p.Imax; });
    var xPad = (Math.max.apply(null, xs) - Math.min.apply(null, xs)) * 0.04;
    // Recoverability score is defined on [0,1] (0/0.5/1 encoding of the verdict) --
    // the Y-axis must match that definition exactly, not run past it.
    var bounds = { xmin: Math.min.apply(null, xs) - xPad, xmax: Math.max.apply(null, xs) + xPad, ymin: 0, ymax: 1.0 };
    $("gfmCaseSweepChart").innerHTML = '<div style="margin-top:20px;"><div style="font-family:var(--display);font-weight:700;font-size:12px;margin-bottom:6px;">Recoverability vs. current limit</div>' +
      '<canvas id="gfmCaseSweepCanvas" width="' + w + '" height="' + h + '" style="width:100%;max-width:' + w + 'px;background:var(--panel-alt);border-radius:6px;"></canvas>' +
      chartLegendHtml([
        { color: "#3FE0A8", label: "Recoverable" },
        { color: "#FFB454", label: "At risk" },
        { color: "#FF6B6B", label: "Non-recoverable" },
      ]) + '</div>';
    var ctx = $("gfmCaseSweepCanvas").getContext("2d");
    var scoreOf = { "RECOVERABLE": 1.0, "AT RISK": 0.5, "NON-RECOVERABLE": 0.0 };
    // The tested Imax values are deliberately dense near the low end (0.3/0.4/0.5/0.6) to resolve
    // the boundary precisely -- but that means using EVERY tested value as an axis tick crowds the
    // labels there specifically (the exact complaint). Ticks and DATA points are decoupled: every
    // data point is still plotted at its real x-position, but only a reduced, evenly-spaced-in-
    // PIXELS subset of values gets an axis label, chosen greedily by minimum pixel gap (not merely
    // rotated) -- rotation is applied on top only if that reduced set is still tight.
    drawGrid(ctx, bounds, w, h, m, "Imax (p.u.)", "Recoverability score", {
      xTicks: xs, yTicks: [0, 0.5, 1.0], tickFontSize: 12, rotateXLabels: true, xTickAutoReduce: true,
    });
    var barW = Math.max(10, (w - m.l - m.r) / (xs.length * 2.2));
    pts.forEach(function (p) {
      var color = p.verdict === "RECOVERABLE" ? "#3FE0A8" : (p.verdict === "AT RISK" ? "#FFB454" : "#FF6B6B");
      var score = scoreOf[p.verdict];
      var mpTop = mapPt([p.Imax, score], bounds, w, h, m), mpBot = mapPt([p.Imax, 0], bounds, w, h, m);
      if (score > 0) {
        ctx.fillStyle = color; ctx.fillRect(mpTop[0] - barW / 2, mpTop[1], barW, mpBot[1] - mpTop[1]);
      } else {
        // Zero-score points: a marker only (no per-point "0.0" text) -- the Y-axis's own
        // "0" tick already labels that value, so a floating text label at every closely-
        // spaced zero-score point added nothing but visual collision (the exact complaint).
        ctx.fillStyle = color; ctx.beginPath(); ctx.arc(mpBot[0], mpBot[1], 4, 0, 2 * Math.PI); ctx.fill();
      }
    });
  } catch (e) {
    $("gfmCaseSweepChart").innerHTML = '<div class="error-box">Request failed: ' + e + '</div>';
  }
}

/* ===================== MULTI-CONVERTER FAULT RECOVERY CASE ===================== */

var multiConvParams = { Imax_gfm: 0.5, Imax_gfl: 0.5, KQ_gfl: 0.0 };

async function showMultiConverterCase() {
  activateSurface("multiConverterCaseView", "Case Library", '<b onclick="showProjectManager()">Projects</b> &rsaquo; <span onclick="showCaseLibrary()" style="cursor:pointer;">Case Library</span> &rsaquo; Multi-Converter Recovery');
  if (!$("multiConverterCaseView").dataset.built) {
    $("multiConverterCaseView").innerHTML =
      '<div style="margin-bottom:22px;">' +
      '<div style="font-family:var(--mono);font-size:11px;color:var(--purple);letter-spacing:0.06em;text-transform:uppercase;margin-bottom:6px;">Case Library &rsaquo; Coordinated Fault Recovery</div>' +
      '<h1 style="font-family:var(--display);font-size:26px;margin:0 0 8px;">Multi-Converter Fault Recovery</h1>' +
      '<p class="sub" style="max-width:820px;">Two genuinely interacting converters: a grid-forming (GFM) anchor and a grid-following (GFL) follower, sharing a network and a common local fault at the follower\'s bus. Compare local vs. remote support.</p>' +
      '<div id="multiConvDisclaimer" class="sub" style="font-size:11px;color:var(--muted);border-left:2px solid var(--purple);padding:8px 12px;background:rgba(177,140,255,0.06);border-radius:0 6px 6px 0;max-width:820px;"></div>' +
      '</div>' +
      '<div style="display:grid;grid-template-columns:300px 1fr;gap:20px;align-items:start;">' +
      '<div class="side-panel" style="position:static;width:auto;max-width:none;padding:18px;">' +
      '<div style="font-family:var(--display);font-weight:700;font-size:13px;margin-bottom:4px;">Stress-test controls</div>' +
      '<div id="multiConvSliders"></div>' +
      '<button class="hero-cta-btn hero-cta-primary" style="width:100%;margin-top:10px;padding:11px 0;" onclick="multiConvRunStressTest()">RUN STRESS TEST</button>' +
      '<button class="secondary-btn" style="width:100%;margin-top:8px;" onclick="multiConvRunAsymmetry()">Check local vs. remote support</button>' +
      '<button class="secondary-btn" style="width:100%;margin-top:8px;" onclick="multiConvRunRecommendations()">Get recommended interventions</button>' +
      '<button class="secondary-btn" style="width:100%;margin-top:8px;border-color:var(--purple);color:var(--purple);" onclick="multiConvRunImsGeometry()">True IMS Geometry</button>' +
      '<div style="margin-top:18px;padding-top:14px;border-top:1px solid var(--border);">' +
      '<button class="secondary-btn" style="width:100%;" onclick="generateReport(\'multi_converter_fault_recovery\', multiConvParams, {include_asymmetry:true, include_recommendations:true, include_ims_geometry:true}, \'multiConvReportActions\')">GENERATE FINAL REPORT</button>' +
      '<div id="multiConvReportActions" style="margin-top:8px;"></div>' +
      '</div></div>' +
      '<div><div id="multiConvVerdictBar"></div><div id="multiConvChart"></div><div id="multiConvCurrentChart"></div><div id="multiConvAsymmetry"></div><div id="multiConvRecommendations"></div><div id="multiConvImsGeometry"></div></div>' +
      '</div>';
    $("multiConverterCaseView").dataset.built = "1";
  }
  renderMultiConvSliders();
  try {
    var resp = await fetch("/api/multi_converter_fault/stress_test", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ params: {} }),
    });
    var data = await resp.json();
    $("multiConvDisclaimer").textContent = data.disclaimer || "";
  } catch (e) { /* non-fatal */ }
}

function renderMultiConvSliders() {
  var defs = [
    { key: "Imax_gfm", label: "GFM anchor current limit (Imax)", min: 0.2, max: 4.0, step: 0.05, fmt: function (v) { return v.toFixed(2); } },
    { key: "Imax_gfl", label: "GFL follower current limit (Imax)", min: 0.2, max: 4.0, step: 0.05, fmt: function (v) { return v.toFixed(2); } },
    { key: "KQ_gfl", label: "GFL follower dynamic support (KQ)", min: 0.0, max: 20.0, step: 0.5, fmt: function (v) { return v.toFixed(1); } },
  ];
  var html = "";
  defs.forEach(function (d) {
    var v = multiConvParams[d.key];
    html += '<div style="margin-bottom:16px;">' +
      '<div style="display:flex;justify-content:space-between;font-size:11.5px;color:var(--text);margin-bottom:4px;">' +
      '<span>' + d.label + '</span><span id="multiConvVal_' + d.key + '" style="font-family:var(--mono);color:var(--purple);">' + d.fmt(v) + '</span></div>' +
      '<input type="range" min="' + d.min + '" max="' + d.max + '" step="' + d.step + '" value="' + v + '" style="width:100%;" ' +
      'oninput="multiConvParams[\'' + d.key + '\']=parseFloat(this.value); $(\'multiConvVal_' + d.key + '\').textContent=(' + d.fmt.toString() + ')(multiConvParams[\'' + d.key + '\']);"/></div>';
  });
  $("multiConvSliders").innerHTML = html;
}

async function multiConvRunStressTest() {
  $("multiConvVerdictBar").innerHTML = '<div class="sub">Running stress test&hellip;</div>';
  $("multiConvAsymmetry").innerHTML = "";
  $("multiConvCurrentChart").innerHTML = "";
  try {
    var resp = await fetch("/api/multi_converter_fault/stress_test", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ params: multiConvParams }),
    });
    var data = await resp.json();
    if (data.error) { $("multiConvVerdictBar").innerHTML = '<div class="error-box">' + data.error + '</div>'; return; }
    if (!data.baseline_ok) { $("multiConvVerdictBar").innerHTML = '<div class="error-box">' + data.message + '</div>'; return; }
    var s = data.summary;
    var vColor = s.verdict === "RECOVERABLE" ? "var(--teal)" : (s.verdict === "AT RISK" ? "var(--amber)" : "#FF6B6B");
    var vBg = s.verdict === "RECOVERABLE" ? "var(--teal-dim)" : (s.verdict === "AT RISK" ? "var(--amber-dim)" : "rgba(255,107,107,0.12)");
    $("multiConvVerdictBar").innerHTML =
      '<div style="display:flex;gap:16px;align-items:center;padding:16px 18px;border-radius:8px;background:' + vBg + ';border:1px solid ' + vColor + ';margin-bottom:16px;">' +
      '<div style="font-family:var(--display);font-weight:800;font-size:20px;color:' + vColor + ';">' + s.verdict + '</div>' +
      '<div style="flex:1;font-size:11.5px;color:var(--text);">busA min: <b>' + s.min_v_busA.toFixed(3) + '</b> &middot; busB min: <b>' + s.min_v_busB.toFixed(3) + '</b> p.u. &middot; limiting bus: <b>' + s.limiting_bus + '</b></div></div>';
    var w = 640, h = 280, m = { l: 60, r: 14, t: 16, b: 46 };
    var t = data.trajectory.t, va = data.voltage_traces.v_busA, vb = data.voltage_traces.v_busB;
    var all = va.concat(vb);
    var bounds = { xmin: t[0], xmax: t[t.length - 1], ymin: Math.min.apply(null, all) - 0.05, ymax: Math.max.apply(null, all) + 0.05 };
    $("multiConvChart").innerHTML = '<div style="margin-top:8px;"><div style="font-family:var(--display);font-weight:700;font-size:12px;margin-bottom:6px;">Bus voltage response (both converters)</div>' +
      '<canvas id="multiConvCanvas" width="' + w + '" height="' + h + '" style="width:100%;max-width:' + w + 'px;background:var(--panel-alt);border-radius:6px;"></canvas>' +
      chartLegendHtml([
        { color: "#6FC6FF", label: "busA (GFM anchor)" },
        { color: "#B18CFF", label: "busB (GFL follower)" },
        { color: "#FF6B6B", label: "Critical threshold", dashed: true },
        { color: "#FFB454", label: "At-risk threshold", dashed: true },
      ]) + '</div>';
    var ctx = $("multiConvCanvas").getContext("2d");
    drawGrid(ctx, bounds, w, h, m, "time (s)", "voltage (p.u.)", { tickFontSize: 13 });
    drawLine(ctx, [[bounds.xmin, data.v_critical], [bounds.xmax, data.v_critical]], bounds, w, h, m, "#FF6B6B", 1.2, [4, 3]);
    drawLine(ctx, [[bounds.xmin, data.v_at_risk], [bounds.xmax, data.v_at_risk]], bounds, w, h, m, "#FFB454", 1.2, [4, 3]);
    drawLine(ctx, t.map(function (tv, i) { return [tv, va[i]]; }), bounds, w, h, m, "#6FC6FF", 2.0);
    drawLine(ctx, t.map(function (tv, i) { return [tv, vb[i]]; }), bounds, w, h, m, "#B18CFF", 2.0);

    if (data.current_traces) {
      var ig = data.current_traces.gfm, il = data.current_traces.gfl;
      var w2 = 640, h2 = 230, m2 = { l: 60, r: 14, t: 16, b: 46 };
      var bounds2 = { xmin: t[0], xmax: t[t.length - 1], ymin: 0, ymax: 1.15 };
      $("multiConvCurrentChart").innerHTML = '<div style="margin-top:14px;"><div style="font-family:var(--display);font-weight:700;font-size:12px;margin-bottom:6px;">Converter current utilization (both converters)</div>' +
        '<canvas id="multiConvCurrentCanvas" width="' + w2 + '" height="' + h2 + '" style="width:100%;max-width:' + w2 + 'px;background:var(--panel-alt);border-radius:6px;"></canvas>' +
        chartLegendHtml([
          { color: "#6FC6FF", label: "|i_gfm| / Imax" },
          { color: "#B18CFF", label: "|i_gfl| / Imax" },
          { color: "#FF6B6B", label: "Current limit (1.0)", dashed: true },
        ]) + '</div>';
      var ctx2 = $("multiConvCurrentCanvas").getContext("2d");
      drawGrid(ctx2, bounds2, w2, h2, m2, "time (s)", "|i| / Imax", { yTicks: [0, 0.25, 0.5, 0.75, 1.0], tickFontSize: 13 });
      drawLine(ctx2, [[bounds2.xmin, 1.0], [bounds2.xmax, 1.0]], bounds2, w2, h2, m2, "#FF6B6B", 1.4, [5, 4]);
      drawLine(ctx2, t.map(function (tv, i) { return [tv, ig[i]]; }), bounds2, w2, h2, m2, "#6FC6FF", 2.0);
      drawLine(ctx2, t.map(function (tv, i) { return [tv, il[i]]; }), bounds2, w2, h2, m2, "#B18CFF", 2.0);
    }
  } catch (e) {
    $("multiConvVerdictBar").innerHTML = '<div class="error-box">Request failed: ' + e + '</div>';
  }
}

async function multiConvRunAsymmetry() {
  $("multiConvAsymmetry").innerHTML = '<div class="sub" style="margin-top:14px;">Checking local vs. remote support&hellip;</div>';
  try {
    var resp = await fetch("/api/multi_converter_fault/asymmetry", { method: "POST" });
    var data = await resp.json();
    if (data.error) { $("multiConvAsymmetry").innerHTML = '<div class="error-box">' + data.error + '</div>'; return; }
    var rows = [["GFM (anchor) support only", data.gfm_only], ["GFL (follower) support only", data.gfl_only], ["Both", data.both]];
    var html = '<div style="margin-top:20px;"><div style="font-family:var(--display);font-weight:700;font-size:12px;margin-bottom:8px;">Local vs. remote support</div><table style="width:100%;border-collapse:collapse;font-size:11px;">';
    html += '<tr style="border-bottom:1px solid var(--border);"><td style="padding:6px;color:var(--muted);">Configuration</td><td style="padding:6px;color:var(--muted);text-align:right;">Worst dip (p.u.)</td><td style="padding:6px;color:var(--muted);text-align:right;">Verdict</td></tr>';
    rows.forEach(function (r) {
      var s = r[1].summary;
      var color = s.verdict === "RECOVERABLE" ? "var(--teal)" : (s.verdict === "AT RISK" ? "var(--amber)" : "#FF6B6B");
      html += '<tr style="border-bottom:1px solid var(--border);"><td style="padding:6px;">' + r[0] + '</td><td style="padding:6px;text-align:right;font-family:var(--mono);">' + s.worst_min_v.toFixed(4) + '</td><td style="padding:6px;text-align:right;color:' + color + ';font-weight:700;">' + s.verdict + '</td></tr>';
    });
    html += '</table><div style="font-size:10.5px;color:var(--muted);margin-top:8px;">Local (follower) support at the faulted bus is necessary and sufficient on its own; remote (anchor) current headroom alone is not, even at its maximum tested value.</div></div>';
    $("multiConvAsymmetry").innerHTML = html;
  } catch (e) {
    $("multiConvAsymmetry").innerHTML = '<div class="error-box">Request failed: ' + e + '</div>';
  }
}

/* ---- shared: render an honest "IMS geometry not applicable" result ---- */
function renderImsGeometryNotApplicable(targetElId, data) {
  var checks = [];
  if (data.applicability_check) checks.push(["Converter", data.applicability_check]);
  if (data.applicability_check_gfm) checks.push(["GFM anchor (conv_gfm)", data.applicability_check_gfm]);
  if (data.applicability_check_gfl) checks.push(["GFL follower (conv_gfl)", data.applicability_check_gfl]);
  var html = '<div style="margin-top:22px;padding-top:16px;border-top:2px solid var(--purple);">' +
    '<div style="font-family:var(--display);font-weight:800;font-size:14px;color:var(--purple);margin-bottom:8px;">True IMS Geometry</div>' +
    '<div style="padding:12px 14px;background:rgba(255,180,84,0.08);border:1px solid var(--amber);border-radius:6px;font-size:11.5px;color:var(--text);margin-bottom:10px;">' +
    '<b style="color:var(--amber);">NOT APPLICABLE to this case.</b> ' + data.message + '</div>' +
    '<table style="width:100%;font-size:11px;border-collapse:collapse;">' +
    '<tr style="border-bottom:1px solid var(--border);"><td style="padding:5px 4px;color:var(--muted);">Converter</td><td style="padding:5px 4px;color:var(--muted);">Manifold construction</td><td style="padding:5px 4px;color:var(--muted);">Evidence</td></tr>';
  checks.forEach(function (c) {
    var label = c[0], check = c[1];
    html += '<tr style="border-bottom:1px solid var(--border);"><td style="padding:5px 4px;">' + label + '</td>' +
      '<td style="padding:5px 4px;color:' + (check.applicable ? "var(--teal)" : "#FF6B6B") + ';font-weight:700;">' + (check.applicable ? "APPLICABLE" : "NOT APPLICABLE") + '</td>' +
      '<td style="padding:5px 4px;font-family:var(--mono);font-size:10px;">timer* range = ' + check.timer_star_range_over_probe.toExponential(2) + ' (v_trip=' + check.v_trip + ')</td></tr>';
  });
  html += '</table>' +
    '<div style="font-size:10px;color:var(--muted);margin-top:8px;">This is a validated NEGATIVE result, checked directly against this case\'s actual parameters -- not assumed to transfer from the Iberian scenario merely because both use the same underlying component.</div></div>';
  $(targetElId).innerHTML = html;
}

async function gfmCaseRunImsGeometry() {
  $("gfmCaseImsGeometry").innerHTML = '<div class="sub" style="margin-top:20px;">Checking IMS geometry applicability&hellip;</div>';
  try {
    var resp = await fetch("/api/gfm_current_limit/ims_geometry", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ params: gfmCaseParams }),
    });
    var data = await resp.json();
    if (data.error) { $("gfmCaseImsGeometry").innerHTML = '<div class="error-box">' + data.error + '</div>'; return; }
    if (!data.available) { renderImsGeometryNotApplicable("gfmCaseImsGeometry", data); return; }
    $("gfmCaseImsGeometry").innerHTML = '<div class="sub" style="margin-top:20px;">IMS geometry is applicable for this case but a dashboard renderer has not been wired for it yet (see the HTML/PDF report).</div>';
  } catch (e) {
    $("gfmCaseImsGeometry").innerHTML = '<div class="error-box">Request failed: ' + e + '</div>';
  }
}

async function multiConvRunImsGeometry() {
  $("multiConvImsGeometry").innerHTML = '<div class="sub" style="margin-top:20px;">Checking IMS geometry applicability for both converters&hellip;</div>';
  try {
    var resp = await fetch("/api/multi_converter_fault/ims_geometry", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ params: multiConvParams }),
    });
    var data = await resp.json();
    if (data.error) { $("multiConvImsGeometry").innerHTML = '<div class="error-box">' + data.error + '</div>'; return; }
    if (!data.available) { renderImsGeometryNotApplicable("multiConvImsGeometry", data); return; }
    $("multiConvImsGeometry").innerHTML = '<div class="sub" style="margin-top:20px;">IMS geometry is applicable for this case but a dashboard renderer has not been wired for it yet (see the HTML/PDF report).</div>';
  } catch (e) {
    $("multiConvImsGeometry").innerHTML = '<div class="error-box">Request failed: ' + e + '</div>';
  }
}

/* ===================== FINAL REPORT GENERATION (shared across cases) ===================== */

async function generateReport(caseId, params, extras, targetElId) {
  var target = $(targetElId);
  target.innerHTML = '<div class="sub">Generating report&hellip;</div>';
  var payload = Object.assign({ params: params }, extras || {});
  try {
    var resp = await fetch("/api/report/" + caseId + "/html", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    });
    if (!resp.ok) {
      var errData = await resp.json().catch(function(){ return {}; });
      target.innerHTML = '<div class="error-box">' + (errData.error || "Report generation failed") + '</div>';
      return;
    }
    var htmlStr = await resp.text();
    window.__lastReportHtml = window.__lastReportHtml || {};
    window.__lastReportHtml[caseId] = htmlStr;
    window.__lastReportPayload = window.__lastReportPayload || {};
    window.__lastReportPayload[caseId] = payload;
    window.__lastReportTarget = window.__lastReportTarget || {};
    window.__lastReportTarget[caseId] = targetElId;
    renderReportActions(caseId, targetElId, "FINAL REPORT READY", "teal");
  } catch (e) {
    target.innerHTML = '<div class="error-box">Request failed: ' + e + '</div>';
  }
}

function renderReportActions(caseId, targetElId, statusText, statusColor) {
  $(targetElId).innerHTML =
    '<div id="reportStatus_' + caseId + '" style="padding:10px 12px;background:var(--' + statusColor + '-dim);border:1px solid var(--' + statusColor + ');border-radius:6px;font-size:11px;color:var(--' + statusColor + ');font-weight:700;margin-bottom:6px;">' + statusText + '</div>' +
    '<button class="secondary-btn" style="width:100%;margin-bottom:6px;" onclick="viewReport(\'' + caseId + '\')">VIEW REPORT</button>' +
    '<button class="secondary-btn" style="width:100%;margin-bottom:6px;" onclick="exportReportHtml(\'' + caseId + '\')">EXPORT HTML</button>' +
    '<button class="secondary-btn" id="pdfBtn_' + caseId + '" style="width:100%;" onclick="exportReportPdf(\'' + caseId + '\')">EXPORT PDF</button>';
}

function viewReport(caseId) {
  var htmlStr = (window.__lastReportHtml || {})[caseId];
  if (!htmlStr) return;
  var w = window.open("", "_blank");
  w.document.open(); w.document.write(htmlStr); w.document.close();
}

function exportReportHtml(caseId) {
  var htmlStr = (window.__lastReportHtml || {})[caseId];
  if (!htmlStr) return;
  var blob = new Blob([htmlStr], { type: "text/html" });
  var a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = caseId + "_report.html";
  a.click();
}

async function exportReportPdf(caseId) {
  var btn = $("pdfBtn_" + caseId);
  var statusEl = $("reportStatus_" + caseId);
  var origBtnText = btn ? btn.textContent : "EXPORT PDF";
  if (btn) { btn.disabled = true; btn.textContent = "GENERATING PDF\u2026"; btn.style.opacity = "0.7"; }
  if (statusEl) { statusEl.textContent = "Generating PDF (re-running analysis + rendering) \u2014 this can take up to ~15s for cases with counterfactual/boundary/recommendations included\u2026"; }
  var payload = (window.__lastReportPayload || {})[caseId] || { params: {} };
  try {
    var resp = await fetch("/api/report/" + caseId + "/pdf", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    });
    if (!resp.ok) {
      var errData = await resp.json().catch(function () { return {}; });
      if (statusEl) { statusEl.textContent = "PDF generation failed: " + (errData.error || ("HTTP " + resp.status)); statusEl.style.color = "#FF6B6B"; statusEl.style.borderColor = "#FF6B6B"; }
      if (btn) { btn.disabled = false; btn.textContent = origBtnText; btn.style.opacity = "1"; }
      return;
    }
    var blob = await resp.blob();
    if (!blob || blob.size === 0 || blob.type.indexOf("pdf") === -1) {
      if (statusEl) { statusEl.textContent = "PDF generation returned an empty or invalid file. Please try again."; statusEl.style.color = "#FF6B6B"; statusEl.style.borderColor = "#FF6B6B"; }
      if (btn) { btn.disabled = false; btn.textContent = origBtnText; btn.style.opacity = "1"; }
      return;
    }
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = caseId + "_report.pdf";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    if (statusEl) { statusEl.textContent = "PDF DOWNLOADED (" + Math.round(blob.size / 1024) + " KB)"; }
  } catch (e) {
    if (statusEl) { statusEl.textContent = "PDF generation failed: " + e; statusEl.style.color = "#FF6B6B"; statusEl.style.borderColor = "#FF6B6B"; }
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = origBtnText; btn.style.opacity = "1"; }
  }
}

function closeBuilderView() {
  $("builderView").style.display = "none";
  showProjectManager();
}

var BUILDER_HAS_INPUT_TYPES = { converter: true, load_cpl: true };  // mirrors network.Converter / ConstantPowerLoad has_input=True

function builderInputCandidates() {
  var out = [];
  builderSpec.converters.forEach(function (c) { out.push(c.id); });
  builderSpec.loads.forEach(function (l) { if (l.type === "cpl") out.push(l.id); });
  return out;
}

function busOptions(selectedId) {
  return builderSpec.buses.map(function (b) {
    return "<option value='" + b.id + "'" + (b.id === selectedId ? " selected" : "") + ">" + b.id + " (" + b.type + ")</option>";
  }).join("");
}

function renderBuilder() {
  var el = $("builderBody");
  var html = "";
  var curBusType = $("newBusType") ? $("newBusType").value : "dynamic";

  // --- Buses ---
  html += "<div class='panel'><div class='panel-title'>Buses</div>";
  if (builderSpec.buses.length) {
    html += "<table style='width:100%;border-collapse:collapse;font-size:12.5px;margin-bottom:10px;'>" +
      "<tr style='color:var(--text-dim);text-align:left;font-size:10px;text-transform:uppercase;'><th style='padding:3px 8px 3px 0;'>ID</th><th>Type</th><th>C / v_fixed</th><th>v_init</th><th></th></tr>" +
      builderSpec.buses.map(function (b, i) {
        return "<tr><td style='padding:3px 8px 3px 0;'>" + b.id + "</td><td>" + b.type + "</td><td>" + (b.type === "dynamic" ? b.C : b.v_fixed) + "</td><td>" + (b.v_init !== undefined ? b.v_init : "\u2014") + "</td>" +
          "<td><button class='secondary-btn' style='margin:0;padding:2px 8px;' onclick='removeBuilderItem(\"buses\",\"" + b.id + "\")'>Remove</button></td></tr>";
      }).join("") + "</table>";
  } else {
    html += "<p class='help-text'>No buses yet. Every network needs at least one.</p>";
  }
  html += "<div style='display:grid;grid-template-columns:1fr 1fr 1fr 1fr auto;gap:6px;align-items:end;'>" +
    "<div><label class='field-label'>ID</label><input id='newBusId' value='bus" + (builderCounter.bus + 1) + "'></div>" +
    "<div><label class='field-label'>Type</label><select id='newBusType' onchange='renderBuilder()'>" +
    "<option value='dynamic'" + (curBusType === "ideal" ? "" : " selected") + ">Dynamic (has its own voltage state)</option>" +
    "<option value='ideal'" + (curBusType === "ideal" ? " selected" : "") + ">Ideal / slack (fixed voltage)</option></select></div>" +
    ((curBusType === "ideal") ?
      "<div><label class='field-label'>v_fixed</label><input id='newBusVal' type='number' value='400'></div>" :
      "<div><label class='field-label'>C (F)</label><input id='newBusVal' type='number' step='any' value='0.001'></div>") +
    "<div><label class='field-label'>v_init</label><input id='newBusVinit' type='number' value='400'></div>" +
    "<button class='secondary-btn' style='margin:0;' onclick='addBuilderBus()'>+ Add Bus</button>" +
    "</div></div>";

  // --- Lines ---
  html += "<div class='panel'><div class='panel-title'>Transmission lines</div>";
  if (builderSpec.lines.length) {
    html += "<table style='width:100%;border-collapse:collapse;font-size:12.5px;margin-bottom:10px;'>" +
      "<tr style='color:var(--text-dim);text-align:left;font-size:10px;text-transform:uppercase;'><th style='padding:3px 8px 3px 0;'>ID</th><th>From</th><th>To</th><th>R</th><th>L</th><th></th></tr>" +
      builderSpec.lines.map(function (l) {
        return "<tr><td style='padding:3px 8px 3px 0;'>" + l.id + "</td><td>" + l.from_bus + "</td><td>" + l.to_bus + "</td><td>" + l.R + "</td><td>" + l.L + "</td>" +
          "<td><button class='secondary-btn' style='margin:0;padding:2px 8px;' onclick='removeBuilderItem(\"lines\",\"" + l.id + "\")'>Remove</button></td></tr>";
      }).join("") + "</table>";
  } else {
    html += "<p class='help-text'>No lines yet (optional \u2014 only needed to connect multiple buses).</p>";
  }
  if (builderSpec.buses.length >= 2) {
    html += "<div style='display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr auto;gap:6px;align-items:end;'>" +
      "<div><label class='field-label'>ID</label><input id='newLineId' value='line" + (builderCounter.line + 1) + "'></div>" +
      "<div><label class='field-label'>From bus</label><select id='newLineFrom'>" + busOptions() + "</select></div>" +
      "<div><label class='field-label'>To bus</label><select id='newLineTo'>" + busOptions() + "</select></div>" +
      "<div><label class='field-label'>R (\u03a9)</label><input id='newLineR' type='number' step='any' value='0.1'></div>" +
      "<div><label class='field-label'>L (H)</label><input id='newLineL' type='number' step='any' value='0.0001'></div>" +
      "<button class='secondary-btn' style='margin:0;' onclick='addBuilderLine()'>+ Add Line</button></div>";
  } else {
    html += "<p class='help-text'>Add at least 2 buses to connect a line.</p>";
  }
  html += "</div>";

  // --- Loads ---
  html += "<div class='panel'><div class='panel-title'>Loads</div>";
  if (builderSpec.loads.length) {
    html += "<table style='width:100%;border-collapse:collapse;font-size:12.5px;margin-bottom:10px;'>" +
      "<tr style='color:var(--text-dim);text-align:left;font-size:10px;text-transform:uppercase;'><th style='padding:3px 8px 3px 0;'>ID</th><th>Bus</th><th>Type</th><th>Value</th><th></th></tr>" +
      builderSpec.loads.map(function (l) {
        var val = l.type === "cpl" ? ("P=" + l.P) : l.type === "impedance" ? ("R=" + l.R) : ("I=" + l.I);
        return "<tr><td style='padding:3px 8px 3px 0;'>" + l.id + "</td><td>" + l.bus + "</td><td>" + l.type + "</td><td>" + val + "</td>" +
          "<td><button class='secondary-btn' style='margin:0;padding:2px 8px;' onclick='removeBuilderItem(\"loads\",\"" + l.id + "\")'>Remove</button></td></tr>";
      }).join("") + "</table>";
  } else {
    html += "<p class='help-text'>No loads yet.</p>";
  }
  if (builderSpec.buses.length) {
    var loadType = $("newLoadType") ? $("newLoadType").value : "cpl";
    html += "<div style='display:grid;grid-template-columns:1fr 1fr 1fr 1fr auto;gap:6px;align-items:end;'>" +
      "<div><label class='field-label'>ID</label><input id='newLoadId' value='load" + (builderCounter.load + 1) + "'></div>" +
      "<div><label class='field-label'>Bus</label><select id='newLoadBus'>" + busOptions() + "</select></div>" +
      "<div><label class='field-label'>Type</label><select id='newLoadType' onchange='renderBuilder()'>" +
      "<option value='cpl'" + (loadType === "cpl" ? " selected" : "") + ">Constant Power (CPL)</option>" +
      "<option value='impedance'" + (loadType === "impedance" ? " selected" : "") + ">Constant Impedance</option>" +
      "<option value='current'" + (loadType === "current" ? " selected" : "") + ">Constant Current</option></select></div>" +
      "<div><label class='field-label'>" + (loadType === "cpl" ? "P (W)" : loadType === "impedance" ? "R (\u03a9)" : "I (A)") + "</label>" +
      "<input id='newLoadVal' type='number' step='any' value='" + (loadType === "cpl" ? "500" : loadType === "impedance" ? "10" : "1") + "'></div>" +
      "<button class='secondary-btn' style='margin:0;' onclick='addBuilderLoad()'>+ Add Load</button></div>" +
      "<div class='help-text' style='margin-top:8px;'>ZIP loads and time-varying load profiles are not yet implemented in the validated component library.</div>";
  } else {
    html += "<p class='help-text'>Add a bus first.</p>";
  }
  html += "</div>";

  // --- Converters ---
  html += "<div class='panel'><div class='panel-title'>Power converters</div>";
  if (builderSpec.converters.length) {
    html += "<table style='width:100%;border-collapse:collapse;font-size:12.5px;margin-bottom:10px;'>" +
      "<tr style='color:var(--text-dim);text-align:left;font-size:10px;text-transform:uppercase;'><th style='padding:3px 8px 3px 0;'>ID</th><th>Bus</th><th>Topology</th><th>Controller</th><th></th></tr>" +
      builderSpec.converters.map(function (c) {
        return "<tr><td style='padding:3px 8px 3px 0;'>" + c.id + "</td><td>" + c.bus + "</td><td>" + c.topology + "</td><td>" + c.controller + "</td>" +
          "<td><button class='secondary-btn' style='margin:0;padding:2px 8px;' onclick='removeBuilderItem(\"converters\",\"" + c.id + "\")'>Remove</button></td></tr>";
      }).join("") + "</table>";
  } else {
    html += "<p class='help-text'>No converters yet.</p>";
  }
  if (builderSpec.buses.length) {
    var ctrlType = $("newConvCtrl") ? $("newConvCtrl").value : "constant_duty";
    var curKp = $("newConvKp") ? $("newConvKp").value : "0.3";
    var curKi = $("newConvKi") ? $("newConvKi").value : "5.0";
    var curRDroop = $("newConvRDroop") ? $("newConvRDroop").value : "0.5";
    var needsVnom = ctrlType === "pi" || ctrlType === "droop";
    html += "<div style='display:grid;grid-template-columns:0.8fr 0.8fr 1fr 1fr 0.7fr 0.7fr 0.7fr auto;gap:6px;align-items:end;'>" +
      "<div><label class='field-label'>ID</label><input id='newConvId' value='conv" + (builderCounter.converter + 1) + "'></div>" +
      "<div><label class='field-label'>Bus</label><select id='newConvBus'>" + busOptions() + "</select></div>" +
      "<div><label class='field-label'>Topology</label><select id='newConvTopology'>" +
      "<option value='buck'>Buck</option><option value='boost'>Boost</option><option value='buckboost'>Buck-Boost</option></select></div>" +
      "<div><label class='field-label'>Controller</label><select id='newConvCtrl' onchange='renderBuilder()'>" +
      "<option value='constant_duty'" + (ctrlType === "constant_duty" ? " selected" : "") + ">Constant duty (open loop)</option>" +
      "<option value='pi'" + (ctrlType === "pi" ? " selected" : "") + ">PI voltage regulator</option>" +
      "<option value='droop'" + (ctrlType === "droop" ? " selected" : "") + ">Droop (voltage-current)</option></select></div>" +
      "<div><label class='field-label'>v_in</label><input id='newConvVin' type='number' step='any' value='24'></div>" +
      "<div><label class='field-label'>L</label><input id='newConvL' type='number' step='any' value='0.001'></div>" +
      "<div><label class='field-label'>" + (needsVnom ? "v_nom" : "duty d") + "</label><input id='newConvCtrlVal' type='number' step='any' value='" + (needsVnom ? "24" : "0.5") + "'></div>" +
      "<button class='secondary-btn' style='margin:0;' onclick='addBuilderConverter()'>+ Add Converter</button></div>" +
      (ctrlType === "pi" ?
        "<div style='display:grid;grid-template-columns:0.7fr 0.7fr 1fr;gap:6px;align-items:end;margin-top:6px;'>" +
        "<div><label class='field-label'>Kp (dimensionless)</label><input id='newConvKp' type='number' step='any' value='" + curKp + "'></div>" +
        "<div><label class='field-label'>Ki (per second)</label><input id='newConvKi' type='number' step='any' value='" + curKi + "'></div>" +
        "<div class='help-text' style='margin-bottom:6px;'>Regulates duty around an auto-estimated nominal duty (v_nom / v_in); Kp and Ki act on the normalized voltage error, not the raw voltage.</div>" +
        "</div>" : "") +
      (ctrlType === "droop" ?
        "<div style='display:grid;grid-template-columns:0.7fr 0.7fr 1fr;gap:6px;align-items:end;margin-top:6px;'>" +
        "<div><label class='field-label'>Kp (dimensionless)</label><input id='newConvKp' type='number' step='any' value='" + curKp + "'></div>" +
        "<div><label class='field-label'>R_droop (V/A)</label><input id='newConvRDroop' type='number' step='any' value='" + curRDroop + "'></div>" +
        "<div class='help-text' style='margin-bottom:6px;'>Voltage setpoint decreases with output current (v_ref = v_nom - R_droop &times; i_L) -- proportional load sharing with no communication between converters, at the cost of some steady-state voltage droop under load.</div>" +
        "</div>" : "") +
      "<div class='help-text' style='margin-top:8px;'>Buck, Boost, and Buck-Boost are the validated topologies in this version; Bidirectional, generic DC/AC, and AC/DC models are not yet implemented. Constant-duty, PI, and Droop are the validated controllers here; Backstepping, Sliding-Mode, MPC, and a general per-converter LQR/MRC assignment are not yet implemented for arbitrary user-built topologies.</div>";
  } else {
    html += "<p class='help-text'>Add a bus first.</p>";
  }
  html += "</div>";

  // --- Sources ---
  html += "<div class='panel'><div class='panel-title'>Ideal sources</div>";
  if (builderSpec.sources.length) {
    html += "<table style='width:100%;border-collapse:collapse;font-size:12.5px;margin-bottom:10px;'>" +
      "<tr style='color:var(--text-dim);text-align:left;font-size:10px;text-transform:uppercase;'><th style='padding:3px 8px 3px 0;'>ID</th><th>Bus</th><th>v_source</th><th>R_source</th><th></th></tr>" +
      builderSpec.sources.map(function (s) {
        return "<tr><td style='padding:3px 8px 3px 0;'>" + s.id + "</td><td>" + s.bus + "</td><td>" + s.v_source + "</td><td>" + s.R_source + "</td>" +
          "<td><button class='secondary-btn' style='margin:0;padding:2px 8px;' onclick='removeBuilderItem(\"sources\",\"" + s.id + "\")'>Remove</button></td></tr>";
      }).join("") + "</table>";
  } else {
    html += "<p class='help-text'>No sources yet (optional \u2014 batteries, PV, wind, and fuel cells are not yet implemented; use an Ideal Source for a fixed-voltage feed).</p>";
  }
  if (builderSpec.buses.length) {
    html += "<div style='display:grid;grid-template-columns:1fr 1fr 1fr 1fr auto;gap:6px;align-items:end;'>" +
      "<div><label class='field-label'>ID</label><input id='newSrcId' value='src" + (builderCounter.source + 1) + "'></div>" +
      "<div><label class='field-label'>Bus</label><select id='newSrcBus'>" + busOptions() + "</select></div>" +
      "<div><label class='field-label'>v_source</label><input id='newSrcV' type='number' step='any' value='400'></div>" +
      "<div><label class='field-label'>R_source</label><input id='newSrcR' type='number' step='any' value='0.01'></div>" +
      "<button class='secondary-btn' style='margin:0;' onclick='addBuilderSource()'>+ Add Source</button></div>";
  }
  html += "</div>";

  // --- Input selection + build ---
  var candidates = builderInputCandidates();
  html += "<div class='panel'><div class='panel-title'>Exogenous input</div>";
  if (candidates.length === 0) {
    html += "<p class='help-text'>No component can yet serve as the input (add a converter or a CPL).</p>";
  } else if (candidates.length === 1) {
    builderSpec.input_component_id = candidates[0];
    html += "<p class='help-text'>Automatically resolved: <b>" + candidates[0] + "</b> (the only component with an exogenous input).</p>";
  } else {
    html += "<label class='field-label'>Multiple components could serve as the input \u2014 pick one</label>" +
      "<select id='builderInputSelect' onchange='builderSpec.input_component_id=this.value'>" +
      candidates.map(function (id) { return "<option value='" + id + "'" + (id === builderSpec.input_component_id ? " selected" : "") + ">" + id + "</option>"; }).join("") + "</select>" +
      "<div class='help-text' style='margin-top:6px;'>This choice matters: an earlier version of this feature silently picked the wrong one here, producing a self-consistent but wrong operating point (see tests/test_project_builder.py). It's explicit and required now.</div>";
    if (!builderSpec.input_component_id) builderSpec.input_component_id = candidates[0];
  }
  html += "</div>";

  html += "<div style='display:flex;gap:10px;'>" +
    "<button class='run-stage' style='flex:1;' onclick='buildCustomNetwork()'>Build Network \u2192</button>" +
    "<button class='secondary-btn' style='margin:0;' onclick='closeBuilderView()'>Cancel</button></div>";

  el.innerHTML = html;
}

function addBuilderBus() {
  var id = $("newBusId").value.trim();
  if (!id) return alert("Bus ID required.");
  if (builderSpec.buses.some(function (b) { return b.id === id; })) return alert("Bus ID already used.");
  var type = $("newBusType").value;
  var val = parseFloat($("newBusVal").value);
  var vinit = parseFloat($("newBusVinit").value);
  var bus = type === "dynamic" ? { id: id, type: "dynamic", C: val, v_init: vinit } : { id: id, type: "ideal", v_fixed: val };
  builderSpec.buses.push(bus);
  builderCounter.bus++;
  renderBuilder();
}

function addBuilderLine() {
  var id = $("newLineId").value.trim();
  if (!id) return alert("Line ID required.");
  builderSpec.lines.push({
    id: id, from_bus: $("newLineFrom").value, to_bus: $("newLineTo").value,
    R: parseFloat($("newLineR").value), L: parseFloat($("newLineL").value),
  });
  builderCounter.line++;
  renderBuilder();
}

function addBuilderLoad() {
  var id = $("newLoadId").value.trim();
  if (!id) return alert("Load ID required.");
  var type = $("newLoadType").value;
  var val = parseFloat($("newLoadVal").value);
  var load = { id: id, bus: $("newLoadBus").value, type: type };
  if (type === "cpl") load.P = val; else if (type === "impedance") load.R = val; else load.I = val;
  builderSpec.loads.push(load);
  builderCounter.load++;
  renderBuilder();
}

function addBuilderConverter() {
  var id = $("newConvId").value.trim();
  if (!id) return alert("Converter ID required.");
  var ctrl = $("newConvCtrl").value;
  var conv = {
    id: id, bus: $("newConvBus").value, topology: $("newConvTopology").value,
    params: { v_in: parseFloat($("newConvVin").value), L: parseFloat($("newConvL").value), R_L: 0.02 },
    controller: ctrl,
  };
  var ctrlVal = parseFloat($("newConvCtrlVal").value);
  var kpVal = $("newConvKp") ? parseFloat($("newConvKp").value) : 0.3;
  var kiVal = $("newConvKi") ? parseFloat($("newConvKi").value) : 5.0;
  var rDroopVal = $("newConvRDroop") ? parseFloat($("newConvRDroop").value) : 0.5;
  if (ctrl === "pi") conv.controller_params = { v_nom: ctrlVal, Kp: kpVal, Ki: kiVal };
  else if (ctrl === "droop") conv.controller_params = { v_nom: ctrlVal, Kp: kpVal, R_droop: rDroopVal };
  else conv.controller_params = { d: ctrlVal };
  builderSpec.converters.push(conv);
  builderCounter.converter++;
  renderBuilder();
}

function addBuilderSource() {
  var id = $("newSrcId").value.trim();
  if (!id) return alert("Source ID required.");
  builderSpec.sources.push({
    id: id, bus: $("newSrcBus").value,
    v_source: parseFloat($("newSrcV").value), R_source: parseFloat($("newSrcR").value),
  });
  builderCounter.source++;
  renderBuilder();
}

function removeBuilderItem(listName, id) {
  builderSpec[listName] = builderSpec[listName].filter(function (item) { return item.id !== id; });
  if (builderSpec.input_component_id === id) builderSpec.input_component_id = null;
  renderBuilder();
}

function defaultStateGuess(stateNames) {
  // Seeds the equilibrium initial guess from the user's OWN spec data
  // wherever possible, rather than a single hardcoded constant that
  // silently mismatches whenever a bus operates far from that constant
  // (e.g. a 400V bus guessed at 10.0 -- exactly the kind of mismatch
  // that can make Newton's method (fsolve) diverge badly for a
  // genuinely nonlinear load like a CPL, whose dynamics behave very
  // differently near v=10 than near v=400).
  var busById = {};
  builderSpec.buses.forEach(function (b) { busById[b.id] = b; });
  var loadPowerByBus = {};
  builderSpec.loads.forEach(function (l) {
    if (l.type === "cpl") loadPowerByBus[l.bus] = (loadPowerByBus[l.bus] || 0) + l.P;
  });
  // A bus's own v_init is a generic default (unrelated to any
  // converter attached to it), but a PI/droop converter's v_nom is the
  // actual target voltage for its bus -- a far better guess than a
  // stale/mismatched v_init. Without this, e.g. a bus left at the
  // default v_init=400 with a v_nom=24 PI converter attached produces
  // exactly the same duty-saturation failure that a wrong
  // nominal_input caused before, just via a different independently-set
  // field the user has no reason to expect needs to match.
  var vNomByBus = {};
  builderSpec.converters.forEach(function (c) {
    if ((c.controller === "pi" || c.controller === "droop") && c.controller_params && c.controller_params.v_nom !== undefined) {
      vNomByBus[c.bus] = c.controller_params.v_nom;
    }
  });

  return stateNames.map(function (n) {
    if (n.startsWith("v_")) {
      var busId = n.substring(2);
      if (vNomByBus[busId] !== undefined) return vNomByBus[busId];
      var bus = busById[busId];
      if (bus) return bus.type === "dynamic" ? bus.v_init : bus.v_fixed;
      return 10.0;  // fallback, should not normally be reached
    }
    if (n.endsWith("_ctrl_e_int")) return 0.0;  // PI integrator: 0 is a physically sensible start
    if (n.match(/^i_/)) return 0.0;             // transmission-line current: 0 is a sensible start
    // Converter local current (e.g. "conv1_em_i_L"): estimate from
    // P/V for whichever bus that converter is attached to, if
    // determinable, since a current guess several orders of magnitude
    // off from the actual operating current is exactly the other half
    // of the mismatch that causes divergence.
    var convId = n.split("_")[0];
    var conv = builderSpec.converters.find(function (c) { return c.id === convId; });
    if (conv) {
      var bus2 = busById[conv.bus];
      var v_guess = vNomByBus[conv.bus] !== undefined ? vNomByBus[conv.bus] : (bus2 ? (bus2.type === "dynamic" ? bus2.v_init : bus2.v_fixed) : 10.0);
      var p_guess = loadPowerByBus[conv.bus];
      if (p_guess && v_guess) return p_guess / v_guess;
    }
    return 1.0;
  });
}

async function buildCustomNetwork() {
  if (!builderSpec.buses.length) return alert("Add at least one bus first.");
  if (!builderInputCandidates().length) return alert("Add at least one converter or CPL to serve as the exogenous input.");

  currentProject = {
    id: "custom", category: "custom_network", label: builderSpec.name || "Custom Network",
    description: "User-built network (Project Builder).",
    default_input: [0.5], default_horizon: 1.0, default_disturbance: null,
    default_radius: 1.0, default_samples: 60, default_tol: 0.1,
    sweep_range: [0.0, 1.0], sweep_points: 60,
  };
  stageResults = {};
  formState = {
    params: {}, nominal_input: [0.5], horizon: 1.0,
    sweep_range: [0.0, 1.0], sweep_points: 30, radius: 1.0, n_samples: 30, recovery_tol: 0.1, trace_boundary: false,
    mrc_enabled: false,
  };

  $("builderView").style.display = "none";
  $("appShell").style.display = "none";
  $("appFooter").style.display = "none";
  $("wsView").style.display = "block";
  $("crumbBar").innerHTML = '<b onclick="showProjectManager()">Project Manager</b> &rsaquo; ' + currentProject.label;
  activeStage = "build";
  renderWorkspace();
  await runStage("build");
  // Now that the real state count is known, size the disturbance and
  // state-guess fields to match (a custom network's state count isn't
  // known until it's actually been assembled).
  if (stageResults.build) {
    formState.disturbance_value = stageResults.build.state_names.map(function () { return 0.0; });
    if (!formState.custom_state_guess) formState.custom_state_guess = defaultStateGuess(stageResults.build.state_names);
    if (stageResults.build.default_input) {
      currentProject.default_input = stageResults.build.default_input;
      formState.nominal_input = stageResults.build.default_input.slice();
    }
    renderMain();
  }
}

async function openProject(id) {
  var resp = await fetch("/api/project/" + id);
  if (!resp.ok) { alert("Could not load project " + id); return; }
  currentProject = await resp.json();
  recordRecentProject(id, currentProject.label);
  stageResults = {};
  formState = { params: {} };
  (currentProject.params || []).forEach(function (p) { formState.params[p.key] = p.def; });
  if (currentProject.category !== "network_mrc") {
    formState.nominal_input = (currentProject.default_input || [0]).slice();
  } else {
    formState.km = currentProject.default_km;
    formState.v_bus_init = currentProject.default_v_bus_init;
  }
  formState.disturbance_value = (currentProject.default_disturbance || [0, 0]).slice();
  formState.horizon = currentProject.default_horizon;
  formState.sweep_range = (currentProject.sweep_range || [0, 1]).slice();
  formState.sweep_points = currentProject.sweep_points;
  formState.radius = currentProject.default_radius;
  formState.n_samples = currentProject.default_samples;
  formState.recovery_tol = currentProject.default_tol;
  formState.mrc_enabled = false;
  formState.trace_boundary = (currentProject.category === "single_model" || currentProject.category === "converter_topology");

  activeStage = "build";
  activateSurface("wsView", null, '<b onclick="showProjectManager()">Projects</b> &rsaquo; ' + currentProject.label);
  renderWorkspace();
}
