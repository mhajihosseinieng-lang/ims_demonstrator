# Increment 6B-6 -- Traceability Record

**Status: validated finding, NOT YET FROZEN.**

## Scope
Mode 1, dynamic-collapse trajectory from frozen 5A case (Delta i_q2=1.5,
E2(0)=-0.5), traced against F_f=0 (Gate 2 / M0 existence) throughout its
approach to the independently-verified Mode-1 algebraic fold
(i_q2,fold^M1 ~= -0.182938).

## Result

**Gate 2 (M0 existence) does not hold along this trajectory.** F_f,
evaluated at the trajectory's own state (not searched nearby), remains
large and negative throughout: -19.07 at switching instant, trending to
-6.90 immediately before the fold is reached. Never approaches zero.
Verified using the trajectory's own algebraic branch as warm start (not a
search artifact).

Gates 3-5 are not meaningfully evaluable given Gate 2 does not hold --
the premise (trajectory near M0, decomposing deviation transverse/
tangential to it) does not apply.

## Bounded applicability check (comparison trajectory)

A known non-collapsing Mode-1 trajectory (Delta i_q2=0.85, E2 baseline,
converges to R_M1(xe1)) was traced identically for comparison:

| | Collapse trajectory | Non-collapse trajectory |
|---|---|---|
| F_f at switch | -19.07 | -5.05 |
| F_f by t~2ms | ~-16 (still far) | -0.006 (essentially on M0) |
| M0 established before outcome? | No | Yes, rapidly |

## Frozen wording (exact)

> IMS is locally valid around the tested Mode-1 equilibria (6B-1 through
> 6B-3), but the manifold-tracking regime is trajectory-dependent in the
> hybrid system. Non-collapsing Mode-1 trajectories rapidly establish and
> maintain proximity to M0 (within ~2ms, reaching |F_f|<0.01), consistent
> with standard singular-perturbation behavior. The documented
> dynamic-collapse trajectory (Delta i_q2=1.5, E2(0)=-0.5) does not
> establish this proximity before reaching the independently-verified
> algebraic fold -- the fast dynamics remain in transient relaxation, far
> from M0, throughout the entire pre-collapse window.

**Explicitly not claimed**: that IMS is invalid in Mode 1 generally; that
this result generalizes to all near-fold trajectories beyond the one
tested and the one comparison case; any causal claim that lack of
manifold-proximity "causes" or "explains" the collapse.
