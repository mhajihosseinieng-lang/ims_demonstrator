# Increment 6B -- Traceability Record (FINAL)

**Status: FROZEN.**

## Frozen basis
Built entirely on frozen Increments 4a and 5A, no equations or parameters
modified. Six equilibria discovered in those increments' own studies
(Mode 0: xe1[already IMS-validated in 4a], xe2; Mode 1: xe1[already
IMS-validated in 3], xe2, xe3, xe4) plus two specific hybrid trajectories.

## What was tested

| Stage | Target | Result |
|---|---|---|
| 6B-1 | Mode 1, xe2 | 5/5 gates pass, alpha/beta=53.7 |
| 6B-2 | Mode 1, xe3 | 5/5 gates pass, alpha/beta=13.1 |
| 6B-3 | Mode 1, xe4 | 5/5 gates pass, alpha/beta=12.5 |
| 6B-4 | Mode 0, xe2 | 5/5 gates pass, alpha/beta=17.1 |
| 6B-5 | Mode-0 near-threshold region | M0 smooth, alpha/beta~16-19, transverse dominance confirmed via biorthogonal decomposition |
| 6B-6 | Mode-1 dynamic-collapse trajectory vs. non-collapse comparison | Trajectory-dependent: non-collapse establishes M0 proximity rapidly, collapse trajectory does not |

## Frozen findings (exact wording)

**Equilibrium-level (6B-1 to 6B-4):**
> All six equilibria discovered across Increments 4a and 5A -- three in
> Mode 0, three newly-discovered Mode-1 equilibria plus Mode 1's own
> original equilibrium -- satisfy the independently-defined IMS
> applicability criteria (fast/slow decomposition, M0 existence, normal
> hyperbolicity, transverse attractivity, consistency with recorded local
> stability), with spectral margins varying substantially and
> non-trivially across equilibria (alpha/beta from 12.5 to 53.7).
> Newly-discovered status does not predict margin tightness.

**Near-threshold region (6B-5):**
> Across the near-threshold regions traversed by Mode-0 dynamics
> approaching the protection surface, the fast manifold remains smooth
> and normally hyperbolic (alpha/beta~16-19). An explicit biorthogonal
> eigenvector decomposition confirms genuine transverse dominance
> throughout, ruling out tangential-drift contamination of the scalar
> manifold-residual metric used in an earlier, less rigorous test.

**Trajectory-level applicability (6B-6):**
> For the two tested Mode-1 trajectories, manifold-tracking behavior was
> trajectory-dependent: the non-collapsing trajectory rapidly approached
> and subsequently remained close to M0, whereas the documented
> dynamic-collapse trajectory did not establish proximity to M0 before
> reaching the independently verified algebraic fold. This is a validated
> trajectory-level observation, not a general classification of all
> collapsing or non-collapsing trajectories.

## The central, platform-level contribution of 6B

> Local existence and stability of an IMS manifold at an equilibrium does
> not imply that every hybrid trajectory reaches the manifold-tracking
> regime before another event intervenes.

Demonstrated concretely: trip -> large post-switch algebraic transient ->
algebraic fold, occurring before the trajectory approaches M0.

## Explicit exclusions (unchanged, reaffirmed at freeze)

- No global IMS claim for Mode 0 or Mode 1.
- IMS does not explain or predict collapse -- no causal claim made.
- IMS applicability is not claimed for every trajectory -- only the
  specific equilibria and the two specific trajectories tested.
- No IMS description of the hybrid switching event itself.
- No cascade, no multi-trip analysis -- explicitly deferred to a future,
  independent increment (second protection mechanism).
- A third trajectory data point was considered and explicitly deferred:
  sufficient for the present, bounded, non-generalized claim; a broader
  trajectory-class study is future work, not required for this freeze.

## Next steps (explicitly outside 6B's scope)

The path toward Guoqing's full cascade demonstration requires an
independent increment defining a second protection mechanism and genuine
multi-trip dynamics -- a different scientific question (hybrid protection
dynamics) from 6B's (IMS applicability), not a continuation of 6B itself.
