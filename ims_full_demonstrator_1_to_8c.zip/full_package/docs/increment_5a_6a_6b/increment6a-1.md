# Increment 6A-1 — Traceability Record

**Status: FROZEN.**

## Frozen basis
The exact frozen Increment 5A hybrid system (Increment 4a network/converter
+ latching protection, V_trip=1.10, K_PV:5->0). No equations or parameters
modified. Only a new disturbance protocol applied.

## Scientific question
Does the direction-dependent recoverability identified in Increment 3
persist once Volt-VAR support (4a) and latched protection (5A) are both
present in the system?

## Protocol A -- converter-side (reference arm)
Delta i_q2 step, Q0,3 fixed at 0.10. Already extensively validated in 5A;
protection is reachable (Delta i_q2,trip in [1.41438,1.41442] at E2 near
baseline; instantaneous threshold ~0.838354 near baseline E2).

## Protocol B -- Bus3-directed (new)
Permanent step Q0,3: 0.10 -> 0.10+Delta Q0,3, i_q2(0)=i_q2* (equilibrium
held at converter's own baseline).

### Stage 6A-1 findings

**Static direction, verified not assumed:**
```
dV4/dQ0,3 < 0 throughout the tested region (local value -0.0556 at baseline)
```
Increasing Q0,3 moves V4 AWAY from V_trip. Decreasing Q0,3 moves V4 TOWARD
V_trip.

**Bounded sensitivity table** (Q0,3 in [-0.5,0.30], the range already
established as physically meaningful in Increments 3/4a):

| Q0,3 | V4 | Delta V4 vs baseline |
|---|---|---|
| -0.50 | 1.001066 | +0.023351 |
| -0.30 | 0.994610 | +0.016895 |
| -0.10 | 0.987124 | +0.009409 |
| 0.00 | 0.982764 | +0.005049 |
| 0.05 | 0.980348 | +0.002633 |
| 0.10 (baseline) | 0.977715 | 0.000000 |
| 0.15 | 0.974786 | -0.002929 |
| 0.20 | 0.971420 | -0.006295 |
| 0.25 | 0.967303 | -0.010412 |
| 0.30 | 0.961330 | -0.016385 |

Smooth, monotonic, well-behaved. At no point in this range does V4 approach
within 0.11 pu of V_trip.

**Extreme-corner check (explicitly separated from the meaningful-range
finding above)**: V4=1.10 is mathematically reachable at Q0,3~=-6.05, but
V3 reaches ~2.63 pu at that point -- a value with no physical analogue in
normal power-system operation. This is reported as a mathematical property
of the model, not as a validated physical disturbance pathway.

### Frozen headline finding (verbatim)

> Protection reachability is disturbance-direction dependent even after
> Volt-VAR protection is introduced: converter-side disturbances can reach
> the overvoltage trip surface within the validated operating regime,
> whereas Bus3-directed reactive-power disturbances do not reach that
> surface within the physically meaningful range examined.

### Precise wording constraints, honored

- NOT claimed: "structurally cannot reach the surface" (an unbounded claim).
  Stated instead: does not reach the surface within the physically
  meaningful range examined.
- NOT claimed: "coupling is too weak" or "wrong-signed" as a mechanistic
  interpretation -- only the observed direction and magnitude are reported.
- NOT studied: post-trip Bus3-directed dynamics, ROA, IMS -- deliberately
  out of scope for this stage.

### Comparison table

| Component | Result |
|---|---|
| Converter-side (Delta i_q2) | Protection reachable |
| Bus3-directed (Delta Q0,3>0) | Moves V4 away from trip |
| Bus3-directed (Delta Q0,3<0) | Moves V4 toward trip, only reaches it far outside physically meaningful range |
| Comparable physical trip via Bus3 protocol | Not established |
| Post-trip Bus3 dynamics / ROA / IMS | Not studied |

## Relationship to Guoqing proposal

Directly supports the proposal's emphasis on nonlinear interaction between
converter, voltage/reactive-power control, network conditions, and
protection -- demonstrating that disturbances do not uniformly lead toward
protection events; direction determines reachability itself, not just
recovery margin (extending, not restating, Increment 3's finding).

## What remains explicitly deferred

Multi-trip cascade, second protection mechanism, IMS applicability (6B),
and any forced search for a Bus3-directed trip scenario -- none pursued in
6A-1, per the explicit instruction not to artificially enlarge the
disturbance domain to force an event.
