# Increment 6B-1 — Traceability Record

**Status: validated, NOT YET FROZEN.**

## Scope
Mode 1 (K_PV=0), equilibrium xe2 = (i_q2,E2)=(0.500645,0.854818),
V=[0.660640,0.779721,0.087587,0.739133]. First of five staged IMS
applicability checks for equilibria newly discovered in Increment 5A.

## Gates, each independently evaluated

**Gate 1 -- Fast/slow decomposition: PASS**
tau_I=0.002s (i_q2, fast), tau_Q=0.03s (E2, slow), unchanged from all prior
increments. Ratio 15:1.

**Gate 2 -- M0 existence: PASS**
Fast-subsystem equilibrium curve {F_f=0} traced smoothly at 15/15 points
over E2 in [0.7548,0.9548], residuals at machine precision (max 1.2e-13,
typically ~1e-16). Equilibrium confirmed exactly on the curve.

**Gate 3 -- Normal hyperbolicity: PASS**
alpha=2949.6, beta=54.9, alpha/beta=53.7 -- independently computed via the
same IFT method used in Increments 2/3/4a, not assumed. Comparable order of
magnitude to Increment 3's own xe1 (alpha/beta=74.2).

**Gate 4 -- Transverse attractivity: PASS**
Manifold residual r_m(t), from a diq=0.1 perturbation, decays 11,727x
within 5*tau_I (0.100 -> -0.000009).

**Gate 5 -- Consistency with local stability: PASS**
alpha and beta are built from the same reduced-Jacobian eigenvalues
previously recorded in the 5A traceability record (-2927.6, -55.4) -- a
structural identity, not a new or conflicting claim.

## Frozen wording (exact)

> The IMS framework survives at Mode 1 equilibrium (xe2) under the
> independently defined criteria established in the earlier validated
> framework.

**Explicitly not claimed**: "IMS is validated for Mode 1" (xe3, xe4, Mode-0
xe2, and the near-threshold region remain untested and unimplied).
