# Increment 6B-2 — Traceability Record

**Status: validated, NOT YET FROZEN.**

## Scope
Mode 1 (K_PV=0), equilibrium xe3 = (1.468027,0.698745),
V=[0.700023,0.478541,0.601906,0.074194].

## Gates

**Gate 1 -- PASS.** tau_I=0.002s, tau_Q=0.03s, unchanged, ratio 15:1.

**Gate 2 -- PASS.** M0 traced smoothly 15/15 points, E2 in [0.6487,0.7487],
residuals up to 4.6e-12 (larger than xe2's but still small/acceptable).

**Gate 3 -- PASS, notably tighter than xe2.**
alpha=956.2, beta=72.8, alpha/beta=13.1 -- clears the normal-hyperbolicity
threshold but substantially smaller margin than xe2 (53.7) or Increment 3's
own xe1 (74.2).

**Gate 4 -- PASS, notably slower than xe2.**
Manifold residual reduction: 551x by 5*tau_I (vs xe2's 11,727x), continuing
to ~5000x by 20*tau_I. Genuinely attracting, but visibly weaker.

**Gate 5 -- PASS.** alpha, beta consistent with previously recorded
eigenvalues (-913.3, -76.2).

## Frozen wording (exact)

> The IMS framework survives at Mode 1 equilibrium (xe3) under the
> independently defined criteria -- with a notably tighter spectral gap
> (alpha/beta ~ 13) and correspondingly slower transverse attraction than
> observed at xe2.

**Not claimed**: that this weaker margin implies any conclusion about xe4,
Mode-0 xe2, or the near-threshold region. A marked reduction in spectral
gap was observed at xe3 relative to xe2; whether this represents a broader
trend across the remaining equilibria is unresolved.
