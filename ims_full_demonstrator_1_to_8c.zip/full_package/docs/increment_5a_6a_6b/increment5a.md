# Increment 5A — Traceability Record

**Status: FROZEN. Validated, reproducible, traceable, and formally frozen as
an independent increment. Guoqing demonstrator inclusion: approved as a
partial/building-block result — see Section 12.**

---

## 1. Physical derivation

Base system: the frozen Increment 4a GFM+Volt-VAR model, completely unmodified
(verified byte-identical throughout, md5sum a03aa27ef3086caeb15a01a39fa9749f).

New mechanism — exactly one, per the established one-mechanism-per-increment
discipline:

```
Discrete latching state: s_PV in {0,1}
  s_PV=0 -> K_PV = K_PV,nom = 5.0   (inherited from Increment 4a, unchanged)
  s_PV=1 -> K_PV = 0                (permanent for remainder of trial)

Trigger:  V4 >= V_trip = 1.10 pu  =>  s_PV: 0 -> 1  (one-way, never resets)
```

Modified equation (only g4 changes from the frozen Increment 4a system):
```
g4(V2,V4) := Bsh4*V4^2 - Q0,4 - V4(V4-V2)/X24 - K_PV(t)*(V4-V4,ref) = 0
```
No P_gen, no active-power state introduced. No second trip mechanism. No timer
or protection-delay dynamics. Bus3 remains a symptom/response bus, never a
trigger actuator (Bus2 and Bus4 are the only mechanism-bearing buses).

Explicit switching-consistency procedure, stated precisely to avoid a circular
solve-trip-resolve loop: at each instant, solve g1-g4 under the *current*
K_PV; check whether the resulting V4 crosses V_trip from below (using that
solve's own output, not a hypothetical re-solve); if crossed and untripped,
latch and only then re-solve under the new K_PV for the next step.

## 2. Parameter selection

**V_trip = 1.10 pu**: selected from a three-candidate table (1.05/1.10/1.15 pu)
via margin-above-baseline reasoning (7.4%/12.5%/17.6% above the frozen V4*
=0.977715), chosen as the most representative "typical momentary-overvoltage
protection" value — frozen *before* any equilibrium, fold, or trajectory
computation was performed.

**K_PV,nom = 5.0**: inherited unchanged from Increment 4a, not re-selected.

**Latching (not non-latching)**: confirmed as the base-case model definition
(not a derived result) — chosen specifically to isolate the effect of the
support-loss event itself from reconnection/hysteresis switching dynamics,
which would be a separate, additional mechanism.

## 3. Equilibrium validation

Deterministic enumeration (Layer A, `layerA_equilibria.py`) via analytic
reduction: F_f=0, F_s=0 combined give E2 and i_q2 as explicit functions of V2
alone; V1, V2 uniquely determined given neighbors; V3, V4 genuinely quadratic
(no trivial root, any K_PV) giving at most 4 branch combinations per mode.
Dense deterministic 1D scan in V2, not random search.

**Mode 0 (K_PV=5): 2 equilibria**, both locally stable:
```
V3[1]_V4[1]: (0.100177, 1.000632)  residual 6.38e-16  eig(-1346.6,-76.2)
V3[0]_V4[1]: (0.269957, 0.929943)  residual 5.55e-16  eig(-1233.9,-77.4)
```

**Mode 1 (K_PV=0): 4 equilibria** (all 4 theoretical branch combinations
populated), all locally stable:
```
V3[1]_V4[1]: (0.172825, 0.968546)  residual 4.72e-16  eig(-3690.7,-50.2)
V3[0]_V4[1]: (0.500645, 0.854818)  residual 2.22e-16  eig(-2927.6,-55.4)
V3[1]_V4[0]: (1.468027, 0.698745)  residual 2.22e-16  eig(-913.3,-76.2)
V3[0]_V4[0]: (1.596589, 0.690200)  residual 1.11e-16  eig(-868.4,-76.4)
```
Sanity test (required before Layer B trust): each of the 6 equilibria used
as its own initial condition under its own mode's dynamics reproduces itself
(distances 1.75e-07 to 5.22e-07) — none drifts to another equilibrium.

**"Complete" qualifier, precisely scoped**: complete over the four
theoretically possible (V3/V4) branch combinations within the specified
V2 search domain [0.02, 6.0] — not a claim of completeness over all of R^n.

## 4. Algebraic structure — two distinct folds

**Mode-0 fold**: i_q2,fold^M0 = -3.70557415 (residual 2.36e-15 at tightest
tolerance). S_M0(-3.70) has 2 solutions; S_M0(-3.71) has 0 (500-start
independent verification). **Static** — confirmed by direct testing that
trajectories starting close to but on the admissible side of this fold fully
recover; the dynamics do not drive the system into it from a comfortable
starting point. This is a property of the *initial condition* at t=0, not a
dynamically-reached crossing.

**Mode-1 fold**: i_q2,fold^M1 = -0.18293841 (residual 4.53e-15). **Dynamic**
— confirmed by direct sub-stage tracing that a trajectory starting admissible
post-switch is driven past this fold by its own fast transient (rate
approximately -3321/s at the crossing), with the exact RK4 sub-stage
(k4, evaluated at i_q2=-0.185822) identified as where the crossing occurs.

These two mechanisms are never merged into one generic "collapse boundary."

## 5. Protection dynamics

**Instantaneous threshold** (E2 near baseline, diq alone): Delta i_q2,trip
approximately 0.838354, confirmed E2-invariant at E2=-0.3 and 0.5 (matches
the physical expectation that V4(0) under Mode 0 depends only on i_q2(0)).

**Delayed-trip mechanism**: a large E2(0) can drive a rapid fast-state
overshoot via the (E2-V2)/Xc coupling term, triggering V4>=V_trip well after
t=0 even when the initial condition alone would not. Confirmed via full
sub-stage trace (Stage E case: diq=-1.0, E2=3.0, trip at t=0.0002775s,
dt-converged at 5/2.5/1.25us, T_max-converged at 0.15/0.30/0.50s).

**Reconciled protection-trigger boundary at Delta i_q=0** (after resolving
an under-resolution artifact in an earlier scattered clean-environment
check — see Section 11):
```
E2,trip(Delta i_q=0) in [1.41438, 1.41442]
```
A central estimate E2,trip ~ 1.414401 may be quoted as the bisection
midpoint, but this is a numerical estimate, not a claim of physical
precision beyond the bracket.

**The tested data do not support representing the protection-trigger set as
a single-valued function of Delta i_q2 over the full E2 range** — at larger
E2 (>=1.5), essentially the entire tested Delta i_q2 range trips, and the
boundary structure changes qualitatively (see Section 7).

## 6. ROA — explicitly defined and scoped

R(x_e) := {x0 : phi_t(x0) -> x_e as t -> infinity}, evaluated under the full
hybrid dynamics (mode switching included in the flow). Six supported target
classes: R_M0(xe1), R_M0(xe2), R_M1(xe1..4).

**Numerically mapped ROA transition** between R_M1(xe1) and R_M1(xe2),
located at Delta i_q2 approximately 3.989 (bracket [3.98877,3.98926] at
E2=0.5 and 1.2; F4-verified dt/T_max convergent, both sides settle to their
respective target with distance <1e-6 by t_max=0.3s).

**Explicitly not called** a "basin boundary" — the term ROA transition
between two locally stable Mode-1 equilibria is used throughout, per
established correction.

**Not claimed**: a global or complete map of any R(x_e) region — only the
specific tested points and the one characterized transition curve.

## 7. Dynamic collapse — two distinct pathways, and the qualitative topology

**Pre-trip Mode-0 static collapse**: initial i_q2(0) already past
i_q2,fold^M0; no trip occurs first (tripped=False in this outcome class).

**Post-trip Mode-1 dynamic collapse**: trip occurs first, then post-trip
transient crosses i_q2,fold^M1. Mapped as a single contiguous region at
Delta i_q2=1.5 across E2 in {0, 0.2, 0.434(boundary), 0.6, 0.8, 1.0, 1.2,
1.4, 1.5, 3.0} — collapse below E2~0.4337, R_M1(xe1) above, no
non-monotonicity or reappearance found in this tested set.

**Qualitative 2-D topology** (tested points only, not a global claim):
```
E2 ~ -0.3 to ~1.0:  no-trip region exists for small |Delta i_q2|;
                     instantaneous threshold ~0.838354
E2 ~ 1.39-1.42:      delayed-trip onset curve (smooth, monotonically
                     decreasing over tested Delta i_q2 in [-0.5,0.75])
E2 >= 1.41 (tested up to 3.0): no no-trip cases observed within tested
                     Delta i_q2 range (not claimed as a proof of absence)
  Delta i_q2 < ~-3.806 (=i_q2,fold^M0 - i_q2*): Mode-0 static collapse
  -3.806 < Delta i_q2 < ~3.99: R_M1(xe1)
  Delta i_q2 > ~3.99: R_M1(xe2)
```

## 8. Numerical validation

**F3 (resolution convergence)**: coarse/medium/fine bisection on all four
identified objects (protection-trigger at 4 diq points, ROA transition at
2 E2 points, Mode-0 fold at 3 tolerance levels, Mode-1 collapse at diq=1.5).
All show shrinking displacement with refinement; classification on either
side unchanged.

**F4 (dt/T_max convergence)**: protection-trigger boundary dt-converged at
5/2.5/1.25us at all 4 diq points. Delayed-trip classification T_max-converged
at 0.15/0.30/0.50s (identical trip_time). ROA transition dt/T_max-convergent
on both sides. Mode-1 collapse confirmed as genuine fold-crossing (not
tracking failure) at both dt values. Mode-0 fold correctly treated as
static/algebraic, not subjected to manufactured time-step convergence.

## 9. Clean-environment reproducibility

Performed with only 4 authoritative files (`layerA_equilibria.py`,
`layerB_hybrid_v2.py`, `sim_5a_hybrid_v3.py`, `sim_5a_stageF.py`), no other
session state, no shared RNG (Layer A uses deterministic fixed-point
derivation, no randomness anywhere in the authoritative chain).

All items reproduced within established brackets: 6 equilibria (exact),
both folds (exact to displayed precision), delayed-trip case (exact), ROA
transition (matches bracket), Mode-1 collapse (matches bracket), dt/T_max
representative checks (identical). Protection-trigger boundary required one
reconciliation pass (Section 11) before matching within tolerance.

## 10. Explicit exclusions

- No IMS recoverability analysis has been performed in Increment 5A.
- No global ROA claim — only specific tested points and one characterized
  transition curve.
- No global 2-D topology claim beyond the tested (Delta i_q2, E2) domain.
- No claim that the entire 2-D landscape is resolution- or dt/T_max-converged
  — only the four specifically identified objects.
- No cascade claim — "cascade" requires a chain of sequential component/
  protection events; Increment 5A has one trippable mechanism only.

---

## 11. Preserved history of mistakes and corrections

Per explicit instruction, preserved as part of the scientific record, not
smoothed into only the final numbers:

1. **Insufficient branch-search coverage** (early Stage F attempts): a
   5-fixed-seed local search missed genuine admissible solutions with
   components outside the searched range, producing false `infeasible`
   classifications. Root-caused via an 800-start exhaustive diagnostic and
   fixed by switching to the structurally-derived Layer A enumeration.

2. **RK4 shared-mutable-state robustness issue**: the original hybrid
   integrator let a failed sub-stage's attempted solve corrupt the warm-start
   used by subsequent sub-stages, producing an unverified `infeasible` at
   (Delta i_q2=1.5, E2=-0.5). Fixed by making every sub-stage thread an
   explicit, non-corruptible V-reference, with escalation (local Newton ->
   wide deterministic scan -> independent verification) before any
   `infeasible` is accepted. The specific failure point was later confirmed
   as *genuine* algebraic collapse via the independently-verified Mode-1
   fold — the fix distinguishes tracking failure from real infeasibility
   correctly in both directions.

3. **Under-resolved clean-environment boundary check**: an initial
   reproducibility pass tested scattered points (1.4144, 1.4145) rather than
   running a full bisection, producing an apparent bracket mismatch against
   the F2/F3 result. Resolved by re-running a proper 14-iteration bisection,
   which converged to [1.414401, 1.414401], consistent with the original
   bracket. Not a physical disagreement — a resolution artifact in the
   verification procedure itself, caught before being written into this
   record as a false discrepancy.

4. **Distinction maintained throughout**: equilibrium residual (machine-
   precision F=0 check) vs. trajectory convergence distance (a 1e-3
   numerical classification tolerance) — never conflated, even when
   reported adjacent to each other.

5. **Terminology discipline maintained**: protection trigger, algebraic
   fold, ROA, and IMS recoverability kept as four distinct, non-substitutable
   concepts throughout every stage of this increment.

---

## 12. Freeze statement and demonstrator-inclusion decision

**Frozen scientific statement, verbatim:**

> Increment 5A demonstrates a validated voltage-triggered, latched loss of
> Volt-VAR support and distinguishes three fundamentally different outcomes:
> trip-with-recovery, static pre-trip algebraic collapse, and dynamic
> post-trip algebraic collapse.

**Explicitly not claimed**: this is not a cascade demonstration. Increment
5A has exactly one trippable mechanism; "cascade" requires a chain of
sequential component/protection events, which has not been built or tested.

**Demonstrator-inclusion decision: approved, as a partial/building-block
result**, positioned in the storyline as:

```
Increment 2 (GFM baseline)
  -> Increment 3 (multi-bus, directional recoverability)
  -> Increment 4a (GFM+Volt-VAR: static/dynamic feasibility effects)
  -> Increment 4b (GFL+Volt-VAR: multiple equilibria, disturbance-induced transition)
  -> Increment 5A (protection-triggered hybrid dynamics: trip != collapse)
```

Core message for the demonstrator: **a protection event does not uniquely
determine system failure** — trip and collapse are separate questions, and
collapse itself splits into two mechanistically distinct pathways (static,
present at t=0; dynamic, reached only through the post-trip transient).

**A methodological note worth carrying forward**: Increment 5A shows that
ROA in a hybrid/switched system must be defined carefully, since a discrete
mode and a switching surface enter the problem in a way the continuous-only
ROA definition (as used for Increment 4a) does not need to address. This is
noted as a direction for future work, not resolved further here.

**Not superseding or substituting for IMS**: protection trigger, algebraic
feasibility/fold, ROA, and IMS recoverability remain four separate,
non-substitutable analyses. IMS has not been attempted for Increment 5A.

**Explicitly deferred to a future, separate increment**: a second trippable
mechanism (e.g., Bus2's i_q2, as originally scoped in the pre-derivation
discussion) would be required to demonstrate trip -> reactive-support loss
-> further trip -> cascade. This is not part of 5A and must not be implied
by its inclusion in the demonstrator.

| Increment | Status |
|---|---|
| 2 | Frozen |
| 3 | Frozen |
| 4a | Frozen |
| 4b | Frozen |
| 5A | **Frozen** |
| 5A -> Guoqing demonstrator | Included, explicitly as partial/building-block |
| Cascade (multi-trip) | Not demonstrated — future increment |
| IMS for 5A | Not analyzed — future work, separate question |
