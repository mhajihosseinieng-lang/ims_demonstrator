# Increment 6B-4 -- Traceability Record

**Status: validated, NOT YET FROZEN.**

## Scope
Mode 0 (K_PV=5), equilibrium xe2 = (0.269957,0.929943),
V=[0.698045,0.889450,0.081345,0.931160]. This equilibrium was discovered
during Increment 4a's ROA study; local stability was confirmed there, but
M0/spectral-gap/transverse-attractivity were never explicitly checked.

## Gates

**Gate 1 -- PASS.** Unchanged tau_I/tau_Q, ratio 15:1.

**Gate 2 -- PASS.** M0 traced smoothly 15/15 points, residuals at machine
precision throughout (max 3.16e-13).

**Gate 3 -- PASS.** alpha=1277.97, beta=74.74, alpha/beta=17.1 -- closer
to the tighter Mode-1 pair (xe3: 13.1, xe4: 12.5) than to Mode-1's own
comfortable xe2 (53.7).

**Gate 4 -- PASS.** Manifold residual reduction 933.6x by 5*tau_I.

**Gate 5 -- PASS.** Consistent with previously recorded eigenvalues
(-1233.9,-77.4).

## Frozen wording (exact)

> The IMS framework survives at Mode 0 equilibrium (xe2) under the
> independently defined criteria, with a spectral gap (alpha/beta ~ 17.1)
> closer to the tighter margins observed at Mode 1's xe3/xe4 than to Mode
> 1's own xe2.

## Cross-equilibrium comparison, all four newly-checked equilibria

| Equilibrium | alpha/beta | 5*tau_I reduction |
|---|---|---|
| Mode 1 xe2 | 53.7 | 11,727x |
| Mode 1 xe3 | 13.1 | 551x |
| Mode 1 xe4 | 12.5 | 507x |
| Mode 0 xe2 | 17.1 | 934x |

**Not claimed**: any conclusion about the near-threshold region, or a
general classification of "newly discovered equilibria have tighter
margins than originally-known ones" -- xe2 in Mode 1 is itself a
newly-discovered equilibrium with a comfortable margin, so discovery
recency alone does not predict spectral-gap tightness.
