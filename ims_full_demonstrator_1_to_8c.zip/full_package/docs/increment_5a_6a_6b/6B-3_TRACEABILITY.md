# Increment 6B-3 — Traceability Record

**Status: validated, NOT YET FROZEN.**

## Scope
Mode 1 (K_PV=0), equilibrium xe4 = (1.596589,0.690200),
V=[0.551128,0.450711,0.115559,0.081185].

## Gates

**Gate 1 -- PASS.** Unchanged tau_I/tau_Q, ratio 15:1.

**Gate 2 -- PASS.** M0 traced smoothly 15/15 points, residuals to 2.26e-12.

**Gate 3 -- PASS.** alpha=911.5, beta=72.8, alpha/beta=12.5 -- nearly
identical to xe3's 13.1, not a continuation of the xe2->xe3 decline rate.

**Gate 4 -- PASS.** Manifold residual reduction 507x by 5*tau_I (vs xe3's
551x) -- consistent with the near-identical spectral gap.

**Gate 5 -- PASS.** Consistent with previously recorded eigenvalues
(-868.4,-76.4).

## Cross-equilibrium comparison (three Mode-1 new equilibria now tested)

| Equilibrium | alpha/beta | 5*tau_I reduction |
|---|---|---|
| xe2 | 53.7 | 11,727x |
| xe3 | 13.1 | 551x |
| xe4 | 12.5 | 507x |

## Frozen wording (exact)

> The IMS framework survives at Mode 1 equilibrium (xe4) under the
> independently defined criteria, with a spectral gap (alpha/beta ~ 12.5)
> nearly identical to xe3's, not a continuation of the sharper decline
> observed between xe2 and xe3.

**Precise characterization of the pattern**: the three tested Mode-1
equilibria do not show a monotonically declining spectral gap. Instead,
xe3 and xe4 form a comparatively tighter-margin pair, distinct from xe2's
substantially larger margin. Whether this reflects a genuine two-regime
structure or is an artifact of only three sample points is unresolved.

**Not claimed**: any conclusion about Mode-0 xe2 or the near-threshold
region.
