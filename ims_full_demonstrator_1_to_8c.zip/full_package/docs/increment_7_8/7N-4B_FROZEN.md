# Increment 7N-4B -- FROZEN

## Scope
50-case pre-registered grid: 4 tau_I values (0.002, 0.004, 0.006, 0.010 s)
x 10 disturbance cases (2 diq x 5 E2(0) severity levels), tau_Q=0.03s fixed
throughout, no protection thresholds/logic/equations modified.

## Trip reachability
| tau_I | Cascades activated |
|---|---|
| 0.002 | 10/10 |
| 0.004 | 10/10 |
| 0.006 | 10/10 |
| 0.010 | 8/10 (both E2=1.5 cases do not reach Trip 1) |

## Frozen wording (exact, as corrected)

> Across all 48 cases in which the two-trip cascade activated, the tested
> IMS indicators did not lose their validity: M0 remained identifiable,
> normal hyperbolicity remained positive, transverse-mode dominance
> persisted, and the transverse modal coefficient remained contractive.

> No case in the pre-registered grid exhibited simultaneous IMS
> degradation and loss of recoverability.

**Explicitly not claimed**: "IMS preservation guarantees recoverability"
or "IMS degradation causes loss of recoverability" -- neither is
supported, since no case in this grid reached a genuinely IMS-degraded
state. What is supported is co-occurrence across the tested domain, not
causation.

## The two non-activating cases (tau_I=0.010, E2=1.5)
Classified separately, neither as IMS success nor failure -- post-cascade
IMS is undefined when no cascade occurs. This reflects a distinct
mechanism: sufficiently slow current-loop dynamics can prevent Trip 1
from being reached at the mildest tested severity.

## Quantitative summary, activated cases
- Final equilibrium: identical across all 48 cases, (i_q2,E2)=(0.158,0.975)
- Fold distance: 0.3593-0.3594 (tau_I-independent, confirmed structurally
  -- the fold is defined by equations not containing tau_I)
- Tightest margin observed: R_fs=3.4, alpha/beta=5.15 (tau_I=0.010,
  E2=3.5) -- reduced substantially from baseline but never below 1

## Status: FROZEN
