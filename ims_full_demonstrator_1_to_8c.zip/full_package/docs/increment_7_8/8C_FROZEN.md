# Increment 8C -- FROZEN

## Scope
8 pre-registered cases: 2 disturbance types (diq=-1.0, 0.0) x 4 protocols
(3 staged timings + 1 single-step comparator), all with identical
cumulative displacement (dE2=2.833413, escalation ratios 2.05/1.28 from
the proposal's 355/727/928 sequence). Frozen protection logic unchanged
(V_trip=1.10, V3_trip=1.05, both latches, both actions).

## Frozen results table

| Case group | Protocol | R_fs(0) | R_fs(end) | eta_f(end) | Peak V4 (pu) |
|---|---|---|---|---|---|
| 1-3 | Staged, diq=-1 | 75.41 | 148.25 | ~-50.0 | 2.264-2.785 |
| 4-6 | Staged, diq=0 | 73.73 | 148.25 | ~-50.0 | 2.263-2.782 |
| 7 | Single-step, diq=-1 | 28.19 | 148.25 | -50.01 | 3.172 |
| 8 | Single-step, diq=0 | 22.68 | 148.25 | -50.01 | 3.178 |

All 8 cases: identical final equilibrium (i_q2,E2)=(0.158,0.975), identical
fold distance ~0.3593, no collapse observed.

## Mechanism, verified directly from event logs
In every staged case, both protection trips (t_PV, t_sh3) occur from
Stage 1 alone, before Stage 2 arrives -- Stages 2 and 3 always land on an
already-tripped Mode(1,1) system. The system partially relaxes toward its
equilibrium between stages, absorbing part of each subsequent increment.

## Frozen wording (exact)

> Temporal staging produces a substantially less severe transient
> response than an equivalent single-step disturbance, evident in both
> peak voltage (2.26-2.79 pu staged vs. 3.17-3.18 pu single-step) and
> initial transverse-mode margin (R_fs(0)~74-75 staged vs. 22.7-28.2
> single-step). All 8 cases retain identical final recoverability (same
> equilibrium, same fold distance ~0.3593) and identical asymptotic IMS
> structure (R_fs(end)=148.25, eta_f~-50 in every case). Staging changes
> transient severity, not eventual outcome.

**Explicitly preserved distinction**: this result shows staging is
associated with transient IMS margin and transient severity. It does
**not** demonstrate that IMS preservation is the cause of recoverability
-- consistent with the same limitation carried through 7N-4B. No case in
this study reached a genuinely IMS-degraded state, so no causal claim
about IMS->recoverability can be drawn from 8C either.

## Status: FROZEN
