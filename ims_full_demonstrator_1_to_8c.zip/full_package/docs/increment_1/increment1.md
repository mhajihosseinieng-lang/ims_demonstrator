# Increment 1 -- Traceability Record

**Status: FROZEN (validated reference case; explicitly not to be extended
further -- treat as the minimal foundation, not a template to copy
parameter values from).**

## Physical model

Single aggregated GFM converter bus tied to a stiff external grid via
reactance X, with a constant-power reactive load Q0 at the local bus.

States: i_q (fast, converter current-control loop), E (slow, droop-filter
internal EMF reference). Bus voltage V is algebraic, eliminated via the
implicit function theorem from the bus reactive-power balance.

```
Fast:      tau_I * d(i_q)/dt = (E - V)/Xc - i_q
Slow:      tau_Q * dE/dt     = -E + Enom - nQ*(V*i_q - Qset)
Algebraic: g(V, i_q) := a*V^2 + b*V - Q0 = 0
           a = Bshunt - 1/X,  b = i_q + Vgrid/X
```

Derivation history preserved: an initial equation for V's own dynamics
was proposed, tested against an actual dq-frame circuit derivation, and
found physically ungrounded (the genuine dynamic driven by a bus
capacitor is driven by *active*-axis current, not reactive -- V cannot
legitimately be an independent dynamic state in this reduction). This
led to the correct structure above, with V eliminated algebraically and
E introduced as the genuine slow controller state. The model was also
initially mis-labeled "GFL" and, once actually derived from a voltage-
source-behind-reactance circuit, was found to be structurally GFM-type;
this was corrected rather than silently relabeled.

A constant-impedance local load was tested first and found to
structurally preclude any fold (only one physical equilibrium exists,
regardless of parameters) -- consistent with classical power-system
theory (voltage-collapse folds require constant-*power*, not constant-
impedance, load characteristics). The model was revised to a
constant-power reactive load specifically to restore the fold mechanism,
not to force a particular result -- this choice is recorded as a
deliberate modeling decision, not hidden.

## Frozen parameters

```
X = 0.4        Vgrid = 1.0       Bshunt = 0.0
Enom = 1.05    nQ = 0.5          Qset = 0.0     Xc = 0.15
tau_I = 0.002 s (fast)           tau_Q = 0.03 s (slow)
```

## Baseline equilibrium (Q0 = 0.3)

```
i_q* = 0.173715   V* = 0.942113   E* = 0.968170
Residual: 5.55e-17 (machine precision)
```

## Algebraic fold

Simultaneous solve of F_f=0, F_s=0, g=0, g_V=0:

```
Q0* = 1.09421   i_q* = 0.80789   E* = 0.78276   V* = 0.66158
Residual: ~1e-14 to 1e-16
```

## Fast/slow partition -- independently derived, not borrowed

Unlike an earlier Droop-CPL reference case (from a separate prior
validation of the IMS methodology itself, on a DC system), this model's
slow equation is a droop low-pass filter *by construction* -- its own
explicit `-E` term is already a first-order pole at rate `-1/tau_Q`, with
no separate pole-extraction needed. This is a genuinely different
structural justification, not a re-application of a borrowed method.

```
epsilon = tau_I/tau_Q = 0.0667
```

## The central validated finding

Tracking the spectral-gap quantities as the fold is approached:

| Q0 | alpha | beta | alpha/beta | g_V |
|---|---|---|---|---|
| 0.300 | 2041.8 | 61.15 | 33.4 | -2.0368 |
| 0.900 | 4222.6 | 51.62 | 81.8 | -0.6706 |
| 1.050 | 13666.8 | 48.07 | 284.3 | -0.1731 |
| 1.080 | 39363.1 | 47.22 | 833.5 | -0.0574 |
| 1.093 | ~445575 | ~46.8 | ~9514 | -0.0050 |

**alpha diverges toward infinity as Q0 -> Q0\* (2042 -> 1.3 million at
the closest tested point), while beta stays essentially flat (~47-61)
throughout. The spectral gap widens dramatically -- it does not narrow.**

Normal hyperbolicity is *not* what fails near this fold. A completely
separate condition fails first: IFT regularity (g_V -> 0). These are two
distinct mathematical requirements, and only one is the actual limiting
factor here. This is the foundational distinction the entire later
chain (2 -> 8C) is built on: **normal hyperbolicity =/= overall stability
=/= recoverability**.

## Algebraic infeasibility vs. dynamic divergence -- checked directly

Re-running a collapse trajectory (Q0=1.09, perturbation delta i_q=+0.05,
delta E=-0.03) with fine-grained output through the event:

```
t(ms)     i_q       E       discriminant
0.0000  0.85156  0.75398    0.332951
0.0965  0.81238  0.75393    0.071860
0.1289  0.80477  0.75394    0.021491
0.1504  0.80151  0.75396   -0.000000   <- event fires
```

i_q and E both change smoothly and remain finite right up to the event
-- nothing diverges. The event fires purely because g(V,i_q)=0 runs out
of real solutions for V. This is unambiguously **loss of algebraic (DAE)
feasibility**, correctly distinguished from dynamic (Lyapunov-type)
instability, which was never observed in any tested trajectory.

## Eigenvalue sensitivity, quantified precisely

Power-law fit e(epsilon) = C*epsilon^p across a sensitivity sweep:

```
fast eigenvalue discrepancy:  p = 1.043   R^2 = 0.99986
slow eigenvalue discrepancy:  p = 1.063   R^2 = 0.99971
```

Both exponents close to 1 with an extremely tight fit -- reported as
**numerically consistent with first-order O(epsilon) scaling**, not
claimed as a proof of Fenichel's theorem.

## Disturbance protocol, stated precisely

The reported "recoverable margin" is a **critical i_q-perturbation
amplitude under a specified disturbance protocol**, not a general
recoverability region: an instantaneous perturbation delta i_q=+Delta
applied to the fast state at t=0, integrated forward, classified as
collapsed if the discriminant b^2+4aQ0 crosses zero (a terminal event),
recovered if the final state returns within 0.01 of (i_q*, E*).

## Explicit exclusions

- Not claimed: that this is a GFL model (it is GFM-type, corrected from
  an initial mislabeling).
- Not claimed: a general multidimensional recoverability region -- only
  the single tested disturbance direction and protocol above.
- Not claimed: that the O(epsilon) power-law fit proves Fenichel's
  theorem -- only that it is numerically consistent with first-order
  scaling.
- Not extended further: per explicit instruction, this model was frozen
  as the minimal validated reference case, and later increments (2
  onward) independently re-derive their own fast/slow structure from
  each new model's own physics rather than reusing Increment 1's
  specific parameter values or assumptions.
