# Increment 3 — Frozen Baseline and Traceability Record

**Status: scientifically closed. Do not modify without explicit re-validation.**
**Topology: 4-bus radial (Grid–Bus1–{Bus2(converter), Bus3(load)}, Bus2–Bus4(load)).**

---

## 1. Parameters — Candidate B (frozen, accepted)

| Parameter | Value | Unit | Source |
|---|---|---|---|
| Xg1 | 0.4 | pu | Inherited, Increment 2 (structural role: grid tie) |
| X12 | 0.4 | pu | Inherited, Increment 2 (structural role: line touching converter) |
| X13 | 0.5 | pu | New — illustrative, inter-area tie (weaker than X12/Xg1) |
| X24 | 0.2 | pu | New — illustrative, distribution-level (tighter than transmission) |
| Q0,3 | 0.10 | pu | New — REVISED from Candidate A's 0.20 (see Candidate A/B note below) |
| Q0,4 | 0.15 | pu | New, reuses Increment 2's validated Bus2 load value |
| B_shunt3 | −0.05 | pu | New, reuses Increment 2's validated B_shunt value |
| B_shunt4 | 0.0 | pu | New — no compensation, simplest default |
| Xc, τ_I, τ_Q, E_nom, n_Q, Q_set | unchanged | — | Inherited exactly from Increment 2 converter |

**Candidate A (original, preserved unmodified for traceability):** Q0,3=0.20, all else identical. Rejected as baseline: V3=0.7443pu (excessively stressed pre-disturbance). Never used past the initial plausibility check.

**Candidate B (accepted, frozen):** Q0,3=0.10 (single-parameter revision from A), X13=0.5 unchanged. Accepted per the sensitivity-based, non-tuning revision protocol.

---

## 2. Baseline equilibrium (Candidate B)

```
[i_q2, E2, V1, V2, V3, V4] = [0.172825, 0.968546, 0.939452, 0.942622, 0.859804, 0.909642]
```
- Computation: `fsolve` on the 6-equation system (F_f, F_s, g1, g2, g3, g4) — `inc3_model.py`
- Validation: max residual = 4.7e-16, verified directly (not solver flag)
- Cross-check: closed-form V1 elimination matches to 1.4e-7 (fsolve tolerance-scale)

---

## 3. J_g and IFT validation

- J_g (4x4, analytic): derived term-by-term in the response, implemented as `Jg_matrix()` logic inline in the sweep scripts (not yet factored into `inc3_model.py` as a standalone function — **note for Increment 4**: extract this into a shared function before further reuse)
- FD cross-check: max discrepancy 3.67e-9
- det(J_g) = −32.613464, condition number = 34.75, rank = 4 (full), singular values [11.376, 6.660, 1.315, 0.327]
- Schur-complement cross-check (V1-elimination Jacobian-level consistency): matches direct reduced Jacobian to 2.26e-7; determinant identity det(J_full)=det(J11)·det(Schur) holds exactly (−32.613464 = −32.613464)

---

## 4. Fold

```
Q0,3* ≈ 0.294630
```
- Computation: simultaneous 7-equation solve (F_f=0, F_s=0, g1..g4=0, det(J_g)=0) via `fsolve`
- Validation: residuals ~1e-14 to 1e-15
- At the fold: i_q2=0.31319, E2=0.91420, V1=0.81414, V2=0.86722, **V3=0.51546** (Bus3 is the bus that collapses), V4=0.83113

---

## 5. Fast/slow derivation and spectral gap

- ∂V2/∂i_q2 computed via full 4x4 IFT: `−J_g⁻¹·(0,V2,0,0)ᵀ`, second component
- λ⊥(F), λ⊥(phys), α, λ∥(phys), β computed by the same formulas as Increment 2, re-derived (not assumed) — see response text for full derivation
- τ_I=2ms, τ_Q=30ms carried forward with re-justification (same converter hardware), NOT blindly inherited

| Q0,3 | α | β | α/β |
|---|---|---|---|
| 0.10 | 3707.5 | 49.95 | 74.2 |
| 0.25 | 4488.8 | 48.20 | 93.1 |
| 0.29 | 9411.3 | 43.23 | 217.7 |
| 0.294 | 38781.1 | 39.69 | 977.0 |
| 0.2946 | 714313.2 | 38.62 | 18498.3 |

---

## 6. Full-vs-reduced nonlinear validation

| Point | max diff after 5τ_I |
|---|---|
| Baseline (Q0,3=0.10) | 0.000197 |
| Intermediate (Q0,3=0.25) | 0.000173 |

- dt convergence confirmed at 10μs/5μs/2.5μs (all agree to 6 decimals) — `inc3_model.py`

---

## 7. Manifold M0

- Definition: M0 := {(i_q2,E2) : F_f(i_q2,E2;Q0,3)=0}, V2(i_q2) from full 4-bus algebraic solve
- Traced at baseline: 21 points, E2∈[0.82,1.12], residuals 1e-12 to 1e-16 — `manifold_baseline.npy`
- Confirmed distinct from the fold: traced successfully at Q0,3=0.29 (near but not at Q0,3*) using dense-scan tracking after the initial chained-warm-start method failed (documented failure mode, see response text)
- Manifold residual along trajectory: r_m(t) drops from 0.100 to −4e-6 within 5τ_I (25,018x reduction) — confirms genuine attraction, not fitted

---

## 8. Recoverability — TWO independently preserved results

### 8a. Converter-side (i_q2 perturbation, Q0,3 held fixed)
| Q0,3 | Critical amplitude |
|---|---|
| 0.10 | ≥0.9 (upper bound not found) |
| 0.28 | ≥0.35 |
| 0.293 | ≥0.15 |

**Statement (verbatim, preserve exactly):**
> Near-fold operating points can retain substantial recoverability against converter-side disturbances in the four-bus network.

### 8b. Bus3-directed (permanent Q0,3 step, i_q2 held at pre-disturbance value)
| Q0,3 | Critical ΔQ0,3 (dt=5us) | Cross-check (dt=2.5us) | Static distance to fold | Ratio (dynamic/static) |
|---|---|---|---|---|
| 0.10 | 0.157049–0.157060 | not re-run (baseline, lower priority) | 0.19463 | 81% |
| 0.28 | 0.006708 | 0.006708–0.006709 | 0.01463 | 46% |
| 0.293 | 0.000212 | 0.000212 (identical) | 0.00163 | 13% |

**Independent verification (separate from the trajectory Newton solver), at the near-fold boundary:**
- Q0,3=0.293212: 2 admissible solutions (800 random starts)
- Q0,3=0.293250: 0 admissible solutions (800 random starts)

**Disparity (converter-side margin ÷ Bus3-directed margin):**
| Q0,3 | Disparity |
|---|---|
| 0.10 | ~5.7x |
| 0.28 | ~52x |
| 0.293 | ~708x |

**Statement (verbatim, preserve exactly):**
> For this four-bus system, large-signal recoverability is strongly dependent on disturbance direction and its coupling to the fold-driving bus; fold proximity alone does not determine the recoverability margin.

**Explicitly NOT claimed:** that fold proximity alone determines recoverability in general (H1, not supported as a general statement).

---

## 9. The four-stage hierarchy (the core Increment 3 conceptual contribution)

```
Static fold (Q0,3*, algebraic, parameter-only)
  -> Post-disturbance equilibrium feasibility (does ANY admissible equilibrium exist at new Q0,3)
    -> Instantaneous algebraic feasibility (does a solution exist at the SPECIFIC pre-disturbance i_q2)
      -> Dynamic recoverability (does the actual trajectory reach it in time)
```
Mechanistically demonstrated: these four conditions can bind at very different points. At Q0,3=0.293212 vs 0.293250, stages 1-2 are essentially unchanged, but stage 3 is exactly where the transition occurs — confirmed by the independent 800-start scan.

---

## 10. Demonstration assets

- Widget 1: four-stage hierarchy diagram (SVG)
- Widget 2: converter-side vs Bus3-directed comparison (log-scale bar chart + disparity cards + 800-start validation table)
- Both reference the numbers in sections 8a/8b above directly — no numbers in the demonstration are independent of this record

---

## 11. Known gaps for a clean-environment reproducibility test (see separate check)

- J_g construction is currently duplicated inline across multiple scripts rather than factored into a single shared function in `inc3_model.py` — works, but is a maintainability risk for Increment 4. Recommend factoring before further extension.
- `inc3_recover.py`'s `global_scan_check` takes an unused `E2` parameter (vestigial) — harmless but should be cleaned up.

---

## 12. Clean-environment reproducibility test — PASSED

Performed by copying only the three frozen module files (`inc3_model.py`,
`inc3_recover.py`, `inc3_bus3_disturbance.py`) into a genuinely fresh
directory with no other state, and re-deriving results from scratch (not
copy-pasted):

- Baseline equilibrium: reproduced exactly (residual 6.4e-16), matches
  recorded value to displayed precision.
- Fold Q0,3*: reproduced exactly (0.294630, residual 3.3e-16).
- Converter-side recoverability module (`inc3_recover.py`): sanity check
  at diq=0.05 reproduces `completed` outcome correctly.
- Near-fold independent validation: re-run at reduced sample count (200
  vs original 800, for speed) still cleanly reproduces 2 solutions below
  the threshold and 0 above it.

**Conclusion: the frozen baseline is genuinely self-contained and
reproducible from a clean environment, not dependent on leftover session
state.** This directly satisfies the "demonstrator, not just development
scripts" requirement before any Increment 4 work begins.

## 13. Known gaps to address before Increment 4 (carried over from section 11)

- J_g construction should be factored into a single shared function in
  `inc3_model.py` rather than duplicated inline across scripts.
- `global_scan_check`'s unused `E2` parameter should be removed.
- Consider consolidating the three `inc3_*.py` files into a single,
  documented module before extending to Increment 4's scope.
