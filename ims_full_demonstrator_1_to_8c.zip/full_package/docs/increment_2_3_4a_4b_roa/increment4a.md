# Increment 4a — Frozen Baseline and Traceability Record

**Status: scientifically closed. Do not modify without explicit re-validation.**
**Scope: one new mechanism only — algebraic Volt-VAR reactive support at Bus4.**
**GFM converter at Bus2, four-bus topology, all Increment 3 dynamic states: UNCHANGED.**
**Increment 3 preserved completely as the frozen control case (see `/tmp/increment3_FROZEN_BASELINE/`).**

---

## 1. Frozen parameters and selection rationale

| Parameter | Value | Unit | Rationale |
|---|---|---|---|
| K_PV | 5.0 | pu/pu | Selected from a 3-candidate study (2/5/10 pu/pu) **before** observing any fold or recoverability outcome. Documented at the time as "close to a typical grid-code default" — **this specific numerical claim about IEEE 1547 Category B has NOT been verified against the actual standard and must not be cited as such in any external report without that verification.** The scientifically load-bearing fact is that K_PV=5 was frozen before seeing the fold/IMS results, not the standard-citation claim. |
| V4,ref | 1.0 | pu | Nominal reference voltage, standard choice |

All other parameters (Xg1, X12, X13, X24, Q0,3 baseline=0.10, Q0,4, B_shunt3, B_shunt4, Xc, τ_I, τ_Q, E_nom, n_Q, Q_set) are **inherited unchanged from the frozen Increment 3 baseline.**

**Candidate study (K_PV=2, 5, 10), performed before any fold/recoverability computation:**
| K_PV | [i_q2,E2,V1,V2,V3,V4] | Residual |
|---|---|---|
| 2 | [0.1190,0.9920,0.9555,0.9742,0.8766,0.9597] | 5.0e-16 |
| **5 (selected)** | **[0.1002,1.0006,0.9613,0.9856,0.8826,0.9777]** | **2.2e-15** |
| 10 | [0.0904,1.0052,0.9644,0.9916,0.8858,0.9872] | 3.6e-16 |

---

## 2. Modified equation and sign convention — derived, not assumed

Sign convention derived from the existing Bus4 KCL (`B_shunt4·V4²` is *added* in Increment 3's own g4 — confirming injection terms are added, consumption/export terms subtracted). Correctly-signed PV injection quantity:
```
Q_PV,injected(V4) := -K_PV(V4 - V4,ref),  K_PV > 0
```
V4>V4,ref → absorbs (stabilizing); V4<V4,ref → injects (stabilizing). Added to g4 per the derived convention:
```
g4_new(V2,V4) := B_shunt4·V4² - Q0,4 - V4(V4-V2)/X24 - K_PV(V4-V4,ref) = 0
```
**Explicitly documented**: unsaturated, deadband-free, linear Volt-VAR only. No active-power injection, no PV irradiance dynamics, no DC-link states, no current limits, no deadband, no saturation. All other bus equations (g1, g2, g3) and both converter equations (F_f, F_s) are byte-identical to Increment 3.

**Algebraic, not dynamic** — explicitly determined, not assumed: Q_PV(V4) is an instantaneous function of the local bus voltage; no new state, no new time constant introduced.

---

## 3. Baseline equilibrium (frozen)

```
[i_q2, E2, V1, V2, V3, V4] = [0.100177, 1.000632, 0.961317, 0.985606, 0.882601, 0.977715]
```
Residual: 2.16e-15 (verified directly). Admissible (all V>0).

---

## 4. Jacobian/IFT validation

- Analytic J_g (4x4), FD cross-check: max discrepancy 5.2e-9
- det(J_g) = -291.725115, condition number = 15.5629, rank = 4, singular values = [14.017, 7.781, 2.970, 0.901]
- Bus1 closed-form elimination: matches full solve to 2.9e-7
- Schur-complement identity: det(J_full) = det(J11)*det(Schur) holds exactly (-291.725115 = -291.725115); direct vs. Schur-complement reduced Jacobian match to 4.5e-7

---

## 5. Increment 3 vs. Increment 4a Jacobian comparison

**Isolated mechanism check** (same equilibrium, K_PV=0 vs 5): only the (4,4) entry changes, by exactly -5.0 (= -K_PV analytically); all other 15 entries identical.

**Full before/after** (each at its own equilibrium):
```
det(J_g):  -32.6135  ->  -291.7251   (magnitude grew ~9x)
cond(J_g):  34.7549  ->   15.5629    (conditioning IMPROVED -- genuine, unforced finding)
```

---

## 6. Fold location and validation

```
Q0,3* (Increment 4a) = 0.323225    (simultaneous 7-eq solve, residuals ~1e-14 to 1e-16)
At the fold: i_q2=0.18188  E2=0.96475
             V1=0.83141  V2=0.93746  V3=0.48810  V4=0.95411
```

**Effect A**: ΔQ0,3* = 0.323225 - 0.294630 = **+0.028595 (+9.71%)**.

**Limiting bus identity unchanged**: Bus3 remains the most-depressed bus at both folds (Inc3: V3=0.51546; Inc4a: V3=0.48810), both substantially below the other three buses at their respective folds.

Genuine saddle-node confirmed: det(J_g) approaches zero smoothly and monotonically (not a jump); no admissible equilibrium found beyond ~0.324 in the tested continuation.

---

## 7. Fast/slow and manifold validation

- τ_I=2ms, τ_Q=30ms re-justified (same converter hardware) — not blindly inherited
- Spectral gap re-derived fresh via the full 4x4 IFT: at Q0,3=0.10, α=1389.5, β=73.81, α/β=18.83 (**substantially smaller than Increment 3's α=3707.5, β=49.95, α/β=74.2 at the same Q0,3** — genuine, unforced finding: PV support narrows the baseline spectral gap even though it widens the static fold margin)
- M0 traced fresh: 21/21 points, E2∈[0.85,1.15], residuals ~1e-14 (`manifold_baseline_4a.npy`)
- Manifold residual along trajectory: 0.100 → -0.000088 within 5τ_I (1140x reduction)
- Full-vs-reduced: |E_full-E_reduced| = 0.000451 at baseline (vs Increment 3's 0.000197 — larger, consistent with the smaller spectral gap)
- dt convergence: 10μs/5μs/2.5μs agree to 6 decimals

---

## 8. Converter-side recoverability (Experiment A)

| Q0,3 | Increment 3 | Increment 4a |
|---|---|---|
| 0.10 (baseline) | ≥0.9 | ≥1.5 |
| near-fold | ≥0.15 (at 0.293) | ≥0.3 (at 0.32) |

---

## 9. Bus3-directed recoverability (Experiment B) — original near-fold comparison, PRESERVED unchanged

| Q0,3 | Critical ΔQ0,3 | Static distance to fold | Dynamic/static ratio |
|---|---|---|---|
| Inc3, 0.10 | 0.157049-0.157060 | 0.19463 | 81% |
| Inc3, 0.28 | 0.006708 (cross-checked dt=2.5us) | 0.01463 | 46% |
| Inc3, 0.293 | 0.000212 (cross-checked dt=2.5us) | 0.00163 | 13% |
| Inc4a, 0.10 | 0.216455-0.216498 | 0.223225 | 97% |
| Inc4a, 0.32 | 0.002483-0.002484 | 0.003225 | 77% |

**This table is NOT replaced by the normalized comparison below — both are preserved as distinct, valid results.**

---

## 10. Normalized-distance comparison (Effect B, additional validation layer)

**Confound identified and corrected**: original near-fold test points were at unmatched ρ (Inc3: 0.837%, Inc4a: 1.445%).

**Matched at common ρ=1%:**
```
                    Inc3 (Q0,3=0.292684)   Inc4a (Q0,3=0.320993)
Absolute distance:  0.001946                0.002232
Critical dQ0,3:     0.000290                0.001631
Dynamic/static:     14.9%                   73.1%
```

**Cross-checked at dt=2.5us:**
```
Inc3:  [0.000290, 0.000290]   (identical to dt=5us)
Inc4a: [0.001630, 0.001631]   (matches dt=5us to displayed precision)
```

**Effect B confirmed: the 15%->73% gap persists at matched normalized distance — not a sampling artifact of comparing points at different proximity to their respective folds.**

---

## 11. Timestep convergence evidence (summary)

| Test | dt=5us | dt=2.5us | Converged |
|---|---|---|---|
| Baseline trajectory (diq=0.1) | matches dt=10us | — | Yes |
| Bus3-directed, original near-fold (Q0,3=0.32) | 0.002483-0.002484 | not separately re-run (lower priority, superseded by matched-rho check below) | — |
| Bus3-directed, matched rho=0.01 (Inc3) | 0.000290 | 0.000290 | Yes, identical |
| Bus3-directed, matched rho=0.01 (Inc4a) | 0.001631 | 0.001630-0.001631 | Yes |

---

## 12. Exact source computation for every displayed number

| Displayed number | Source computation |
|---|---|
| K_PV=5.0, V4,ref=1.0 | Section 1 candidate study, frozen before fold/IMS analysis |
| Baseline equilibrium | `fsolve` on 6-eq system, `inc4a_model.py`-equivalent inline script |
| det(J_g)=-291.73, cond=15.56 | Analytic Jacobian, `inc4a_model.py` derivative formulas |
| Fold Q0,3*=0.323225 | Simultaneous 7-eq fsolve (F_f,F_s,g1-g4,det(Jg)=0) |
| alpha=1389.5, beta=73.81 at Q0,3=0.10 | Full 4x4 IFT: dV2/diq2 = -Jg^-1(0,V2,0,0), chain rule per Increment 2/3 method |
| Manifold trace | `manifold_baseline_4a.npy`, dense-scan tracking, `inc4a_model.py` |
| Converter-side critical amplitudes | `inc4a_recover.py`, bisection, dt=5us fixed |
| Bus3-directed critical amplitudes | `inc4a_bus3.py`, bisection, dt=5us fixed, cross-checked dt=2.5us |
| Normalized-distance matched equilibria | `fsolve` at Q0,3=0.292684 (Inc3) and 0.320993 (Inc4a), residuals 3.3e-16 and 3.6e-16 |

---

## Final scientific wording (frozen, verbatim)

> For this four-bus configuration with K_PV=5, Volt-VAR support at Bus4 both shifts the static fold outward and substantially narrows the gap between static feasibility and dynamic recoverability for Bus3-directed disturbances.

**Not claimed**: generalization to arbitrary Volt-VAR systems, other K_PV values, other topologies, or a literal correspondence to IEEE 1547 Category B without independent verification of that standard's actual specification.

---

## 13. Clean-environment reproducibility test — PASSED

Performed by copying only the four frozen module files (`inc4a_model.py`,
`inc4a_fast.py`, `inc4a_recover.py`, `inc4a_bus3.py`) into a genuinely fresh
directory with no other state, and re-deriving results from scratch:

- Baseline equilibrium: reproduced exactly (residual 4.16e-16), matches
  recorded value to displayed precision.
- Fold Q0,3*: reproduced exactly (0.323225, residual 1.14e-14).
- Recoverability module (`inc4a_recover.py`): sanity check reproduces
  correctly from the clean copy.

**Conclusion: the frozen Increment 4a baseline is genuinely self-contained
and reproducible from a clean environment**, matching the standard
established for Increment 3.
