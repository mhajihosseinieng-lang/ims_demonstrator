# ROA Study — GFM+Volt-VAR (Increment 4a basis) — Traceability Record

**Status: methodology validated, NOT YET FROZEN as a demonstrator result.**
**This record uses the frozen Increment 4a model as its physical basis but
does not modify it. Increment 4a's own equations, parameters, fold result,
and IMS results remain completely unchanged (see
`/tmp/increment4a_FROZEN_BASELINE/`, verified byte-identical, section 8).**

---

## 0. Scope statement — read this before anything else

**What this study establishes:**
> The numerical study maps the ROA partition over a tested two-dimensional
> initial-condition domain: Delta i_q2 in roughly [-1.3, 5.8], E2 in
> [-0.5, 3.0], at the grid resolutions and bisection precisions documented
> below.

**What this study does NOT establish:**
> A complete, analytically-derived, or globally-valid characterization of
> R(x_e1) and R(x_e2) over all of R^2. The reported boundary
> (Delta i_q2* ~ 4.717) is a **numerically resolved ROA boundary over the
> tested domain**, not a proven analytical boundary. Behavior outside the
> tested domain is unknown and unclaimed.

Every number in this record should be read with that scope attached.

---

## 1. Physical basis (frozen, unmodified)

GFM+Volt-VAR converter at Bus2, four-bus network, Q0,3=0.10, K_PV=5.0,
V4,ref=1.0 — identical to the frozen Increment 4a baseline. State space:
x=(i_q2, E2). V1-V4 algebraically slaved via the SAME structural branch
enumeration validated in Increment 4b (reused deliberately, not
re-derived, since Bus1-4's algebraic equations are identical between the
GFM and GFL converter cases).

## 2. Target equilibria — both independently verified

| | x_e1 (original) | x_e2 (newly discovered) |
|---|---|---|
| (i_q2, E2) | (0.100177, 1.000632) | (0.269957, 0.929943) |
| Equilibrium residual (F_f,F_s,g1-g4 all ->0) | **4.16e-16** | **5.55e-16** |
| Local eigenvalues | (from Increment 4a's own validated spectral analysis) | -1233.90, -77.41 (both real, negative) |
| Locally stable | Yes | Yes |

**x_e2 is an additive discovery from this ROA study, not a correction to
Increment 4a.** Increment 4a's own frozen results were computed correctly
at and near x_e1; nothing there was wrong. x_e2 was simply never explored
by that earlier, narrower validation.

## 3. Methodology — Layer A / Layer B, reused from Increment 4b

Deliberately reusing the validated deterministic branch-enumeration
(Layer A) and dynamic branch-tracking (Layer B) architecture from
Increment 4b's own traceability record, since the underlying algebraic
structure (V1,V2 unique given neighbors; V3,V4 genuinely quadratic, up to
4 branch combinations) is identical for this GFM case. Not re-derived from
scratch; reuse is intentional and documented.

**Branch-selection convention for the ROA scan (a documented modeling
choice, not an assumption-free fact):** initial conditions vary (i_q2(0),
E2(0)) while the algebraic voltage state at t=0 is selected for continuity
from x_e1's own branch (nearest-V3 matching), representing "a disturbance
applied while the network started on the healthy operating branch."
Starting a trajectory exactly at x_e2's own true algebraic state is a
SEPARATE validation case (confirmed to reproduce x_e2, not conflated with
the general scan's convention).

## 4. Boundary continuation — Delta i_q2 exclusively

Delta i_q2 := i_q2(0) - i_q2,e1, applied exactly once, verified explicitly
(cross-checked against the absolute-i_q2 convention used in an earlier,
now-reconciled fine-grid pass -- see section 7).

| E2(0) | Delta i_q2 boundary bracket |
|---|---|
| -0.5 | [4.7158, 4.7183] |
| -0.1 | [4.7170, 4.7183] |
| 0.5 | [4.7170, 4.7183] |
| 1.000632 (E2*) | [4.7170, 4.7183] |
| 1.5 | [4.7170, 4.7183] |
| 2.0 | [4.7170, 4.7183] |
| 3.0 | [4.7158, 4.7207] |

**Observed: the boundary is approximately invariant with respect to E2 over
the tested domain E2 in [-0.5, 3.0].** NOT claimed: that the boundary is
mathematically independent of E2, or that this holds outside the tested
range. NOT claimed: any analytical explanation for the invariance. The
possible relationship to the system's fast/slow spectral structure
(already established at large in Increment 4a) is noted explicitly as an
UNTESTED HYPOTHESIS, not a finding.

## 5. Convergence and cross-checks

| Check | Result |
|---|---|
| dt = 5us vs 2.5us | Identical classification at all tested points |
| T_max = 0.15s vs 0.3s | Identical |
| Grid resolution (coarse 5pt vs fine 0.005-spacing) | Consistent boundary location |
| Deterministic reproducibility | Confirmed (Layer A uses fixed starting points, no RNG) |

## 6. Convergence criterion vs. equilibrium residual — kept explicitly distinct

- **Trajectory convergence criterion**: ||x(T) - x_e|| < 1e-3 at T=t_max —
  the numerical test used to classify a trajectory's endpoint. This is
  NOT an equilibrium residual. A representative value: 7.13e-07 (distance
  of one trajectory's final state from x_e1, well within tolerance).
- **Equilibrium residual**: F_f=F_s=g1=g2=g3=g4=0 evaluated at the claimed
  equilibrium itself, independent of any trajectory. x_e1: 4.16e-16.
  x_e2: 5.55e-16. Both machine precision, both established independently
  via direct fsolve on the full system, unrelated to any convergence
  tolerance choice.

These two numbers were previously reported adjacent to each other in a
way that risked being read as the same kind of quantity. They are not,
and are recorded separately here.

## 7. Boundary-value units discrepancy — investigated and reconciled

An apparent inconsistency (4.717 vs. 4.815-4.820) was raised and
investigated. Resolution: the two figures were in different unit
conventions (Delta i_q2 offset vs. absolute i_q2), both computed correctly,
both describing the same boundary. Converting either to the other's
convention recovers agreement to bisection precision. This was a
reporting-clarity error, not a computational bug, and does not constitute
an additional scientific finding. Recorded here for traceability; not
carried forward as a "second boundary."

## 8. Increment 4a frozen baseline — confirmed unmodified

```
md5sum /tmp/increment4a_FROZEN_BASELINE/inc4a_model.py
  = a03aa27ef3086caeb15a01a39fa9749f  (unchanged from original freeze)
```

## 9. What has NOT been done (explicitly, to prevent scope creep)

- No claim of global/analytical ROA characterization over all of R^2
- No IMS manifold, spectral gap, or transverse-attractivity analysis
  performed as PART OF this ROA study (Increment 4a's own, separately
  frozen IMS results are not modified or extended here)
- No connection between the observed E2-invariance and the fast/slow
  spectral structure has been demonstrated — flagged as hypothesis only
- No decision made about inclusion in the Guoqing demonstrator
- No clean-environment reproducibility test yet performed (see section 10,
  pending)

---

## 10. Clean-environment reproducibility test — PASSED

Performed in `/tmp/increment_roa_clean_test/`, containing only the 4
authoritative files (`inc4a_model.py`, `roa_branch_enum.py`,
`roa_branch_tracker.py`, `roa_classify.py`), no other session state.

| Item | Reproduced | Matches record |
|---|---|---|
| x_e1 algebraic branch | V=[0.9613,0.9856,0.8826,0.9777], residual 1.20e-15 | Yes |
| x_e2 algebraic branch | V=[0.6980,0.8894,0.0813,0.9312], residual 1.14e-15 | Yes |
| Boundary at E2=-0.5 | [4.7158,4.7183] | Yes |
| Boundary at E2=1.000632 | [4.7158,4.7183] | Yes |
| Boundary at E2=3.0 | [4.7158,4.7183] | Yes |
| dt=5us vs 2.5us | Identical | Yes |
| Convergence distance sample | 7.23e-07 (vs. recorded 7.13e-07 -- consistent, both well within 1e-3 tolerance) | Yes |

**Conclusion: methodology is genuinely reproducible from a clean
environment, independent of session state.**

---

## Status: FROZEN (methodology and numerically-scoped results)

Frozen as an independent, reproducibility-verified analysis on this date.
This freeze covers the ROA methodology (Layer A/B reuse, branch-selection
convention, convergence criterion) and its results exactly as scoped in
Section 0 — a numerically mapped ROA approximation over the tested 2-D
initial-condition domain, not a global or analytical characterization.

**Freezing this result is a separate decision from including it in the
Guoqing demonstrator.** The demonstrator-inclusion decision remains open
and is not implied by this freeze.

If the demonstrator inclusion proceeds, the intended framing is:
- **IMS** (Increment 4a, already separately frozen): geometric/manifold-based
  stability and recoverability analysis — intrinsic manifold persistence,
  normal hyperbolicity, transverse attractivity.
- **ROA** (this record): numerical mapping of the initial-condition regions
  converging to each identified equilibrium.

These are complementary, not substitutable. ROA must never be presented as
proof of, or a replacement for, IMS recoverability, and the boundary
Delta i_q2* ~ 4.717 must always be captioned as a **numerically identified
ROA boundary over the tested domain**, never as a global analytical ROA
boundary.
