# Increment 4b — Frozen Architecture and Traceability Record

**Status: architecture frozen, reproducibility-verified. NOT yet scientifically closed —
ROA and any IMS applicability remain open, deliberately unaddressed questions.**

**Terminology hierarchy in force throughout this record (do not conflate):**
```
algebraic feasibility  ->  algebraic branch identity  ->  dynamic branch tracking
  -> local equilibrium stability -> 1-D disturbance-induced branch transition
```
ROA and IMS recoverability are SEPARATE, NOT-YET-PERFORMED analyses. Nothing in
this record should be read as an ROA or IMS claim.

---

## 1. Authoritative (frozen) modules

| File | Role |
|---|---|
| `inc4b_model.py` | Ground-truth algebraic equations (`full_g`), Newton solver (`solve_V_newton`) |
| `inc4b_branch_enum.py` | **Layer A** — deterministic algebraic branch enumeration |
| `inc4b_branch_tracker.py` | **Layer B** — dynamic branch tracking with 4-way status |
| `inc4b_integrator_v2.py` | Converter-side (Δi_q) trajectory integrator, built on Layers A+B |
| `inc4b_bus3_v2.py` | Bus3-directed (ΔQ0,3) trajectory integrator, built on Layers A+B |

All five copied into `/tmp/increment4b_FROZEN_BASELINE/`.

## 2. Superseded modules — explicitly marked, must not be used

`inc4b_fast.py`, `inc4b_recover.py`, `inc4b_landscape.py`, `inc4b_landscape2.py`,
`inc4b_rigorous_feasibility.py`, `inc4b_sim.py`, and `SUPERSEDED_landscape_v1/`
— all archived under `SUPERSEDED/` with a README documenting the specific defect
in each (three sequential bugs in the RNG/search-based classifier: tracking_lost
mishandling, insufficient fixed-seed coverage, non-deterministic shared RNG state,
and finally a structural range-coverage gap that motivated the full rebuild).
The withdrawn "interleaved/fractal-like landscape" interpretation is recorded
there as explicitly withdrawn, not deleted, for traceability.

## 3. Layer A — algebraic feasibility, structurally derived

Definition: **S(i_q, Q0,3) = {V : g(V,i_q,Q0,3)=0, V_k>0}** — not ROA, not
recoverability, an existence question only.

Derivation: V1, V2 each have a unique nontrivial root (their own quadratics
factor as V·(linear), the V=0 root excluded by admissibility). V3, V4 are
genuinely quadratic (no trivial factor) — up to 2 branches each. Complete
solution set: at most 2×2=4 branch combinations, each solved as a small,
explicit fixed-point problem in (V1,V2) via deterministic (non-random) fixed
starting points.

**Verified deterministic**: identical results (to displayed float precision)
across 3 independent runs of the same query.

## 4. Both equilibria — independently reproduced in a clean environment

At i_q=0.08809, Q0,3=0.10:

| branch_id | V = [V1,V2,V3,V4] | residual | det(J_g) | cond(J_g) | local eigenvalue | stable |
|---|---|---|---|---|---|---|
| V3[1]_V4[1] (original) | [0.9597, 0.9824, 0.8809, 0.9761] | 1.03e-15 | -289.92 | 15.57 | -1166.40 | Yes |
| V3[0]_V4[1] (second) | [0.6836, 0.8473, **0.0836**, 0.9115] | 2.22e-16 | +186.39 | 12.97 | -1076.01 | Yes |

Both reproduced exactly in `/tmp/increment4b_clean_test/` (only the 5 frozen
files present, no other state). Second branch's V3≈0.084 pu is mathematically
admissible and locally stable, but operationally unrealistic (Bus3 severely
depressed) — this distinction is preserved, not smoothed over.

## 5. Converter-side (Δi_q) result — reproduced exactly

```
diq <= 3.3242: settles to the ORIGINAL equilibrium
diq >= 3.3262: settles to the SECOND (branch2) equilibrium
Transition bracket: [3.3242, 3.3262], dt=5us
Cross-checked dt=2.5us: diq=3.324 -> original, diq=3.326 -> branch2 (consistent)
```

**Exact permitted description**: "converter-side disturbance-induced transition
between two locally stable equilibria." **Not** collapse (no infeasibility
occurred at any point in this sweep). **Not** a recoverability boundary. **Not**
an ROA boundary (this is one 1-D slice through initial-condition space via a
single disturbance direction with all else fixed — not the mapped set of
initial conditions converging to either equilibrium). **Not** an IMS boundary
(no manifold, no fast/slow structure, no transverse attractivity has been
established for this one-state system, nor was any attempted).

## 6. Bus3-directed matched-rho result — independently reconfirmed under the corrected architecture

```
Increment 4a (GFM+VoltVAR), rho=1%: critical dQ0,3 = 0.001631 (frozen, unchanged, separate model)
Increment 4b (GFL+VoltVAR), rho=1%: critical dQ0,3 = 0.001293
  dt=5us:   [0.001293, 0.001293]
  dt=2.5us: [0.001293, 0.001293]
  Zero branch transitions, zero tracking-failed events throughout the bisection.
GFL/GFM critical-amplitude ratio: 0.001293/0.001631 = 79.3%
```

Reproduced exactly in the clean-environment test (Section 8).

## 7. What has explicitly NOT been done

- No ROA mapped for either equilibrium (would require R(x_e) = {x0 : phi_t(x0) -> x_e},
  scanning a genuinely varied set of initial conditions, not a single disturbance direction)
- No IMS manifold, spectral gap, lambda_perp/lambda_parallel constructed or attempted
  for this one-state system — its single-state structure is itself preserved as a
  meaningful finding, not treated as a gap to be artificially filled
- No GFM-vs-GFL topological/basin comparison performed
- No search for genuine algebraic collapse (S=empty) beyond i_q~20; not pursued
  further per explicit instruction, since the architectural correction is the
  scientifically meaningful result at this stage, not an eventual collapse number

## 8. Clean-environment reproducibility test — PASSED

Performed in `/tmp/increment4b_clean_test/`, containing only the 5 frozen
files above, no other session state, no cached solutions, no RNG state carried
over (Layer A uses fixed deterministic starting points, not RNG, by design).

| Item | Reproduced value | Matches frozen record |
|---|---|---|
| Original equilibrium | [0.9597,0.9824,0.8809,0.9761], residual 1.03e-15 | Yes |
| Second equilibrium | [0.6836,0.8473,0.0836,0.9115], residual 2.22e-16 | Yes |
| Local eigenvalues | -1166.40, -1076.01 (both stable) | Yes |
| Converter-side transition | [3.3242,3.3262] (dt=5us), consistent at dt=2.5us | Yes |
| Bus3-directed matched-rho | 0.001293 (dt=5us AND dt=2.5us) | Yes |

## 9. Current validated scientific statement (frozen, verbatim)

> GFL introduces a one-state nonlinear system with multiple admissible, locally
> stable equilibria and a disturbance-direction-dependent transition between
> them, while the validated Bus3-directed matched-rho result remains 0.001293,
> or 79.3% of the corresponding GFM+Volt-VAR threshold.

This statement is kept explicitly separate from any future ROA or IMS claim,
per instruction. Next steps (a formal ROA study, and/or a decision on whether
any part of this model supports an IMS-style analysis) are open and undecided,
not implied by anything in this record.
