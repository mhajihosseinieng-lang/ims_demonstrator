# Increment 2 — Frozen Validated Baseline

**Status: scientifically closed. Do not modify without explicit re-validation.**

## Physical model
Two-bus algebraically coupled converter-network model (NOT "two dynamic buses" --
V1, V2 are both algebraic; only i_q1 (fast) and E1 (slow) are dynamic states).
Bus 1: voltage-behind-reactance GFM converter (E1 behind Xc). Bus 2: passive,
constant-power reactive load + shunt. Line 2-3 to a stiff external grid.

Parameters (frozen): X12=0.4, X23=0.4, Xc=0.15, Bshunt1=0.0, Bshunt2=-0.05,
Q0_2=0.15, Enom=1.05, nQ=0.5, Qset=0.0, Vgrid=1.0, tau_I=0.002s, tau_Q=0.03s.

## Validated quantitative results (frozen)
- Fold: Q0,1* = 0.63054 (simultaneous solution of Ff=0,Fs=0,g=0,g_V=0; residuals ~1e-14)
- Critical recoverable amplitude (bisected, dt=5us, cross-verified dt=2.5us):
  - Q0,1=0.30 (normal):       [0.73125, 0.73145]  ~= 0.7313
  - Q0,1=0.50 (intermediate): [0.32402, 0.32422]  ~= 0.3241
  - Q0,1=0.62 (near-fold):    [0.028555, 0.028564] ~= 0.0286
- Recoverability reduction: 0.7313 / 0.0286 ~= 25.6x
- Spectral gap widens toward the fold (alpha diverges, beta stays ~44-48) --
  IFT-regularity failure (det(J_g)->0), NOT normal-hyperbolicity failure.

## Three-way trajectory classification -- both non-recovery outcomes validated
1. RECOVERED: e.g. diq1=0.0285 at Q0,1=0.62 -- literal RK4 trajectory saved
   (traj_diq_0.0285.npy), i_q1 returns to 0.62372.
2. DRIFTED TO ANOTHER ADMISSIBLE EQUILIBRIUM: e.g. diq1=0.0286, 0.0287 at
   Q0,1=0.62 -- literal RK4 trajectories saved (traj_diq_0.0286.npy,
   traj_diq_0.0287.npy). Final state (i_q1~4.535, E1~0.793, V1~0.113,
   V2~0.491) independently verified: admissible (V1,V2>0), IFT-regular
   (det(J_g)=-11.63), locally stable (reduced-Jacobian eigenvalues
   -0.930+-0.230j, both Re<0).
3. GENUINE COLLAPSE (algebraic infeasibility): validated via the Q0,1
   disturbance-STEP test (0.3 -> 0.8, crossing Q0,1* at t=50ms) -- i_q1, E1
   remain finite and UNCHANGED through the event (states had no time to
   evolve); the algebraic network equations g1=g2=0 lose their real solution
   the instant Q0,1 crosses the fold. This is the validated example of this
   outcome category; it was not produced by the i_q1-amplitude sweep at
   Q0,1=0.62 within the tested range, which instead produced only outcomes
   1 and 2 above.

## Two permanent numerical-methodology rules established this increment
1. Never trust a nonlinear solver's success/convergence flag -- verify the
   actual residual norm directly (caught: scipy `method=lm` false convergence
   with residual ~0.04 reported as success=True).
2. Integration step size (dt) must be FIXED and independently
   convergence-verified -- NEVER let dt scale with T_MAX/n_steps (caught:
   this exact pattern silently reintroduced RK4-overshoot collapse artifacts
   near the fold, producing a materially wrong "very small margin" result
   that was corrected only by fixing dt independently and re-verifying at a
   second, tighter dt).

## Files in this baseline
- inc2_model3.py, inc2_fast.py, inc2_robust.py -- fixed-window and
  fine-scan/global-scan algebraic solvers (the fine-scan fix, replacing an
  earlier endpoint-only bracket check that missed closely-spaced roots near
  the fold, is load-bearing -- do not revert to the endpoint-only version).
- inc2_final2.py, inc2_sim2.py -- RK4 integrators with the three-way
  classifier (ok / tracking_lost / infeasible at the algebraic level;
  recovered / drifted_to_other_branch / collapsed at the trajectory level).
- traj_diq_0.0285/0.0286/0.0287.npy, traj_data.json -- literal saved
  trajectories embedded in the demonstration widget. Do not regenerate with
  different parameters without updating the frozen record.
