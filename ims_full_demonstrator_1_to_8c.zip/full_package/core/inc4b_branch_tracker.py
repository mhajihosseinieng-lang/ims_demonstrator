"""
Layer B -- Dynamic branch tracking.

At every RK4 stage, determines which admissible algebraic branch is
DYNAMICALLY CONSISTENT with the current state (closest to the previous
V, via local Newton warm-start first, since that is cheap and correct
almost always for small steps), and explicitly distinguishes:

  'continuation'   -- local Newton succeeded, same branch as before
  'transition'      -- local Newton failed, but the FULL branch enumeration
                        (Layer A) finds an admissible solution -- a genuine
                        transition to a different branch, not a failure
  'tracking_failed' -- local Newton failed AND the branch closest to the
                        previous V could not be re-acquired, but Layer A's
                        enumeration is not exhaustive at this exact instant
                        (should not normally occur, since Layer A's
                        enumeration IS exhaustive given the derived
                        structure -- retained as a distinct diagnostic
                        category rather than silently merged with collapse)
  'infeasible'      -- Layer A's COMPLETE branch enumeration returns an
                        EMPTY set (S(iq2,Q3)=empty) -- the only condition
                        that may be called genuine algebraic infeasibility

tracking_lost / tracking_failed NEVER automatically becomes 'infeasible'.
"""
import numpy as np
from inc4b_branch_enum import full_g, enumerate_branches, P

def local_newton(iq2, Q3, V_guess, p=P, tol=1e-12, max_iter=30):
    V = np.array(V_guess, dtype=float)
    for _ in range(max_iter):
        g = full_g(V[0],V[1],V[2],V[3], iq2, Q3, p)
        if np.max(np.abs(g)) < tol:
            return V, True
        h = 1e-7
        J = np.zeros((4,4))
        for j in range(4):
            Vp = V.copy(); Vp[j]+=h
            Vm = V.copy(); Vm[j]-=h
            J[:,j] = (full_g(*Vp, iq2, Q3, p) - full_g(*Vm, iq2, Q3, p)) / (2*h)
        try:
            dV = np.linalg.solve(J, -g)
        except np.linalg.LinAlgError:
            return V, False
        if np.any(V + dV <= 0):
            return V, False
        V = V + dV
    return V, False

def track_state(iq2, Q3, V_prev, p=P):
    """
    Returns (status, V) where status in
    {'continuation','transition','tracking_failed','infeasible'}.
    """
    V_new, ok = local_newton(iq2, Q3, V_prev, p)
    if ok:
        return 'continuation', V_new
    # local tracking failed -- consult the COMPLETE branch enumeration (Layer A)
    branches = enumerate_branches(iq2, Q3, p)
    if not branches:
        return 'infeasible', None
    # genuine transition: closest admissible branch to the previous state
    best = min(branches, key=lambda b: np.linalg.norm(b['V']-V_prev))
    return 'transition', best['V']
