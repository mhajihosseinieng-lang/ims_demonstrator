import numpy as np
from inc2_fast import P, classify_and_track_fast

def integrate_and_classify(iq0, E0, Q0_1, tau_I, tau_Q, V1_ref0, t_max, dt):
    n_steps = int(round(t_max/dt))
    V1_ref = [V1_ref0]
    n_tracking_lost = [0]

    def rhs(y):
        iq1, E1 = y
        status, V1, V2 = classify_and_track_fast(iq1, Q0_1, V1_ref[0])
        if status == 'infeasible':
            return None, status
        if status == 'tracking_lost':
            n_tracking_lost[0] += 1
        V1_ref[0] = V1
        f1 = ((E1-V1)/P['Xc'] - iq1) / tau_I
        f2 = (-E1 + P['Enom'] - P['nQ']*(V1*iq1 - P['Qset'])) / tau_Q
        return np.array([f1,f2]), status

    y = np.array([iq0,E0], dtype=float)
    t = 0.0
    for step in range(n_steps):
        k1,s1 = rhs(y)
        if s1=='infeasible': return 'infeasible', y, t, n_tracking_lost[0]
        k2,s2 = rhs(y+dt/2*k1)
        if s2=='infeasible': return 'infeasible', y, t+dt/2, n_tracking_lost[0]
        k3,s3 = rhs(y+dt/2*k2)
        if s3=='infeasible': return 'infeasible', y, t+dt/2, n_tracking_lost[0]
        k4,s4 = rhs(y+dt*k3)
        if s4=='infeasible': return 'infeasible', y, t+dt, n_tracking_lost[0]
        y = y + (dt/6)*(k1+2*k2+2*k3+k4)
        t += dt
    return 'recovered', y, None, n_tracking_lost[0]
