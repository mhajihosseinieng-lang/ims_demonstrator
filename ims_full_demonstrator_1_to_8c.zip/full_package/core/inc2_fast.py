import numpy as np
from scipy.optimize import brentq

P = dict(Bshunt1=0.0, X12=0.4, Enom=1.05, nQ=0.5, Qset=0.0, Xc=0.15,
          Bshunt2=-0.05, Q0_2=0.15, X23=0.4, Vgrid=1.0)

def V2_roots(V1, p=P):
    a = p['Bshunt2'] - 1.0/p['X12'] - 1.0/p['X23']
    b = V1/p['X12'] + p['Vgrid']/p['X23']
    c = -p['Q0_2']
    disc = b**2 - 4*a*c
    if disc < 0: return None
    sq = np.sqrt(disc)
    return sorted([(-b+sq)/(2*a), (-b-sq)/(2*a)])

def g1(V1, V2, iq1, Q0_1, p=P):
    return V1*iq1 + p['Bshunt1']*V1**2 - Q0_1 - V1*(V1-V2)/p['X12']

def newton_local(iq1, Q0_1, V1_guess, p=P, tol=1e-11, max_iter=25):
    """Fast Newton on V1 (upper V2-branch), for the common case where V1_guess is already close."""
    V1 = V1_guess
    for _ in range(max_iter):
        r = V2_roots(V1, p)
        if r is None: return None
        V2 = r[1]
        f = g1(V1, V2, iq1, Q0_1, p)
        if abs(f) < tol:
            return V1, V2
        h = 1e-7
        r2 = V2_roots(V1+h, p)
        if r2 is None: return None
        fph = g1(V1+h, r2[1], iq1, Q0_1, p)
        dfdV1 = (fph-f)/h
        if abs(dfdV1) < 1e-12: return None
        V1_new = V1 - f/dfdV1
        if V1_new <= 0: return None
        V1 = V1_new
    return None

def fine_scan(iq1, Q0_1, V1_ref, window=0.15, n_scan=250, p=P):
    lo, hi = max(1e-4, V1_ref-window), V1_ref+window
    V1_grid = np.linspace(lo, hi, n_scan)
    vals = np.full(n_scan, np.nan)
    for i, V1 in enumerate(V1_grid):
        r = V2_roots(V1, p)
        if r is not None:
            vals[i] = g1(V1, r[1], iq1, Q0_1, p)
    roots = []
    for i in range(n_scan-1):
        if np.isnan(vals[i]) or np.isnan(vals[i+1]): continue
        if vals[i]*vals[i+1] < 0:
            def h(V1):
                r = V2_roots(V1, p); return g1(V1, r[1], iq1, Q0_1, p)
            V1c = brentq(h, V1_grid[i], V1_grid[i+1], xtol=1e-12)
            r = V2_roots(V1c, p)
            roots.append((V1c, r[1]))
    return roots

def global_scan(iq1, Q0_1, V1_lo=0.001, V1_hi=3.0, n_scan=4000, p=P):
    V1_grid = np.linspace(V1_lo, V1_hi, n_scan)
    vals = np.full(n_scan, np.nan)
    for i, V1 in enumerate(V1_grid):
        r = V2_roots(V1, p)
        if r is not None:
            vals[i] = g1(V1, r[1], iq1, Q0_1, p)
    roots = []
    for i in range(n_scan-1):
        if np.isnan(vals[i]) or np.isnan(vals[i+1]): continue
        if vals[i]*vals[i+1] < 0:
            def h(V1):
                r = V2_roots(V1, p); return g1(V1, r[1], iq1, Q0_1, p)
            V1c = brentq(h, V1_grid[i], V1_grid[i+1], xtol=1e-12)
            r = V2_roots(V1c, p)
            roots.append((V1c, r[1]))
    return roots

def classify_and_track_fast(iq1, Q0_1, V1_ref):
    """
    Tiered: (1) fast Newton from V1_ref -- succeeds almost always for adjacent
    RK4 stages. (2) fine local scan if Newton fails. (3) exhaustive global scan
    if local also fails -- distinguishes tracking_lost from genuine infeasible.
    """
    n = newton_local(iq1, Q0_1, V1_ref)
    if n is not None and abs(n[0]-V1_ref) < 0.3:  # sanity: Newton didn't jump to a wildly different branch
        return 'ok', n[0], n[1]
    local_roots = fine_scan(iq1, Q0_1, V1_ref)
    if local_roots:
        best = min(local_roots, key=lambda r: abs(r[0]-V1_ref))
        return 'ok', best[0], best[1]
    g_roots = global_scan(iq1, Q0_1)
    if not g_roots:
        return 'infeasible', None, None
    best = min(g_roots, key=lambda r: abs(r[0]-V1_ref))
    return 'tracking_lost', best[0], best[1]
