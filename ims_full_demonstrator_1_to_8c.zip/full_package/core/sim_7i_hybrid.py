"""
Increment 7I -- hybrid integrator with s_PV (frozen, unchanged) and s_sh3
(new). Both triggers evaluated on the SAME pre-event/post-step state;
both latches updated simultaneously, matching 7C's convention exactly.
"""
import numpy as np
from layerA_equilibria_7i import full_g_param
from layerA_equilibria import Xc, Enom, nQ, Qset

tau_I, tau_Q = 0.002, 0.03
V_TRIP = 1.10

def solve_V_param(iq2, K_PV, Bsh3, V_guess, tol=1e-13, max_iter=40):
    V = np.array(V_guess, dtype=float)
    for _ in range(max_iter):
        g = full_g_param(V[0],V[1],V[2],V[3], iq2, K_PV, Bsh3)
        if np.max(np.abs(g)) < tol: return V, True
        h = 1e-7
        J = np.zeros((4,4))
        for j in range(4):
            Vp=V.copy(); Vp[j]+=h; Vm=V.copy(); Vm[j]-=h
            J[:,j] = (full_g_param(*Vp,iq2,K_PV,Bsh3) - full_g_param(*Vm,iq2,K_PV,Bsh3))/(2*h)
        try: dV = np.linalg.solve(J,-g)
        except np.linalg.LinAlgError: return V, False
        if np.any(V+dV<=0): return V, False
        V = V+dV
    return V, False

def integrate_7i(iq0, E0, V_ref0, t_max, dt, V3_trip, record_trace=False):
    s_PV, s_sh3 = 0, 0
    K_PV = 5.0
    Bsh3 = -0.05
    y = np.array([iq0, E0], dtype=float)
    V_ref = [np.array(V_ref0, dtype=float)]
    event_log = []

    # t=0 event evaluation
    V0, ok0 = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
    if not ok0: return 'infeasible', y, (s_PV,s_sh3), event_log
    V_ref[0] = V0
    T_PV = V0[3] >= V_TRIP
    T_sh3 = V0[2] >= V3_trip
    if T_PV or T_sh3:
        s_PV = 1 if T_PV else s_PV
        s_sh3 = 1 if T_sh3 else s_sh3
        K_PV = 0.0 if s_PV==1 else 5.0
        Bsh3 = 0.0 if s_sh3==1 else -0.05
        Vp, okp = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
        if not okp: return 'infeasible_at_switch', y, (s_PV,s_sh3), event_log
        V_ref[0] = Vp
        event_log.append((0.0, T_PV, T_sh3, s_PV, s_sh3))

    def rhs(y):
        V, ok = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
        if not ok: return None
        V_ref[0] = V
        f1 = ((y[1]-V[1])/Xc - y[0])/tau_I
        f2 = (-y[1]+Enom-nQ*(V[1]*y[0]-Qset))/tau_Q
        return np.array([f1,f2])

    n_steps = int(round(t_max/dt))
    for step in range(n_steps):
        k1=rhs(y)
        if k1 is None: return 'infeasible', y, (s_PV,s_sh3), event_log
        k2=rhs(y+dt/2*k1)
        if k2 is None: return 'infeasible', y, (s_PV,s_sh3), event_log
        k3=rhs(y+dt/2*k2)
        if k3 is None: return 'infeasible', y, (s_PV,s_sh3), event_log
        k4=rhs(y+dt*k3)
        if k4 is None: return 'infeasible', y, (s_PV,s_sh3), event_log
        y = y+(dt/6)*(k1+2*k2+2*k3+k4)
        t = (step+1)*dt

        V_check, ok_check = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
        if not ok_check: return 'infeasible', y, (s_PV,s_sh3), event_log
        V_ref[0] = V_check
        T_PV = (s_PV==0) and (V_check[3] >= V_TRIP)
        T_sh3 = (s_sh3==0) and (V_check[2] >= V3_trip)
        if T_PV or T_sh3:
            s_PV_new = 1 if T_PV else s_PV
            s_sh3_new = 1 if T_sh3 else s_sh3
            K_PV_new = 0.0 if s_PV_new==1 else 5.0
            Bsh3_new = 0.0 if s_sh3_new==1 else -0.05
            Vp, okp = solve_V_param(y[0], K_PV_new, Bsh3_new, V_ref[0])
            if not okp: return 'infeasible_at_switch', y, (s_PV_new,s_sh3_new), event_log
            s_PV, s_sh3, K_PV, Bsh3 = s_PV_new, s_sh3_new, K_PV_new, Bsh3_new
            V_ref[0] = Vp
            event_log.append((t, T_PV, T_sh3, s_PV, s_sh3))
    return 'completed', y, (s_PV,s_sh3), event_log

# Hardened M0 search (7N) -- survives isolated solver failures at bracket
# endpoints by scanning inward with a dense grid rather than trusting a
# single wide bracket.
def iq2_star_at_robust(E2, iq2_guess, V_guess, K_PV, Bsh3, window=0.05, max_window=5.0):
    import numpy as np
    from scipy.optimize import brentq
    Xc_local = 0.15
    def Ff_local(iq2, Vr):
        V, ok = solve_V_param(iq2, K_PV, Bsh3, Vr)
        if not ok: return None, None
        return (E2-V[1])/Xc_local - iq2, V
    n_scan = 40
    w = window
    while w <= max_window:
        pts = np.linspace(iq2_guess-w, iq2_guess+w, n_scan)
        prev_iq2, prev_f, prev_V = None, None, V_guess
        for iq2_t in pts:
            f, V = Ff_local(iq2_t, prev_V)
            if f is None: continue
            if prev_f is not None and prev_f*f < 0:
                def h(x):
                    v,_ = Ff_local(x, prev_V)
                    return v if v is not None else 1e6
                try:
                    root = brentq(h, prev_iq2, iq2_t, xtol=1e-12)
                    _, Vroot = Ff_local(root, prev_V)
                    return root, Vroot
                except Exception:
                    pass
            prev_iq2, prev_f, prev_V = iq2_t, f, V
        w *= 2
    return None, None
