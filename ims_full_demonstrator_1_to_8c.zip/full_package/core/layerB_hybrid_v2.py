"""
Layer B v2 -- hardened hybrid dynamic branch tracking for Increment 5A.

Fixes the state-dependent RK4 sub-stage failure found in v1: each sub-stage
now solves from an EXPLICIT, PASSED-IN branch reference (not a shared
mutable object silently corrupted by a prior failed sub-stage). A failed
sub-stage NEVER writes back to the caller's reference.

Escalation order per sub-stage:
  1. local Newton (cheap, correct for small steps) from the given reference
  2. deterministic full branch enumeration (wide, not narrow-seed) if (1) fails
  3. if BOTH fail, an INDEPENDENT wide verification scan (different starting
     grid entirely) before accepting infeasibility
  4. only if (3) ALSO finds nothing is genuine infeasibility returned

Every accepted sub-stage records (branch_id, V, residual) for traceability.
"""
import numpy as np
from scipy.optimize import fsolve
from layerA_equilibria import full_g, Q3

def local_newton(iq2, K_PV, V_ref, tol=1e-12, max_iter=30):
    V = np.array(V_ref, dtype=float)
    for _ in range(max_iter):
        g = full_g(V[0],V[1],V[2],V[3], iq2, K_PV)
        if np.max(np.abs(g)) < tol:
            return V, True, float(np.max(np.abs(g)))
        h = 1e-7
        J = np.zeros((4,4))
        for j in range(4):
            Vp = V.copy(); Vp[j]+=h
            Vm = V.copy(); Vm[j]-=h
            J[:,j] = (full_g(*Vp, iq2, K_PV) - full_g(*Vm, iq2, K_PV)) / (2*h)
        try:
            dV = np.linalg.solve(J, -g)
        except np.linalg.LinAlgError:
            return V, False, None
        if np.any(V + dV <= 0):
            return V, False, None
        V = V + dV
    return V, False, None

def full_branch_scan(iq2, K_PV, starts=None):
    """Wide, deterministic multi-start -- fixed grid, not seed-dependent."""
    if starts is None:
        starts = []
        for v1_0 in [0.3,0.9,1.5,2.5,4.0]:
            for v2_0 in [0.3,0.9,1.5,2.5,4.0]:
                starts.append([v1_0,v2_0,v1_0*0.9,v2_0*0.95])
    results = []
    for x0 in starts:
        sol, info, ier, msg = fsolve(lambda V: full_g(V[0],V[1],V[2],V[3],iq2,K_PV), x0, full_output=True, xtol=1e-13)
        res = full_g(sol[0],sol[1],sol[2],sol[3],iq2,K_PV)
        if ier==1 and max(abs(r) for r in res)<1e-9 and all(v>0 for v in sol):
            is_new = all(not np.allclose(sol, r, atol=1e-5) for r in results)
            if is_new: results.append(sol)
    return results

_INDEPENDENT_STARTS = []
for v1_0 in [0.05, 0.6, 1.2, 2.0, 3.2, 5.0]:
    for v2_0 in [0.05, 0.6, 1.2, 2.0, 3.2, 5.0]:
        _INDEPENDENT_STARTS.append([v1_0, v2_0, v1_0*1.1, v2_0*0.85])

def independent_verify(iq2, K_PV):
    """A DIFFERENT starting grid entirely -- genuinely independent, not a
    re-run of the same seeds that already failed."""
    return full_branch_scan(iq2, K_PV, starts=_INDEPENDENT_STARTS)

def track_substage(iq2, K_PV, V_ref):
    """
    Returns (status, V, branch_id, residual).
    status in {'continuation','transition','infeasible'}.
    NEVER mutates V_ref -- caller decides what to do with the result.
    """
    V_new, ok, res = local_newton(iq2, K_PV, V_ref)
    if ok:
        return 'continuation', V_new, 'local', res

    branches = full_branch_scan(iq2, K_PV)
    if branches:
        best = min(branches, key=lambda v: np.linalg.norm(v-np.array(V_ref)))
        res_best = np.max(np.abs(full_g(*best, iq2, K_PV)))
        return 'transition', best, 'scan', float(res_best)

    branches2 = independent_verify(iq2, K_PV)
    if branches2:
        best = min(branches2, key=lambda v: np.linalg.norm(v-np.array(V_ref)))
        res_best = np.max(np.abs(full_g(*best, iq2, K_PV)))
        return 'transition', best, 'independent_verify', float(res_best)

    return 'infeasible', None, None, None
