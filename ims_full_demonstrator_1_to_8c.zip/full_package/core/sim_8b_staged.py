"""
Increment 8B -- three-stage disturbance operator layered on the frozen
7C/7I hybrid integrator (s_PV, s_sh3 unchanged, V_trip=1.10, V3_trip=1.05
unchanged). The disturbance operator D(dE2) applies E2 += dE2 at a
specified accepted-state time, leaving iq2 untouched, then re-solves
V1-V4 under whatever protection mode is currently active.
"""
import numpy as np
from sim_7i_hybrid import solve_V_param

tau_I, tau_Q = 0.002, 0.03
Xc,Enom,nQ,Qset = 0.15,1.05,0.5,0.0
V_TRIP = 1.10
V3_TRIP = 1.05
V_s = [0.961317,0.985606,0.882601,0.977715]

def integrate_staged(iq0, E0, V_ref0, t_max, dt, disturbance_schedule=None):
    """
    disturbance_schedule: list of (t_k, dE2_k) pairs, sorted by time.
    Applied when the accepted-state time crosses t_k.
    """
    if disturbance_schedule is None:
        disturbance_schedule = []
    schedule = sorted(disturbance_schedule, key=lambda x: x[0])
    sched_idx = 0

    s_PV, s_sh3 = 0, 0
    K_PV = 5.0
    Bsh3 = -0.05
    y = np.array([iq0, E0], dtype=float)
    V_ref = [np.array(V_ref0, dtype=float)]
    event_log = []

    def check_and_apply_protection(t):
        nonlocal s_PV, s_sh3, K_PV, Bsh3
        T_PV = (s_PV==0) and (V_ref[0][3] >= V_TRIP)
        T_sh3 = (s_sh3==0) and (V_ref[0][2] >= V3_TRIP)
        if not (T_PV or T_sh3): return
        s_PV_new = 1 if T_PV else s_PV
        s_sh3_new = 1 if T_sh3 else s_sh3
        K_PV_new = 0.0 if s_PV_new==1 else 5.0
        Bsh3_new = 0.0 if s_sh3_new==1 else -0.05
        Vp, okp = solve_V_param(y[0], K_PV_new, Bsh3_new, V_ref[0])
        if not okp: return
        s_PV, s_sh3, K_PV, Bsh3 = s_PV_new, s_sh3_new, K_PV_new, Bsh3_new
        V_ref[0] = Vp
        event_log.append(('protection', t, T_PV, T_sh3, s_PV, s_sh3))

    def apply_disturbance(dE2, t):
        """The operator D(dE2): E2 += dE2, iq2 unchanged, re-solve V."""
        y[1] = y[1] + dE2
        Vp, okp = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
        if not okp: return False
        V_ref[0] = Vp
        event_log.append(('disturbance', t, dE2, y[0], y[1]))
        return True

    def rhs(y):
        V, ok = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
        if not ok: return None
        V_ref[0] = V
        f1 = ((y[1]-V[1])/Xc - y[0])/tau_I
        f2 = (-y[1]+Enom-nQ*(V[1]*y[0]-Qset))/tau_Q
        return np.array([f1,f2])

    V0, ok0 = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
    if not ok0: return 'infeasible', y, (s_PV,s_sh3), event_log
    V_ref[0] = V0
    check_and_apply_protection(0.0)
    while sched_idx < len(schedule) and schedule[sched_idx][0] <= 0.0:
        apply_disturbance(schedule[sched_idx][1], 0.0)
        sched_idx += 1
        check_and_apply_protection(0.0)

    n_steps = int(round(t_max/dt))
    t = 0.0
    for step in range(n_steps):
        k1=rhs(y)
        if k1 is None: return 'infeasible', y, (s_PV,s_sh3), event_log
        k2=rhs(y+dt/2*k1)
        if k2 is None: return 'infeasible', y, (s_PV,s_sh3), event_log
        k3=rhs(y+dt/2*k2)
        if k3 is None: return 'infeasible', y, (s_PV,s_sh3), event_log
        k4=rhs(y+dt*k3)
        if k4 is None: return 'infeasible', y, (s_PV,s_sh3), event_log
        y = y+(dt/6)*(k1+2*k2+2*k3+k4)
        t = (step+1)*dt

        # accepted-state: re-solve V, THEN check disturbance schedule, THEN protection
        V_check, ok_check = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
        if not ok_check: return 'infeasible', y, (s_PV,s_sh3), event_log
        V_ref[0] = V_check

        while sched_idx < len(schedule) and schedule[sched_idx][0] <= t:
            ok_d = apply_disturbance(schedule[sched_idx][1], t)
            if not ok_d: return 'infeasible_at_disturbance', y, (s_PV,s_sh3), event_log
            sched_idx += 1

        check_and_apply_protection(t)
    return 'completed', y, (s_PV,s_sh3), event_log
