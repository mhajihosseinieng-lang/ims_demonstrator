"""
Layer A -- Algebraic feasibility.

Given (iq2, Q0,3), determines the complete admissible algebraic solution
set S(iq2,Q0,3) = {V : g(V,iq2,Q0,3)=0, V_k>0}, via the STRUCTURAL degree
of each bus equation (not bounded random search):

  V1 = V1_of(V2,V3)      -- unique nontrivial root (g1 factors V*(linear))
  V2 = V2_of(V1,V4,iq2)  -- unique nontrivial root (g2 factors V*(linear))
  V3 in V3_branches(V1)  -- genuinely quadratic, up to 2 roots, no trivial factor
  V4 in V4_branches(V2)  -- genuinely quadratic, up to 2 roots, no trivial factor

giving at most 2x2=4 branch combinations, each solved as a small, explicit
fixed-point problem in (V1,V2). This is NOT called ROA, basin, collapse,
or recoverability -- it is the algebraic feasibility layer only.
"""
import numpy as np
from scipy.optimize import fsolve

P = dict(Xg1=0.4, X12=0.4, X13=0.5, X24=0.2, Q4=0.15, Bsh3=-0.05, Bsh4=0.0,
          Vgrid=1.0, K_PV=5.0, V4_ref=1.0)

def full_g(V1, V2, V3, V4, iq2, Q3, p=P):
    g1 = V1*(V1-p['Vgrid'])/p['Xg1'] + V1*(V1-V2)/p['X12'] + V1*(V1-V3)/p['X13']
    g2 = V2*iq2 - V2*(V2-V1)/p['X12'] - V2*(V2-V4)/p['X24']
    g3 = p['Bsh3']*V3**2 - Q3 - V3*(V3-V1)/p['X13']
    g4 = p['Bsh4']*V4**2 - p['Q4'] - V4*(V4-V2)/p['X24'] - p['K_PV']*(V4-p['V4_ref'])
    return np.array([g1,g2,g3,g4])

def V1_of(V2, V3, p=P):
    num = V2*p['X13']*p['Xg1'] + V3*p['X12']*p['Xg1'] + p['Vgrid']*p['X12']*p['X13']
    den = p['X12']*p['X13'] + p['X12']*p['Xg1'] + p['X13']*p['Xg1']
    return num/den

def V2_of(V1, V4, iq2, p=P):
    return (V1*p['X24'] + V4*p['X12'] + p['X12']*p['X24']*iq2) / (p['X12']+p['X24'])

def V3_branches(V1, Q3, p=P):
    a = p['Bsh3']*p['X13'] - 1.0
    disc = 4*p['Bsh3']*Q3*p['X13']**2 - 4*Q3*p['X13'] + V1**2
    if disc < 0: return None
    sq = np.sqrt(disc)
    return sorted([(-V1 - sq)/(2*a), (-V1 + sq)/(2*a)])

def V4_branches(V2, p=P):
    a = p['Bsh4']*p['X24'] - 1.0
    b_term = p['K_PV']*p['X24'] - V2
    disc = (-4*p['Bsh4']*p['K_PV']*p['V4_ref']*p['X24']**2 + 4*p['Bsh4']*p['Q4']*p['X24']**2
            + p['K_PV']**2*p['X24']**2 - 2*p['K_PV']*V2*p['X24'] + 4*p['K_PV']*p['V4_ref']*p['X24']
            - 4*p['Q4']*p['X24'] + V2**2)
    if disc < 0: return None
    sq = np.sqrt(disc)
    return sorted([(b_term - sq)/(2*a), (b_term + sq)/(2*a)])

# Fixed, deterministic starting points per branch -- NOT random, NOT session-history-dependent
_DETERMINISTIC_STARTS = [
    (0.5, 0.5), (1.0, 1.0), (0.3, 1.5), (1.5, 0.3), (2.0, 2.0),
    (0.2, 2.0), (2.0, 0.2), (0.8, 0.8), (3.0, 3.0), (0.5, 3.0),
]

def enumerate_branches(iq2, Q3, p=P, residual_tol=1e-9):
    """
    Layer A: complete admissible algebraic solution set, via structural
    branch enumeration + deterministic multi-start (not RNG-based).
    Returns a list of dicts, each a fully verified, admissible solution
    with a deterministic branch_id and diagnostic fields.
    """
    results = []
    for v3_idx in [0, 1]:
        for v4_idx in [0, 1]:
            branch_id = f"V3[{v3_idx}]_V4[{v4_idx}]"
            def resid(x):
                V1, V2 = x
                v3s = V3_branches(V1, Q3, p)
                v4s = V4_branches(V2, p)
                if v3s is None or v4s is None:
                    return [1e6, 1e6]
                V3, V4 = v3s[v3_idx], v4s[v4_idx]
                return [V1 - V1_of(V2, V3, p), V2 - V2_of(V1, V4, iq2, p)]
            for x0 in _DETERMINISTIC_STARTS:
                sol, info, ier, msg = fsolve(resid, x0, full_output=True, xtol=1e-13)
                if ier != 1:
                    continue
                V1, V2 = sol
                v3s = V3_branches(V1, Q3, p)
                v4s = V4_branches(V2, p)
                if v3s is None or v4s is None:
                    continue
                V3, V4 = v3s[v3_idx], v4s[v4_idx]
                if V1 <= 0 or V2 <= 0 or V3 <= 0 or V4 <= 0:
                    continue
                # verify against the FULL ORIGINAL equations, not just the reduced fixed point
                res_full = full_g(V1, V2, V3, V4, iq2, Q3, p)
                if np.max(np.abs(res_full)) > residual_tol:
                    continue
                candidate = np.array([V1, V2, V3, V4])
                is_new = all(not np.allclose(candidate, r['V'], atol=1e-6) for r in results)
                if is_new:
                    Jg = _jacobian(V1, V2, V3, V4, iq2, p)
                    results.append(dict(
                        branch_id=branch_id, V=candidate,
                        residual_norm=float(np.max(np.abs(res_full))),
                        admissible=True,
                        detJg=float(np.linalg.det(Jg)),
                        condJg=float(np.linalg.cond(Jg)),
                    ))
    return results

def _jacobian(V1,V2,V3,V4,iq2,p=P):
    dg1_dV1 = (2*V1-p['Vgrid'])/p['Xg1'] + (2*V1-V2)/p['X12'] + (2*V1-V3)/p['X13']
    dg1_dV2 = -V1/p['X12']; dg1_dV3 = -V1/p['X13']; dg1_dV4 = 0.0
    dg2_dV1 = V2/p['X12']
    dg2_dV2 = iq2 - (2*V2-V1)/p['X12'] - (2*V2-V4)/p['X24']
    dg2_dV3 = 0.0; dg2_dV4 = V2/p['X24']
    dg3_dV1 = V3/p['X13']; dg3_dV2 = 0.0
    dg3_dV3 = 2*p['Bsh3']*V3 - (2*V3-V1)/p['X13']; dg3_dV4 = 0.0
    dg4_dV1 = 0.0; dg4_dV2 = V4/p['X24']; dg4_dV3 = 0.0
    dg4_dV4 = 2*p['Bsh4']*V4 - (2*V4-V2)/p['X24'] - p['K_PV']
    return np.array([[dg1_dV1,dg1_dV2,dg1_dV3,dg1_dV4],
                      [dg2_dV1,dg2_dV2,dg2_dV3,dg2_dV4],
                      [dg3_dV1,dg3_dV2,dg3_dV3,dg3_dV4],
                      [dg4_dV1,dg4_dV2,dg4_dV3,dg4_dV4]])
