"""
Layer A for the ROA study -- reusing the SAME structural derivation validated
in Increment 4b (inc4b_branch_enum.py), since Bus1-Bus4's algebraic equations
are IDENTICAL between the GFM and GFL cases (only converter dynamics differ).
This is a deliberate reuse of validated infrastructure, not a new derivation.
"""
import numpy as np
from scipy.optimize import fsolve
from inc4a_model import P, full_g

def V1_of(V2, V3, p=P):
    num = V2*p['X13']*p['Xg1'] + V3*p['X12']*p['Xg1'] + p['Vgrid']*p['X12']*p['X13']
    den = p['X12']*p['X13'] + p['X12']*p['Xg1'] + p['X13']*p['Xg1']
    return num/den

def V2_of(V1, V4, iq2, p=P):
    return (V1*p['X24'] + V4*p['X12'] + p['X12']*p['X24']*iq2) / (p['X12']+p['X24'])

def V3_branches(V1, Q3, p=P):
    a = p['Bsh3']*p['X13'] - 1.0
    disc = 4*p['Bsh3']*Q3*p['X13']**2 - 4*Q3*p['X13'] + V1**2
    if disc < 0: return None
    sq = np.sqrt(disc)
    return sorted([(-V1 - sq)/(2*a), (-V1 + sq)/(2*a)])

def V4_branches(V2, p=P):
    a = p['Bsh4']*p['X24'] - 1.0
    b_term = p['K_PV']*p['X24'] - V2
    disc = (-4*p['Bsh4']*p['K_PV']*p['V4_ref']*p['X24']**2 + 4*p['Bsh4']*p['Q4']*p['X24']**2
            + p['K_PV']**2*p['X24']**2 - 2*p['K_PV']*V2*p['X24'] + 4*p['K_PV']*p['V4_ref']*p['X24']
            - 4*p['Q4']*p['X24'] + V2**2)
    if disc < 0: return None
    sq = np.sqrt(disc)
    return sorted([(b_term - sq)/(2*a), (b_term + sq)/(2*a)])

_DETERMINISTIC_STARTS = [
    (0.5, 0.5), (1.0, 1.0), (0.3, 1.5), (1.5, 0.3), (2.0, 2.0),
    (0.2, 2.0), (2.0, 0.2), (0.8, 0.8), (3.0, 3.0), (0.5, 3.0),
]

def enumerate_branches(iq2, Q3, p=P, residual_tol=1e-9):
    results = []
    for v3_idx in [0, 1]:
        for v4_idx in [0, 1]:
            branch_id = f"V3[{v3_idx}]_V4[{v4_idx}]"
            def resid(x):
                V1, V2 = x
                v3s = V3_branches(V1, Q3, p)
                v4s = V4_branches(V2, p)
                if v3s is None or v4s is None:
                    return [1e6, 1e6]
                V3, V4 = v3s[v3_idx], v4s[v4_idx]
                return [V1 - V1_of(V2, V3, p), V2 - V2_of(V1, V4, iq2, p)]
            for x0 in _DETERMINISTIC_STARTS:
                sol, info, ier, msg = fsolve(resid, x0, full_output=True, xtol=1e-13)
                if ier != 1: continue
                V1, V2 = sol
                v3s = V3_branches(V1, Q3, p)
                v4s = V4_branches(V2, p)
                if v3s is None or v4s is None: continue
                V3, V4 = v3s[v3_idx], v4s[v4_idx]
                if V1<=0 or V2<=0 or V3<=0 or V4<=0: continue
                res_full = full_g(V1, V2, V3, V4, iq2, Q3, p)
                if np.max(np.abs(res_full)) > residual_tol: continue
                candidate = np.array([V1, V2, V3, V4])
                is_new = all(not np.allclose(candidate, r['V'], atol=1e-6) for r in results)
                if is_new:
                    results.append(dict(branch_id=branch_id, V=candidate,
                                         residual_norm=float(np.max(np.abs(res_full)))))
    return results
