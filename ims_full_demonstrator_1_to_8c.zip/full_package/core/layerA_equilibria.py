"""
Layer A -- authoritative, deterministic equilibrium enumeration for the
Increment 5A hybrid system, valid for ANY K_PV (Mode 0: K_PV=5, Mode 1: K_PV=0).

Derivation: F_f=0, F_s=0 combined analytically give E2 and i_q2 as EXPLICIT
functions of V2 alone:
    E2(V2)  = (Enom*Xc + Qset*Xc*nQ + V2^2*nQ) / (V2*nQ + Xc)
    iq2(V2) = (Enom + Qset*nQ - V2) / (V2*nQ + Xc)
V1 is a fixed point of V1 = V1_of(V2, V3_branch(V1)) given V2 and a V3-branch
choice. V4 is a genuinely quadratic branch of V2 (2 choices), independent of
K_PV's branch count (K_PV enters the g4 coefficients but g4 remains quadratic
in V4 with no trivial root for any K_PV, verified below).

This reduces the FULL 6-equation dynamic equilibrium problem, for each of
4 (V3,V4) branch combinations, to a single 1D equation in V2 alone:
    g2(V1(V2), V2, V4_branch(V2), iq2(V2)) = 0
solved by a DENSE, DETERMINISTIC scan (not random search) over a wide V2
range, finding ALL sign changes -- not a single Newton attempt from one seed.
"""
import numpy as np
from scipy.optimize import brentq, fsolve

Xg1,X12,X13,X24 = 0.4,0.4,0.5,0.2
Q4,Bsh3,Bsh4,Vgrid,V4ref = 0.15,-0.05,0.0,1.0,1.0
Xc,Enom,nQ,Qset = 0.15,1.05,0.5,0.0
Q3 = 0.10

def E2_of_V2(V2):
    return (Enom*Xc + Qset*Xc*nQ + V2**2*nQ) / (V2*nQ + Xc)

def iq2_of_V2(V2):
    return (Enom + Qset*nQ - V2) / (V2*nQ + Xc)

def V3_branches(V1):
    a = Bsh3*X13 - 1.0
    disc = 4*Bsh3*Q3*X13**2 - 4*Q3*X13 + V1**2
    if disc < 0: return None
    sq = np.sqrt(disc)
    return sorted([(-V1 - sq)/(2*a), (-V1 + sq)/(2*a)])

def V4_branches(V2, K_PV):
    a = Bsh4*X24 - 1.0
    b_term = K_PV*X24 - V2
    disc = (-4*Bsh4*K_PV*V4ref*X24**2 + 4*Bsh4*Q4*X24**2
            + K_PV**2*X24**2 - 2*K_PV*V2*X24 + 4*K_PV*V4ref*X24
            - 4*Q4*X24 + V2**2)
    if disc < 0: return None
    sq = np.sqrt(disc)
    return sorted([(b_term - sq)/(2*a), (b_term + sq)/(2*a)])

def V1_fixed_point(V2, v3_idx, V1_guess=0.9):
    """V1 = V1_of(V2, V3_branch(V1)) -- solve the 1D fixed point."""
    def resid(V1):
        v3s = V3_branches(V1)
        if v3s is None: return 1e6
        V3 = v3s[v3_idx]
        num = V2*X13*Xg1 + V3*X12*Xg1 + Vgrid*X12*X13
        den = X12*X13 + X12*Xg1 + X13*Xg1
        return V1 - num/den
    try:
        sol = fsolve(resid, V1_guess, xtol=1e-13, full_output=False)[0]
        if abs(resid(sol)) > 1e-9: return None
        return sol
    except Exception:
        return None

def g2_residual(V2, v3_idx, v4_idx, K_PV):
    E2 = E2_of_V2(V2)
    iq2 = iq2_of_V2(V2)
    V1 = V1_fixed_point(V2, v3_idx)
    if V1 is None: return None
    v4s = V4_branches(V2, K_PV)
    if v4s is None: return None
    V4 = v4s[v4_idx]
    return V2*iq2 - V2*(V2-V1)/X12 - V2*(V2-V4)/X24

def full_g(V1,V2,V3,V4,iq2,K_PV):
    g1 = V1*(V1-Vgrid)/Xg1 + V1*(V1-V2)/X12 + V1*(V1-V3)/X13
    g2 = V2*iq2 - V2*(V2-V1)/X12 - V2*(V2-V4)/X24
    g3 = Bsh3*V3**2 - Q3 - V3*(V3-V1)/X13
    g4 = Bsh4*V4**2 - Q4 - V4*(V4-V2)/X24 - K_PV*(V4-V4ref)
    return np.array([g1,g2,g3,g4])

def enumerate_equilibria(K_PV, V2_range=(0.02, 6.0), n_scan=4000, residual_tol=1e-9):
    """Dense, deterministic scan over V2 for each of 4 branch combinations."""
    results = []
    V2_grid = np.linspace(V2_range[0], V2_range[1], n_scan)
    for v3_idx in [0,1]:
        for v4_idx in [0,1]:
            vals = []
            for V2 in V2_grid:
                r = g2_residual(V2, v3_idx, v4_idx, K_PV)
                vals.append(np.nan if r is None else r)
            vals = np.array(vals)
            for i in range(n_scan-1):
                if np.isnan(vals[i]) or np.isnan(vals[i+1]): continue
                if vals[i]*vals[i+1] < 0:
                    try:
                        V2_root = brentq(lambda v: g2_residual(v, v3_idx, v4_idx, K_PV),
                                          V2_grid[i], V2_grid[i+1], xtol=1e-12)
                    except Exception:
                        continue
                    V1 = V1_fixed_point(V2_root, v3_idx)
                    if V1 is None: continue
                    v3s = V3_branches(V1); v4s = V4_branches(V2_root, K_PV)
                    if v3s is None or v4s is None: continue
                    V3, V4 = v3s[v3_idx], v4s[v4_idx]
                    E2, iq2 = E2_of_V2(V2_root), iq2_of_V2(V2_root)
                    if V1<=0 or V2_root<=0 or V3<=0 or V4<=0: continue
                    res = full_g(V1,V2_root,V3,V4,iq2,K_PV)
                    if np.max(np.abs(res)) > residual_tol: continue
                    sol = np.array([iq2,E2,V1,V2_root,V3,V4])
                    is_new = all(not np.allclose(sol, r['x'], atol=1e-5) for r in results)
                    if is_new:
                        results.append(dict(branch_id=f"V3[{v3_idx}]_V4[{v4_idx}]", x=sol,
                                             residual=float(np.max(np.abs(res)))))
    return results
