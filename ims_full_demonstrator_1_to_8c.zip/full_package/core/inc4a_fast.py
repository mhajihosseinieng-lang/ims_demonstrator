import numpy as np
from scipy.optimize import brentq
from inc4a_model import P, full_g

def V2_roots_upper_lower_placeholder():
    pass

def newton_local(iq2, Q3, V1_guess, p=P, tol=1e-11, max_iter=25):
    from inc4a_model import solve_V_newton
    V, ok = solve_V_newton(iq2, Q3, V1_guess, p, tol=tol, max_iter=max_iter)
    return (V, ok)

def fine_scan(iq2, Q3, V_ref, window=0.2, n_scan=250, p=P):
    from scipy.optimize import fsolve
    sol, info, ier, msg = fsolve(lambda V: full_g(V[0],V[1],V[2],V[3], iq2, Q3, p), V_ref, full_output=True, xtol=1e-12)
    res = full_g(sol[0],sol[1],sol[2],sol[3], iq2, Q3, p)
    if ier==1 and max(abs(r) for r in res)<1e-8 and np.all(sol>0):
        return sol
    return None

def global_scan_check(iq2, Q3, p=P):
    from scipy.optimize import fsolve
    seeds = [[0.9,0.9,0.6,0.9],[0.5,0.5,0.3,0.5],[1.0,1.0,0.9,1.0],[0.2,0.2,0.1,0.2],[0.85,0.9,0.5,0.9]]
    for Vs in seeds:
        sol, info, ier, msg = fsolve(lambda V: full_g(V[0],V[1],V[2],V[3], iq2, Q3, p), Vs, full_output=True, xtol=1e-11)
        res = full_g(sol[0],sol[1],sol[2],sol[3], iq2, Q3, p)
        if ier==1 and max(abs(r) for r in res)<1e-9 and np.all(sol>0):
            return True
    return False

def classify_and_track_fast(iq2, Q3, V_ref):
    from inc4a_model import solve_V_newton
    V, ok = solve_V_newton(iq2, Q3, V_ref, tol=1e-11, max_iter=30)
    if ok and np.all(V>0):
        return 'ok', V
    sol = fine_scan(iq2, Q3, V_ref)
    if sol is not None:
        return 'ok', sol
    if global_scan_check(iq2, Q3):
        return 'tracking_lost', None
    return 'infeasible', None
