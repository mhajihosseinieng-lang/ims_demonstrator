import numpy as np
from scipy.optimize import brentq

P = dict(Xg1=0.4, X12=0.4, X13=0.5, X24=0.2, Q4=0.15, Bsh3=-0.05, Bsh4=0.0,
          Vgrid=1.0, Xc=0.15, Enom=1.05, nQ=0.5, Qset=0.0, tau_I=0.002, tau_Q=0.03)

def full_g(V1,V2,V3,V4, iq2, Q3, p=P):
    g1 = V1*(V1-p['Vgrid'])/p['Xg1'] + V1*(V1-V2)/p['X12'] + V1*(V1-V3)/p['X13']
    g2 = V2*iq2 - V2*(V2-V1)/p['X12'] - V2*(V2-V4)/p['X24']
    g3 = p['Bsh3']*V3**2 - Q3 - V3*(V3-V1)/p['X13']
    g4 = p['Bsh4']*V4**2 - p['Q4'] - V4*(V4-V2)/p['X24']
    return np.array([g1,g2,g3,g4])

def solve_V_newton(iq2, Q3, V_guess, p=P, tol=1e-12, max_iter=30):
    """Fast Newton on the full 4-var algebraic system, warm-started from V_guess."""
    V = np.array(V_guess, dtype=float)
    for _ in range(max_iter):
        g = full_g(V[0],V[1],V[2],V[3], iq2, Q3, p)
        if np.max(np.abs(g)) < tol:
            return V, True
        h = 1e-7
        J = np.zeros((4,4))
        for j in range(4):
            Vp = V.copy(); Vp[j]+=h
            Vm = V.copy(); Vm[j]-=h
            J[:,j] = (full_g(*Vp, iq2, Q3, p) - full_g(*Vm, iq2, Q3, p)) / (2*h)
        try:
            dV = np.linalg.solve(J, -g)
        except np.linalg.LinAlgError:
            return V, False
        if np.any(V + dV <= 0):
            return V, False
        V = V + dV
    return V, False

def rhs_full(iq2, E2, Q3, V_ref, p=P):
    V, ok = solve_V_newton(iq2, Q3, V_ref, p)
    if not ok:
        return None, None
    f1 = ((E2 - V[1])/p['Xc'] - iq2) / p['tau_I']
    f2 = (-E2 + p['Enom'] - p['nQ']*(V[1]*iq2 - p['Qset'])) / p['tau_Q']
    return np.array([f1,f2]), V
