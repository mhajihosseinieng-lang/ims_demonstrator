"""
Increment 7I -- Bsh3-parameterized version of the frozen full_g, for the
new s_sh3 latch. Bsh3 becomes a function argument instead of a module
constant. Verified below to be identical to the frozen full_g when
Bsh3=-0.05.
"""
import numpy as np

Xg1,X12,X13,X24 = 0.4,0.4,0.5,0.2
Q3,Q4 = 0.10, 0.15
Bsh4 = 0.0
Vgrid = 1.0
V4ref = 1.0

def full_g_param(V1,V2,V3,V4,iq2,K_PV,Bsh3):
    g1 = V1*(V1-Vgrid)/Xg1 + V1*(V1-V2)/X12 + V1*(V1-V3)/X13
    g2 = V2*iq2 - V2*(V2-V1)/X12 - V2*(V2-V4)/X24
    g3 = Bsh3*V3**2 - Q3 - V3*(V3-V1)/X13
    g4 = Bsh4*V4**2 - Q4 - V4*(V4-V2)/X24 - K_PV*(V4-V4ref)
    return np.array([g1,g2,g3,g4])
