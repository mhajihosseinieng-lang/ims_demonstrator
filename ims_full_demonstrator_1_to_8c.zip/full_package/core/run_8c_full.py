import numpy as np
from sim_7i_hybrid import solve_V_param, iq2_star_at_robust

tau_I, tau_Q = 0.002, 0.03
Xc,Enom,nQ,Qset = 0.15,1.05,0.5,0.0
Xg1,X12,X13,X24 = 0.4,0.4,0.5,0.2
Vgrid = 1.0
V_TRIP = 1.10
V3_TRIP = 1.05
V_s = [0.961317,0.985606,0.882601,0.977715]
FOLD_IQ2 = -0.201347

def full_2x2_jacobian(iq2, E2, V, K_PV, Bsh3):
    V1,V2,V3,V4 = V
    Bsh4 = 0.0
    Jg = np.array([
        [(2*V1-Vgrid)/Xg1 + (2*V1-V2)/X12 + (2*V1-V3)/X13, -V1/X12, -V1/X13, 0.0],
        [V2/X12, iq2-(2*V2-V1)/X12-(2*V2-V4)/X24, 0.0, V2/X24],
        [V3/X13, 0.0, 2*Bsh3*V3-(2*V3-V1)/X13, 0.0],
        [0.0, V4/X24, 0.0, 2*Bsh4*V4-(2*V4-V2)/X24-K_PV],
    ])
    dg_diq2 = np.array([0.0, V2, 0.0, 0.0])
    dV_diq2 = -np.linalg.solve(Jg, dg_diq2)
    dFf_diq2 = -(1.0/Xc)*dV_diq2[1] - 1.0
    dFf_dE2 = 1.0/Xc
    dFs_diq2 = -nQ*(dV_diq2[1]*iq2 + V2)
    dFs_dE2 = -1.0
    A = np.array([[dFf_diq2/tau_I, dFf_dE2/tau_I],
                  [dFs_diq2/tau_Q, dFs_dE2/tau_Q]])
    return A

def run_case(diq, disturbance_schedule, t_max=0.35, dt=5e-6, sample_every=200):
    iq0 = 0.100177 + diq
    E0 = 1.000632  # healthy baseline
    s_PV, s_sh3 = 0, 0
    K_PV = 5.0
    Bsh3 = -0.05
    y = np.array([iq0, E0], dtype=float)
    V_ref = [np.array(V_s)]
    schedule = sorted(disturbance_schedule, key=lambda x: x[0])
    sched_idx = 0

    events = []
    peak_V = np.array([0.0,0.0,0.0,0.0])
    peak_V_t = np.array([0.0,0.0,0.0,0.0])
    min_fold_dist = None
    decomp_samples = []  # (t, mode, c_fast, c_slow)

    def check_prot(t):
        nonlocal s_PV, s_sh3, K_PV, Bsh3
        T_PV = (s_PV==0) and (V_ref[0][3] >= V_TRIP)
        T_sh3 = (s_sh3==0) and (V_ref[0][2] >= V3_TRIP)
        if not (T_PV or T_sh3): return
        s_PV_new = 1 if T_PV else s_PV
        s_sh3_new = 1 if T_sh3 else s_sh3
        K_PV_new = 0.0 if s_PV_new==1 else 5.0
        Bsh3_new = 0.0 if s_sh3_new==1 else -0.05
        Vp, okp = solve_V_param(y[0], K_PV_new, Bsh3_new, V_ref[0])
        if not okp: return
        s_PV, s_sh3, K_PV, Bsh3 = s_PV_new, s_sh3_new, K_PV_new, Bsh3_new
        V_ref[0] = Vp
        events.append(dict(type='protection', t=t, T_PV=bool(T_PV), T_sh3=bool(T_sh3), mode=(s_PV,s_sh3)))

    def apply_dist(dE2, t):
        y[1] = y[1] + dE2
        Vp, okp = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
        if not okp: return False
        V_ref[0] = Vp
        events.append(dict(type='disturbance', t=t, dE2=dE2, iq2=float(y[0]), E2=float(y[1])))
        return True

    def rhs(y):
        V, ok = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
        if not ok: return None
        V_ref[0] = V
        f1 = ((y[1]-V[1])/Xc - y[0])/tau_I
        f2 = (-y[1]+Enom-nQ*(V[1]*y[0]-Qset))/tau_Q
        return np.array([f1,f2])

    def update_peaks():
        nonlocal peak_V, peak_V_t
        for i in range(4):
            if V_ref[0][i] > peak_V[i]:
                peak_V[i] = V_ref[0][i]
                peak_V_t[i] = t

    def update_fold_and_decomp(t):
        nonlocal min_fold_dist
        if s_sh3 == 1:
            d = y[0] - FOLD_IQ2
            if min_fold_dist is None or d < min_fold_dist: min_fold_dist = d

    t = 0.0
    V0, ok0 = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
    if not ok0: return dict(status='infeasible', events=events)
    V_ref[0] = V0
    update_peaks()
    check_prot(0.0)
    while sched_idx < len(schedule) and schedule[sched_idx][0] <= 0.0:
        if not apply_dist(schedule[sched_idx][1], 0.0): return dict(status='infeasible_at_disturbance', events=events)
        sched_idx += 1
        check_prot(0.0)
    update_fold_and_decomp(0.0)

    n_steps = int(round(t_max/dt))
    iq2_g, V_g = y[0], V_ref[0].copy()
    for step in range(n_steps):
        k1=rhs(y)
        if k1 is None: return dict(status='infeasible', events=events, peak_V=peak_V, peak_V_t=peak_V_t, min_fold_dist=min_fold_dist, decomp_samples=decomp_samples, final_y=y)
        k2=rhs(y+dt/2*k1)
        if k2 is None: break
        k3=rhs(y+dt/2*k2)
        if k3 is None: break
        k4=rhs(y+dt*k3)
        if k4 is None: break
        y = y+(dt/6)*(k1+2*k2+2*k3+k4)
        t = (step+1)*dt
        V_check, ok_check = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
        if not ok_check: return dict(status='infeasible', events=events, peak_V=peak_V, peak_V_t=peak_V_t, min_fold_dist=min_fold_dist, decomp_samples=decomp_samples, final_y=y)
        V_ref[0] = V_check
        update_peaks()

        while sched_idx < len(schedule) and schedule[sched_idx][0] <= t:
            if not apply_dist(schedule[sched_idx][1], t): return dict(status='infeasible_at_disturbance', events=events, final_y=y)
            sched_idx += 1
            check_prot(t)
            update_peaks()

        check_prot(t)
        update_fold_and_decomp(t)

        if s_sh3 == 1 and step % sample_every == 0:
            target, Vtarget = iq2_star_at_robust(y[1], iq2_g, V_g, K_PV, Bsh3)
            if target is not None:
                iq2_g, V_g = target, Vtarget
                delta_x = np.array([y[0]-target, 0.0])
                A = full_2x2_jacobian(target, y[1], Vtarget, K_PV, Bsh3)
                eigvals, eigvecs_R = np.linalg.eig(A)
                eigvecs_L = np.linalg.inv(eigvecs_R)
                c = [np.dot(eigvecs_L[i,:], delta_x) for i in range(2)]
                idx_fast = np.argmax(np.abs(eigvals.real))
                idx_slow = 1-idx_fast
                decomp_samples.append((t, (s_PV,s_sh3), abs(c[idx_fast]), abs(c[idx_slow])))

    return dict(status='completed', events=events, peak_V=peak_V, peak_V_t=peak_V_t,
                min_fold_dist=min_fold_dist, decomp_samples=decomp_samples, final_y=y)
