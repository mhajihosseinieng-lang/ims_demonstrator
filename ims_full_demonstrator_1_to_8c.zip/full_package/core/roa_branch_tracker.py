"""
Layer B for the GFM ROA study -- dynamic branch tracking, same 4-way status
discipline validated in Increment 4b: continuation / transition / tracking_failed
/ infeasible. Infeasible means ONLY that Layer A's complete enumeration returns
empty -- never a local-solver failure alone.
"""
import numpy as np
from inc4a_model import P, full_g, solve_V_newton
from roa_branch_enum import enumerate_branches

def local_newton(iq2, Q3, V_guess, p=P, tol=1e-12, max_iter=30):
    return solve_V_newton(iq2, Q3, V_guess, p, tol=tol, max_iter=max_iter)

def track_state(iq2, Q3, V_prev, p=P):
    V_new, ok = local_newton(iq2, Q3, V_prev, p)
    if ok and np.all(V_new > 0):
        return 'continuation', V_new
    branches = enumerate_branches(iq2, Q3, p)
    if not branches:
        return 'infeasible', None
    best = min(branches, key=lambda b: np.linalg.norm(b['V']-V_prev))
    return 'transition', best['V']
