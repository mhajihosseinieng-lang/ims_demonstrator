"""
Increment 1 -- minimal Iberian-inspired GFM reactive/voltage model.

Single aggregated bus (GFM converter behind coupling reactance Xc) tied
to a stiff external grid via reactance X, with a constant-power reactive
load Q0 at the local bus.

States: i_q (fast, converter current-loop), E (slow, droop-filter
internal EMF reference). V (bus voltage) is algebraic, eliminated via
the implicit function theorem from the bus reactive-power balance.

  Fast:  tau_I * d(i_q)/dt = (E - V)/Xc - i_q
  Slow:  tau_Q * dE/dt     = -E + Enom - nQ*(V*i_q - Qset)
  Algebraic: g(V, i_q) := a*V^2 + b*V - Q0 = 0
             a = Bshunt - 1/X,  b = i_q + Vgrid/X

Validated finding (frozen): the fold at Q0* ~ 1.09421 is NOT caused by
loss of normal hyperbolicity -- alpha diverges (grows without bound) as
the fold is approached while beta stays flat. The actual limiting factor
is loss of IFT regularity (g_V -> 0), i.e. algebraic infeasibility, a
distinct condition from dynamic/normal-hyperbolicity failure. This
distinction -- normal hyperbolicity =/= overall stability =/= recoverability
-- is the central validated result of Increment 1 and the foundation the
entire later chain builds on.
"""
import numpy as np

# Frozen parameters
X = 0.4          # tie reactance to grid (pu)
Vgrid = 1.0       # stiff grid voltage (pu)
Bshunt = 0.0      # local shunt susceptance (pu)
Enom = 1.05       # droop filter nominal EMF (pu)
nQ = 0.5          # droop gain
Qset = 0.0        # droop reactive setpoint
Xc = 0.15         # converter coupling reactance (pu)
tau_I = 0.002     # fast current-loop time constant (s)
tau_Q = 0.03      # slow droop-filter time constant (s)


def V_of_iq(iq, Q0):
    """Solve the algebraic constraint for V given i_q (physical/admissible root)."""
    a = Bshunt - 1.0 / X
    b = iq + Vgrid / X
    disc = b**2 + 4 * a * Q0
    if disc < 0:
        return None
    sq = np.sqrt(disc)
    roots = sorted([(-b + sq) / (2 * a), (-b - sq) / (2 * a)])
    # physical root is the admissible (V>0), higher-voltage branch
    admissible = [r for r in roots if r > 0]
    if not admissible:
        return None
    return max(admissible)


def g_V(V, iq):
    """Partial derivative dg/dV -- vanishes at the fold (IFT regularity failure)."""
    a = Bshunt - 1.0 / X
    b = iq + Vgrid / X
    return 2 * a * V + b


def equilibrium(Q0, iq_guess=0.17):
    """Solve the full (i_q, E, V) equilibrium at given Q0."""
    from scipy.optimize import fsolve

    def resid(x):
        iq, E = x
        V = V_of_iq(iq, Q0)
        if V is None:
            return [1e6, 1e6]
        F_f = (E - V) / Xc - iq
        F_s = -E + Enom - nQ * (V * iq - Qset)
        return [F_f, F_s]

    sol, info, ier, msg = fsolve(resid, [iq_guess, 1.0], full_output=True, xtol=1e-14)
    iq, E = sol
    V = V_of_iq(iq, Q0)
    res = resid(sol)
    max_res = max(abs(r) for r in res)
    return dict(iq=iq, E=E, V=V, residual=max_res, converged=(max_res < 1e-8))


def alpha_beta(iq, E, V, Q0):
    """Spectral-gap quantities at a given equilibrium (full derivation, not a shortcut)."""
    a = Bshunt - 1.0 / X
    b = iq + Vgrid / X
    dV_diq = -V / (2 * a * V + b)  # dV/d(iq) via IFT

    df1_diq = -(1.0 / Xc) * dV_diq - 1.0
    df1_dE = 1.0 / Xc
    df2_diq = -nQ * (dV_diq * iq + V)
    df2_dE = -1.0

    eps = tau_I / tau_Q
    lambda_perp_F = df1_diq / tau_Q
    lambda_perp_phys = lambda_perp_F / eps
    alpha = -lambda_perp_phys

    diq_dE = -df1_dE / df1_diq
    lambda_par_undiv = df2_diq * diq_dE + df2_dE
    lambda_par_phys = lambda_par_undiv / tau_Q
    beta = -lambda_par_phys

    return alpha, beta, g_V(V, iq)


def find_fold(Q0_guess=1.0, iq_guess=0.8):
    """Simultaneous solve of the fold conditions: F_f=F_s=g=g_V=0."""
    from scipy.optimize import fsolve

    def resid(x):
        iq, E, V, Q0 = x
        F_f = (E - V) / Xc - iq
        F_s = -E + Enom - nQ * (V * iq - Qset)
        a = Bshunt - 1.0 / X
        b = iq + Vgrid / X
        g = a * V**2 + b * V - Q0
        gV = 2 * a * V + b
        return [F_f, F_s, g, gV]

    sol, info, ier, msg = fsolve(resid, [iq_guess, 0.78, 0.66, Q0_guess], full_output=True, xtol=1e-14)
    iq, E, V, Q0 = sol
    res = resid(sol)
    return dict(iq=iq, E=E, V=V, Q0=Q0, residual=max(abs(r) for r in res))
