#!/usr/bin/env python3
"""
IMS Platform Demonstrator -- Full Chain, Increment 1 through 8C
===================================================================

This script walks through the ENTIRE validated research chain in order,
reproducing a headline result from each increment live. It is a
reproduction of already-frozen numbers, not a new experiment -- every
value printed here traces to a specific traceability record in ../docs/.

Sections:
  1.  Foundational GFM model: fold, and the central validated distinction
      that normal hyperbolicity is NOT what fails at a fold (algebraic
      infeasibility is a separate condition).
  2.  Two-bus extension: same distinction, reproduced independently, plus
      directional recoverability under disturbance.
  3.  Four-bus network: the fold shifts, and recoverability becomes
      direction-dependent (converter-side vs. Bus3-directed disturbance).
  4a. Volt-VAR reactive support: moves the fold AND narrows the dynamic/
      static feasibility gap -- two independent effects.
  4b. GFL replacement: a structural change, not just a parameter change --
      multiple stable equilibria appear.
  ROA. Numerically mapped regions of attraction for two coexisting
      equilibria.
  5A-8C. Protection-triggered hybrid dynamics: a causally-verified
      two-trip cascade, post-cascade IMS characterization, and temporal
      disturbance staging.

Run with: python3 run_full_demo.py
Runtime: approximately 2-3 minutes.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'core'))

import numpy as np


def banner(n, title):
    print()
    print("#" * 78)
    print(f"# INCREMENT {n} -- {title}")
    print("#" * 78)


def subbanner(title):
    print()
    print("-" * 78)
    print(title)
    print("-" * 78)


# =======================================================================
# INCREMENT 1 -- Foundational GFM reactive/voltage model
# =======================================================================
def increment1():
    banner("1", "Foundational GFM reactive/voltage model")
    from increment1_model import equilibrium, find_fold, alpha_beta

    print("""
Single aggregated bus (GFM converter) tied to a stiff grid, with a
constant-power reactive load Q0. States: i_q (fast), E (slow); bus
voltage V is algebraic.
""")
    eq = equilibrium(0.3)
    print(f"  Baseline equilibrium (Q0=0.3): i_q*={eq['iq']:.6f}  "
          f"V*={eq['V']:.6f}  E*={eq['E']:.6f}")
    print(f"  Residual: {eq['residual']:.2e} (machine precision)")

    fold = find_fold()
    print(f"\n  Algebraic fold: Q0* = {fold['Q0']:.5f}  "
          f"(residual {fold['residual']:.2e})")

    subbanner("The central validated finding: what actually fails at the fold?")
    print(f"  {'Q0':>8} {'alpha':>12} {'beta':>8} {'alpha/beta':>12}")
    guesses = [(0.3, 0.17), (0.9, 0.8), (1.05, 0.8), (1.08, 0.8)]
    for Q0, g in guesses:
        e = equilibrium(Q0, iq_guess=g)
        a, b, gv = alpha_beta(e['iq'], e['E'], e['V'], Q0)
        print(f"  {Q0:8.3f} {a:12.1f} {b:8.2f} {a/b:12.1f}")
    print("""
  alpha DIVERGES as the fold is approached (2042 -> 39363), while beta
  stays flat (~47-61). The spectral gap WIDENS, not narrows -- normal
  hyperbolicity is not what fails here. The actual limiting factor is
  algebraic infeasibility (loss of a real solution to the network
  equations), a completely separate condition. This distinction --
  normal hyperbolicity =/= overall stability =/= recoverability -- is
  the foundation the entire later chain is built on.
""")


# =======================================================================
# INCREMENT 2 -- Two-bus extension
# =======================================================================
def increment2():
    banner("2", "Two-bus GFM extension")
    from inc2_final2 import integrate_and_classify

    print("""
Extends Increment 1 to two buses. Same fold/recoverability distinction,
now tested dynamically: does a converter-side current disturbance
recover, and does the recoverable margin shrink near the fold?
""")
    points = {
        'normal (Q0_1=0.3)': (0.294290, 0.920978, 0.876835, 0.3, [0.02, 0.05, 0.1]),
        'near-fold (Q0_1=0.62)': (0.623720, 0.822630, 0.729070, 0.62, [0.005, 0.015, 0.025]),
    }
    for label, (iq1_s, E1_s, V1_s, Q0_1, diqs) in points.items():
        print(f"\n  {label}:")
        for diq in diqs:
            outcome, y, t_ev, n_lost = integrate_and_classify(
                iq1_s + diq, E1_s, Q0_1, 0.002, 0.03, V1_s, t_max=0.12, dt=4e-5)
            print(f"    disturbance={diq:.3f}: {outcome}")
    print("""
  The near-fold case collapses even at a tiny disturbance (0.005) that
  the normal operating point comfortably absorbs at 20x the amplitude
  (0.1) -- the recoverable margin shrinks dramatically as the fold is
  approached, exactly as the widening-alpha/flat-beta structure from
  Section 1 would lead us to expect.
""")


# =======================================================================
# INCREMENT 3 -- Four-bus network, directional recoverability
# =======================================================================
def increment3():
    banner("3", "Four-bus network -- directional recoverability")
    from inc3_model import solve_V_newton, P
    from scipy.optimize import fsolve

    print("""
Extends to a 4-bus radial network (Grid - Bus1 - {Bus2(converter),
Bus3(load)} - Bus4(load)). The central question: does recoverability
depend on WHICH bus the disturbance targets, not just how close the
system is to its fold?
""")
    V, ok = solve_V_newton(0.172825, 0.10, [0.94, 0.94, 0.86, 0.91])
    print(f"  Baseline equilibrium: V1..V4 = {np.round(V, 6)}  (converged={ok})")

    def full_and_detJ(x):
        iq2, E2, V1, V2, V3, V4, Q3 = x
        Xc, Enom, nQ, Qset = P['Xc'], P['Enom'], P['nQ'], P['Qset']
        F_f = (E2 - V2) / Xc - iq2
        F_s = -E2 + Enom - nQ * (V2 * iq2 - Qset)
        from inc3_model import full_g
        g = full_g(V1, V2, V3, V4, iq2, Q3)
        Xg1, X12, X13, X24 = P['Xg1'], P['X12'], P['X13'], P['X24']
        Bsh3, Bsh4, Vgrid = P['Bsh3'], P['Bsh4'], P['Vgrid']
        Jg = np.array([
            [(2*V1-Vgrid)/Xg1+(2*V1-V2)/X12+(2*V1-V3)/X13, -V1/X12, -V1/X13, 0.0],
            [V2/X12, iq2-(2*V2-V1)/X12-(2*V2-V4)/X24, 0.0, V2/X24],
            [V3/X13, 0.0, 2*Bsh3*V3-(2*V3-V1)/X13, 0.0],
            [0.0, V4/X24, 0.0, 2*Bsh4*V4-(2*V4-V2)/X24],
        ])
        return list([F_f, F_s]) + list(g) + [np.linalg.det(Jg)]

    sol, info, ier, msg = fsolve(full_and_detJ, [0.31, 0.91, 0.81, 0.87, 0.52, 0.83, 0.29],
                                   full_output=True, xtol=1e-13)
    res = full_and_detJ(sol)
    print(f"  Algebraic fold: Q0,3* = {sol[6]:.6f}  (residual {max(abs(r) for r in res):.2e})")
    print("""
  Frozen finding (see docs/): near this fold, converter-side disturbances
  retain most of their recoverability margin, while Bus3-directed
  disturbances lose recoverability roughly 25x faster than the static
  fold alone would suggest. Fold proximity alone does not determine
  recoverability -- disturbance DIRECTION matters just as much.
""")


# =======================================================================
# INCREMENT 4a -- Volt-VAR reactive support
# =======================================================================
def increment4a():
    banner("4a", "GFM + Volt-VAR reactive support")
    from inc4a_model import solve_V_newton, P

    print("""
Adds algebraic Volt-VAR support at Bus4: a converter-like reactive
injection that responds to local voltage deviation. Question: does this
simply shift the fold, or does it have a second, independent effect?
""")
    V, ok = solve_V_newton(0.100177, 0.10, [0.96, 0.99, 0.88, 0.98])
    print(f"  Baseline equilibrium: V1..V4 = {np.round(V, 6)}")
    print("""
  Frozen findings (see docs/):
    Effect A -- static fold margin: Q0,3* moves from 0.294630 (Inc3) to
                0.323225 (+9.71%)
    Effect B -- dynamic/static feasibility ratio at matched severity:
                14.9% -> 73.1% (confirmed at two independent dt values)

  These are two SEPARATE effects of the same mechanism, not one. And,
  genuinely unforced: the baseline spectral gap actually NARROWS under
  Volt-VAR (alpha/beta: 74.2 -> 18.83) even while the static fold margin
  widens -- reactive support helps static feasibility while narrowing
  the margin between static feasibility and dynamic recoverability.
""")


# =======================================================================
# INCREMENT 4b -- GFL structural contrast
# =======================================================================
def increment4b():
    banner("4b", "GFL replacement -- structural, not parametric, change")
    from inc4b_model import P
    from inc4b_branch_enum import enumerate_branches

    print("""
Replaces the GFM converter at Bus2 with a Grid-Following (GFL) model --
a genuinely different mathematical structure (one dynamic state, not
two), not just different parameter values.
""")
    print(f"  GFL parameters: nQ_gfl={P['nQ_gfl']}  V2_nom={P['V2_nom']}  tau_i={P['tau_i']}")

    r = enumerate_branches(0.08809, 0.10)
    print(f"\n  At i_q2=0.08809: {len(r)} admissible algebraic branches found")
    for b in r:
        print(f"    {b['branch_id']}: residual={b['residual_norm']:.2e}")
    print("""
  Frozen finding (see docs/): this one-state GFL system admits MULTIPLE
  locally stable equilibria (unlike GFM's single stable branch at
  comparable conditions) -- a genuinely structural finding, not
  something GFM would show under the same disturbance. A converter-side
  disturbance can transition the system between these equilibria.
""")


# =======================================================================
# ROA -- numerically mapped regions of attraction
# =======================================================================
def increment_roa():
    banner("ROA", "Numerically mapped regions of attraction")
    from roa_branch_enum import enumerate_branches

    print("""
Increment 4a's own model, explored more broadly, reveals a SECOND
locally-stable equilibrium never found during 4a's original validation
(which only explored near the first). This section maps which initial
conditions converge to which equilibrium.
""")
    r = enumerate_branches(4.1, 0.10)
    print(f"  At i_q2=4.1 (far from the original equilibrium): "
          f"{len(r)} admissible branches")
    for b in r:
        print(f"    {b['branch_id']}: residual={b['residual_norm']:.2e}")
    print("""
  Frozen finding (see docs/): a boundary-continuation study found the
  ROA transition at i_q2,boundary ~= 4.817 (absolute), approximately
  invariant with respect to E2 over the tested range E2 in [-0.5, 3.0].
  This ROA mapping later became the direct methodological ancestor of
  the hybrid-system ROA work in Increment 6B.
""")


# =======================================================================
# 5A-8C -- protection cascade (imported from the headline demo)
# =======================================================================
def increments_5a_to_8c():
    banner("5A-8C", "Protection-triggered hybrid dynamics and cascade")
    print("""
This is the most extensively validated part of the chain: a single
Volt-VAR protection trip (5A) is extended to a SECOND, independent
protection mechanism (a Bus3 shunt-reactor trip, derived and selected
across Increments 7A-7I after two other candidates were reviewed and
one -- converter current limiting -- was tested and rejected for lack
of causal evidence). The result is a causally-verified two-trip cascade,
characterized under a 50-case severity/timescale study (7N series), and
under three-stage disturbance timing (Increment 8).
""")
    from run_8c_full import run_case

    V_TRIP = 1.10
    V3_TRIP = 1.05

    subbanner("Causal cascade: does the first trip actually cause the second?")
    from sim_7i_hybrid import solve_V_param

    def run(diq, E0, suppress_PV, t_max=0.05, dt=5e-6):
        iq0 = 0.100177 + diq
        s_PV, s_sh3 = 0, 0
        K_PV, Bsh3 = 5.0, -0.05
        y = np.array([iq0, E0], dtype=float)
        V_s = [0.961317, 0.985606, 0.882601, 0.977715]
        V_ref = [np.array(V_s)]
        t_PV, t_sh3 = None, None

        def check(t):
            nonlocal s_PV, s_sh3, K_PV, Bsh3, t_PV, t_sh3
            T_PV = (not suppress_PV) and (s_PV == 0) and (V_ref[0][3] >= V_TRIP)
            T_sh3 = (s_sh3 == 0) and (V_ref[0][2] >= V3_TRIP)
            if not (T_PV or T_sh3):
                return
            s_PV = 1 if T_PV else s_PV
            s_sh3 = 1 if T_sh3 else s_sh3
            K_PV = 0.0 if s_PV == 1 else 5.0
            Bsh3 = 0.0 if s_sh3 == 1 else -0.05
            Vp, ok = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
            if ok:
                V_ref[0] = Vp
            if T_PV:
                t_PV = t
            if T_sh3:
                t_sh3 = t

        V0, ok0 = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
        V_ref[0] = V0
        check(0.0)

        def rhs(y):
            V, ok = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
            if not ok:
                return None
            V_ref[0] = V
            Xc, Enom, nQ, Qset = 0.15, 1.05, 0.5, 0.0
            f1 = ((y[1] - V[1]) / Xc - y[0]) / 0.002
            f2 = (-y[1] + Enom - nQ * (V[1] * y[0] - Qset)) / 0.03
            return np.array([f1, f2])

        n = int(t_max / dt)
        for step in range(n):
            k1 = rhs(y)
            if k1 is None:
                break
            k2 = rhs(y + dt / 2 * k1)
            if k2 is None:
                break
            k3 = rhs(y + dt / 2 * k2)
            if k3 is None:
                break
            k4 = rhs(y + dt * k3)
            if k4 is None:
                break
            y = y + (dt / 6) * (k1 + 2 * k2 + 2 * k3 + k4)
            t = (step + 1) * dt
            V_chk, ok_chk = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
            if not ok_chk:
                break
            V_ref[0] = V_chk
            check(t)
        return t_PV, t_sh3

    t_PV_a, t_sh3_a = run(-1.0, 3.0, suppress_PV=False)
    _, t_sh3_cf = run(-1.0, 3.0, suppress_PV=True, t_max=0.3)
    print(f"  Actual:        Bus4 trip at {t_PV_a*1000:.4f} ms, Bus3 trip at {t_sh3_a*1000:.4f} ms")
    print(f"  Counterfactual (Bus4 protection suppressed): Bus3 trip at {t_sh3_cf*1000:.4f} ms")
    print(f"  Delta t = {(t_sh3_a-t_sh3_cf)*1000:.4f} ms -- Bus4 trip ADVANCES Bus3 trip (causal, not coincidental)")

    subbanner("Post-cascade recovery")
    r = run_case(-1.0, [(0.0, 0.499368), (0.005, 1.023704), (0.010, 1.310341)], t_max=0.35)
    fy = r['final_y']
    fold_iq2 = -0.201347
    print(f"  Final state: i_q2={fy[0]:.6f}  E2={fy[1]:.6f}")
    print(f"  Peak V4 during transient: {r['peak_V'][3]:.4f} pu")
    print(f"  Distance from nearest algebraic fold: {fy[0]-fold_iq2:.4f} pu -- comfortably recoverable")

    subbanner("Temporal disturbance staging vs. equivalent single-step disturbance")
    dE2_1, dE2_2, dE2_3 = 0.499368, 1.023704, 1.310341
    dE2_single = dE2_1 + dE2_2 + dE2_3
    cases = [
        ("Staged (5,10) ms  ", [(0.0, dE2_1), (0.005, dE2_2), (0.010, dE2_3)]),
        ("Staged (20,40) ms ", [(0.0, dE2_1), (0.020, dE2_2), (0.040, dE2_3)]),
        ("Single-step (t=0) ", [(0.0, dE2_single)]),
    ]
    print(f"  {'Protocol':<20} {'Peak V4 (pu)':>14}")
    for label, sched in cases:
        r = run_case(-1.0, sched, t_max=0.06, sample_every=5000)
        print(f"  {label:<20} {r['peak_V'][3]:>14.4f}")
    print("""
  Same cumulative disturbance, different temporal application -> markedly
  different peak severity. All cases recover to the identical equilibrium.

  ACROSS A 50-CASE PRE-REGISTERED STUDY (severity x converter timescale,
  see docs/increment_7_8/7N-4B_FROZEN.md): IMS structure (manifold
  existence, normal hyperbolicity, transverse-mode dominance, genuine
  transverse contraction) was never lost in any activated cascade.
  Recoverability was never lost either. This does NOT establish that
  IMS preservation causes recoverability -- no case reached a genuinely
  IMS-degraded state, so that contrasting experiment was never obtained.
""")


if __name__ == "__main__":
    print("=" * 78)
    print("IMS PLATFORM DEMONSTRATOR -- FULL CHAIN, INCREMENT 1 THROUGH 8C")
    print("=" * 78)
    print("""
Reproducing headline results live from every increment in the frozen
research chain. No new computation is being performed beyond what is
already validated and recorded in ../docs/.
""")
    increment1()
    increment2()
    increment3()
    increment4a()
    increment4b()
    increment_roa()
    increments_5a_to_8c()

    print()
    print("=" * 78)
    print("DONE. See ../docs/ for the complete traceability record, including")
    print("every negative result, implementation bug found and fixed, and")
    print("applicability limit encountered along the way.")
    print()
    print("The load-bearing summary sentence:")
    print("""
  The frozen study does not demonstrate that IMS preservation causes
  recoverability or that every protection cascade culminates in
  collapse; instead, it demonstrates -- under a rigorously pre-
  registered and counterfactually tested reduced-order model -- that
  sequential protection actions can form a genuinely causal cascade,
  that disturbance timing materially alters transient severity, and
  that IMS provides a quantitatively verifiable geometric
  characterization of the resulting large-signal recovery dynamics.
""")
    print("=" * 78)
