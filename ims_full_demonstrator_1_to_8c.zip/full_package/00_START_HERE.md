# IMS Platform Demonstrator -- Full Chain, Increment 1 through 8C

This package contains a runnable reproduction of the **complete**
research chain -- every increment from the foundational GFM model
through the causally-verified protection cascade -- plus the full
traceability record.

## How to run it

```
cd demo
python3 run_full_demo.py
```

Requires Python 3 with numpy and scipy (`pip install numpy scipy` if
needed). Runtime is approximately 1.5-2 minutes. No other setup.

## What it shows, in order

| # | Increment | What it demonstrates |
|---|---|---|
| 1 | Foundational GFM model | A genuine algebraic fold, and the core distinction: normal hyperbolicity is *not* what fails there -- alpha diverges while beta stays flat; the real limit is algebraic (IFT) infeasibility, a separate condition |
| 2 | Two-bus extension | Same distinction, reproduced independently; the recoverable margin against disturbance shrinks dramatically near the fold |
| 3 | Four-bus network | The fold persists in a larger network; recoverability becomes *direction*-dependent, not just distance-to-fold-dependent |
| 4a | Volt-VAR support | Reactive support has two *independent* effects: it moves the static fold outward AND separately narrows the margin between static and dynamic feasibility |
| 4b | GFL structural contrast | Replacing the converter type is a structural change (fewer states), not a parameter change -- multiple stable equilibria appear |
| ROA | Regions of attraction | A second, previously unknown equilibrium is found; initial-condition space is mapped between the two |
| 5A-8C | Protection cascade | A single protection trip is extended to a causally-verified **two-trip cascade**, characterized across a 50-case severity/timescale study, with temporal disturbance staging shown to materially change transient severity |

## Package structure

```
00_START_HERE.md              <- this file
core/                          <- all model implementations (frozen, unmodified)
  increment1_model.py            foundational GFM single-bus model
  inc2_fast.py, inc2_final2.py   two-bus extension
  inc3_model.py                  four-bus network
  inc4a_model.py, inc4a_fast.py  Volt-VAR reactive support
  inc4b_model.py, inc4b_branch_* GFL structural contrast
  roa_branch_*                   region-of-attraction mapping
  layerA_equilibria*.py          deterministic equilibrium enumeration
  layerB_hybrid_v2.py            hybrid branch-tracking with escalating
                                  fallback (local Newton -> wide scan ->
                                  independent verification)
  sim_7i_hybrid.py               two-latch hybrid integrator (the two-
                                  trip protection cascade)
  sim_8b_staged.py               three-stage disturbance operator
  run_8c_full.py                 full cascade instrumentation
demo/
  run_full_demo.py               <- run this
docs/                           <- complete traceability record, by increment
  increment_1/
  increment_2_3_4a_4b_roa/
  increment_5a_6a_6b/
  increment_7_8/
```

## What this package does and does not claim

**Demonstrated, with pre-registered protocols and counterfactual tests
where applicable:**
- A genuine algebraic fold exists in the foundational model, and the
  mechanism that fails there (algebraic infeasibility) is rigorously
  distinguished from normal-hyperbolicity loss -- the spectral gap
  actually *widens* near the fold, it does not narrow.
- Recoverability depends on disturbance *direction*, not just distance
  from a fold (Increment 3).
- Reactive support and converter architecture each have real, sometimes
  counterintuitive and *independent* effects on static vs. dynamic
  feasibility (4a, 4b).
- A converter-side disturbance can trip a first protection mechanism,
  which measurably and causally advances (or in some cases creates) a
  second, independent protection event -- not merely two events that
  happen in sequence (5A-8C, with actual-vs-counterfactual tests).
- The resulting two-trip cascade produces substantial transient voltage
  escalation followed by recovery to a verified stable equilibrium.
- IMS (fast/slow manifold) structure persists throughout every cascade
  tested, across a 50-case grid spanning severity and converter
  timescale.
- Temporal disturbance staging measurably reduces transient severity
  relative to an equivalent single-step disturbance.

**Explicitly NOT demonstrated -- do not claim these:**
- That IMS preservation *causes* recoverability. Every case in this
  package shows co-occurrence, not a causal link -- no case reached a
  genuinely IMS-degraded state, so the contrasting experiment needed to
  establish causation was never obtained.
- That any tested cascade culminates in collapse. Every activated
  cascade in this package recovers.
- That this reproduces the actual 2025 Iberian blackout, or that the
  three-stage disturbance protocol corresponds to real MW magnitudes.
  Only the proposal's own escalation *ratios* are used; the underlying
  quantity has no physical unit correspondence to real power.
- That this model contains synchronous-generator dynamics, a real
  tie-line, current limiting, fixed-PF/Q switching, or GFM-penetration
  sweeps. A candidate for a third protection mechanism (converter
  current limiting) was explicitly tested and rejected for lack of
  causal evidence -- see `docs/increment_7_8/`.

**The single sentence that best summarizes what is actually established:**

> The frozen study does not demonstrate that IMS preservation causes
> recoverability or that every protection cascade culminates in
> collapse; instead, it demonstrates -- under a rigorously
> pre-registered and counterfactually tested reduced-order model --
> that sequential protection actions can form a genuinely causal
> cascade, that disturbance timing materially alters transient
> severity, and that IMS provides a quantitatively verifiable geometric
> characterization of the resulting large-signal recovery dynamics.

## If you want to explore further

Every number the demo prints traces back to a specific traceability
record in `docs/`. Each record documents not just the final result but
negative results, implementation bugs found and fixed, and applicability
limits encountered along the way -- these are preserved as first-class
findings throughout, not smoothed over. In particular:

- `docs/increment_1/increment1.md` -- the foundational normal-
  hyperbolicity-vs-IFT-regularity distinction, including the modeling
  dead ends (rejected V-dynamics, GFL-vs-GFM reclassification,
  constant-impedance-vs-constant-power load) worked through explicitly.
- `docs/increment_7_8/8C_FROZEN.md` and
  `docs/increment_5a_6a_6b/increment6b_full_review.md` are the most
  load-bearing documents for the causal-cascade and IMS-applicability
  claims respectively.
