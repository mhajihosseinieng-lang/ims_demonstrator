#!/usr/bin/env python3
"""
IMS Platform Demonstrator -- Increment 8C headline results
=============================================================

This script reproduces, live, the core validated findings of the frozen
2 -> 8C chain:

  1. The causal two-protection-event cascade (Bus4 Volt-VAR trip ->
     Bus3 shunt-reactor trip), with an actual-vs-counterfactual test
     showing the first trip genuinely creates/advances the second.
  2. The post-cascade recovery to a stable equilibrium, with distance
     to the nearest algebraic fold.
  3. The three-stage disturbance protocol vs. an equivalent single-step
     disturbance, showing that temporal staging materially reduces
     transient severity despite identical cumulative disturbance.

Everything below reproduces numbers already frozen in the traceability
record (see ../docs/). No parameters are tuned here; this is a
reproduction, not a new experiment.

Run with:  python3 run_demo.py
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'core'))

import numpy as np
from sim_7i_hybrid import solve_V_param
from run_8c_full import run_case

# ---------------------------------------------------------------------
# Frozen system parameters (do not modify -- these are the validated
# operating point and protection thresholds from Increments 5A/7G-7I)
# ---------------------------------------------------------------------
V_TRIP = 1.10       # Bus4 Volt-VAR overvoltage trip threshold (pu)
V3_TRIP = 1.05       # Bus3 shunt-reactor overvoltage trip threshold (pu)
IQ2_BASELINE = 0.100177
E2_BASELINE = 1.000632
FOLD_IQ2 = -0.201347  # independently verified Mode(1,1) algebraic fold


def banner(title):
    print()
    print("=" * 78)
    print(title)
    print("=" * 78)


def section1_causal_cascade():
    banner("SECTION 1 -- Causal two-trip protection cascade (Increment 7K/7L)")
    print("""
Disturbance: Delta i_q2 = -1.0, E2(0) = 3.0 (a case where the fast/slow
coupling drives a large transient overshoot before either trip fires).
""")

    from sim_7i_hybrid import iq2_star_at_robust

    def run(diq, E0, suppress_PV, t_max=0.05, dt=5e-6):
        iq0 = IQ2_BASELINE + diq
        s_PV, s_sh3 = 0, 0
        K_PV, Bsh3 = 5.0, -0.05
        y = np.array([iq0, E0], dtype=float)
        V_s = [0.961317, 0.985606, 0.882601, 0.977715]
        V_ref = [np.array(V_s)]
        t_PV, t_sh3 = None, None

        def check(t):
            nonlocal s_PV, s_sh3, K_PV, Bsh3, t_PV, t_sh3
            T_PV = (not suppress_PV) and (s_PV == 0) and (V_ref[0][3] >= V_TRIP)
            T_sh3 = (s_sh3 == 0) and (V_ref[0][2] >= V3_TRIP)
            if not (T_PV or T_sh3):
                return
            s_PV = 1 if T_PV else s_PV
            s_sh3 = 1 if T_sh3 else s_sh3
            K_PV = 0.0 if s_PV == 1 else 5.0
            Bsh3 = 0.0 if s_sh3 == 1 else -0.05
            Vp, ok = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
            if ok:
                V_ref[0] = Vp
            if T_PV:
                t_PV = t
            if T_sh3:
                t_sh3 = t

        V0, ok0 = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
        V_ref[0] = V0
        check(0.0)

        def rhs(y):
            V, ok = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
            if not ok:
                return None
            V_ref[0] = V
            Xc, Enom, nQ, Qset = 0.15, 1.05, 0.5, 0.0
            f1 = ((y[1] - V[1]) / Xc - y[0]) / 0.002
            f2 = (-y[1] + Enom - nQ * (V[1] * y[0] - Qset)) / 0.03
            return np.array([f1, f2])

        n = int(t_max / dt)
        for step in range(n):
            k1 = rhs(y)
            if k1 is None:
                break
            k2 = rhs(y + dt / 2 * k1)
            if k2 is None:
                break
            k3 = rhs(y + dt / 2 * k2)
            if k3 is None:
                break
            k4 = rhs(y + dt * k3)
            if k4 is None:
                break
            y = y + (dt / 6) * (k1 + 2 * k2 + 2 * k3 + k4)
            t = (step + 1) * dt
            V_chk, ok_chk = solve_V_param(y[0], K_PV, Bsh3, V_ref[0])
            if not ok_chk:
                break
            V_ref[0] = V_chk
            check(t)
        return t_PV, t_sh3

    t_PV_actual, t_sh3_actual = run(-1.0, 3.0, suppress_PV=False)
    _, t_sh3_cf = run(-1.0, 3.0, suppress_PV=True, t_max=0.3)

    print(f"  Actual system  : Bus4 trip at t = {t_PV_actual*1000:.4f} ms")
    print(f"                   Bus3 trip at t = {t_sh3_actual*1000:.4f} ms")
    print(f"  Counterfactual (Bus4 protection disabled):")
    print(f"                   Bus3 trip at t = {t_sh3_cf*1000:.4f} ms" if t_sh3_cf
          else "                   Bus3 NEVER trips within 0.3s")
    if t_sh3_cf:
        dt_ms = (t_sh3_actual - t_sh3_cf) * 1000
        print(f"\n  Delta t = {dt_ms:.4f} ms  -> Bus4 trip ADVANCES Bus3 trip")
        print("  (this is causal evidence, not mere temporal ordering --")
        print("   the counterfactual, with Bus4 protection suppressed,")
        print("   reaches the Bus3 threshold measurably later)")


def section2_recovery():
    banner("SECTION 2 -- Post-cascade recovery and fold distance (Increment 7L/7L-1)")
    r = run_case(-1.0, [(0.0, 0.499368), (0.005, 1.023704), (0.010, 1.310341)], t_max=0.35)
    fy = r['final_y']
    dist = fy[0] - FOLD_IQ2
    print(f"""
  Final state after the full three-stage cascade:
    i_q2 = {fy[0]:.6f}   E2 = {fy[1]:.6f}
    Peak V4 during transient = {r['peak_V'][3]:.4f} pu  (at t = {r['peak_V_t'][3]*1000:.2f} ms)

  Distance from the nearest independently-verified algebraic fold
  (i_q2,fold = {FOLD_IQ2}):
    {dist:.4f} pu  -- comfortably recoverable, not near the boundary
""")


def section3_staging_comparison():
    banner("SECTION 3 -- Temporal staging vs. equivalent single-step disturbance (8C)")
    dE2_1, dE2_2, dE2_3 = 0.499368, 1.023704, 1.310341
    dE2_single = dE2_1 + dE2_2 + dE2_3

    print(f"""
  All cases share the identical cumulative disturbance:
    Delta E2_total = {dE2_single:.6f}
""")
    cases = [
        ("Staged  (5,10) ms ", [(0.0, dE2_1), (0.005, dE2_2), (0.010, dE2_3)]),
        ("Staged (10,20) ms ", [(0.0, dE2_1), (0.010, dE2_2), (0.020, dE2_3)]),
        ("Staged (20,40) ms ", [(0.0, dE2_1), (0.020, dE2_2), (0.040, dE2_3)]),
        ("Single-step (t=0) ", [(0.0, dE2_single)]),
    ]
    print(f"  {'Protocol':<20} {'Peak V4 (pu)':>14}")
    print(f"  {'-'*20} {'-'*14}")
    for label, sched in cases:
        # t_max=0.06s is sufficient here: peak voltage occurs within the
        # first ~45ms in every case and does not change with a longer
        # window (verified against the full t_max=0.35s convergence
        # window used to establish the frozen record; only the reported
        # PEAK value is used here, not the final equilibrium)
        r = run_case(-1.0, sched, t_max=0.06, sample_every=5000)
        print(f"  {label:<20} {r['peak_V'][3]:>14.4f}")

    print("""
  Slower staging -> progressively lower peak voltage, despite identical
  cumulative disturbance magnitude. All four cases converge to the same
  final equilibrium (recoverability is unaffected by staging).
""")


if __name__ == "__main__":
    print("IMS Platform Demonstrator -- reproducing frozen results 2 -> 8C")
    print("(No new computation is being performed beyond what is already")
    print(" frozen in the traceability record; this is a reproduction.)")
    section1_causal_cascade()
    section2_recovery()
    section3_staging_comparison()
    banner("Done. See ../docs/ for the complete traceability record and")
    print("caveats (in particular: IMS preservation is NOT shown to cause")
    print("recoverability -- see 00_START_HERE.md).")
    print("=" * 78)
