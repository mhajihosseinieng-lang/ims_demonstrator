# IMS Platform Demonstrator -- Package Guide

This package contains a runnable reproduction of the headline results
from the frozen research chain **2 -> 3 -> 4a -> 4b -> 5A -> 6A-1 -> 6B ->
7A...7N-4B -> 8A -> 8B -> 8C**, plus the complete traceability record for
every frozen increment.

## How to run it

```
cd demo
python3 run_demo.py
```

No setup beyond a working Python 3 with numpy and scipy is required. The
script reproduces, live, numbers that are already frozen in the
traceability record -- it is a reproduction, not a new experiment. Runtime
is approximately 1.5-2 minutes (the algebraic solves at every integration
step are the bottleneck, not anything you need to configure).

## What the demo shows

1. **A causally-verified two-protection-event cascade.** A disturbance
   trips Bus4's Volt-VAR support, and an actual-vs-counterfactual test
   shows that this first trip genuinely advances (not merely precedes)
   a second protection event at Bus3.
2. **Post-cascade recovery**, quantified by distance from the nearest
   independently-verified algebraic fold -- confirming the system
   recovers with margin, not by luck.
3. **Temporal disturbance staging matters.** The same cumulative
   disturbance applied in three escalating stages produces markedly
   lower peak transient voltage than applying it all at once.

## Package structure

```
00_START_HERE.md          <- this file
core/                      <- the model implementation (frozen, unmodified)
  layerA_equilibria.py       equilibrium enumeration (deterministic, no RNG)
  layerB_hybrid_v2.py         hybrid branch-tracking with escalating
                               fallback (local Newton -> wide scan ->
                               independent verification)
  layerA_equilibria_7i.py    parameterized algebraic equations (Bsh3 as
                               an argument, for the second protection latch)
  sim_7i_hybrid.py            the two-latch hybrid integrator
                               (s_PV: Bus4 Volt-VAR trip,
                                s_sh3: Bus3 shunt-reactor trip)
  sim_8b_staged.py            adds the three-stage disturbance operator
                               on top of sim_7i_hybrid
  run_8c_full.py              full instrumentation: event history, peak
                               voltages, IMS decomposition, recoverability
demo/
  run_demo.py                 <- run this
docs/                         <- complete traceability record, by increment
  increment_2_3_4a_4b_roa/    foundational GFM model, multi-bus network,
                               directional recoverability, Volt-VAR
                               effects, GFL structural contrast, ROA study
  increment_5a_6a_6b/          protection mechanism, IMS applicability
                               across new equilibria and hybrid trajectories
  increment_7_8/               second protection mechanism, causal cascade,
                               severity/timescale robustness study,
                               staged-disturbance protocol
```

## What this package does and does not claim

Read this before presenting or citing any result from this package.

**Demonstrated, with pre-registered protocols and counterfactual tests:**
- A converter-side disturbance can trip Bus4 protection, which measurably
  and causally advances (or in some cases creates) a second trip at
  Bus3 -- not merely two events that happen in sequence.
- The resulting two-trip cascade produces substantial transient voltage
  escalation (observed up to ~3x nominal in tested cases) followed by
  recovery to a stable, locally verified equilibrium.
- IMS (fast/slow manifold) structure -- existence, normal hyperbolicity,
  transverse-mode dominance, genuine transverse contraction -- persists
  throughout every cascade tested, across a 50-case grid spanning
  disturbance severity and converter current-loop timescale.
- Temporal staging of a disturbance measurably reduces transient
  severity relative to an equivalent single-step disturbance of the
  same cumulative magnitude, without changing the eventual outcome.

**Explicitly NOT demonstrated -- do not claim these:**
- That IMS preservation *causes* recoverability. The evidence shows
  co-occurrence across every tested case, not a causal link -- no case
  in this package's pre-registered grid reached a genuinely
  IMS-degraded state, so the contrasting experiment needed to establish
  causation was never obtained.
- That the tested cascades culminate in collapse. Every activated
  cascade in this package recovers.
- That this reproduces the actual 2025 Iberian blackout, or that the
  three-stage disturbance protocol corresponds to real MW magnitudes.
  The escalation *ratios* (2.05x, then 1.28x) are taken from that
  event's public reporting; the underlying quantity (a converter slow-
  state displacement) has no physical unit correspondence to real power.
- That this model contains synchronous-generator dynamics, a real
  tie-line, current limiting, fixed-PF/Q switching, or GFM-penetration
  sweeps. None of these exist in the frozen model. Several candidate
  mechanisms for a *third* protection event (current limiting, control-
  mode switching) were explicitly reviewed and found not viable or not
  yet justified -- see docs/increment_7_8/.

**The single sentence that best summarizes what is actually established:**

> The frozen study does not demonstrate that IMS preservation causes
> recoverability or that every protection cascade culminates in
> collapse; instead, it demonstrates -- under a rigorously
> pre-registered and counterfactually tested reduced-order model --
> that sequential protection actions can form a genuinely causal
> cascade, that disturbance timing materially alters transient
> severity, and that IMS provides a quantitatively verifiable geometric
> characterization of the resulting large-signal recovery dynamics.

## If you want to explore further

Every number the demo prints traces back to a specific increment's
traceability record in `docs/`. Each record documents not just the
final result but the negative results, implementation bugs found and
fixed, and applicability limits encountered along the way -- these are
treated as first-class findings throughout, not omitted. If you're
deciding what this platform can support in a funding or publication
context, `docs/increment_7_8/8C_FROZEN.md` and
`docs/increment_5a_6a_6b/6B_full_review.md` are the most load-bearing
documents for the causal-cascade and IMS-applicability claims
respectively.
