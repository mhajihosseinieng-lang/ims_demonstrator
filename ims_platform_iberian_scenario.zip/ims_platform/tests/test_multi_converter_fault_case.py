"""Tests for server.multi_converter_fault_case -- the "Multi-Converter Fault Recovery" Case Library entry."""
import numpy as np

from ims_platform.server import multi_converter_fault_case as mcc


def test_reference_bifurcation():
    r = mcc.verify_reference_bifurcation()
    assert r["baseline_case"]["summary"]["verdict"] == "NON-RECOVERABLE"
    assert r["coordinated_case"]["summary"]["verdict"] == "RECOVERABLE"


def test_local_vs_remote_support_asymmetry_is_genuine():
    """
    The corrected, verified finding: local (grid-following) support is
    necessary and sufficient; remote (grid-forming anchor) support
    alone is not. This test locks in the ACTUAL result, not the
    "coordination is required" assumption an earlier draft of this
    case made before checking.
    """
    r = mcc.verify_local_vs_remote_support_asymmetry()
    assert r["gfm_only"]["summary"]["verdict"] == "NON-RECOVERABLE"
    assert r["gfl_only"]["summary"]["verdict"] == "RECOVERABLE"
    assert r["both"]["summary"]["verdict"] == "RECOVERABLE"


def test_two_converters_have_independent_states():
    """Confirms this is genuinely a two-converter model (distinct states/buses), not a duplicated single model."""
    system, comps = mcc.build_network(Imax_gfm=1.0, Imax_gfl=1.0, KQ_gfl=0.0)
    assert comps["gfm"] is not comps["gfl"]
    assert comps["gfm"].bus != comps["gfl"].bus
    assert "v_busA" in system.state_names
    assert "v_busB" in system.state_names
    assert "conv_gfm_trip_timer" in system.state_names
    assert "conv_gfl_trip_timer" in system.state_names


def test_every_fault_returns_to_same_prefault_equilibrium():
    for params in [mcc.BASELINE_REFERENCE, mcc.COORDINATED_REFERENCE]:
        r = mcc.run_stress_test(params)
        assert r["baseline_ok"]
        assert r["summary"]["settled_to_prefault_equilibrium"] is True


def test_baseline_prefault_equilibrium_small_signal_stable():
    r = mcc.run_stress_test(mcc.BASELINE_REFERENCE)
    assert r["baseline"]["small_signal_stable"] is True


def test_limiting_bus_is_reported():
    r = mcc.run_stress_test(mcc.BASELINE_REFERENCE)
    assert r["summary"]["limiting_bus"] in ("busA", "busB")


def test_disclaimer_present():
    r = mcc.run_stress_test({})
    assert r.get("disclaimer")


def test_does_not_touch_iberian_or_gfm_case_frozen_params():
    from ims_platform.server import iberian_scenario as isc
    from ims_platform.server import gfm_current_limit_case as gcc
    before_iberian = dict(isc.DEFAULT_NETWORK_PARAMS)
    before_gfm = dict(gcc.DEFAULT_PARAMS)
    mcc.run_stress_test(mcc.BASELINE_REFERENCE)
    assert dict(isc.DEFAULT_NETWORK_PARAMS) == before_iberian
    assert dict(gcc.DEFAULT_PARAMS) == before_gfm
