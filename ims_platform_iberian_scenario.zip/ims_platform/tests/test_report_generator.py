"""
Tests for server.report_generator -- the shared HTML/PDF report engine.

Includes a specific regression guard: an earlier version of this module
had a line-based edit accidentally delete the
`section_time_domain_plots(...)` call from build_iberian_report's
sections list, silently producing a report with NO embedded plots (and
about 1/20th the expected size) while still completing without error.
Every report builder's test below explicitly asserts the presence of
at least one embedded plot image, specifically to catch this class of
silent, no-exception content-loss bug again.
"""
import numpy as np

from ims_platform.server import iberian_scenario as isc
from ims_platform.server import gfm_current_limit_case as gcc
from ims_platform.server import multi_converter_fault_case as mcc
from ims_platform.server import report_generator as rg


def _assert_has_real_content(html_str: str, min_len: int = 20000):
    assert "data:image/png;base64" in html_str, "report is missing at least one embedded plot"
    assert len(html_str) > min_len, f"report suspiciously short ({len(html_str)} chars) -- likely a dropped section"


def test_iberian_report_has_embedded_plots_and_real_values():
    r = isc.run_stress_test({"KQ": 0.0, "Q_avail": 0.05, "Imax": 1.3})
    html_str = rg.build_iberian_report(r)
    _assert_has_real_content(html_str)
    assert "NON-RECOVERABLE" in html_str
    assert f"{r['summary']['max_v_es_sw']:.4f}" in html_str


def test_iberian_report_with_all_optional_sections():
    r = isc.run_stress_test({"KQ": 0.0, "Q_avail": 0.05, "Imax": 1.3})
    cf = isc.run_baseline_vs_dynamic_q_counterfactual()
    bm = isc.run_boundary_map({"KQ": 0.0, "Q_avail": 0.05, "Imax": 1.3})
    rec = isc.find_recommended_interventions({"KQ": 0.0, "Q_avail": 0.05, "Imax": 1.3})
    html_str = rg.build_iberian_report(r, counterfactual=cf, boundary=bm, recommendations=rec)
    _assert_has_real_content(html_str)
    assert "Not evaluated in this analysis." not in html_str.split("7. Counterfactual")[1].split("9. Scientific")[0]


def test_iberian_report_without_optional_sections_says_not_evaluated():
    r = isc.run_stress_test({"KQ": 0.0, "Q_avail": 0.05, "Imax": 1.3})
    html_str = rg.build_iberian_report(r)
    assert "Not evaluated in this analysis." in html_str


def test_gfm_report_has_embedded_plots_and_real_values():
    r = gcc.run_stress_test({"Imax": 0.4})
    html_str = rg.build_gfm_report(r)
    _assert_has_real_content(html_str, min_len=15000)
    assert "NON-RECOVERABLE" in html_str
    assert f"{r['summary']['min_v_poc']:.4f}" in html_str


def test_gfm_report_recoverable_reference():
    r = gcc.run_stress_test({"Imax": 2.0})
    html_str = rg.build_gfm_report(r)
    assert "RECOVERABLE" in html_str
    _assert_has_real_content(html_str, min_len=15000)


def test_multiconverter_report_has_embedded_plots_and_real_values():
    r = mcc.run_stress_test(mcc.BASELINE_REFERENCE)
    html_str = rg.build_multiconverter_report(r)
    _assert_has_real_content(html_str, min_len=15000)
    assert "NON-RECOVERABLE" in html_str
    assert f"{r['summary']['min_v_busA']:.4f}" in html_str
    assert f"{r['summary']['min_v_busB']:.4f}" in html_str


def test_multiconverter_report_with_asymmetry_section():
    r = mcc.run_stress_test(mcc.BASELINE_REFERENCE)
    asym = mcc.verify_local_vs_remote_support_asymmetry()
    html_str = rg.build_multiconverter_report(r, asymmetry=asym)
    assert "Local vs. remote support" in html_str
    assert "GFM (anchor) support only" in html_str


def test_pdf_generation_produces_nonempty_valid_pdf():
    r = isc.run_stress_test({"KQ": 0.0, "Q_avail": 0.05, "Imax": 1.3})
    html_str = rg.build_iberian_report(r)
    pdf_bytes = rg.html_to_pdf_bytes(html_str)
    assert len(pdf_bytes) > 10000
    assert pdf_bytes[:4] == b"%PDF"


def test_pdf_generation_for_all_three_cases():
    r1 = isc.run_stress_test({"KQ": 0.0, "Q_avail": 0.05, "Imax": 1.3})
    r2 = gcc.run_stress_test({"Imax": 0.4})
    r3 = mcc.run_stress_test(mcc.BASELINE_REFERENCE)
    for html_str in [rg.build_iberian_report(r1), rg.build_gfm_report(r2), rg.build_multiconverter_report(r3)]:
        pdf_bytes = rg.html_to_pdf_bytes(html_str)
        assert pdf_bytes[:4] == b"%PDF"
        assert len(pdf_bytes) > 10000


def test_report_never_shows_not_achievable_as_impossible():
    rec = isc.find_recommended_interventions({"KQ": 0.0, "Q_avail": 0.05, "Imax": 1.3})
    r = isc.run_stress_test({"KQ": 0.0, "Q_avail": 0.05, "Imax": 1.3})
    html_str = rg.build_iberian_report(r, recommendations=rec)
    assert "impossible" not in html_str.lower()
    assert "not achievable within tested range" in html_str


def test_failed_baseline_report_does_not_crash():
    """A case with no stable baseline must still produce a valid (if minimal) report, not raise."""
    bad_result = {"baseline_ok": False, "message": "test failure case", "disclaimer": "test disclaimer"}
    html_str = rg.build_iberian_report(bad_result)
    assert "test failure case" in html_str
    assert "<html>" in html_str
