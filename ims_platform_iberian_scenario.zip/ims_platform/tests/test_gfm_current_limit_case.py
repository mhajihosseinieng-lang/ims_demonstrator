"""Tests for server.gfm_current_limit_case -- the "GFM Current-Limit Recovery" Case Library entry."""
import numpy as np

from ims_platform.server import gfm_current_limit_case as gcc


def test_reference_bifurcation():
    r = gcc.verify_reference_bifurcation()
    assert r["non_recoverable_case"]["summary"]["verdict"] == "NON-RECOVERABLE"
    assert r["recoverable_case"]["summary"]["verdict"] == "RECOVERABLE"


def test_every_fault_returns_to_same_prefault_equilibrium_regardless_of_imax():
    """This case's own documented claim: recoverability here is an FRT-depth criterion, not a
    bistable-equilibrium bifurcation -- every tested Imax must settle back to the pre-fault point."""
    for imax in [0.3, 0.5, 1.0, 2.0, 4.0]:
        r = gcc.run_stress_test({"Imax": imax})
        assert r["baseline_ok"]
        assert r["summary"]["settled_to_prefault_equilibrium"] is True


def test_dip_depth_monotonic_in_imax():
    imax_values = [0.3, 0.5, 0.8, 1.2, 1.8, 2.5, 4.0]
    dips = []
    for imax in imax_values:
        r = gcc.run_stress_test({"Imax": imax})
        assert r["baseline_ok"]
        dips.append(r["summary"]["min_v_poc"])
    diffs = np.diff(dips)
    assert np.all(diffs >= -1e-9), f"dip depth should be non-decreasing in Imax, got {dips}"


def test_imax_sweep_crosses_both_thresholds():
    sweep = gcc.run_imax_sweep()
    verdicts = [p["verdict"] for p in sweep["points"]]
    assert "NON-RECOVERABLE" in verdicts
    assert "RECOVERABLE" in verdicts


def test_baseline_pre_fault_equilibrium_is_small_signal_stable():
    r = gcc.run_stress_test({"Imax": 1.0})
    assert r["baseline"]["small_signal_stable"] is True
    assert r["baseline"]["max_eigenvalue_real_part"] < 0


def test_disclaimer_present():
    r = gcc.run_stress_test({})
    assert r.get("disclaimer")


def test_does_not_touch_iberian_frozen_params():
    """Importing/using this module must not mutate the Iberian scenario's frozen parameters."""
    from ims_platform.server import iberian_scenario as isc
    before = dict(isc.DEFAULT_NETWORK_PARAMS)
    gcc.run_stress_test({"Imax": 1.0})
    after = dict(isc.DEFAULT_NETWORK_PARAMS)
    assert before == after
