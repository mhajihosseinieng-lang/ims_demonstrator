"""
server.gfm_current_limit_case
--------------------------------

Case Library entry: "GFM Current-Limit Recovery" (funding-demo brief,
Case Library scope). A standalone, genuinely distinct demonstration
from the Iberian scenario: a single grid-forming (GFM) converter at
the point of common coupling of a weak grid, subjected to a nearby
fault (a temporary heavy local load, applied and cleared), showing how
the converter's own current rating determines how deep the voltage
dip goes during the fault -- the causal chain the proposal explicitly
asks for:

    disturbance (fault) -> GFM Thevenin restoring current demand
        -> current-limit clamp saturates (or doesn't)
        -> depth of the voltage dip during the fault
        -> ride-through classification (recoverable / at risk / non-recoverable)

Deliberately reuses network.renewable_components.GFLRenewableSource's
already-validated GFM mechanism (gfm_fraction=1.0, i.e. the ENTIRE
converter operates as a Thevenin voltage source behind X_gfm, with its
own current-limit clamp) -- this is legitimate reuse of a library
component (the same way ShuntReactor or LineChargingShunt are reused
across cases), NOT a re-presentation of the Iberian scenario's own
disturbance or result. The topology, the disturbance TYPE (a local
fault demanding current, not a network-wide loss of reactive
absorption), the verdict criterion, and the parameter set are all
different from the Iberian case, and neither this case's network nor
its frozen reference values were changed by, or feed back into, the
Iberian scenario's own frozen parameters (server/iberian_scenario.py's
DEFAULT_NETWORK_PARAMS is untouched).

Recoverability criterion -- explicitly different in KIND from the
Iberian case's, and documented as such: this case does NOT rely on an
internal bistable-equilibrium bifurcation (there is no protection/trip
element here, deliberately -- see the module docstring's note on not
inventing unsupported mechanisms). Every fault in this network
algebraically returns to the same pre-fault equilibrium once the fault
is cleared, regardless of Imax (verified below). What DOES depend on
Imax is how deep the voltage dips WHILE the fault is present -- and
that transient depth is assessed against a fault-ride-through (FRT)
style admissibility envelope (a fixed critical voltage threshold),
exactly the way real grid codes define "must not disconnect" curves
for converter-based generation. A dip below the critical threshold is
reported as NON-RECOVERABLE in the sense that real equipment governed
by such a grid code would be required (or permitted) to disconnect --
not in the sense that this simulation shows the network failing to
return to normal on its own.
"""

from __future__ import annotations

import numpy as np
from typing import Dict, List, Optional

from ..network import Network, Bus, Line, ConstantImpedanceLoad, GFLRenewableSource, AutomaticModelBuilder
from ..core.simulator import Simulator

DISCLAIMER = (
    "Illustrative, reduced-order test system demonstrating fault-ride-through behaviour of a "
    "current-limited grid-forming converter. Not a reconstruction of any real installation; "
    "parameters are chosen to produce a clear, verified demonstration of the current-limit / "
    "recoverability relationship, not to match any specific converter or grid code."
)

# ---------------------------------------------------------------------
# FROZEN, VALIDATED parameters (see this module's dev/tuning notes --
# same methodology as server.iberian_scenario.DEFAULT_NETWORK_PARAMS).
# Do not tune casually; re-verify via tests/test_gfm_current_limit_case.py
# if changed.
# ---------------------------------------------------------------------
DEFAULT_PARAMS = dict(
    P_nom=0.3,
    R_tie=0.15, L_tie=0.03, C_bus=0.1,
    R_load_normal=3.0,
    R_load_fault=0.4,     # heavy local load during the fault (low R = large current draw)
    t_fault=0.3, t_clear=0.45,   # 150 ms fault duration
    tail_horizon=1.5,
    X_gfm=0.1,
    v_critical=0.5,   # below this during the fault: NON-RECOVERABLE (FRT violation)
    v_at_risk=0.7,    # below this (but above v_critical): AT RISK
)

SLIDER_DEFAULTS = dict(Imax=0.4)
SLIDER_RANGES = {
    "Imax": {"min": 0.1, "max": 4.0, "step": 0.05, "label": "Converter current limit (Imax, p.u.)"},
}

IMAX_NONRECOVERABLE_REFERENCE = 0.4
IMAX_RECOVERABLE_REFERENCE = 2.0


def build_network(Imax: float, P_nom: Optional[float] = None):
    p = DEFAULT_PARAMS
    P_nom = p["P_nom"] if P_nom is None else P_nom
    net = Network("gfm_current_limit_recovery")
    net.add_bus(Bus(id="grid", v_fixed=1.0))
    net.add_bus(Bus(id="poc", C=p["C_bus"], v_init=1.0))
    net.add_line(Line(id="tie", from_bus="grid", to_bus="poc", R=p["R_tie"], L=p["L_tie"]))

    gfm = GFLRenewableSource(
        id="gfm_conv", bus="poc", P_set=P_nom, KQ=0.0, v_ref=1.0,
        Imax=Imax, v_trip=999.0, t_delay=1.0,  # overvoltage trip disabled (v_trip effectively unreachable):
                                                 # this case's story is undervoltage/current-limited support,
                                                 # not overvoltage protection -- the mechanism the Iberian
                                                 # case already covers.
        gfm_fraction=1.0,  # entire converter operates as the GFM (Thevenin) mechanism
        X_gfm=p["X_gfm"], k_damp=0.05,
    )
    net.add_component(gfm)
    load = ConstantImpedanceLoad(id="load", bus="poc", R=p["R_load_normal"])
    net.add_component(load)

    system = AutomaticModelBuilder.build(net, input_component_id="gfm_conv", name="gfm_current_limit_recovery")
    return system, {"gfm": gfm, "load": load}


def _simulate_fault(system, comps: Dict, P_nom: float, x_star: np.ndarray):
    p = DEFAULT_PARAMS
    sim = Simulator(system, method="Radau")
    u = np.array([P_nom])

    seg1 = sim.simulate(x_star, (0.0, p["t_fault"]), u=u, n_eval=60)
    comps["load"].params["R"] = p["R_load_fault"]
    seg2 = sim.simulate(seg1.x[:, -1], (p["t_fault"], p["t_clear"]), u=u, n_eval=80)
    comps["load"].params["R"] = p["R_load_normal"]
    seg3 = sim.simulate(seg2.x[:, -1], (p["t_clear"], p["t_clear"] + p["tail_horizon"]), u=u, n_eval=200)

    t = np.concatenate([seg1.t, seg2.t, seg3.t])
    x = np.concatenate([seg1.x, seg2.x, seg3.x], axis=1)
    success = bool(seg1.success and seg2.success and seg3.success)
    return t, x, success


def run_stress_test(params: Dict) -> dict:
    Imax = float(params.get("Imax", SLIDER_DEFAULTS["Imax"]))
    P_nom = DEFAULT_PARAMS["P_nom"]
    system, comps = build_network(Imax=Imax, P_nom=P_nom)
    state_names = list(system.state_names)

    x0 = system.initial_guess()
    eq = system.find_equilibrium(x0, u=np.array([P_nom]))

    result = {
        "disclaimer": DISCLAIMER,
        "params_used": {"Imax": Imax, "P_nom": P_nom},
        "state_names": state_names,
        "fault_definition": {
            "t_fault": DEFAULT_PARAMS["t_fault"], "t_clear": DEFAULT_PARAMS["t_clear"],
            "duration_s": round(DEFAULT_PARAMS["t_clear"] - DEFAULT_PARAMS["t_fault"], 3),
            "R_load_normal": DEFAULT_PARAMS["R_load_normal"], "R_load_fault": DEFAULT_PARAMS["R_load_fault"],
            "description": "A temporary heavy local load at the point of common coupling, applied for "
                            f"{round((DEFAULT_PARAMS['t_clear']-DEFAULT_PARAMS['t_fault'])*1000)} ms then cleared "
                            "-- representing a nearby fault's current demand.",
        },
        "v_critical": DEFAULT_PARAMS["v_critical"],
        "v_at_risk": DEFAULT_PARAMS["v_at_risk"],
    }

    if not (eq.converged and eq.is_stable):
        result["baseline_ok"] = False
        result["message"] = f"No stable pre-fault operating point (residual={eq.residual_norm:.2e})."
        return result

    result["baseline_ok"] = True
    result["baseline"] = {
        "x_star": {n: float(v) for n, v in zip(state_names, eq.x_star)},
        "max_eigenvalue_real_part": float(np.max(eq.eigenvalues.real)),
        "small_signal_stable": bool(eq.is_stable),
    }

    t, x, sim_success = _simulate_fault(system, comps, P_nom, eq.x_star)
    idx_v = state_names.index("v_poc")
    v_trace = x[idx_v, :]

    min_v = float(np.min(v_trace))
    final_v = float(v_trace[-1])
    idx_min = int(np.argmin(v_trace))
    t_min = float(t[idx_min])

    # Independent re-solved-equilibrium check that the post-fault state
    # genuinely returns to the SAME pre-fault equilibrium (confirming
    # this case's documented claim that recoverability here is a
    # transient/FRT criterion, not an endogenous bifurcation -- unlike
    # the Iberian case).
    eq_final = system.find_equilibrium(x[:, -1], u=np.array([P_nom]))
    settled_to_prefault = bool(
        eq_final.converged and eq_final.is_stable
        and np.linalg.norm(x[:, -1] - eq.x_star) < 0.02 * max(1.0, np.linalg.norm(eq.x_star))
    )

    if min_v < DEFAULT_PARAMS["v_critical"] or not settled_to_prefault or not sim_success:
        verdict = "NON-RECOVERABLE"
    elif min_v < DEFAULT_PARAMS["v_at_risk"]:
        verdict = "AT RISK"
    else:
        verdict = "RECOVERABLE"

    result.update({
        "trajectory": {"t": t.tolist(), "success": sim_success},
        "voltage_trace": v_trace.tolist(),
        "summary": {
            "min_v_poc": min_v,
            "t_min_v": t_min,
            "final_v_poc": final_v,
            "settled_to_prefault_equilibrium": settled_to_prefault,
            "verdict": verdict,
            "recoverable": bool(verdict == "RECOVERABLE"),
            "criterion_note": (
                "This case's verdict is a fault-ride-through (FRT) depth criterion: whether the "
                "voltage dip during the fault stays above a critical threshold, in the same spirit "
                "as a grid code's must-not-disconnect envelope -- NOT an endogenous stable/unstable "
                "equilibrium bifurcation like the Iberian scenario's. Every fault here algebraically "
                "returns to the same pre-fault equilibrium once cleared (verified: "
                f"settled_to_prefault_equilibrium={settled_to_prefault}), regardless of Imax."
            ),
        },
    })
    return result


def verify_reference_bifurcation() -> dict:
    """Executable proof, mirroring server.iberian_scenario.verify_baseline_bifurcation."""
    bad = run_stress_test({"Imax": IMAX_NONRECOVERABLE_REFERENCE})
    good = run_stress_test({"Imax": IMAX_RECOVERABLE_REFERENCE})
    assert bad["baseline_ok"] and good["baseline_ok"]
    assert bad["summary"]["verdict"] == "NON-RECOVERABLE", bad["summary"]
    assert good["summary"]["verdict"] == "RECOVERABLE", good["summary"]
    assert bad["summary"]["min_v_poc"] < good["summary"]["min_v_poc"]
    assert bad["summary"]["settled_to_prefault_equilibrium"]
    assert good["summary"]["settled_to_prefault_equilibrium"]
    return {"non_recoverable_case": bad, "recoverable_case": good}


def run_imax_sweep(severities: Optional[List[float]] = None) -> dict:
    """Boundary-map-style sweep of Imax alone (the case's one physically meaningful lever)."""
    imax_values = severities or [0.3, 0.4, 0.5, 0.6, 0.8, 1.0, 1.5, 2.0, 3.0, 4.0]
    points = []
    for imax in imax_values:
        r = run_stress_test({"Imax": imax})
        if not r.get("baseline_ok"):
            points.append({"Imax": imax, "verdict": None, "min_v_poc": None})
            continue
        points.append({"Imax": imax, "verdict": r["summary"]["verdict"], "min_v_poc": r["summary"]["min_v_poc"]})
    return {"disclaimer": DISCLAIMER, "points": points}
