"""
server.report_generator
--------------------------

A single, generic report-building engine used by every Case Library
case (Iberian, GFM Current-Limit Recovery, Multi-Converter Fault
Recovery). Per the explicit requirement this was built against: HTML
and PDF are generated from the SAME structured input and the SAME HTML
markup (PDF is produced by rendering that exact HTML with wkhtmltopdf,
not a second, independently-written template) -- so they cannot drift
apart.

Design rule, followed throughout: this module NEVER invents a value.
Every number and every plotted curve is read directly out of the
result dict a case's own `run_stress_test`-style function already
returned (the same dict the API/UI already display) or out of an
explicitly-passed counterfactual/boundary/recommendation dict from
that same case's own backend functions. A section for which the
caller did not supply data renders the literal string "Not evaluated
in this analysis." -- it is never silently populated with a default,
and "not achievable within tested range" (a real, negative result) is
never rendered as "impossible" (a stronger claim the underlying search
did not establish).

Plots are rendered SERVER-SIDE (matplotlib, Agg backend) and embedded
as base64 PNGs directly in the HTML. This is a deliberate choice, not
a style preference: the exported HTML/PDF must be self-contained and
show the actual simulated curves without depending on the dashboard's
own canvas/JS renderer (which cannot run inside a static export or a
PDF converter). The data plotted is read from the same result dict's
`trajectory`/`voltage_trace(s)`/`trip_timer_trace` arrays used by the
live dashboard -- the same numbers, a different renderer.
"""

from __future__ import annotations

import base64
import datetime
import html as html_lib
import io
from typing import Dict, List, Optional, Sequence, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

PLATFORM_VERSION = "v4.5"

_BG = "#0b1620"
_PANEL = "#0f1e29"
_GRID = "#1b2733"
_TEXT = "#dce6ef"
_MUTED = "#9fb0bf"
_COLORS = ["#3FE0A8", "#6FC6FF", "#B18CFF", "#FFB454", "#FF6B6B", "#7CE38B"]


# ---------------------------------------------------------------------
# Plot rendering (server-side, matplotlib -> base64 PNG)
# ---------------------------------------------------------------------

def _fig_to_data_uri(fig) -> str:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=140, bbox_inches="tight", facecolor=_BG)
    plt.close(fig)
    buf.seek(0)
    b64 = base64.b64encode(buf.read()).decode("ascii")
    return f"data:image/png;base64,{b64}"


def _style_axes(ax, xlabel, ylabel, title=None):
    ax.set_facecolor(_PANEL)
    ax.grid(True, color=_GRID, linewidth=0.8)
    ax.spines[:].set_color(_GRID)
    ax.tick_params(colors=_MUTED, labelsize=9)
    ax.set_xlabel(xlabel, color=_TEXT, fontsize=10)
    ax.set_ylabel(ylabel, color=_TEXT, fontsize=10)
    if title:
        ax.set_title(title, color=_TEXT, fontsize=11, loc="left", fontweight="bold")


def plot_time_series(t: Sequence[float], series: Dict[str, Sequence[float]], xlabel: str, ylabel: str,
                      title: str, hlines: Optional[List[Tuple[float, str, str]]] = None,
                      vlines: Optional[List[Tuple[float, str]]] = None) -> str:
    """hlines: list of (y, label, color). vlines: list of (x, color) -- for disturbance event markers."""
    fig, ax = plt.subplots(figsize=(7.6, 3.4))
    fig.patch.set_facecolor(_BG)
    _style_axes(ax, xlabel, ylabel, title)
    for i, (label, vals) in enumerate(series.items()):
        ax.plot(t, vals, label=label, color=_COLORS[i % len(_COLORS)], linewidth=1.8)
    for y, label, color in (hlines or []):
        ax.axhline(y, color=color, linestyle="--", linewidth=1.2, label=label)
    for x, color in (vlines or []):
        ax.axvline(x, color=color, linestyle=":", linewidth=1.0, alpha=0.6)
    ax.legend(facecolor=_PANEL, edgecolor=_GRID, labelcolor=_TEXT, fontsize=8, loc="best")
    return _fig_to_data_uri(fig)


def plot_bar_verdicts(x_values: Sequence[float], verdicts: Sequence[Optional[str]], xlabel: str,
                       title: str) -> str:
    score_of = {"RECOVERABLE": 1.0, "AT RISK": 0.5, "NON-RECOVERABLE": 0.0}
    color_of = {"RECOVERABLE": "#3FE0A8", "AT RISK": "#FFB454", "NON-RECOVERABLE": "#FF6B6B"}
    fig, ax = plt.subplots(figsize=(7.6, 3.0))
    fig.patch.set_facecolor(_BG)
    _style_axes(ax, xlabel, "Recoverability score (0/0.5/1)", title)
    width = (max(x_values) - min(x_values)) / max(len(x_values) - 1, 1) * 0.5 if len(x_values) > 1 else 0.3
    for x, v in zip(x_values, verdicts):
        if v is None:
            continue
        score = score_of[v]
        if score > 0:
            ax.bar(x, score, width=width, color=color_of[v])
        else:
            ax.scatter([x], [0], color=color_of[v], s=40, zorder=5)
            ax.annotate("0.0", (x, 0), textcoords="offset points", xytext=(0, 8),
                        ha="center", color=color_of[v], fontsize=8)
    ax.set_ylim(-0.1, 1.3)
    return _fig_to_data_uri(fig)


# ---------------------------------------------------------------------
# Report shell / section rendering
# ---------------------------------------------------------------------

def _esc(s) -> str:
    return html_lib.escape(str(s))


def _fmt(v, ndigits=4):
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, (int, float)):
        return f"{v:.{ndigits}f}"
    return _esc(v)


def _params_table(params: Dict) -> str:
    rows = "".join(f"<tr><td>{_esc(k)}</td><td class='num'>{_fmt(v)}</td></tr>" for k, v in params.items())
    return f"<table class='ptable'><tbody>{rows}</tbody></table>"


def _not_evaluated() -> str:
    return "<p class='not-evaluated'>Not evaluated in this analysis.</p>"


def _verdict_badge(verdict: str) -> str:
    color = {"RECOVERABLE": "#3FE0A8", "AT RISK": "#FFB454", "NON-RECOVERABLE": "#FF6B6B"}.get(verdict, "#9fb0bf")
    return f"<span class='verdict-badge' style='color:{color};border-color:{color};'>{_esc(verdict)}</span>"


def document_shell(title: str, subtitle: str, case_id: str, sections_html: List[str]) -> str:
    generated_at = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    body = "\n".join(sections_html)
    return f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<title>{_esc(title)} -- Analysis Report</title>
<style>
  @page {{ margin: 18mm 14mm; }}
  body {{ background:{_BG}; color:{_TEXT}; font-family: -apple-system, Segoe UI, Arial, sans-serif;
          margin:0; padding: 28px 34px; line-height:1.55; }}
  h1 {{ font-size: 22px; margin: 0 0 4px; }}
  h2 {{ font-size: 15px; margin: 30px 0 10px; padding-bottom: 6px; border-bottom: 1px solid #24313d;
        color: #eaf2f8; }}
  h3 {{ font-size: 12.5px; color: {_TEXT}; margin: 16px 0 6px; }}
  .subtitle {{ color: {_MUTED}; font-size: 12.5px; margin-bottom: 4px; }}
  .meta {{ color: {_MUTED}; font-size: 10.5px; font-family: monospace; margin-bottom: 18px; }}
  .disclaimer {{ font-size: 11px; color: {_MUTED}; border-left: 3px solid #FFB454;
                 background: rgba(255,180,84,0.06); padding: 10px 14px; border-radius: 0 6px 6px 0;
                 margin: 14px 0; }}
  table {{ border-collapse: collapse; width: 100%; font-size: 11.5px; margin: 8px 0 14px; }}
  table.ptable td:first-child, table.ctable td:first-child {{ color: {_MUTED}; }}
  td, th {{ padding: 6px 10px; border-bottom: 1px solid #1b2733; text-align: left; }}
  td.num {{ text-align: right; font-family: monospace; }}
  th {{ color: {_MUTED}; font-weight: 600; font-size: 10.5px; text-transform: uppercase; }}
  .verdict-badge {{ display:inline-block; font-weight: 800; font-size: 16px; border: 1.5px solid;
                     border-radius: 6px; padding: 4px 14px; }}
  .metric-grid {{ display:flex; flex-wrap:wrap; gap: 14px; margin: 10px 0 16px; }}
  .metric {{ background:{_PANEL}; border:1px solid #1b2733; border-radius:6px; padding:10px 14px; min-width:160px; }}
  .metric .label {{ font-size: 9.5px; color:{_MUTED}; text-transform:uppercase; letter-spacing:.04em; }}
  .metric .value {{ font-size: 15px; font-weight:700; margin-top:2px; font-family: monospace; }}
  img.plot {{ max-width: 100%; border-radius: 6px; border: 1px solid #1b2733; margin: 8px 0 4px; }}
  .not-evaluated {{ color: {_MUTED}; font-style: italic; font-size: 11.5px; }}
  .note {{ font-size: 10.5px; color: {_MUTED}; margin-top: 6px; }}
  .comparison {{ display:grid; grid-template-columns: 1fr 1fr; gap: 14px; margin: 10px 0; }}
  .footer {{ margin-top: 34px; padding-top: 12px; border-top: 1px solid #1b2733; color: {_MUTED};
             font-size: 9.5px; font-family: monospace; }}
  @media print {{ body {{ padding: 0; }} }}
</style>
</head>
<body>
  <h1>{_esc(title)}</h1>
  <div class="subtitle">{_esc(subtitle)}</div>
  <div class="meta">Case ID: {_esc(case_id)} &middot; Generated: {generated_at} &middot; Platform: {PLATFORM_VERSION}</div>
  {body}
  <div class="footer">Generated by IMS Platform Explorer ({PLATFORM_VERSION}) &middot; report_generator.py &middot;
  This report was produced directly from the analysis result object returned by the case's own backend
  function -- no value in it was entered by hand.</div>
</body>
</html>"""


def section_executive_summary(verdict: str, summary_metrics: Dict[str, str], disclaimer: str) -> str:
    metrics_html = "".join(
        f"<div class='metric'><div class='label'>{_esc(k)}</div><div class='value'>{_esc(v)}</div></div>"
        for k, v in summary_metrics.items()
    )
    return f"""
<h2>1. Executive Summary</h2>
<p>Assessment: {_verdict_badge(verdict)}</p>
<div class="metric-grid">{metrics_html}</div>
<div class="disclaimer">{_esc(disclaimer)}</div>
"""


def section_scenario_definition(description: str, network_summary: Optional[Dict], disturbance_text: str) -> str:
    net_html = _params_table(network_summary) if network_summary else _not_evaluated()
    return f"""
<h2>2. Scenario Definition</h2>
<p>{_esc(description)}</p>
<h3>Network summary</h3>
{net_html}
<h3>Disturbance</h3>
<p>{_esc(disturbance_text)}</p>
"""


def section_system_configuration(params_used: Dict) -> str:
    return f"""
<h2>3. Input Conditions</h2>
{_params_table(params_used) if params_used else _not_evaluated()}
"""


def section_large_signal_results(summary: Dict, extra_rows: Optional[Dict] = None) -> str:
    rows = dict(summary)
    if extra_rows:
        rows.update(extra_rows)
    rows_html = "".join(f"<tr><td>{_esc(k)}</td><td class='num'>{_fmt(v)}</td></tr>" for k, v in rows.items())
    return f"""
<h2>4. Large-Signal Results</h2>
<table class="ctable"><tbody>{rows_html}</tbody></table>
"""


def section_time_domain_plots(plot_data_uris: List[Tuple[str, str]]) -> str:
    if not plot_data_uris:
        return f"<h2>5. Time-Domain Plots</h2>{_not_evaluated()}"
    imgs = "".join(f"<h3>{_esc(title)}</h3><img class='plot' src='{uri}'/>" for title, uri in plot_data_uris)
    return f"<h2>5. Time-Domain Plots</h2>{imgs}"


def section_ims_assessment(small_signal_note: str, large_signal_note: str) -> str:
    return f"""
<h2>6. IMS / Large-Signal Assessment</h2>
<table class="ctable">
<tr><td>Conventional (small-signal)</td><td>{_esc(small_signal_note)}</td></tr>
<tr><td>Large-signal / recoverability</td><td>{_esc(large_signal_note)}</td></tr>
</table>
<p class="note">This platform's recoverability criterion characterizes whether a specific simulated
disturbance stays within (or returns to) an admissible operating region -- it does not claim to predict
collapse in general, nor that small-signal stability implies or fails to imply any particular large-signal
outcome beyond the specific case simulated here.</p>
"""


def section_counterfactual(counterfactual: Optional[Dict]) -> str:
    if not counterfactual:
        return f"<h2>7. Counterfactual Comparison</h2>{_not_evaluated()}"
    rows = "".join(
        f"<tr><td>{_esc(r['metric'])}</td><td class='num'>{_esc(r['baseline'])}</td>"
        f"<td class='num'>{_esc(r.get('dynamic_q', r.get('intervention','')))}</td></tr>"
        for r in counterfactual["comparison_table"]
    )
    return f"""
<h2>7. Counterfactual Comparison</h2>
<p>{_esc(counterfactual.get('note',''))}</p>
<table class="ctable">
<tr><th>Metric</th><th>Baseline</th><th>Intervention</th></tr>
{rows}
</table>
"""


def section_boundary(boundary_plot_uri: Optional[str], recommendations: Optional[Dict]) -> str:
    parts = ["<h2>8. Boundary / Sensitivity Results</h2>"]
    parts.append(f"<img class='plot' src='{boundary_plot_uri}'/>" if boundary_plot_uri else _not_evaluated())
    if recommendations:
        rows = "".join(
            f"<tr><td>{_esc(s['label'])}</td><td>{_esc(s['value_label'])}</td>"
            f"<td>{'achievable' if s['achievable'] else 'not achievable within tested range'}</td></tr>"
            for s in recommendations["strategies"]
        )
        parts.append(f"""<h3>Intervention search</h3>
<table class="ctable"><tr><th>Strategy</th><th>Result</th><th>Status</th></tr>{rows}</table>
<p class="note">{_esc(recommendations.get('note',''))}</p>""")
    return "\n".join(parts)


def section_limitations(disclaimer: str, extra: Optional[str] = None) -> str:
    return f"""
<h2>9. Scientific Limitations and Applicability</h2>
<div class="disclaimer">{_esc(disclaimer)}</div>
{f"<p class='note'>{_esc(extra)}</p>" if extra else ""}
<p class="note">Conclusions apply to the implemented reduced-order model and the tested parameter range
only; they are not a claim about any real physical system beyond the mechanism class this model is
inspired by.</p>
"""


def section_reproducibility(case_id: str, params_used: Dict) -> str:
    generated_at = datetime.datetime.now().isoformat()
    return f"""
<h2>10. Reproducibility</h2>
<table class="ctable">
<tr><td>Case ID</td><td class="num">{_esc(case_id)}</td></tr>
<tr><td>Analysis timestamp</td><td class="num">{_esc(generated_at)}</td></tr>
<tr><td>Platform version</td><td class="num">{_esc(PLATFORM_VERSION)}</td></tr>
</table>
<h3>Exact parameter set</h3>
{_params_table(params_used)}
"""


# ---------------------------------------------------------------------
# PDF export (same HTML, rendered by wkhtmltopdf via pdfkit)
# ---------------------------------------------------------------------

def html_to_pdf_bytes(html_str: str) -> bytes:
    import pdfkit
    options = {
        "quiet": "",
        "enable-local-file-access": None,
        "print-media-type": None,
        "margin-top": "14mm", "margin-bottom": "14mm", "margin-left": "12mm", "margin-right": "12mm",
    }
    return pdfkit.from_string(html_str, False, options=options)


# ---------------------------------------------------------------------
# Case-specific report builders. Each takes the REAL result dict(s)
# already returned by that case's own backend function(s) -- the same
# objects the API/UI already serve -- and assembles them into the
# generic section shell above. No value here is computed independently
# of those dicts.
# ---------------------------------------------------------------------

def build_iberian_report(result: Dict, counterfactual: Optional[Dict] = None,
                          boundary: Optional[Dict] = None, recommendations: Optional[Dict] = None) -> str:
    if not result.get("baseline_ok"):
        sections = [
            section_executive_summary("NON-RECOVERABLE", {"Status": "No stable baseline"}, result.get("disclaimer", "")),
            f"<p>{_esc(result.get('message',''))}</p>",
        ]
        return document_shell("Iberian 2025-Inspired Overvoltage Cascade", "Analysis could not be completed",
                               "iberian_2025_overvoltage_cascade", sections)

    s = result["summary"]
    verdict = s["verdict"]
    t = result["trajectory"]["t"]
    bus_labels = {"v_es_c": "Central Spain", "v_es_sw": "SW renewable cluster", "v_pt": "Portugal", "v_emb": "Embedded zone"}
    series = {bus_labels.get(k, k): v for k, v in result["voltage_traces"].items()}
    volt_uri = plot_time_series(t, series, "time (s)", "voltage (p.u.)", "Bus voltage response",
                                 hlines=[(result["v_trip"], "Overvoltage trip threshold", "#FF6B6B")],
                                 vlines=[(e["t"], "#FFB454") for e in result.get("event_timeline", [])])
    ind_uri = plot_time_series(t, {"Protection indicator": result["trip_timer_trace"]}, "time (s)",
                                "indicator (0-1)", "Overvoltage-protection indicator (0=clear, 1=tripped)",
                                hlines=[(0.5, "trip threshold (indicator)", "#FFB454")])

    boundary_uri = None
    if boundary and boundary.get("points"):
        pts = [p for p in boundary["points"] if p.get("verdict")]
        if pts:
            boundary_uri = plot_bar_verdicts([p["severity"] for p in pts], [p["verdict"] for p in pts],
                                              "Disturbance severity (\u00d7 documented magnitude)",
                                              "Recoverability vs. disturbance severity")

    disturbance_text = " | ".join(e["label"] for e in result.get("event_timeline", []))
    sections = [
        section_executive_summary(verdict, {
            "Peak voltage (p.u.)": _fmt(s["max_v_es_sw"]), "Settled voltage (p.u.)": _fmt(s["final_v_es_sw"]),
            "Voltage margin (p.u.)": _fmt(s["min_voltage_margin"]),
            "Protection indicator (final)": _fmt(s["final_trip_timer"]),
        }, result["disclaimer"]),
        section_scenario_definition(
            "Reduced-order 5-bus network inspired by the mechanism class described in ENTSO-E's report on "
            "the 28 April 2025 Iberian Peninsula event (insufficient dynamic voltage support, current "
            "limiting, delayed overvoltage protection, cascading disconnection).",
            None, disturbance_text),
        section_system_configuration(result["params_used"]),
        section_large_signal_results({k: v for k, v in s.items() if k not in ("small_signal_stable_throughout_note", "criterion_note")}),
        section_time_domain_plots([("Bus voltage response", volt_uri), ("Overvoltage-protection indicator", ind_uri)]),
        section_ims_assessment(s["small_signal_stable_throughout_note"],
                                f"Large-signal verdict: {verdict}. " + s["criterion_note"] if "criterion_note" in s else
                                f"Large-signal verdict: {verdict}."),
        section_counterfactual(counterfactual),
        section_boundary(boundary_uri, recommendations),
        section_limitations(result["disclaimer"]),
        section_reproducibility("iberian_2025_overvoltage_cascade", result["params_used"]),
    ]
    return document_shell("Iberian 2025-Inspired Overvoltage Cascade", "Overvoltage Cascade Analysis Report",
                           "iberian_2025_overvoltage_cascade", sections)


def build_gfm_report(result: Dict, sweep: Optional[Dict] = None) -> str:
    if not result.get("baseline_ok"):
        sections = [section_executive_summary("NON-RECOVERABLE", {"Status": "No stable baseline"},
                                                result.get("disclaimer", "")),
                    f"<p>{_esc(result.get('message',''))}</p>"]
        return document_shell("GFM Current-Limit Recovery", "Analysis could not be completed",
                               "gfm_current_limit_recovery", sections)

    s = result["summary"]
    verdict = s["verdict"]
    t = result["trajectory"]["t"]
    volt_uri = plot_time_series(t, {"v_poc": result["voltage_trace"]}, "time (s)", "voltage (p.u.)",
                                 "Point-of-connection voltage response",
                                 hlines=[(result["v_critical"], "Critical (non-recoverable) threshold", "#FF6B6B"),
                                         (result["v_at_risk"], "At-risk threshold", "#FFB454")],
                                 vlines=[(result["fault_definition"]["t_fault"], "#FFB454"),
                                         (result["fault_definition"]["t_clear"], "#FFB454")])
    sweep_uri = None
    if sweep and sweep.get("points"):
        pts = [p for p in sweep["points"] if p.get("verdict")]
        if pts:
            sweep_uri = plot_bar_verdicts([p["Imax"] for p in pts], [p["verdict"] for p in pts],
                                           "Converter current limit (Imax, p.u.)",
                                           "Recoverability vs. current limit")

    fd = result["fault_definition"]
    sections = [
        section_executive_summary(verdict, {
            "Min voltage during fault (p.u.)": _fmt(s["min_v_poc"]), "Time of minimum (s)": _fmt(s["t_min_v"]),
            "Settled voltage (p.u.)": _fmt(s["final_v_poc"]),
        }, result["disclaimer"]),
        section_scenario_definition(
            "Standalone single-converter network: a grid-forming (GFM) converter -- a Thevenin voltage "
            "source behind a fixed internal reactance, with its own current limit -- at the point of "
            "common coupling of a weak grid.", None, fd["description"]),
        section_system_configuration(result["params_used"]),
        section_large_signal_results({k: v for k, v in s.items() if k != "criterion_note"}),
        section_time_domain_plots([("Point-of-connection voltage response", volt_uri)]),
        section_ims_assessment(
            f"Pre-fault operating point is small-signal stable (max Re(eig)={_fmt(result['baseline']['max_eigenvalue_real_part'])}).",
            f"Large-signal verdict: {verdict}. {s['criterion_note']}"),
        section_counterfactual(None),
        section_boundary(sweep_uri, None),
        section_limitations(result["disclaimer"],
                             "This case's recoverability criterion is a fault-ride-through (FRT) depth "
                             "criterion, distinct from an endogenous stable/unstable equilibrium bifurcation."),
        section_reproducibility("gfm_current_limit_recovery", result["params_used"]),
    ]
    return document_shell("GFM Current-Limit Recovery", "Fault-Ride-Through Analysis Report",
                           "gfm_current_limit_recovery", sections)


def build_multiconverter_report(result: Dict, asymmetry: Optional[Dict] = None) -> str:
    if not result.get("baseline_ok"):
        sections = [section_executive_summary("NON-RECOVERABLE", {"Status": "No stable baseline"},
                                                result.get("disclaimer", "")),
                    f"<p>{_esc(result.get('message',''))}</p>"]
        return document_shell("Multi-Converter Fault Recovery", "Analysis could not be completed",
                               "multi_converter_fault_recovery", sections)

    s = result["summary"]
    verdict = s["verdict"]
    t = result["trajectory"]["t"]
    volt_uri = plot_time_series(t, {"v_busA (GFM anchor)": result["voltage_traces"]["v_busA"],
                                     "v_busB (GFL follower)": result["voltage_traces"]["v_busB"]},
                                 "time (s)", "voltage (p.u.)", "Bus voltage response (both converters)",
                                 hlines=[(result["v_critical"], "Critical threshold", "#FF6B6B"),
                                         (result["v_at_risk"], "At-risk threshold", "#FFB454")],
                                 vlines=[(result["fault_definition"]["t_fault"], "#FFB454"),
                                         (result["fault_definition"]["t_clear"], "#FFB454")])

    fd = result["fault_definition"]
    asym_html = ""
    if asymmetry:
        rows = "".join(
            f"<tr><td>{_esc(label)}</td><td class='num'>{_fmt(asymmetry[key]['summary']['worst_min_v'])}</td>"
            f"<td>{_esc(asymmetry[key]['summary']['verdict'])}</td></tr>"
            for label, key in [("GFM (anchor) support only", "gfm_only"), ("GFL (follower) support only", "gfl_only"),
                                ("Both", "both")]
        )
        asym_html = f"""<h3>Local vs. remote support (asymmetry check)</h3>
<table class="ctable"><tr><th>Configuration</th><th>Worst voltage dip (p.u.)</th><th>Verdict</th></tr>{rows}</table>
<p class="note">Local (follower) support at the faulted bus is necessary and sufficient on its own; remote
(anchor) current headroom alone is not, even at its maximum tested value.</p>"""

    sections = [
        section_executive_summary(verdict, {
            "Min voltage, busA (p.u.)": _fmt(s["min_v_busA"]), "Min voltage, busB (p.u.)": _fmt(s["min_v_busB"]),
            "Limiting bus": s["limiting_bus"],
        }, result["disclaimer"]),
        section_scenario_definition(
            "Two genuinely interacting converters sharing a network: a grid-forming (GFM) anchor at busA and "
            "a grid-following (GFL) converter at busB, coupled through the network and subjected to a common "
            "local fault at busB.", None, fd["description"]),
        section_system_configuration(result["params_used"]),
        section_large_signal_results({k: v for k, v in s.items() if k != "criterion_note"}),
        section_time_domain_plots([("Bus voltage response (both converters)", volt_uri)]),
        section_ims_assessment(
            f"Pre-fault operating point is small-signal stable (max Re(eig)={_fmt(result['baseline']['max_eigenvalue_real_part'])}).",
            f"Large-signal verdict: {verdict}. {s['criterion_note']}"),
        section_counterfactual(None),
        "<h2>8. Multi-Converter Interaction</h2>" + (asym_html if asym_html else _not_evaluated()),
        section_limitations(result["disclaimer"],
                             "Recoverability here is an FRT-depth criterion against the worse of the two "
                             "buses' voltage dips, not an endogenous bifurcation."),
        section_reproducibility("multi_converter_fault_recovery", result["params_used"]),
    ]
    return document_shell("Multi-Converter Fault Recovery", "Coordinated Fault-Ride-Through Analysis Report",
                           "multi_converter_fault_recovery", sections)
